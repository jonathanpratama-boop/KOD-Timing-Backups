# KOD clock erratum and review clarifications — 4 November 2026

Recorded from a live check at 19:44 WIB, before the first 20:00 scheduled slot. Source, plan, scheduler and original evidence have not been changed by this review.

## Confirmed clock-reporting defect

At source dbb27ea5c6a16c5b37c6f94b938a1509c2a9148e, runtime/timing.py reads chronyc CSV index 3 instead of index 4. Runtime/timing_evidence.py repeats the same mistake, so a coordinated correction is required. The synthetic test CSV omitted the reference-address column and masked the defect.

The retained commissioning raw CSV is:
334FA8DC,51.79.168.220,3,1793795343.592268319,0.002434953,-0.001220258,0.004042143,-100.449,-0.144,5.471,0.003564034,0.012801948,65.0,Normal

Its stored offset_seconds is 1793795343.592268319. This is the reference-update Unix timestamp. The system correction estimate is +0.002434953 seconds, from zero-based index 4. This estimate is not proof of absolute clock accuracy; chrony's root delay and dispersion also matter.

Raw evidence ID: clock_44499b11c6b067fc2239684750462ec5b9140169be0e71a34c4b56c6fda019c0.
Commissioning attempt: attempt_961e650bb6504be698974b104301dd7b.

The defect is in descriptive telemetry. It does not set the system clock, reschedule jobs, change raw market data, or grant entry permission. Existing offset_seconds values from this producer must not be interpreted as valid clock estimates. The preserved raw CSV permits a separately versioned derived correction.

Future source correction must fix both producer and verifier and use a realistic 14-column fixture, malformed-input tests, and explicit compatibility/version handling. Do not simply change the verifier then declare unchanged legacy records corrupt. Do not rewrite original records or silently replace the frozen deployment during the cohort.

## Other review findings

- Two plan digests hash different representations: raw file bytes bffe919924e56a48d49e92045f86e3ee4678ac5ae03aad8287ae8d6e6af6af6b, and sorted JSON contents 693394f0efffc485a0892a4b5b2115454a858ff0d50ff6daeaff7717c7e2cbb9. Same plan; ambiguous naming is a reporting defect.
- Expected BLOCKED/PARTIAL captures do not automatically halt collection. Unexpected exceptions and integrity failures create HALTED.json. While halted, later slots remain DUE_UNRECORDED; they are not automatically marked MISSED. No automatic notification exists.
- Initial package test failed because the PAPER_BOOK protocol fixture was omitted. Original bytes were added; all 317 focused tests then passed unchanged. The initial failure log is retained in the bundle.
- The audit bundle DOES contain the original real-capture folder and the restored folder. Independent SHA-256 comparison of archive members found 37 original and 37 restored files, all identical.
- Ongoing backups remain on the same server. The commissioning bundle is copied off-server. This is a real availability risk, not automatic disaster recovery.
- Host clock measurement, collector-level clock provenance, and independent RFC3161 time anchoring have different scopes. Their status labels must not be treated as directly equivalent.

## Current operating state

At 19:44 WIB the timer was active, the service's most recent result was success, HALTED.json was absent, and all 30 future slots were pending. The first is scheduled for 20:00 WIB today. This snapshot is not proof of future successful observations.
