# KOD cloud handoff — 4 November 2026

Deployment is installed and armed on 159.65.2.145 (DigitalOcean Singapore, Ubuntu 24.04, 1 GB).
The Mac can be off. No credentials, private keys, broker access or paid AI service are installed on the server.

## What is running

A thirty-slot operational collection diagnostic. First slot: 4 November 2026 20:00 WIB (13:00 UTC).
Every four hours thereafter: 00:00, 04:00, 08:00, 12:00, 16:00, 20:00 WIB.
Last slot: 9 November 2026 16:00 WIB (09:00 UTC). There is no 31st collection slot; server billing continues until the server is deleted.

Each slot requests BTCUSDT and ETHUSDT, the most recent 60 completed one-minute bars, metadata, bid/ask and order-book snapshots (up to 100 levels per side). This is a sparse operational sample, not continuous minute coverage or whole-market surveillance.
No detector, forecasts, paper-account strategy, broker orders or early-entry profitability test are enabled by this schedule. INFO_MAGNET and existing GitHub daily jobs were not migrated or altered.

## Version and deployment scope

Source commit: dbb27ea5c6a16c5b37c6f94b938a1509c2a9148e.
Source: /opt/kod/current (root-owned sparse export, 527 original files checked against Git blob identity and SHA-256; full repository history and historical research data are not bundled).
Manifest: /opt/kod/current/SOURCE_MANIFEST.json.
Python: /opt/kod/venv; exact installed packages: /var/lib/kod/commissioning/installed-packages.txt.
The deployment-specific scheduler is an additional wrapper; it is not a change to frozen strategy code or a claim that the wrapper was committed to GitHub.

## Checks completed

- The exact source commit's GitHub run 41819277462 is successful; this is separate from host validation.
- Host-focused release gate: 293 runtime/core tests + 10 operational-page tests + 14 timing-page tests = 317 passed, plus synthetic restart/idempotency and backup/restore checks.
- Eight deployment scheduler tests passed locally and on Linux: future slots, duplicate prevention, BLOCKED classification, outage/missed slots, interrupted attempts, integrity halt, thirty-slot limit, invalid profiles.
- One real commissioning capture completed for both symbols; all 19 linked evidence checks passed. Its nine timing identities include eight source-request records; these are not nine independent investment decisions.
- Real-data backup restored to a separate directory, all 37 files byte-identical; restored timing verification passed.
- pip check passed. Chrony synchronized (Normal); actual clock evidence is retained. These local receipts do not establish independent RFC3161 timestamp proof.
- The production systemd service was started once before the first slot and exited successfully without collecting early. Timer enabled; next slot verified as 13:00 UTC, 4 November. No scheduled cohort observation had occurred at the deployment snapshot.
- KOD runs as unprivileged `kod`; service cannot modify source or system configuration. Firewall exposes SSH only. No dashboard is published on the internet.

## How Claude can inspect

Use the owner's existing Mac SSH access, if the Claude environment has access to it. Do not request or upload the private key. A cloud-only Claude environment might lack SSH access; in that case inspect the attached audit bundle and report the access limitation.

Connect: `ssh root@159.65.2.145`
Compact status: `kod-status`
Timer: `systemctl list-timers kod-observe.timer --all`
Configuration: `systemctl cat kod-observe.service kod-observe.timer`
Logs: `journalctl -u kod-observe.service --no-pager`
Frozen schedule: `/etc/kod/observation-plan.json`
Deployment receipt: `/etc/kod/DEPLOYMENT.json`
Scheduler: `/opt/kod/bin/observe.py`
Scheduler tests: `/opt/kod/test_observe.py`
Source verification: `/opt/kod/venv/bin/python /opt/kod/bin/check-source.py`
Full timing verification: `/opt/kod/venv/bin/python /opt/kod/current/tools/kod.py runtime --root /var/lib/kod/timing-forward timing-status`

Data: /var/lib/kod/timing-forward
Per-slot immutable begin/end/result/integrity receipts: /var/lib/kod/schedule/slot-NN
Commissioning evidence and logs: /var/lib/kod/commissioning (separate from the thirty-slot cohort)
Backups: /var/lib/kod/backups (same-server, after each processed invocation; not off-site disaster recovery).
An off-server commissioning copy is saved in the owner's Codex outputs. Ongoing cohort archives have no automatic off-server replication.

## Failure and stop behavior

Slots over ten minutes late are recorded MISSED, never filled with later data pretending to be historical observations. Failed, PARTIAL, BLOCKED, MISSED and INTERRUPTED slots count toward the thirty declared slots. A begun slot is never recollected automatically. Root-owned plan and source verification pin the observation profile; altered source prevents service execution.
Runtime errors or integrity failures retain a FAILED slot and HALTED.json; later collection requires operator review. Do not delete ledger entries, restart a new cohort to hide failures, or reset counts. Backup failure produces a failed service result visible in systemd. There is no email or push-alert integration; Claude must inspect status, including failed-service and halted indicators.

To pause future collections: `systemctl disable --now kod-observe.timer`.
To stop an already-running invocation as well: `systemctl stop kod-observe.service` (may leave an explicitly interrupted attempt).
Read before changing anything. Preserve the current source, plan, evidence and receipts. Any correction should be versioned and tested.

## Independent review requested

Verify actual service state and files rather than accepting this note as proof. Check cohort denominators, slot times, request versus investment-decision counts, backup coverage and missed/blocked handling. Confirm the experiment is described as operational diagnosis only. A price forecast or profitability claim requires a separately frozen, owner-relevant economic test.
