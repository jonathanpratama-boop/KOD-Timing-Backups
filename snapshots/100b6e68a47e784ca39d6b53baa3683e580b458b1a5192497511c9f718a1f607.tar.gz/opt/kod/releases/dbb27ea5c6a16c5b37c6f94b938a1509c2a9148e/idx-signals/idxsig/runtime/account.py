"""Versioned offline shared-cash BTC/ETH paper account.

Derived from reviewed TREND_CORE v2 at repository commit 9bf18a7; originals in
vendor/reviewed_trend are byte-for-byte preserved. The profile seams add explicit
synthetic/public-market identities, recorded-source lineage and instrument filters.
No network, credentials, real orders or historical-open fills exist in this module.
The 25% portfolio / 90-return kill is the trend contract, not a per-trade 5% stop.

Public API: PaperAccount(directory, profile), observe(quote_event),
decide(signal_date, bars_by_symbol, decision_at), snapshot(at), mark(at), verify().
Mapping schema and validation live in _validate_profile / _quote / _bars below.
All fills are simulated. Top-of-book size is an explicit availability assumption;
receipt time is local observation time, never invented exchange publication time.
"""
from __future__ import annotations

import copy
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_FLOOR
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / "vendor/reviewed_trend/vendor/paper_cash_accounting.py"
VENDOR_HASH = "29688797f6738e4aa02ca87403a5a90d60dec0bca54cffab36a4a4a7e266f8a6"
if hashlib.sha256(VENDOR.read_bytes()).hexdigest() != VENDOR_HASH:
    raise ValueError("reviewed accounting source hash mismatch")
_spec = importlib.util.spec_from_file_location("reviewed_paper_cash", VENDOR)
_core = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_core)
D = Decimal
SYMBOLS = ("BTCUSDT", "ETHUSDT")
VERSION = "KOD_TREND_ACCOUNT_RUNTIME_V1"


def wire(x):
    if isinstance(x, Decimal):
        return str(x)
    if isinstance(x, dict):
        return {k: wire(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)):
        return [wire(v) for v in x]
    return x


def canonical(x):
    return json.dumps(wire(x), sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha(x):
    return hashlib.sha256(canonical(x).encode()).hexdigest()


def _strict_json(raw):
    def unique(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"duplicate journal key: {key}")
            result[key] = value
        return result
    def reject(value):
        raise ValueError(f"nonfinite journal number: {value}")
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject)


def number(x, *, minimum=D(0), positive=False):
    if isinstance(x, bool) or not isinstance(x, (str, int, float, Decimal)):
        raise ValueError("finite numeric input required")
    n = D(str(x))
    if not n.is_finite() or n < minimum or (positive and n <= 0):
        raise ValueError("invalid numeric input")
    return n


def utc(s):
    t = datetime.fromisoformat(s.replace("Z", "+00:00"))
    if t.tzinfo is None or t.utcoffset() is None:
        raise ValueError("timezone-aware timestamp required")
    return t.astimezone(timezone.utc)


def stamp(t):
    return t.isoformat().replace("+00:00", "Z")


def bundle_pins():
    paths = ["account.py", "vendor/reviewed_trend/paper_candidate.py",
             "vendor/reviewed_trend/PAPER_PROTOCOL_v2_CANDIDATE.md",
             "vendor/reviewed_trend/PROTOCOL_ADDENDUM_1.md",
             "vendor/reviewed_trend/vendor/paper_cash_accounting.py",
             "vendor/reviewed_trend/PROVENANCE.json"]
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}


def scenario_record(s):
    required = {"id", "fee", "slippage", "precision", "quote_max_age_seconds",
                "intent_life_seconds", "daily_grace_seconds"}
    if set(s) != required or not isinstance(s["id"], str) or not s["id"]:
        raise ValueError("explicit versioned scenario fields required")
    for k in ("fee", "slippage"):
        if number(s[k]) >= 1:
            raise ValueError("scenario cost must be below one")
    for k in ("precision", "quote_max_age_seconds", "intent_life_seconds", "daily_grace_seconds"):
        if isinstance(s[k], bool) or not isinstance(s[k], int) or s[k] < 0:
            raise ValueError("nonnegative integer scenario field required")
    if s["precision"] > 12 or not 0 < s["quote_max_age_seconds"] <= 120 or not 0 < s["intent_life_seconds"] <= 3600 or s["daily_grace_seconds"] > 300:
        raise ValueError("unsupported candidate timing/precision")
    return wire(s)


def evidence(payload, received_at):
    """Fixture helper; this creates a local hash, NOT an external time receipt."""
    return {"kind": "synthetic", "payload": wire(payload), "received_at": received_at,
            "payload_sha256": sha(payload)}


def unpack(e, at):
    if set(e) != {"kind", "payload", "received_at", "payload_sha256"} or e["kind"] not in ("synthetic", "public_market"):
        raise ValueError("explicit supported evidence type required")
    if sha(e["payload"]) != e["payload_sha256"] or utc(e["received_at"]) > utc(at):
        raise ValueError("evidence hash mismatch or future receipt")
    return copy.deepcopy(e["payload"])


def fresh_quote(st, symbol, at):
    e = st["quotes"].get(symbol)
    if not e:
        return None
    q = e["payload"]
    age = (utc(at) - utc(q["observed_at"])).total_seconds()
    if not 0 <= age <= st["scenario"]["quote_max_age_seconds"] or utc(e["received_at"]) > utc(at):
        return None
    return q


def account_view(st, at):
    cash = st["cash_total"]
    reserved = sum((o.get("reserved", D(0)) for o in st["intents"] if o["status"] == "PENDING"), D(0))
    if cash < 0 or reserved < 0 or reserved > cash:
        raise ValueError("cash reservation invariant broken")
    missing, values = [], {}
    for symbol, qty in st["holdings"].items():
        if qty < 0:
            raise ValueError("short position forbidden")
        if not qty:
            values[symbol] = D(0)
            continue
        q = fresh_quote(st, symbol, at)
        if q is None:
            missing.append(symbol)
        else:
            values[symbol] = qty * number(q["bid"], positive=True)
    gross = None if missing else sum(values.values(), D(0))
    nav = None if gross is None else cash + gross
    exposure = None if nav is None or nav <= 0 else gross / nav
    if exposure is not None and exposure > 1:
        raise ValueError("gross exposure exceeds equity")
    return {"cash_total": cash, "cash_reserved": reserved, "cash_available": cash - reserved,
            "holdings": copy.deepcopy(st["holdings"]), "nav": nav, "gross_value": gross,
            "gross_fraction": exposure, "missing_marks": missing, "nav_basis": "fresh_bid_indicative"}


def cancel_pending(st, reason):
    for o in st["intents"]:
        if o["status"] == "PENDING":
            o.update(status="CANCELLED", reserved=D(0), cancellation_reason=reason)


def reserve(st):
    pending = [o for o in st["intents"] if o["status"] == "PENDING" and o["side"] == "BUY"]
    total = sum((o["budget"] for o in pending), D(0))
    alloc = min(st["cash_total"], total)
    left = alloc
    for i, o in enumerate(pending):
        amount = left if i == len(pending) - 1 else (alloc * o["budget"] / total if total else D(0))
        o["reserved"] = amount
        left -= amount


def liquidations(st, at, trigger):
    for symbol, qty in st["holdings"].items():
        exists = any(o["symbol"] == symbol and o["status"] == "PENDING" for o in st["intents"])
        if qty and not exists:
            st["intents"].append({"id": f"liquidate:{trigger}:{symbol}", "symbol": symbol,
                "side": "SELL", "quantity": qty, "reserved": D(0), "status": "PENDING",
                "made_at": at, "expires_at": stamp(utc(at) + timedelta(seconds=st["scenario"]["intent_life_seconds"])),
                "reason": "PERSISTENT_KILL"})


def kill(st, at, reason, trigger):
    if st["kill"] is None:
        st["kill"] = {"at": at, "reason": reason, "trigger": trigger}
        cancel_pending(st, "KILLED")
        liquidations(st, at, trigger)


def risk(st, at, trigger):
    v = account_view(st, at)
    if v["nav"] is not None:
        st["peak"] = max(st["peak"], v["nav"])
        dd = (st["peak"] - v["nav"]) / st["peak"]
        st["maximum_observed_drawdown"] = max(st["maximum_observed_drawdown"], dd)
        if dd >= D(".25"):
            kill(st, at, "DRAWDOWN_AT_LEAST_25_PERCENT", trigger)
    return v


def expire(st, at):
    for o in st["intents"]:
        if o["status"] == "PENDING" and utc(at) >= utc(o["expires_at"]):
            o.update(status="EXPIRED", reserved=D(0))
    reserve(st)


def signals(e, signal_date, at):
    p = unpack(e, at)
    if set(p) != set(SYMBOLS):
        raise ValueError("both specified spot instruments required")
    end = date.fromisoformat(signal_date)
    if utc(at) < datetime.combine(end + timedelta(days=1), datetime.min.time(), timezone.utc):
        raise ValueError("signal day not complete")
    raw, metrics = {}, {}
    for symbol in SYMBOLS:
        bars = p[symbol]
        if len(bars) != 40:
            raise ValueError("exactly 40 clean consecutive closes required")
        closes = []
        for i, bar in enumerate(bars):
            expected = end - timedelta(days=39-i)
            if bar["day"] != expected.isoformat():
                raise ValueError("missing/duplicate/nonconsecutive day")
            close_at = datetime.combine(expected + timedelta(days=1), datetime.min.time(), timezone.utc)
            if not close_at <= utc(bar["received_at"]) <= utc(e["received_at"]) <= utc(at):
                raise ValueError("noncausal bar availability")
            if bar.get("published_at") is not None and not close_at <= utc(bar["published_at"]) <= utc(bar["received_at"]):
                raise ValueError("noncausal declared publication time")
            if bar["source_sha256"] != sha({"day": bar["day"], "close": bar["close"]}):
                raise ValueError("bar content hash mismatch")
            closes.append(float(number(bar["close"], positive=True)))
        sma10, sma40 = statistics.mean(closes[-10:]), statistics.mean(closes)
        logs = [math.log(closes[i]/closes[i-1]) for i in range(20,40)]
        sigma = statistics.stdev(logs)
        is_long = sma10 > sma40
        if is_long and (not math.isfinite(sigma) or sigma <= 0):
            raise ValueError("nonpositive volatility for long signal")
        raw[symbol] = D(str(min(1.0, .015/sigma))) if is_long else D(0)
        metrics[symbol] = {"sma10": sma10, "sma40": sma40, "sigma20": sigma, "long": is_long}
    total = sum(raw.values(), D(0))
    targets = {s: v / total if total > 1 else v for s, v in raw.items()}
    return raw, targets, metrics


def sharpe_status(samples):
    if len(samples) < 91:
        return {"status": "INSUFFICIENT_90_RETURNS", "value": None, "negative": False}
    window = samples[-91:]
    if any(x["nav"] is None for x in window) or any(date.fromisoformat(b["date"]) - date.fromisoformat(a["date"]) != timedelta(days=1) for a,b in zip(window,window[1:])):
        return {"status": "MISSING_DAILY_MARK", "value": None, "negative": False}
    if any(x["nav"] <= 0 for x in window):
        return {"status": "NONPOSITIVE_NAV", "value": None, "negative": False}
    returns = [float(b["nav"]/a["nav"]-1) for a,b in zip(window,window[1:])]
    mean, sd = statistics.mean(returns), statistics.stdev(returns)
    if sd == 0:
        label = "ZERO_MEAN_ZERO_VARIANCE" if mean == 0 else "NEGATIVE_INFINITY" if mean < 0 else "POSITIVE_INFINITY"
        return {"status": label, "value": None, "negative": mean < 0}
    value = mean/sd*math.sqrt(365)
    return {"status": "FINITE", "value": value, "negative": value < 0, "returns": 90}


def operation_id(c):
    op = c["op"]
    if op == "init": return "init:" + c["account_id"]
    if op == "observe": return "observe:" + sha(c["evidence"])
    if op == "decision": return "decision:" + c["signal_date"]
    if op in ("daily", "missed"): return op + ":" + c["date"]
    if op == "audit": return "audit:" + c["reference_sha256"]
    if op == "advance": return "advance:" + c["at"]
    raise ValueError("unsupported operation / no live adapter")


def initial(c):
    profile = _validate_profile(c["profile"])
    if c.get("mode") != "paper_only" or c.get("initial_cash") != profile["initial_cash"]:
        raise ValueError("explicit paper-only profile and matching research cash required")
    s = scenario_record(c["scenario"])
    if s != _scenario(profile):
        raise ValueError("scenario differs from profile")
    cash = number(c["initial_cash"], positive=True)
    utc(c["at"])
    st = {"version": VERSION, "account_id": c["account_id"], "profile": profile,
          "profile_sha256": sha(profile), "evidence_type": profile["evidence_type"],
          "simulation_only": True, "scenario": s,
          "scenario_sha256": sha(s), "pins": bundle_pins(), "cash_total": cash,
          "holdings": dict.fromkeys(SYMBOLS, D(0)), "quotes": {}, "intents": [],
          "peak": cash, "maximum_observed_drawdown": D(0), "kill": None,
          "daily": [], "clock": c["at"], "realized_fees": D(0), "fills": []}
    return st


def apply(st, c):
    op, at, oid = c["op"], c["at"], operation_id(c)
    if op == "init":
        if st is not None: raise ValueError("account already initialized")
        st = initial(c)
        return st, {"status": "INITIALIZED", "account": account_view(st, at)}
    if st is None: raise ValueError("init required")
    if utc(at) < utc(st["clock"]): raise ValueError("operation clock cannot move backwards")
    st = copy.deepcopy(st)
    st["clock"] = at
    expire(st, at)
    if st["kill"]: liquidations(st, at, oid)
    result = {}
    if op == "observe":
        e = c["evidence"]
        q = unpack(e, at)
        if e["kind"] != st["evidence_type"] or q.get("venue") != st["profile"]["venue"] or q.get("product") != "spot" or q.get("symbol") not in SYMBOLS:
            raise ValueError("cross-profile venue / product / evidence forbidden")
        _validate_instrument(st["profile"], q["symbol"], at)
        if q.get("profile_id") != st["profile"]["id"]:
            raise ValueError("quote bound to another profile")
        if not utc(q["observed_at"]) <= utc(e["received_at"]) <= utc(at):
            raise ValueError("quote received before observation or in future")
        bid, ask = number(q["bid"], positive=True), number(q["ask"], positive=True)
        if ask < bid: raise ValueError("crossed quote")
        for k in ("bid_qty", "ask_qty"):
            if q.get(k) is not None: number(q[k])
        previous = st["quotes"].get(q["symbol"])
        if previous and utc(q["observed_at"]) < utc(previous["payload"]["observed_at"]):
            raise ValueError("out-of-order quote")
        st["quotes"][q["symbol"]] = copy.deepcopy(e)
        # Observe risk BEFORE filling pending buys; kill never fills at triggering quote.
        risk(st, at, oid)
        result["fills"] = []
        result["blocked"] = []
        for o in sorted(st["intents"], key=lambda x: x["side"] == "BUY"):
            if o["status"] != "PENDING" or o["symbol"] != q["symbol"]:
                continue
            if st["evidence_type"] == "public_market" and q.get("source_time") is None and q.get("request_started_at") is None:
                result["blocked"].append({"intent": o["id"], "reason": "UNKNOWN_REQUEST_START"})
                continue
            if not utc(o["made_at"]) < utc(q["observed_at"]) <= utc(e["received_at"]) <= utc(at) < utc(o["expires_at"]) or fresh_quote(st, q["symbol"], at) is None or (q.get("request_started_at") is not None and utc(q["request_started_at"]) <= utc(o["made_at"])):
                result["blocked"].append({"intent": o["id"], "reason": "INELIGIBLE_TIME"})
                continue
            size = q.get("ask_qty" if o["side"] == "BUY" else "bid_qty")
            if size is None:
                result["blocked"].append({"intent": o["id"], "reason": "UNKNOWN_LIQUIDITY"})
                continue
            limit = number(size)
            precision = st["scenario"]["precision"]
            instrument = st["profile"]["instruments"][q["symbol"]]
            step = number(instrument["lot_step"], positive=True)
            fee, slip = st["scenario"]["fee"], st["scenario"]["slippage"]
            limit = min(limit, number(instrument.get("max_qty", limit)))
            px = _fill_price(ask if o["side"] == "BUY" else bid, o["side"], instrument, slip)
            if o["side"] == "BUY":
                if st["kill"]: raise ValueError("buy pending after kill")
                if any(x["status"] == "PENDING" and x["side"] == "SELL" for x in st["intents"]):
                    result["blocked"].append({"intent": o["id"], "reason": "WAITING_FOR_SELLS"})
                    continue
                if account_view(st, at)["nav"] is None:
                    result["blocked"].append({"intent": o["id"], "reason": "UNKNOWN_AGGREGATE_NAV_AT_FILL"})
                    continue
                reserve(st)
                if o["reserved"] == 0:
                    result["blocked"].append({"intent": o["id"], "reason": "WAITING_FOR_ACTUAL_CASH"})
                    continue
                sized = _core.buy_size(o["reserved"], px, fee, "0", precision)
                qty = _lot_floor(min(sized["units"], limit), step)
                qty = _notional_limit(qty, px, instrument, step)
                if not _venue_size_ok(qty, px, instrument):
                    o.update(status="IOC_CANCELLED", reserved=D(0), cancellation_reason="VENUE_SIZE_OR_NOTIONAL")
                    result["blocked"].append({"intent": o["id"], "reason": "VENUE_SIZE_OR_NOTIONAL"})
                    continue
                cost = _core.cash_round(qty*px*number(fee))
                debit = qty*px+cost
                st["cash_total"] -= debit
                st["holdings"][q["symbol"]] += qty
                cash_change = -debit
            else:
                qty = _lot_floor(min(o["quantity"], st["holdings"][q["symbol"]], limit), step)
                qty = _notional_limit(qty, px, instrument, step)
                if not _venue_size_ok(qty, px, instrument):
                    o.update(status="IOC_CANCELLED", reserved=D(0), cancellation_reason="VENUE_SIZE_OR_NOTIONAL")
                    result["blocked"].append({"intent": o["id"], "reason": "VENUE_SIZE_OR_NOTIONAL"})
                    continue
                liquid = _core.liquidation([qty], px, fee, "0")
                cost = liquid["commission"]
                cash_change = liquid["net"]
                st["cash_total"] += cash_change
                st["holdings"][q["symbol"]] -= qty
            o.update(status="IOC_COMPLETE", reserved=D(0), filled_quantity=qty,
                     fill_observation=oid, remainder_cancelled=True)
            if qty:
                fill = {"id": "fill:"+o["id"], "intent_id": o["id"], "side": o["side"],
                    "symbol": q["symbol"], "quantity": qty, "price": px, "fee": cost,
                    "cash_change": cash_change, "observation_id": oid,
                    "observed_at": q["observed_at"], "received_at": e["received_at"],
                    "fill_recorded_at": at, "available_quantity": limit,
                    "evidence": "synthetic_top_of_book_quantity_scenario" if st["evidence_type"] == "synthetic" else "recorded_top_of_book_simulated_fill",
                    "simulation_only": True, "profile_id": st["profile"]["id"],
                    "source_evidence_id": q.get("evidence_id"),
                    "source_time": q.get("source_time"), "source_time_basis": q.get("source_time_basis"),
                    "scenario_sha256": st["scenario_sha256"]}
                st["fills"].append(fill)
                result["fills"].append(fill)
                st["realized_fees"] += cost
            reserve(st)
            risk(st, at, oid)
        # Residual kill holdings receive a new intent, not an invented fill.
        if st["kill"]: liquidations(st, at, oid+":residual")
        result["status"] = "OBSERVED"
    elif op == "decision":
        if st["kill"]:
            result["status"] = "BLOCKED_PERSISTENT_KILL"
        else:
            if c["evidence"]["kind"] != st["evidence_type"]:
                raise ValueError("cross-profile bar evidence forbidden")
            for symbol in SYMBOLS:
                _validate_instrument(st["profile"], symbol, at)
            raw, targets, metrics = signals(c["evidence"], c["signal_date"], at)
            quotes = {s: fresh_quote(st, s, at) for s in SYMBOLS}
            view = risk(st, at, oid)
            if st["kill"]:
                result["status"] = "BLOCKED_PERSISTENT_KILL"
            elif view["nav"] is None or any(q is None for q in quotes.values()):
                result["status"] = "DECLINED_UNKNOWN_NAV_OR_QUOTE"
            else:
                cancel_pending(st, "SUPERSEDED_DECISION")
                for symbol in SYMBOLS:
                    current = st["holdings"][symbol] * number(quotes[symbol]["bid"], positive=True)
                    desired = targets[symbol] * view["nav"]
                    delta = desired - current
                    if delta == 0: continue
                    o = {"id": oid+":"+symbol, "symbol": symbol,
                         "side": "BUY" if delta > 0 else "SELL", "reserved": D(0),
                         "made_at": at, "expires_at": stamp(utc(at)+timedelta(seconds=st["scenario"]["intent_life_seconds"])),
                         "status": "PENDING", "decision_quote_sha256": st["quotes"][symbol]["payload_sha256"]}
                    if delta > 0: o["budget"] = delta
                    else: o["quantity"] = min(st["holdings"][symbol], -delta/number(quotes[symbol]["bid"], positive=True))
                    st["intents"].append(o)
                reserve(st)
                result.update(status="DECIDED", raw_targets=raw, normalized_targets=targets, signal_metrics=metrics)
    elif op == "daily":
        day = date.fromisoformat(c["date"])
        boundary = datetime.combine(day, datetime.min.time(), timezone.utc)
        lateness = (utc(at)-boundary).total_seconds()
        if lateness < 0: raise ValueError("future daily boundary")
        if st["daily"] and day <= date.fromisoformat(st["daily"][-1]["date"]):
            raise ValueError("daily marks must advance")
        v = risk(st, at, oid)
        nav = v["nav"] if lateness <= st["scenario"]["daily_grace_seconds"] else None
        sample = {"date": c["date"], "at": at, "nav": nav,
                  "status": "COMPLETE" if nav is not None else "MISSED_CUTOFF" if lateness > st["scenario"]["daily_grace_seconds"] else "UNKNOWN_MARKS",
                  "daily_return": None}
        if st["daily"] and nav is not None:
            prev = st["daily"][-1]
            if prev["nav"] is not None and prev["nav"] > 0 and day-date.fromisoformat(prev["date"]) == timedelta(days=1):
                sample["daily_return"] = nav/prev["nav"]-1
        st["daily"].append(sample)
        sh = sharpe_status(st["daily"])
        if sh["negative"]: kill(st, at, "NEGATIVE_TRAILING_90_DAY_SHARPE", oid)
        result.update(status=sample["status"], sample=sample, trailing_sharpe=sh)
    elif op == "missed":
        if date.fromisoformat(c["date"]) > utc(at).date(): raise ValueError("future missed cycle")
        result.update(status="MISSED_CYCLE", cycle_date=c["date"], reason=c["reason"], logged_at=at)
    elif op == "audit":
        if len(c["reference_sha256"]) != 64: raise ValueError("audit reference hash required")
        result.update(status="AUDIT_ONLY_NO_BALANCE_EFFECT", reference_sha256=c["reference_sha256"], details=c["details"])
    elif op == "advance":
        result["status"] = "ADVANCED_NO_SYNTHETIC_FILL"
    else:
        raise ValueError("unsupported operation")
    result.update(account=account_view(st, at), kill=st["kill"], peak=st["peak"],
                  maximum_observed_drawdown=st["maximum_observed_drawdown"])
    return st, result


class Ledger:
    """Single local journal. flock serializes whole replay/validate/append transaction.

    On partial writes, fail closed rather than truncate or invent successful events.
    The lock is advisory: every writer must use this API; external deployment unsupported.
    """
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _sync_directory(self):
        fd = os.open(self.path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)

    def _sync_existing(self):
        # A previous complete append may have failed its durability barrier.
        # An idempotent retry must establish that barrier, not merely find bytes.
        with open(self.path, "rb") as f:
            os.fsync(f.fileno())
        self._sync_directory()

    def _read(self):
        raw = self.path.read_bytes() if self.path.exists() else b""
        if raw and not raw.endswith(b"\n"): raise ValueError("torn journal tail; manual preservation/recovery required")
        rows = [_strict_json(line) for line in raw.splitlines()]
        _core.verify_chain(rows)
        st = None
        for row in rows:
            if row["provenance"] != bundle_pins(): raise ValueError("source/code/protocol pin mismatch")
            if row["input_sha256"] != sha(row["command"]): raise ValueError("input hash mismatch")
            if row["id"] != operation_id(row["command"]): raise ValueError("semantic operation id mismatch")
            st, result = apply(st, row["command"])
            if wire(result) != row["result"] or sha(st) != row["state_sha256"]:
                raise ValueError("deterministic replay mismatch")
        return rows, st

    def transact(self, command):
        command = json.loads(canonical(command))
        oid = operation_id(command)
        with open(str(self.path)+".lock", "a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            rows, st = self._read()
            for row in rows:
                if row["id"] == oid:
                    if row["command"] != command: raise ValueError("same economic operation id with conflicting payload")
                    self._sync_existing()
                    return copy.deepcopy(row["result"])
            st, result = apply(st, command)
            record = _core.append_event(rows, {"id": oid, "type": "PAPER_OPERATION",
                "command": command, "input_sha256": sha(command), "provenance": bundle_pins(),
                "result": wire(result), "state_sha256": sha(st)})
            with open(self.path, "ab", buffering=0) as f:
                raw = (canonical(record)+"\n").encode()
                view = memoryview(raw)
                while view:
                    written = f.write(view)
                    if not written: raise OSError("journal append incomplete")
                    view = view[written:]
                os.fsync(f.fileno())
            self._sync_directory()
            return wire(result)

    def state(self):
        with open(str(self.path)+".lock", "a") as lock:
            fcntl.flock(lock, fcntl.LOCK_SH)
            return self._read()[1]


# Profile adapter. Original signal, shared-cash allocation and persistence above
# are retained from the reviewed core; venue handling is a new versioned seam.
def _validate_profile(value):
    p = copy.deepcopy(value)
    required = {"id", "evidence_type", "venue", "quote_currency", "initial_cash",
                "fee_rate", "slippage", "max_quote_age", "expiry", "instruments"}
    if not isinstance(p, dict) or not required <= set(p):
        raise ValueError("complete explicit account profile required")
    if not isinstance(p["id"], str) or not p["id"]:
        raise ValueError("profile id required")
    expected = {"synthetic": "SYNTHETIC_SPOT", "public_market": "BINANCE_SPOT"}
    if expected.get(p["evidence_type"]) != p["venue"] or p["quote_currency"] != "USDT":
        raise ValueError("profile venue/currency/evidence mismatch")
    p["initial_cash"] = str(number(p["initial_cash"], positive=True))
    for key in ("fee_rate", "slippage"):
        p[key] = str(number(p[key]))
        if D(p[key]) >= 1:
            raise ValueError("invalid cost assumption")
    if isinstance(p["instruments"], list):
        symbols = [i["symbol"] for i in p["instruments"]]
        if len(symbols) != len(set(symbols)):
            raise ValueError("duplicate profile instrument")
        p["instruments"] = {i["symbol"]: i for i in p["instruments"]}
    if set(p["instruments"]) != set(SYMBOLS):
        raise ValueError("profile requires exactly BTCUSDT and ETHUSDT")
    for symbol, item in p["instruments"].items():
        required_meta = {"tick_size", "lot_step", "min_notional", "trading_status"}
        if not required_meta <= set(item):
            raise ValueError("missing venue instrument rules")
        if item.get("venue", p["venue"]) != p["venue"] or item.get("symbol", symbol) != symbol:
            raise ValueError("instrument identity mismatch")
        if item.get("quote_currency", "USDT") != "USDT":
            raise ValueError("instrument quote currency mismatch")
        for key in ("tick_size", "lot_step"):
            item[key] = str(number(item[key], positive=True))
        for key in ("min_notional", "min_qty", "max_qty", "max_notional"):
            if key in item:
                item[key] = str(number(item[key]))
        if "max_qty" in item and D(item["max_qty"]) < D(item.get("min_qty", "0")):
            raise ValueError("inverted quantity bounds")
        if "max_notional" in item and D(item["max_notional"]) < D(item["min_notional"]):
            raise ValueError("inverted notional bounds")
        if p["evidence_type"] == "public_market" and (not item.get("evidence_id") or not item.get("metadata_received_at")):
            raise ValueError("recorded metadata evidence and availability required")
        if item.get("metadata_received_at"):
            utc(item["metadata_received_at"])
    p.setdefault("daily_grace_seconds", 300)
    p.setdefault("precision", 12)
    # These are named simulation assumptions, not a representation of a real fee
    # asset, authenticated balance or guaranteed liquidatable size.
    p["fee_currency_assumption"] = "USDT"
    p["fee_rounding_assumption"] = "0.01 USDT half-up per fill"
    p["fill_model"] = "IOC at later observed top of book, quantity-capped, simulated"
    scenario_record(_scenario(p))
    return wire(p)


def _scenario(profile):
    return {"id": profile["id"], "fee": profile["fee_rate"], "slippage": profile["slippage"],
            "precision": profile.get("precision", 12), "quote_max_age_seconds": profile["max_quote_age"],
            "intent_life_seconds": profile["expiry"], "daily_grace_seconds": profile.get("daily_grace_seconds", 300)}


def _validate_instrument(profile, symbol, at):
    item = profile["instruments"][symbol]
    if item["trading_status"] != "TRADING":
        raise ValueError("instrument not trading")
    if item.get("metadata_received_at") and utc(item["metadata_received_at"]) > utc(at):
        raise ValueError("future instrument metadata")
    if item.get("valid_until") and utc(at) >= utc(item["valid_until"]):
        raise ValueError("expired instrument metadata")
    return item


def _lot_floor(quantity, step):
    return (quantity / step).to_integral_value(rounding=ROUND_FLOOR) * step


def _fill_price(price, side, instrument, slippage):
    from decimal import ROUND_CEILING
    tick = number(instrument["tick_size"], positive=True)
    adverse = price * (1 + number(slippage) if side == "BUY" else 1 - number(slippage))
    value = (adverse / tick).to_integral_value(rounding=ROUND_CEILING if side == "BUY" else ROUND_FLOOR) * tick
    return number(value, positive=True)


def _notional_limit(quantity, price, instrument, step):
    if "max_notional" in instrument:
        return min(quantity, _lot_floor(number(instrument["max_notional"]) / price, step))
    return quantity


def _venue_size_ok(quantity, price, instrument):
    return quantity > 0 and quantity >= number(instrument.get("min_qty", "0")) and quantity * price >= number(instrument["min_notional"])


def _evidence(kind, payload, received_at):
    return {"kind": kind, "payload": wire(payload), "received_at": received_at,
            "payload_sha256": sha(payload)}


def _quote(event, profile):
    q = copy.deepcopy(event)
    kind = q.get("evidence_type", q.get("evidence_kind"))
    if kind != profile["evidence_type"] or q.get("venue") != profile["venue"]:
        raise ValueError("quote evidence/venue does not match account profile")
    symbol = q["symbol"]
    if symbol not in SYMBOLS or not q.get("evidence_id") or not q.get("observation_id"):
        raise ValueError("quote identity and evidence references required")
    received = stamp(utc(q["received_at"]))
    at = stamp(utc(q.get("at", received)))
    if utc(received) > utc(at):
        raise ValueError("future quote receipt")
    item = _validate_instrument(profile, symbol, at)
    source_time = q.get("source_time")
    if source_time is not None:
        source_time = stamp(utc(source_time))
        if utc(source_time) > utc(received):
            raise ValueError("quote source timestamp after receipt")
    observed = source_time or received
    start = q.get("request_started_at")
    if start is not None and utc(start) > utc(received):
        raise ValueError("quote request started after receipt")
    bid, ask = number(q["bid"], positive=True), number(q["ask"], positive=True)
    if ask < bid:
        raise ValueError("crossed quote")
    tick = number(item["tick_size"], positive=True)
    if bid % tick or ask % tick:
        raise ValueError("quote price violates venue tick")
    payload = {"profile_id": profile["id"], "venue": profile["venue"], "product": "spot", "symbol": symbol,
               "bid": str(bid), "ask": str(ask), "bid_qty": q.get("bid_size"), "ask_qty": q.get("ask_size"),
               "observed_at": observed, "source_time": source_time,
               "source_time_basis": "PROVIDER" if source_time else "UNAVAILABLE_LOCAL_RECEIPT_OBSERVATION",
               "request_started_at": start, "evidence_id": q["evidence_id"], "observation_id": q["observation_id"]}
    for key in ("bid_qty", "ask_qty"):
        if payload[key] is not None:
            payload[key] = str(number(payload[key]))
    return _evidence(kind, payload, received), at


def _bars(bars_by_symbol, signal_date, at, profile):
    if set(bars_by_symbol) != set(SYMBOLS):
        raise ValueError("bars for both account instruments required")
    payload, receipts = {}, []
    end = date.fromisoformat(signal_date)
    for symbol, rows in bars_by_symbol.items():
        if len(rows) != 40:
            raise ValueError("exactly 40 daily bars required per account instrument")
        payload[symbol] = []
        for n, row in enumerate(rows):
            if row.get("evidence_type", row.get("evidence_kind")) != profile["evidence_type"]:
                raise ValueError("cross-profile bar evidence forbidden")
            if row.get("symbol", symbol) != symbol or row.get("venue", profile["venue"]) != profile["venue"]:
                raise ValueError("bar instrument identity mismatch")
            if not row.get("evidence_id"):
                raise ValueError("bar evidence reference required")
            opened, closed, received = utc(row["open_time"]), utc(row["close_time"]), utc(row["received_at"])
            expected = end - timedelta(days=39-n)
            boundary = datetime.combine(expected, datetime.min.time(), timezone.utc)
            day_end = boundary + timedelta(days=1)
            if opened != boundary or not day_end-timedelta(seconds=1) <= closed <= day_end or not day_end <= received <= utc(at):
                raise ValueError("daily bar incomplete, missing, out of order or unavailable")
            close = str(number(row["close"], positive=True))
            for key in ("open", "high", "low"):
                if key in row:
                    number(row[key], positive=True)
            if "high" in row and "low" in row and not number(row["low"]) <= number(close) <= number(row["high"]):
                raise ValueError("close outside daily range")
            normalized = {"day": expected.isoformat(), "close": close, "received_at": stamp(received),
                          "source_sha256": sha({"day": expected.isoformat(), "close": close}),
                          "source_evidence_id": row["evidence_id"], "source_open_time": row["open_time"],
                          "source_close_time": row["close_time"]}
            payload[symbol].append(normalized)
            receipts.append(received)
    return _evidence(profile["evidence_type"], payload, stamp(max(receipts)))


class PaperAccount:
    """One isolated, replayable paper account. Construction does not initialize cash.

    `observe` accepts root runtime's quote mapping plus explicit evidence_type.
    `decide` accepts exactly forty oldest-first completed bars per BTCUSDT/ETHUSDT,
    each with root runtime bar fields plus explicit evidence_type. `mark` advances
    the current clock and records a current NAV; `daily_mark` alone records a
    performance sample at the declared UTC boundary. Late samples remain unknown.
    `operation_id` may equal the canonical semantic ID; `run_id` is caller tracing
    only and does not alter economic identity. Same event retry returns original.
    """

    def __init__(self, directory, profile):
        self.profile = _validate_profile(profile)
        self.directory = Path(directory)
        self.ledger = Ledger(self.directory / "account.jsonl")
        st = self.ledger.state()
        if st is not None and st.get("profile_sha256") != sha(self.profile):
            raise ValueError("account already belongs to another profile")

    def _initialize(self, at):
        st = self.ledger.state()
        if st is None:
            # Concurrent initialization uses a caller-supplied profile epoch when
            # provided. Distinct clocks otherwise fail closed rather than race.
            epoch = self.profile.get("initialized_at", at)
            if utc(epoch) > utc(at):
                raise ValueError("future account initialization")
            self.ledger.transact({"op": "init", "at": epoch, "account_id": self.profile["id"],
                                  "mode": "paper_only", "profile": self.profile,
                                  "initial_cash": self.profile["initial_cash"], "scenario": _scenario(self.profile)})

    def observe(self, quote_event, *, operation_id=None, run_id=None):
        e, at = _quote(quote_event, self.profile)
        command = {"op": "observe", "at": at, "evidence": e}
        if operation_id is not None and operation_id != globals()["operation_id"](command):
            raise ValueError("observation operation id differs from semantic identity")
        self._initialize(at)
        return self.ledger.transact(command)

    def decide(self, signal_date, bars_by_symbol, decision_at, *, operation_id=None, run_id=None):
        at = stamp(utc(decision_at))
        if operation_id is not None and operation_id != "decision:" + signal_date:
            raise ValueError("decision operation id differs from semantic identity")
        e = _bars(bars_by_symbol, signal_date, at, self.profile)
        # Validate the full bar sequence before any account write.
        signals(e, signal_date, at)
        self._initialize(at)
        return self.ledger.transact({"op": "decision", "at": at, "signal_date": signal_date, "evidence": e})

    def snapshot(self, at):
        at = stamp(utc(at))
        st = self.ledger.state()
        if st is None:
            return {"status": "UNINITIALIZED", "profile_id": self.profile["id"],
                    "evidence_type": self.profile["evidence_type"], "simulation_only": True,
                    "account": None, "fills": []}
        if utc(at) < utc(st["clock"]):
            raise ValueError("snapshot cannot use future account state")
        return wire({"status": "KILLED" if st["kill"] else "ACTIVE", "profile_id": self.profile["id"],
                     "evidence_type": self.profile["evidence_type"], "simulation_only": True,
                     "account": account_view(st, at), "fills": st["fills"], "intents": st["intents"],
                     "kill": st["kill"], "daily": st["daily"], "profile_sha256": st["profile_sha256"],
                     "realized_fees": st["realized_fees"], "maximum_observed_drawdown": st["maximum_observed_drawdown"]})

    def mark(self, at):
        at = stamp(utc(at))
        if self.ledger.state() is None:
            return self.snapshot(at)
        return self.ledger.transact({"op": "advance", "at": at})

    def daily_mark(self, day, at):
        if self.ledger.state() is None:
            raise ValueError("daily mark requires initialized account")
        return self.ledger.transact({"op": "daily", "date": day, "at": stamp(utc(at))})

    def missed(self, day, at, reason):
        if self.ledger.state() is None:
            raise ValueError("missed record requires initialized account")
        return self.ledger.transact({"op": "missed", "date": day, "at": stamp(utc(at)), "reason": reason})

    def verify(self):
        st = self.ledger.state()
        if st is not None and st["profile_sha256"] != sha(self.profile):
            raise ValueError("profile hash mismatch")
        return {"ok": True, "initialized": st is not None, "profile_id": self.profile["id"],
                "fills": len(st["fills"]) if st else 0, "simulation_only": True}
