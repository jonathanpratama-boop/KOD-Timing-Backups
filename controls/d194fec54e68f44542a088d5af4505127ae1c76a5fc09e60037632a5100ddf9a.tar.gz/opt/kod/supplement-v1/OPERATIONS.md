# KOD half-hour supplement v1

This bounded observation supplement starts 2026-11-04 17:30 UTC and shares the
original experiment's end, 2026-11-09 09:00 UTC. There are 196 new supplemental
attempts. The combined grid has 224 slots: 196 supplemental attempts and 28
references to the existing four-hour cohort. The last new request is scheduled
08:30 UTC on November 9; the final 09:00 observation belongs to the original.

The original 30-slot cohort, source, plan, services, receipts and safeguard code
remain separate. No detector, strategy, forecast, broker endpoint or model call
is introduced. Overlapping one-hour lookbacks improve capture resilience but
coverage is measured from actual retained candle timestamps and deduplicated by
venue, symbol, interval and opening timestamp. Snapshot counts are distinct from
unique candle counts and investment decisions.

## Paths and operation

- Root-owned code, immutable plan and installation evidence: `/opt/kod/supplement-v1`.
- Unprivileged collector state: `/var/lib/kod/supplement-v1/slot-NNN`.
- Each slot has its own `runtime`, immutable begin/result/integrity/clock/end receipts.
- Collector: `kod-supplement-v1.service`; exact finite timer: `kod-supplement-v1.timer`.
- Health and recovery: `kod-supplement-guard-v1.service` and timer (five-minute checks).
- Guard state: `/var/lib/kod-supplement-ops`; local health: `HEALTH.json` there.
- Dedicated recovery branch: `supplement-30m-v1` in the existing private
  `jonathanpratama-boop/KOD-Timing-Backups` repository.

The collector checks frozen source and plan hashes before requests. It never
requests a timestamp owned by the original cohort. Starts more than ten minutes
late become MISSED; begun attempts are never retried. Failed verification,
interruption or provider blocking halts the supplement for operator review.
Original failure statuses remain visible and never receive substitute data.
Provider stop statuses and Retry-After evidence are retained, with no fallback
host or automatic retry. The original experiment continues independently.

Clock receipts preserve raw evidence. Frozen legacy `offset_seconds` is invalid;
additive `clock-corrections.json` carries corrections derived by the existing
reviewed helper, or explicitly unknown values. These are local clock evidence,
not independent timestamp proof.

## Recovery and monitoring

Only new completed slot directories are compressed, hashed and backed up. A
separate control archive holds this supplement's code, plan, tests, units and
installation receipt. Original source is identified by frozen commit and its
existing recovery snapshots; it is not copied again for each half-hour slot.
The isolated branch and separate Git checkout avoid original guard Git races,
full-source snapshots and the existing main-branch push-triggered CI workflow.
Normal pushes are batched hourly; changed health issues can be pushed sooner.
Git remote acknowledgement is checked before recording successful backup.

The local guard checks receipts, verified retained captures, HALTED state,
service/timer results, original artifact hashes, clock evidence and free disk.
It defers during or immediately before collection. The existing independent
main-branch watchdog still covers host/original heartbeat. This supplemental
branch introduces no separate external notification service: inspect its health
and systemd results for supplemental failures. No new keys or access grants are
created; the existing dedicated recovery key and known-hosts file are reused.

To recover, fetch `supplement-30m-v1` through the already-authorized repository
route. Verify each archive against its published SHA-256, then verify each
member against its `MANIFEST.json` before extracting into a new directory. Reject
absolute paths, traversal, symlinks, or unexpected files. Restore code/plan from
the control archive and each completed slot from its own archive. Obtain the
matching original source from the original recovery snapshot. That older
snapshot omits four dot-prefixed source templates; the small
`source-recovery-addendum.json` preserves exactly those manifest-pinned files.
Decode them into the recovered source staging directory and verify all source
hashes before using it. No live original source file was changed. Then run its
`timing-status` against each restored per-slot runtime. Preserve all receipts,
including failed, blocked, missed and interrupted attempts. Never reset the plan
or ledger to recollect them. Recovery during the bounded period records missed
slots explicitly; it does not backfill historical observations.

Pause only the supplement with `systemctl disable --now kod-supplement-v1.timer`.
Stop its active invocation with `systemctl stop kod-supplement-v1.service` (this
may leave an explicitly interrupted attempt). Keep health/recovery running to
retain failure evidence. Do not alter the original service or its safeguard.

## Capacity and billing boundary

Preflight measured 961 MB RAM, 614 MB available, 21 GB free disk, load 0.08, and
original collection peak 25,423,872 bytes. The first original slot's runtime and
receipts occupy about 335 KB. At that observed size, 196 supplemental slots use
about 66 MB before filesystem and Git overhead. New collection is limited to
192 MB and 50% CPU, and the guard to 192 MB and 25% CPU. No server resize,
subscription, paid backup product or model usage is introduced.

DigitalOcean documents free inbound traffic and included outbound transfer;
overage is billed if the account exceeds its allowance. Account-wide quota and
invoice were not available through the server, so zero marginal billing is not
asserted. This design adds small compressed deltas and avoids full snapshots and
push-triggered CI on the supplement branch. Existing server billing continues
independently of the collection end.

Pricing reference checked 2026-11-04:
https://www.digitalocean.com/pricing/droplets and https://www.digitalocean.com/pricing.
