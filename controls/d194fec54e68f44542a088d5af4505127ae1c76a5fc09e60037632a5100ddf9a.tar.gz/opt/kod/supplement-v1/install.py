#!/usr/bin/env python3
"""Install only this versioned supplement; refuse an existing installation."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import pwd
import shutil
import subprocess

SOURCE = Path(__file__).resolve().parent
TARGET = Path('/opt/kod/supplement-v1')
STATE = Path('/var/lib/kod/supplement-v1')
OPS = Path('/var/lib/kod-supplement-ops')
UNITS = ['kod-supplement-v1.service', 'kod-supplement-v1.timer',
         'kod-supplement-guard-v1.service', 'kod-supplement-guard-v1.timer']
FILES = ['observe_supplement.py', 'test_observe_supplement.py',
         'combined_view.py', 'test_combined_view.py',
         'backup_supplement.py', 'test_backup_supplement.py',
         'plan.json', 'frozen-original-baseline.json', 'source-recovery-addendum.json',
         'OPERATIONS.md', 'install.py', *UNITS]


def run(args, **kw):
    return subprocess.run(args, check=True, text=True, capture_output=True, **kw)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if os.geteuid() != 0:
        raise RuntimeError('installer requires existing authorized root SSH route')
    baseline = json.loads((SOURCE / 'frozen-original-baseline.json').read_bytes())
    for name, expected in baseline['fixed_hashes'].items():
        if sha(name) != expected:
            raise RuntimeError('frozen original artifact differs: ' + name)
    for path in [TARGET, STATE, OPS, *(Path('/etc/systemd/system') / name for name in UNITS)]:
        if path.exists() or path.is_symlink():
            raise RuntimeError('refusing duplicate or uncertain existing installation: ' + str(path))
    for name in FILES:
        path = SOURCE / name
        if not path.is_file() or path.is_symlink():
            raise RuntimeError('missing regular package file: ' + name)
    plan = json.loads((SOURCE / 'plan.json').read_bytes())
    now = dt.datetime.now(dt.timezone.utc)
    first = dt.datetime.fromisoformat(plan['slots'][0].replace('Z', '+00:00'))
    if (first - now).total_seconds() < 120:
        raise RuntimeError('first declared slot is too close or past; freeze a new future version before install')
    checked = json.loads(run(['/opt/kod/venv/bin/python', '/opt/kod/bin/check-source.py']).stdout)
    if checked.get('ok') is not True:
        raise RuntimeError('original source verification failed')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    tests = run(['/opt/kod/venv/bin/python', '-m', 'unittest', 'discover', '-s', str(SOURCE), '-p', 'test_*.py'], env=env)
    run(['systemd-analyze', 'verify', *(str(SOURCE / x) for x in UNITS)])
    staged = TARGET.with_name('supplement-v1.installing')
    if staged.exists():
        raise RuntimeError('uncertain staging directory already exists')
    staged.mkdir(mode=0o755)
    for name in FILES:
        shutil.copyfile(SOURCE / name, staged / name)
        os.chmod(staged / name, 0o644)
    receipt = {'schema': 'KOD_SUPPLEMENT_INSTALLATION_V1', 'installed_at': now.isoformat(),
               'plan_sha256': sha(SOURCE / 'plan.json'), 'first_new_slot': plan['slots'][0],
               'last_new_slot': plan['slots'][-1], 'shared_original_end': plan['end_at'],
               'supplemental_slots': len(plan['slots']), 'files': {x: sha(SOURCE / x) for x in FILES},
               'frozen_original_hashes_before': baseline['fixed_hashes'],
               'original_source_check': checked, 'synthetic_tests': tests.stderr,
               'original_artifacts_changed': False, 'new_paid_resources': False,
               'credentials_or_access_grants_changed': False, 'strategy_enabled': False}
    (staged / 'INSTALLATION.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    os.rename(staged, TARGET)
    STATE.mkdir(mode=0o750)
    account = pwd.getpwnam('kod')
    os.chown(STATE, account.pw_uid, account.pw_gid)
    OPS.mkdir(mode=0o700)
    for name in UNITS:
        shutil.copyfile(TARGET / name, Path('/etc/systemd/system') / name)
        os.chmod(Path('/etc/systemd/system') / name, 0o644)
    run(['systemctl', 'daemon-reload'])
    # Early invocation proves there is no premature collection; only PIN/lock created.
    run(['systemctl', 'start', 'kod-supplement-v1.service'])
    run(['systemctl', 'enable', '--now', 'kod-supplement-v1.timer', 'kod-supplement-guard-v1.timer'])
    run(['systemctl', 'start', 'kod-supplement-guard-v1.service'])
    for name, expected in baseline['fixed_hashes'].items():
        if sha(name) != expected:
            raise RuntimeError('original artifact changed across install: ' + name)
    print(json.dumps(receipt, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
