#!/usr/bin/env python3
"""Read-only references to the frozen cohort and supplemental observations.

This view never collects, retries, substitutes observations, or changes receipts.
Coverage counts unique candle identities; overlapping lookbacks are not independent
observations. Capture verification re-reads the retained raw provider evidence.
"""
import argparse
import collections
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sys

UTC = dt.timezone.utc
ORIGINAL_PLAN_SHA256 = 'bffe919924e56a48d49e92045f86e3ee4678ac5ae03aad8287ae8d6e6af6af6b'
SOURCE_COMMIT = 'dbb27ea5c6a16c5b37c6f94b938a1509c2a9148e'


def parse(value):
    parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.utcoffset() is None:
        raise ValueError('timezone required')
    return parsed.astimezone(UTC)


def stamp(value):
    return value.astimezone(UTC).isoformat().replace('+00:00', 'Z')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_reference(path):
    path = Path(path)
    raw = path.read_bytes()
    return json.loads(raw), {'path': str(path), 'sha256': sha(raw)}


def source_verifier(source):
    root = Path(source).resolve()
    manifest = json.loads((root / 'SOURCE_MANIFEST.json').read_bytes())
    if manifest.get('commit') != SOURCE_COMMIT:
        raise ValueError('frozen verifier source version mismatch')
    for name, info in manifest['files'].items():
        path = root / name
        if (not path.is_file() or path.is_symlink()
                or root not in path.resolve().parents
                or sha(path.read_bytes()) != info['sha256']):
            raise ValueError('frozen verifier source integrity mismatch: ' + name)
    sys.path.insert(0, str(root / 'idx-signals'))
    from idxsig.runtime.intraday import load_intraday
    return load_intraday


def clock_reference(folder, row):
    row['clock'] = {'status': 'UNKNOWN_LEGACY_OFFSET_INVALID',
                    'legacy_offset_seconds_invalid': True,
                    'system_correction_seconds': None}
    path = folder / 'clock-corrections.json'
    if not path.exists():
        return
    try:
        corrections, ref = read_reference(path)
        row['references']['clock_corrections'] = ref
        records = corrections.get('records', [])
        row['clock']['records'] = [{k: value.get(k) for k in
            ('status', 'observed_at', 'original_sha256', 'system_correction_seconds',
             'conditional_error_bound_seconds')} for value in records]
        verified = bool(records) and all(value.get('status') == 'DERIVED_FROM_RETAINED_RAW' for value in records)
        row['clock']['status'] = 'DERIVED_FROM_RETAINED_RAW' if verified else 'UNKNOWN_LEGACY_OFFSET_INVALID'
        if verified and len(records) == 1:
            row['clock']['system_correction_seconds'] = records[0].get('system_correction_seconds')
    except (ValueError, OSError, KeyError, TypeError) as exc:
        row['issues'].append('Unreadable additive clock corrections: ' + str(exc))


def grid(plan, original_plan):
    start, end = parse(plan['start_at']), parse(plan['end_at'])
    if start > end or end != parse(original_plan['slots'][-1]):
        raise ValueError('supplement must end with original cohort')
    if any(x.second or x.microsecond or x.minute not in (0, 30) for x in (start, end)):
        raise ValueError('halfhour boundaries required')
    dates = []
    cursor = start
    while cursor <= end:
        dates.append(stamp(cursor))
        cursor += dt.timedelta(minutes=30)
    originals = set(original_plan['slots'])
    if plan['slots'] != [s for s in dates if s not in originals]:
        raise ValueError('supplement slots must fill only intervening halfhours')
    return dates


def slot_row(folder, runtime, scheduled, origin, index, now, verify_capture,
             expected_receipt_plan_sha=None):
    folder, runtime = Path(folder), Path(runtime)
    row = {'scheduled_at': scheduled, 'origin': origin, 'slot': index,
           'status': 'PENDING', 'receipt_verified': False,
           'capture_verified': False, 'references': {}, 'issues': []}
    clock_reference(folder, row)
    if not (folder / 'end.json').exists():
        if (folder / 'begin.json').exists():
            row['status'] = 'STARTED_WITHOUT_COMPLETION'
        elif parse(scheduled) <= now:
            row['status'] = 'DUE' if (now - parse(scheduled)).total_seconds() <= 900 else 'OVERDUE'
        return row, []
    bars = []
    try:
        end, ref = read_reference(folder / 'end.json')
        row['references']['end'] = ref
        # Preserve the producer's status even if its evidence cannot be verified.
        row['status'] = end['status']
        row['completed_at'] = end.get('completed_at')
        if end.get('scheduled_at') != scheduled or end.get('slot') != index:
            raise ValueError('completion receipt slot identity mismatch')
        if expected_receipt_plan_sha and end.get('plan_sha256') != expected_receipt_plan_sha:
            raise ValueError('completion receipt plan hash mismatch')
        if row['status'] in ('FAILED', 'INTERRUPTED'):
            row['issues'].append('Retained failed/interrupted observation; never substituted or retried')
            return row, []
        result, ref = read_reference(folder / 'result.json')
        row['references']['result'] = ref
        integrity, ref = read_reference(folder / 'integrity.json')
        row['references']['integrity'] = ref
        if integrity.get('integrity', {}).get('ok') is not True:
            raise ValueError('retained integrity receipt did not pass')
        attempt = result.get('attempt_id') or result.get('id')
        if not isinstance(attempt, str) or not re.fullmatch(r'attempt_[A-Za-z0-9]+', attempt):
            raise ValueError('invalid attempt identity')
        identities = {x.get('id') for x in integrity.get('summary', {}).get('records', [])}
        if attempt not in identities:
            raise ValueError('result absent from retained verified timing journal')
        row['attempt_id'] = attempt
        row['receipt_verified'] = True
        if row['status'] == 'MISSED':
            return row, []
        if row['status'] not in ('CAPTURED', 'PARTIAL', 'BLOCKED'):
            raise ValueError('unrecognized completed observation status')
        path = runtime / 'timing' / 'captures' / (attempt + '.json')
        capture, ref = read_reference(path)
        row['references']['capture'] = ref
        loaded = verify_capture(path, runtime / 'evidence')
        # load_intraday adds the SHA of raw capture bytes to its returned value;
        # that derived field is in result.json, not in the immutable capture file.
        if ({k: v for k, v in loaded.items() if k != 'capture_sha256'} != capture
                or loaded.get('capture_sha256') != ref['sha256']
                or loaded != result.get('capture')):
            raise ValueError('retained capture differs from result receipt')
        if capture.get('scheduled_at') != scheduled:
            raise ValueError('capture schedule differs from declared slot')
        expected_status = {'COLLECTED': 'CAPTURED', 'PARTIAL': 'PARTIAL', 'BLOCKED': 'BLOCKED'}.get(capture.get('status'))
        if expected_status != row['status']:
            raise ValueError('capture and completion statuses differ')
        row['capture_verified'] = True
        row['window_start_at'] = capture['window_start_at']
        row['window_end_at'] = capture['window_end_at']
        row['started_at'] = capture.get('started_at')
        row['bar_rows'] = len(capture['bars'])
        row['request_count'] = len(capture.get('requests', []))
        row['quote_snapshots'] = len(capture.get('quotes', []))
        row['depth_snapshots'] = len(capture.get('depth', []))
        bars = capture['bars']
    except (ValueError, OSError, KeyError, TypeError) as exc:
        row['capture_verified'] = False
        row['issues'].append(str(exc))
    return row, bars


def coverage(bars, symbols, target_start, target_end):
    unique = {}
    conflicts = set()
    market_fields = ('open', 'high', 'low', 'close', 'base_volume', 'quote_volume', 'bar_end_at')
    for bar in bars:
        key = tuple(bar[x] for x in ('venue', 'symbol', 'interval', 'open_time'))
        values = tuple(bar.get(x) for x in market_fields)
        if key in unique and unique[key][1] != values:
            conflicts.add(key)
        unique.setdefault(key, (bar, values))
    details = []
    for symbol in symbols:
        selected = [b for (venue, sym, interval, opened), (b, _) in unique.items()
                    if sym == symbol and interval == '1m' and venue == 'BINANCE_SPOT']
        times = {parse(b['open_time']) for b in selected if b.get('complete') is True}
        gaps, gap_start = [], None
        current = target_start
        while current < target_end:
            if current not in times and gap_start is None:
                gap_start = current
            if current in times and gap_start is not None:
                gaps.append({'start_at': stamp(gap_start), 'end_at': stamp(current),
                             'missing_minutes': int((current-gap_start).total_seconds()/60)})
                gap_start = None
            current += dt.timedelta(minutes=1)
        if gap_start is not None:
            gaps.append({'start_at': stamp(gap_start), 'end_at': stamp(target_end),
                         'missing_minutes': int((target_end-gap_start).total_seconds()/60)})
        details.append({'symbol': symbol, 'unique_complete_bars': len(times),
                        'first_open_time': stamp(min(times)) if times else None,
                        'latest_bar_end_at': stamp(max(times)+dt.timedelta(minutes=1)) if times else None,
                        'gaps_in_due_lookback_target': gaps})
    return {'retained_bar_rows': len(bars), 'unique_candle_identities': len(unique),
            'overlapping_bar_rows': len(bars)-len(unique),
            'conflicting_candle_identities': len(conflicts),
            'identity_fields': ['venue', 'symbol', 'interval', 'open_time'],
            'target_start_at': stamp(target_start), 'target_end_at': stamp(target_end),
            'by_symbol': details}


def build(plan, original_plan, original_state, supplement_state, now,
          *, original_runtime='/var/lib/kod/timing-forward', verify_capture=None,
          supplement_plan_sha256=None):
    """Build a view without writes; injected verifier supports offline tests."""
    if verify_capture is None:
        verify_capture = source_verifier('/opt/kod/current')
    dates = grid(plan, original_plan)
    original_index = {s: n for n, s in enumerate(original_plan['slots'], 1)}
    supplemental_index = {s: n for n, s in enumerate(plan['slots'], 1)}
    semantic_hash = sha(json.dumps(original_plan, sort_keys=True).encode())
    rows, bars = [], []
    for scheduled in dates:
        if scheduled in original_index:
            n = original_index[scheduled]
            row, found = slot_row(Path(original_state)/f'slot-{n:02d}', original_runtime,
                                  scheduled, 'ORIGINAL_REFERENCE', n, now, verify_capture, semantic_hash)
        else:
            n = supplemental_index[scheduled]
            folder = Path(supplement_state)/f'slot-{n:03d}'
            row, found = slot_row(folder, folder/'runtime', scheduled,
                                  'SUPPLEMENT', n, now, verify_capture, supplement_plan_sha256)
        rows.append(row)
        bars.extend(found)
    due = [parse(s) for s in dates if parse(s) <= now]
    target_start = parse(plan['start_at']) - dt.timedelta(hours=1)
    target_end = max(due) if due else target_start
    issues = [{'scheduled_at': r['scheduled_at'], 'origin': r['origin'], 'reason': issue}
              for r in rows for issue in r['issues']]
    return {'schema': 'KOD_COMBINED_OBSERVATION_VIEW_V1', 'as_of': stamp(now),
            'scope': 'Read-only operational observations; original 30-slot report remains separate',
            'start_at': plan['start_at'], 'end_at': plan['end_at'],
            'counts': dict(collections.Counter(r['status'] for r in rows)),
            'origins': dict(collections.Counter(r['origin'] for r in rows)),
            'verified_captured_observations': sum(r['status']=='CAPTURED' and r['capture_verified'] for r in rows),
            'slots': rows, 'issues': issues,
            'coverage': coverage(bars, plan['symbols'], target_start, target_end),
            'limitations': ['Candle windows follow actual process start, not scheduled time.',
                'Overlapping candle rows are deduplicated by identity, not independent observations.',
                'Failed, missed, blocked and pending original slots remain unchanged references.',
                'Clock legacy offset_seconds is invalid; use retained clock-corrections.json where available.',
                'Local evidence verification does not establish independent timestamp proof or profitability.'],
            'entry_permission': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', default='/opt/kod/supplement-v1/plan.json')
    parser.add_argument('--expected-plan-sha256', required=True)
    parser.add_argument('--original-plan', default='/etc/kod/observation-plan.json')
    parser.add_argument('--original-state', default='/var/lib/kod/schedule')
    parser.add_argument('--original-runtime', default='/var/lib/kod/timing-forward')
    parser.add_argument('--state', default='/var/lib/kod/supplement-v1')
    parser.add_argument('--source', default='/opt/kod/current')
    parser.add_argument('--now')
    args = parser.parse_args()
    original, original_ref = read_reference(args.original_plan)
    plan, plan_ref = read_reference(args.plan)
    if original_ref['sha256'] != ORIGINAL_PLAN_SHA256 or plan.get('original_plan_sha256') != ORIGINAL_PLAN_SHA256:
        raise ValueError('frozen original plan hash mismatch')
    if plan_ref['sha256'] != args.expected_plan_sha256:
        raise ValueError('supplement plan hash mismatch')
    result = build(plan, original, args.original_state, args.state,
                   parse(args.now) if args.now else dt.datetime.now(UTC),
                   original_runtime=args.original_runtime, verify_capture=source_verifier(args.source),
                   supplement_plan_sha256=args.expected_plan_sha256)
    result['plans'] = {'original': original_ref, 'supplement': plan_ref}
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
