#!/usr/bin/env python3
"""Prospective half-hour supplement. Original cohort and source are read-only.

The existing collector is reused with an independent runtime for each declared
supplemental slot. This wrapper cannot collect at an original cohort timestamp.
"""
import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile

UTC = dt.timezone.utc
COMMIT = 'dbb27ea5c6a16c5b37c6f94b938a1509c2a9148e'
ORIGINAL_SHA = 'bffe919924e56a48d49e92045f86e3ee4678ac5ae03aad8287ae8d6e6af6af6b'
ORIGINAL_FIRST = dt.datetime(2026, 11, 4, 13, tzinfo=UTC)
ORIGINAL_END = dt.datetime(2026, 11, 9, 9, tzinfo=UTC)
SOURCE = Path('/opt/kod/current')
PYTHON = '/opt/kod/venv/bin/python'
DEFAULT_STATE = Path('/var/lib/kod/supplement-v1')


def stamp(value):
    return value.astimezone(UTC).isoformat().replace('+00:00', 'Z')


def parse(value):
    result = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.utcoffset() is None:
        raise ValueError('naive schedule time')
    return result.astimezone(UTC)


def read(path):
    return json.loads(Path(path).read_bytes())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def immutable(path, value):
    """Publish a complete, fsynced receipt without replacing an existing one."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    fd, name = tempfile.mkstemp(dir=path.parent, prefix='.receipt-')
    try:
        with os.fdopen(fd, 'wb') as output:
            output.write(raw)
            output.flush()
            os.fsync(output.fileno())
        os.link(name, path)
        descriptor = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        os.unlink(name)


def original_times():
    return [ORIGINAL_FIRST + dt.timedelta(hours=4 * i) for i in range(30)]


def validate(plan, original_plan):
    originals = original_times()
    if original_plan.get('slots') != [stamp(x) for x in originals]:
        raise ValueError('original thirty-slot schedule differs from the frozen cohort')
    for value in (plan, original_plan):
        if (value.get('source_commit') != COMMIT or value.get('symbols') != ['BTCUSDT', 'ETHUSDT']
                or value.get('interval') != '1m' or value.get('bars') != 60
                or value.get('strategy_enabled') is not False or value.get('late_after_seconds') != 600):
            raise ValueError('unexpected observation profile or execution policy')
    if plan.get('schema') != 'KOD_SUPPLEMENT_30M_V1' or plan.get('original_plan_sha256') != ORIGINAL_SHA:
        raise ValueError('unexpected supplemental version or original plan pin')
    start, end = parse(plan['start_at']), parse(plan['end_at'])
    if not ORIGINAL_FIRST < start < end or end != ORIGINAL_END:
        raise ValueError('supplement must start after original beginning and share original end')
    if any(x.microsecond or int(x.timestamp()) % 1800 for x in (start, end)):
        raise ValueError('supplement boundaries must lie on the UTC half-hour grid')
    wanted = []
    cursor = start
    while cursor <= end:
        if cursor not in originals:
            wanted.append(cursor)
        cursor += dt.timedelta(minutes=30)
    if not wanted or plan.get('slots') != [stamp(x) for x in wanted]:
        raise ValueError('supplement slots must be the exact half-hour grid excluding original slots')
    return wanted


def execute(plan, original_plan, state, invoke, *, plan_sha256=None,
            clock=lambda: dt.datetime.now(UTC), clock_report=None):
    """Process declared due slots once; an uncertain attempt is never recollected.

    invoke(action, scheduled_at, runtime) may perform capture/missed/verify.
    Tests inject it; main uses only the existing frozen collector CLI.
    """
    times = validate(plan, original_plan)
    plan_sha256 = plan_sha256 or hashlib.sha256(json.dumps(plan, sort_keys=True).encode()).hexdigest()
    state = Path(state)
    state.mkdir(parents=True, exist_ok=True)
    with (state / 'scheduler.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        pin = {'schema': plan['schema'], 'plan_sha256': plan_sha256,
               'original_plan_sha256': ORIGINAL_SHA, 'source_commit': COMMIT}
        if (state / 'PIN.json').exists():
            if read(state / 'PIN.json') != pin:
                raise RuntimeError('state belongs to a different frozen plan')
        else:
            immutable(state / 'PIN.json', pin)
        if (state / 'HALTED.json').exists():
            raise RuntimeError('supplement HALTED; operator review required; no automatic retries')
        processed = []
        for index, scheduled in enumerate(times, 1):
            if scheduled > clock():
                continue
            folder = state / f'slot-{index:03d}'
            runtime = folder / 'runtime'
            if folder.is_symlink() or runtime.is_symlink():
                raise RuntimeError('symlink in supplemental runtime path')
            receipt = {'slot': index, 'scheduled_at': stamp(scheduled),
                       'plan_sha256': plan_sha256, 'observed_at': stamp(clock()),
                       'runtime': str(runtime), 'entry_permission': False,
                       'clock_legacy_offset_seconds_invalid': True}
            if (folder / 'end.json').exists():
                old = read(folder / 'end.json')
                if any(old.get(k) != receipt[k] for k in ('slot', 'scheduled_at', 'plan_sha256', 'runtime')):
                    raise RuntimeError('completion receipt identity mismatch')
                if old.get('status') in ('FAILED', 'BLOCKED', 'INTERRUPTED'):
                    # Recover a crash between publishing the failure receipt and its halt.
                    immutable(state / 'HALTED.json', old)
                    break
                if old.get('status') not in ('CAPTURED', 'PARTIAL', 'MISSED'):
                    raise RuntimeError('unknown completion status')
                continue
            if (folder / 'begin.json').exists():
                receipt.update(status='INTERRUPTED', completed_at=stamp(clock()),
                               reason='Prior invocation began without completion; not recollected')
                immutable(folder / 'end.json', receipt)
                immutable(state / 'HALTED.json', receipt)
                processed.append(receipt)
                break
            immutable(folder / 'begin.json', receipt)
            try:
                # Independent exclusion check guards capture even if validation changes later.
                if scheduled in original_times():
                    raise RuntimeError('refusing a duplicate original cohort capture')
                late = (clock() - scheduled).total_seconds() > plan['late_after_seconds']
                result = invoke('missed' if late else 'capture', stamp(scheduled), runtime)
                immutable(folder / 'result.json', result)
                status = 'MISSED' if late else {
                    'COLLECTED': 'CAPTURED', 'PARTIAL': 'PARTIAL', 'BLOCKED': 'BLOCKED'
                }[result['capture']['status']]
                integrity = invoke('verify', stamp(scheduled), runtime)
                immutable(folder / 'integrity.json', integrity)
                if integrity.get('integrity', {}).get('ok') is not True:
                    raise RuntimeError('supplement timing integrity verification failed')
                try:
                    corrections = clock_report(runtime) if clock_report else {
                        'status': 'UNKNOWN', 'reason': 'No correction reader supplied',
                        'legacy_offset_seconds_is_invalid': True}
                except Exception as exc:
                    corrections = {'status': 'UNKNOWN', 'reason': str(exc)[:1000],
                                   'legacy_offset_seconds_is_invalid': True}
                immutable(folder / 'clock-corrections.json', corrections)
                receipt.update(status=status, completed_at=stamp(clock()))
                identity = result.get('attempt_id') or result.get('id')
                if identity:
                    receipt['attempt_id'] = identity
                if not late:
                    captured = result['capture']
                    receipt.update(window_start_at=captured.get('window_start_at'),
                                   window_end_at=captured.get('window_end_at'),
                                   provider_stops=[{k: row.get(k) for k in
                                                    ('http_status', 'retry_after', 'status', 'endpoint')}
                                                   for row in captured.get('requests', [])
                                                   if row.get('status') == 'BLOCKED'])
            except Exception as exc:
                receipt.update(status='FAILED', completed_at=stamp(clock()), error=str(exc)[:2000])
                immutable(folder / 'end.json', receipt)
                immutable(state / 'HALTED.json', receipt)
                raise
            immutable(folder / 'end.json', receipt)
            processed.append(receipt)
            if status == 'BLOCKED':
                halt = dict(receipt, reason='Provider blocked collection; preserve Retry-After; no automatic retries')
                immutable(state / 'HALTED.json', halt)
                break
        return processed


def run_json(command, *, cwd=None, timeout=180):
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(f'{command[-1]} failed: {result.stderr[-2000:]}')
    return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', default='/opt/kod/supplement-v1/plan.json')
    parser.add_argument('--expected-plan-sha256', required=True)
    parser.add_argument('--original-plan', default='/etc/kod/observation-plan.json')
    parser.add_argument('--state', default=str(DEFAULT_STATE))
    args = parser.parse_args()
    if digest(args.original_plan) != ORIGINAL_SHA:
        raise RuntimeError('original frozen plan byte hash differs')
    if digest(args.plan) != args.expected_plan_sha256:
        raise RuntimeError('supplement frozen plan byte hash differs')
    state = Path(args.state)
    if state.resolve() != DEFAULT_STATE or state.is_symlink():
        raise ValueError('live supplemental state must be the separate versioned directory')
    plan, original_plan = read(args.plan), read(args.original_plan)
    spec = importlib.util.spec_from_file_location('kod_clock_corrections', '/opt/kod/bin/clock_corrections.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    def invoke(action, slot, runtime):
        base = [PYTHON, str(SOURCE / 'tools/kod.py'), 'runtime', '--root', str(runtime)]
        if action == 'capture':
            # Frozen source validation is local and precedes every new provider request.
            checked = run_json([PYTHON, '/opt/kod/bin/check-source.py'])
            if checked.get('ok') is not True or checked.get('commit') != COMMIT:
                raise RuntimeError('frozen source verification did not pass')
            original = subprocess.run(['systemctl', 'show', 'kod-observe.service', '-p', 'ActiveState', '--value'],
                                      capture_output=True, text=True, timeout=10)
            if original.returncode or original.stdout.strip() in ('activating', 'active', 'deactivating'):
                raise RuntimeError('original collector active or unknown; supplemental requests refused')
            command = [*base, 'timing-capture', '--scheduled-at', slot, '--symbols', *plan['symbols'],
                       '--interval', plan['interval'], '--bars', str(plan['bars'])]
        elif action == 'missed':
            command = [*base, 'timing-missed', '--scheduled-at', slot, '--symbols', *plan['symbols'],
                       '--reason', 'Supplement slot more than 600 seconds late; no historical backfill']
        else:
            command = [*base, 'timing-status']
        return run_json(command, cwd=SOURCE)

    processed = execute(plan, original_plan, state, invoke,
                        plan_sha256=args.expected_plan_sha256,
                        clock_report=lambda runtime: module.report([runtime]))
    print(json.dumps({'processed': processed, 'halted': (state / 'HALTED.json').exists(),
                      'entry_permission': False, 'original_cohort_changed': False}, sort_keys=True))
    if (state / 'HALTED.json').exists():
        raise SystemExit(2)


if __name__ == '__main__':
    main()
