import datetime as dt
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import backup_supplement as b


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_control_allowlist_excludes_original_source_and_credentials(self):
        code = self.root / 'code'
        code.mkdir()
        units = self.root / 'units'
        units.mkdir()
        for name in ('plan.json', 'observe_supplement.py', 'github_backup', '.env', 'secret.key'):
            (code / name).write_text(name)
        (code / 'original-source').mkdir()
        (code / 'original-source' / 'source.py').write_text('do not copy')
        (units / 'kod-observe.service').write_text('original frozen unit')
        (units / b.UNITS[0]).write_text('supplement unit')
        selected = b.control_files(code, units)
        self.assertEqual({p.name for p in selected}, {'plan.json', 'observe_supplement.py', b.UNITS[0]})

    def test_slot_archive_is_content_addressed_exact_and_idempotent(self):
        folder = self.root / 'slot-001'
        folder.mkdir()
        (folder / 'end.json').write_text('{"status":"CAPTURED"}')
        (folder / 'runtime').mkdir()
        raw = folder / 'runtime' / 'raw.json'
        raw.write_bytes(b'provider exact bytes')
        (folder / 'scheduler.lock').write_text('lock not data')
        (folder / '.unfinished').write_text('temporary')
        selected = b.regular_files(folder)
        first, signature, hashes = b.archive_files(selected, self.root / 'archive')
        second, same, _ = b.archive_files(selected, self.root / 'archive')
        self.assertEqual(first, second)
        self.assertEqual(signature, same)
        self.assertEqual(len(list(first.parent.glob('*.tar.gz'))), 1)
        self.assertEqual(b.verify_archive(first), hashes)
        self.assertEqual(len(hashes), 2)
        raw.write_bytes(b'changed bytes')
        changed, other, _ = b.archive_files(selected, self.root / 'archive')
        self.assertNotEqual(first, changed)
        self.assertNotEqual(signature, other)
        self.assertTrue(first.exists())

    def test_archive_detects_corruption_and_unsafe_members(self):
        for name in ('safe', '../escape'):
            archive = self.root / (name.replace('/', '_') + '.tar.gz')
            with tarfile.open(archive, 'w:gz') as out:
                payload = b'corrupted'
                item = tarfile.TarInfo(name)
                item.size = len(payload)
                out.addfile(item, io.BytesIO(payload))
                raw = json.dumps({name: b.sha(b'original')}).encode()
                item = tarfile.TarInfo('MANIFEST.json')
                item.size = len(raw)
                out.addfile(item, io.BytesIO(raw))
            with self.assertRaises(ValueError):
                b.verify_archive(archive)

    def test_symlinks_cannot_include_other_runtime_or_keys(self):
        folder = self.root / 'slot'
        folder.mkdir()
        (folder / 'outside').symlink_to('/etc/passwd')
        with self.assertRaisesRegex(ValueError, 'symlink'):
            b.regular_files(folder)

    def test_original_repository_cannot_be_initialized_or_changed(self):
        with patch.object(b, 'run') as run:
            with self.assertRaisesRegex(ValueError, 'original recovery'):
                b.prepare_repository(Path('/var/lib/kod-ops/repository'))
            run.assert_not_called()

    def test_existing_repository_on_main_is_refused_before_fetch(self):
        repo = self.root / 'repository'
        (repo / '.git').mkdir(parents=True)
        calls = []
        def fake_git(*args, **kwargs):
            calls.append(args)
            if args[:2] == ('remote', 'get-url'):
                return b.REMOTE
            return 'main'
        with patch.object(b, 'git', side_effect=fake_git):
            with self.assertRaisesRegex(ValueError, 'other than'):
                b.prepare_repository(repo)
        self.assertFalse(any(call[0] in ('fetch', 'push', 'merge') for call in calls))

    def test_existing_supplement_remote_fetches_only_its_branch(self):
        repo = self.root / 'repository'
        (repo / '.git').mkdir(parents=True)
        calls = []
        def fake_git(*args, **kwargs):
            calls.append(args)
            if args[:2] == ('remote', 'get-url'):
                return b.REMOTE
            if args[0] == 'symbolic-ref':
                return b.BRANCH
            if args[0] == 'ls-remote':
                return 'a'*40 + '\trefs/heads/' + b.BRANCH
            return ''
        with patch.object(b, 'git', side_effect=fake_git):
            with patch.object(b.subprocess, 'run') as run:
                run.return_value.returncode = 0
                b.prepare_repository(repo)
        self.assertIn(('fetch', '--depth=1', 'origin', b.BRANCH), calls)
        self.assertIn(('merge', '--ff-only', 'FETCH_HEAD'), calls)
        self.assertFalse(any('main' in call for call in calls))

    def test_active_and_imminent_collectors_defer_without_network(self):
        now = dt.datetime(2026, 11, 4, 17, 29, tzinfo=b.UTC)
        plan = {'slots': ['2026-11-04T17:30:00Z']}
        original = {'slots': ['2026-11-04T21:00:00Z']}
        units = {name: {'ActiveState': 'inactive'} for name in ('kod-observe.service', 'kod-supplement-v1.service')}
        self.assertIn('imminent', b.defer_reason(now, plan, original, units))
        units['kod-observe.service']['ActiveState'] = 'active'
        self.assertIn('active', b.defer_reason(now, plan, original, units))
        units['kod-observe.service']['ActiveState'] = 'inactive'
        self.assertIsNone(b.defer_reason(now-dt.timedelta(minutes=5), plan, original, units))

    def test_interrupted_begin_and_raw_evidence_are_retained_on_separate_branch(self):
        repo, ops, state = self.root/'repo', self.root/'ops', self.root/'state'
        repo.mkdir()
        ops.mkdir()
        folder = state/'slot-001'
        folder.mkdir(parents=True)
        (folder/'begin.json').write_text('{"slot":1}')
        (folder/'partial.raw').write_bytes(b'incomplete provider evidence')
        control = self.root/'plan.json'
        control.write_text('{}')
        calls = []
        head = 'b'*40
        def fake_git(*args, **kwargs):
            calls.append(args)
            if args[0] == 'status':
                return 'M INDEX.json'
            if args[0] == 'rev-parse':
                return head
            if args[0] == 'ls-remote':
                return head+'\trefs/heads/'+b.BRANCH
            return ''
        with patch.multiple(b, REPO=repo, OPS=ops, STATE=state):
            with patch.object(b, 'prepare_repository'), patch.object(b, 'control_files', return_value=[control]):
                with patch.object(b, 'git', side_effect=fake_git):
                    result = b.backup({'issues':[], 'as_of':'2026-11-04T17:40:00Z'}, force=True)
        index = json.loads((repo/'INDEX.json').read_text())
        self.assertEqual(result['completed_slots'], 0)
        self.assertEqual(result['begun_slots_archived'], 1)
        self.assertEqual(index['slots'][0]['status'], 'STARTED_WITHOUT_COMPLETION')
        self.assertFalse(index['slots'][0]['completed'])
        hashes = b.verify_archive(repo/index['slots'][0]['archive'])
        self.assertTrue(any(name.endswith('/begin.json') for name in hashes))
        self.assertTrue(any(name.endswith('/partial.raw') for name in hashes))
        self.assertIn(('push','origin','HEAD:refs/heads/'+b.BRANCH), calls)
        self.assertFalse(any('main' in call for call in calls))
        self.assertEqual(json.loads((ops/'last-push.json').read_text())['commit'], head)

    def test_failed_source_and_view_verification_still_produce_health_for_backup(self):
        code, ops = self.root/'code', self.root/'ops'
        code.mkdir()
        ops.mkdir()
        plan = {'slots':['2026-11-04T17:30:00Z'], 'end_at':'2026-11-09T09:00:00Z'}
        plan_path = code/'plan.json'
        plan_path.write_text(json.dumps(plan))
        original = self.root/'original.json'
        original.write_text('{"slots":[]}')
        (code/'frozen-original-baseline.json').write_text('{"fixed_hashes":{}}')
        def fake_unit(name):
            return {'ActiveState':'active' if name.endswith('.timer') else 'inactive', 'Result':'success'}
        with patch.multiple(b, CODE=code, OPS=ops, STATE=self.root/'state', ORIGINAL_PLAN=original):
            with patch.object(b, 'unit', side_effect=fake_unit):
                with patch.object(b, 'run', side_effect=RuntimeError('integrity failed')):
                    health, reason = b.health(plan_path, b.sha(plan_path.read_bytes()),
                        dt.datetime(2026,11,4,17,10,tzinfo=b.UTC))
        self.assertIsNone(reason)
        self.assertFalse(health['source_check']['ok'])
        self.assertTrue(health['view']['verification_failed'])
        self.assertTrue(any('Frozen source integrity failed' in issue for issue in health['issues']))
        self.assertTrue(any('Combined evidence view could not verify' in issue for issue in health['issues']))


if __name__ == '__main__':
    unittest.main()
