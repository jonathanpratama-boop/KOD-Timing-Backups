import copy
import datetime as dt
import fcntl
import json
from pathlib import Path
import tempfile
import unittest

from observe_supplement import (execute, immutable, validate, stamp, UTC, COMMIT,
                                ORIGINAL_SHA, original_times, read)

START = dt.datetime(2026, 11, 4, 17, 30, tzinfo=UTC)
END = dt.datetime(2026, 11, 9, 9, tzinfo=UTC)


def original():
    return {'slots': [stamp(x) for x in original_times()], 'symbols': ['BTCUSDT', 'ETHUSDT'],
            'interval': '1m', 'bars': 60, 'late_after_seconds': 600,
            'strategy_enabled': False, 'source_commit': COMMIT}


def plan():
    value = original()
    slots = []
    cursor = START
    while cursor <= END:
        if cursor not in original_times():
            slots.append(stamp(cursor))
        cursor += dt.timedelta(minutes=30)
    value.update(schema='KOD_SUPPLEMENT_30M_V1', original_plan_sha256=ORIGINAL_SHA,
                 start_at=stamp(START), end_at=stamp(END), slots=slots)
    return value


class SchedulerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.calls = []

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, action, slot, runtime):
        self.calls.append((action, slot, runtime))
        if action == 'capture':
            return {'attempt_id': 'capture-'+slot, 'capture': {'status': 'COLLECTED', 'requests': [],
                    'window_start_at': stamp(START-dt.timedelta(hours=1)), 'window_end_at': stamp(START)}}
        if action == 'missed':
            return {'id': 'missed-'+slot}
        return {'integrity': {'ok': True}}

    def run_at(self, now, **kwargs):
        return execute(plan(), original(), self.root, self.invoke, clock=lambda: now, **kwargs)

    def test_exact_bounded_nonduplicate_population(self):
        times = validate(plan(), original())
        self.assertEqual(len(times), 196)
        self.assertEqual(times[0], START)
        self.assertEqual(times[-1], END-dt.timedelta(minutes=30))
        self.assertFalse(set(times) & set(original_times()))
        self.assertEqual(len(set(times)), len(times))

    def test_future_invocation_pins_but_never_collects(self):
        self.assertEqual(self.run_at(START-dt.timedelta(seconds=1)), [])
        self.assertEqual(self.calls, [])
        self.assertTrue((self.root/'PIN.json').exists())

    def test_repeat_and_restart_never_duplicate_request(self):
        rows = self.run_at(START)
        self.assertEqual(rows[0]['status'], 'CAPTURED')
        self.assertEqual(self.run_at(START), [])
        self.assertEqual([x[0] for x in self.calls], ['capture', 'verify'])
        self.assertEqual(self.calls[0][2], self.root/'slot-001/runtime')

    def test_original_boundary_does_not_capture_it(self):
        now = dt.datetime(2026, 11, 4, 21, tzinfo=UTC)
        self.run_at(now)
        self.assertNotIn(stamp(now), [x[1] for x in self.calls])
        self.assertEqual([x[0] for x in self.calls].count('capture'), 0)

    def test_ten_minute_lateness_boundary(self):
        rows = self.run_at(START+dt.timedelta(seconds=600))
        self.assertEqual(rows[0]['status'], 'CAPTURED')

    def test_outage_records_missed_without_provider_requests(self):
        rows = self.run_at(START+dt.timedelta(minutes=71))
        self.assertEqual([x['status'] for x in rows], ['MISSED']*3)
        self.assertNotIn('capture', [x[0] for x in self.calls])
        self.assertTrue(all((self.root/f'slot-{i:03d}/integrity.json').exists() for i in range(1, 4)))

    def test_separate_runtime_per_slot(self):
        self.run_at(START+dt.timedelta(minutes=30))
        runtimes = {x[2] for x in self.calls}
        self.assertEqual(runtimes, {self.root/'slot-001/runtime', self.root/'slot-002/runtime'})

    def test_interrupted_attempt_is_preserved_and_halts(self):
        immutable(self.root/'slot-001/begin.json', {'started': True})
        rows = self.run_at(START)
        self.assertEqual(rows[0]['status'], 'INTERRUPTED')
        self.assertEqual(self.calls, [])
        with self.assertRaisesRegex(RuntimeError, 'HALTED'):
            self.run_at(START+dt.timedelta(minutes=30))

    def test_provider_block_preserves_retry_advice_and_halts(self):
        def blocked(action, slot, runtime):
            if action != 'capture':
                return self.invoke(action, slot, runtime)
            self.calls.append((action, slot, runtime))
            return {'capture': {'status': 'BLOCKED', 'requests': [{'status': 'BLOCKED',
                    'http_status': 429, 'retry_after': '3600', 'endpoint': '/api/v3/time'}]}}
        rows = execute(plan(), original(), self.root, blocked, clock=lambda: START)
        self.assertEqual(rows[0]['status'], 'BLOCKED')
        self.assertEqual(rows[0]['provider_stops'][0]['retry_after'], '3600')
        self.assertTrue((self.root/'HALTED.json').exists())
        with self.assertRaisesRegex(RuntimeError, 'HALTED'):
            execute(plan(), original(), self.root, blocked, clock=lambda: START+dt.timedelta(minutes=30))
        self.assertEqual([x[0] for x in self.calls].count('capture'), 1)

    def test_partial_is_not_reported_captured(self):
        def partial(action, slot, runtime):
            result = self.invoke(action, slot, runtime)
            if action == 'capture':
                result['capture']['status'] = 'PARTIAL'
            return result
        rows = execute(plan(), original(), self.root, partial, clock=lambda: START)
        self.assertEqual(rows[0]['status'], 'PARTIAL')

    def test_integrity_failure_halts_and_does_not_retry(self):
        def broken(action, slot, runtime):
            result = self.invoke(action, slot, runtime)
            return {'integrity': {'ok': False}} if action == 'verify' else result
        with self.assertRaisesRegex(RuntimeError, 'integrity'):
            execute(plan(), original(), self.root, broken, clock=lambda: START)
        self.assertEqual(read(self.root/'slot-001/end.json')['status'], 'FAILED')
        with self.assertRaisesRegex(RuntimeError, 'HALTED'):
            self.run_at(START)
        self.assertEqual([x[0] for x in self.calls].count('capture'), 1)

    def test_command_error_retains_failure_and_halt(self):
        def error(action, slot, runtime):
            raise RuntimeError('source or command failed')
        with self.assertRaisesRegex(RuntimeError, 'source or command'):
            execute(plan(), original(), self.root, error, clock=lambda: START)
        self.assertTrue((self.root/'HALTED.json').exists())
        self.assertTrue((self.root/'slot-001/begin.json').exists())
        self.assertEqual(read(self.root/'slot-001/end.json')['status'], 'FAILED')

    def test_changed_plan_cannot_reuse_state(self):
        self.run_at(START, plan_sha256='a'*64)
        with self.assertRaisesRegex(RuntimeError, 'different frozen plan'):
            self.run_at(START, plan_sha256='b'*64)

    def test_original_overlap_or_changed_end_or_profile_is_rejected(self):
        for key, value in [('slots', [stamp(original_times()[1])]+plan()['slots']),
                           ('end_at', stamp(END+dt.timedelta(minutes=30))),
                           ('strategy_enabled', True), ('bars', 120),
                           ('start_at', '2026-11-04T17:31:00Z'),
                           ('original_plan_sha256', 'changed')]:
            changed = plan()
            changed[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate(changed, original())
        changed = original()
        changed['slots'][1] = '2026-11-04T17:30:00Z'
        with self.assertRaises(ValueError):
            validate(plan(), changed)

    def test_immutable_receipts_cannot_be_replaced(self):
        path = self.root/'receipt.json'
        immutable(path, {'first': True})
        with self.assertRaises(FileExistsError):
            immutable(path, {'first': False})
        self.assertEqual(read(path), {'first': True})

    def test_concurrent_invocation_does_not_begin(self):
        with (self.root/'scheduler.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaises(BlockingIOError):
                self.run_at(START)
        self.assertFalse((self.root/'slot-001/begin.json').exists())
        self.assertEqual(self.calls, [])

    def test_clock_correction_is_additive_or_explicitly_unknown(self):
        def clock_report(runtime):
            raise ValueError('unknown CSV')
        self.run_at(START, clock_report=clock_report)
        report = read(self.root/'slot-001/clock-corrections.json')
        self.assertEqual(report['status'], 'UNKNOWN')
        self.assertTrue(report['legacy_offset_seconds_is_invalid'])
        self.assertTrue(read(self.root/'slot-001/end.json')['clock_legacy_offset_seconds_invalid'])

    def test_crash_after_blocked_end_cannot_resume_capture(self):
        self.run_at(START)
        end_path = self.root/'slot-001/end.json'
        value = read(end_path)
        value['status'] = 'BLOCKED'
        end_path.write_text(json.dumps(value))
        before = len(self.calls)
        self.run_at(START+dt.timedelta(minutes=30))
        self.assertEqual(len(self.calls), before)
        self.assertTrue((self.root/'HALTED.json').exists())

    def test_no_capture_after_original_end(self):
        rows = self.run_at(END+dt.timedelta(days=1))
        self.assertEqual(len(rows), len(plan()['slots']))
        self.assertTrue(all(x['status'] == 'MISSED' for x in rows))
        self.assertEqual([x[0] for x in self.calls].count('capture'), 0)
        self.assertEqual(self.run_at(END+dt.timedelta(days=2)), [])


if __name__ == '__main__':
    unittest.main()
