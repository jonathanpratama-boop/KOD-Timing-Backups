#!/usr/bin/env python3
"""Independent supplement health and delta recovery; never invokes collection.

Only the new supplement's allowlisted controls and completed slot folders are
archived. The frozen source remains recoverable from the original repository
main branch snapshots. This dedicated branch does not run the main CI workflow.
"""
import argparse
import collections
import csv
import datetime as dt
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tempfile
import time

UTC = dt.timezone.utc
CODE = Path('/opt/kod/supplement-v1')
STATE = Path('/var/lib/kod/supplement-v1')
OPS = Path('/var/lib/kod-supplement-ops')
REPO = OPS / 'repository'
REMOTE = 'git@github.com:jonathanpratama-boop/KOD-Timing-Backups.git'
BRANCH = 'supplement-30m-v1'
ORIGINAL_PLAN = Path('/etc/kod/observation-plan.json')
UNITS = ('kod-supplement-v1.service', 'kod-supplement-v1.timer',
         'kod-supplement-guard-v1.service', 'kod-supplement-guard-v1.timer')
CONTROL_NAMES = frozenset({'observe_supplement.py', 'combined_view.py',
    'backup_supplement.py', 'test_observe_supplement.py', 'test_combined_view.py',
    'test_backup_supplement.py', 'plan.json', 'frozen-original-baseline.json',
    'INSTALLATION.json', 'OPERATIONS.md', 'install.py', 'source-recovery-addendum.json',
    'DEPLOYMENT.json', 'README.md', 'RESTORE.md', *UNITS})


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def parse(value):
    return dt.datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(UTC)


def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix='.atomic-')
    try:
        with os.fdopen(fd, 'w') as out:
            json.dump(value, out, indent=2, sort_keys=True, allow_nan=False)
            out.write('\n')
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def run(args, **kwargs):
    result = subprocess.run(args, text=True, capture_output=True, timeout=120, **kwargs)
    if result.returncode:
        raise RuntimeError(f'{args[0]} {args[1] if len(args)>1 else ""} failed: {result.stderr[-1500:]}')
    return result.stdout.strip()


def unit(name):
    raw = run(['systemctl', 'show', name, '-p', 'ActiveState', '-p', 'Result', '-p', 'ExecMainStatus'])
    return dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)


def regular_files(root):
    """Return immutable slot payload files, rejecting symlinks and special files."""
    root = Path(root)
    found = []
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if any(p.startswith('.') or p == '__pycache__' for p in relative.parts):
            continue
        if path.name.endswith(('.lock', '.pyc')):
            continue
        if path.is_symlink():
            raise ValueError('symlink excluded from recovery archive: ' + str(path))
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError('special file excluded from recovery archive: ' + str(path))
        found.append(path)
    return found


def control_files(code=CODE, unit_root=Path('/etc/systemd/system')):
    paths = [Path(code) / name for name in sorted(CONTROL_NAMES)]
    paths.extend(Path(unit_root) / name for name in UNITS)
    return sorted({p for p in paths if p.is_file() and not p.is_symlink()})


def manifest(paths):
    return {str(path).lstrip('/'): sha(path.read_bytes()) for path in paths}


def verify_archive(path, expected=None):
    """Verify exact membership, safe names, types, and all retained bytes."""
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers()
        names = [m.name for m in members]
        if len(names) != len(set(names)) or names.count('MANIFEST.json') != 1:
            raise ValueError('archive duplicate membership or missing manifest')
        for member in members:
            parts = Path(member.name).parts
            if member.name.startswith('/') or '..' in parts or not member.isfile():
                raise ValueError('unsafe archive member: ' + member.name)
        hashes = json.load(archive.extractfile('MANIFEST.json'))
        if set(names) != set(hashes) | {'MANIFEST.json'}:
            raise ValueError('archive membership mismatch')
        if expected is not None and hashes != expected:
            raise ValueError('archive expected manifest mismatch')
        for name, digest in hashes.items():
            if sha(archive.extractfile(name).read()) != digest:
                raise ValueError('archive content mismatch: ' + name)
        return hashes


def archive_files(paths, destination):
    """Content-addressed archive; verify completed readback before publication."""
    paths = list(paths)
    hashes = manifest(paths)
    signature = sha(json.dumps(hashes, sort_keys=True).encode())
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    output = destination / (signature + '.tar.gz')
    if output.exists():
        verify_archive(output, hashes)
        return output, signature, hashes
    fd, temporary = tempfile.mkstemp(dir=destination, prefix='.archive-')
    os.close(fd)
    try:
        with tarfile.open(temporary, 'w:gz') as archive:
            for path in paths:
                archive.add(path, arcname=str(path).lstrip('/'), recursive=False)
            raw = json.dumps(hashes, sort_keys=True, indent=2).encode()
            info = tarfile.TarInfo('MANIFEST.json')
            info.size = len(raw)
            archive.addfile(info, io.BytesIO(raw))
        verify_archive(temporary, hashes)
        if manifest(paths) != hashes:
            raise RuntimeError('recovery inputs changed during archive creation')
        os.link(temporary, output)
        return output, signature, hashes
    finally:
        os.unlink(temporary)


def git(*args, repo=REPO):
    return run(['git', '-C', str(repo), *args])


def prepare_repository(repo=REPO):
    """Only this isolated repository and explicit supplement branch may change."""
    repo = Path(repo)
    if repo.resolve() == Path('/var/lib/kod-ops/repository').resolve():
        raise ValueError('original recovery repository is read-only')
    repo.mkdir(parents=True, exist_ok=True)
    if not (repo / '.git').exists():
        run(['git', 'init', '-b', BRANCH, str(repo)])
        git('remote', 'add', 'origin', REMOTE, repo=repo)
        git('config', 'user.name', 'KOD Recovery', repo=repo)
        git('config', 'user.email', 'jonathanpratama-boop@users.noreply.github.com', repo=repo)
    if git('remote', 'get-url', 'origin', repo=repo) != REMOTE:
        raise ValueError('unexpected supplement recovery destination')
    branch = git('symbolic-ref', '--short', 'HEAD', repo=repo)
    if branch != BRANCH:
        raise ValueError('refusing to write any branch other than ' + BRANCH)
    remote = git('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH, repo=repo)
    if remote:
        git('fetch', '--depth=1', 'origin', BRANCH, repo=repo)
        has_head = subprocess.run(['git', '-C', str(repo), 'rev-parse', '--verify', 'HEAD'],
                                  text=True, capture_output=True, timeout=30).returncode == 0
        if has_head:
            git('merge', '--ff-only', 'FETCH_HEAD', repo=repo)
        else:
            git('reset', '--hard', 'FETCH_HEAD', repo=repo)


def defer_reason(now, plan, original_plan, units):
    for name in ('kod-observe.service', 'kod-supplement-v1.service'):
        if units[name].get('ActiveState') in ('activating', 'active', 'deactivating'):
            return name + ' active; defer independent monitor to next check'
    for scheduled in [*plan['slots'], *original_plan['slots']]:
        if 0 <= (parse(scheduled) - now).total_seconds() < 120:
            return 'Declared collection imminent; defer monitor'
    return None


def health(plan_path, expected, now):
    issues = []
    try:
        raw = Path(plan_path).read_bytes()
        if sha(raw) != expected:
            issues.append('Supplement plan bytes do not match installed pin')
        plan = json.loads(raw)
    except (OSError, ValueError) as exc:
        issues.append('Supplement plan unreadable: ' + str(exc))
        plan = {'slots': [], 'end_at': now.isoformat()}
    try:
        original_plan = read(ORIGINAL_PLAN)
    except (OSError, ValueError) as exc:
        issues.append('Original plan unreadable: ' + str(exc))
        original_plan = {'slots': []}
    units = {name: unit(name) for name in (*UNITS, 'kod-observe.service')}
    try:
        reason = defer_reason(now, plan, original_plan, units)
    except (ValueError, KeyError, TypeError) as exc:
        issues.append('Declared schedule cannot be read safely: ' + str(exc))
        reason = None
    if reason:
        return None, reason
    baseline = read(CODE / 'frozen-original-baseline.json')
    changed = [name for name, expected_hash in baseline['fixed_hashes'].items()
               if not Path(name).is_file() or sha(Path(name).read_bytes()) != expected_hash]
    if changed:
        issues.append('Frozen original controls changed: ' + ', '.join(changed))
    try:
        checked = json.loads(run(['/opt/kod/venv/bin/python', '/opt/kod/bin/check-source.py']))
    except (RuntimeError, ValueError) as exc:
        checked = {'ok': False, 'error': str(exc)}
    if checked.get('ok') is not True:
        issues.append('Frozen source integrity failed')
    try:
        clock_raw = run(['chronyc', '-c', 'tracking'])
        fields = next(csv.reader(io.StringIO(clock_raw)))
        synchronized = len(fields) == 14 and fields[13].strip() == 'Normal' and 1 <= int(fields[2]) <= 15
        if not synchronized:
            issues.append('Current host clock is not synchronized normally')
        current_clock = {'status': 'SYNCHRONIZED' if synchronized else 'UNKNOWN',
                         'command': 'chronyc -c tracking', 'raw_csv': clock_raw,
                         'meaning': 'Current local chrony evidence; not independent absolute-time proof'}
    except (RuntimeError, ValueError, StopIteration) as exc:
        issues.append('Current host clock status unknown: ' + str(exc))
        current_clock = {'status': 'UNKNOWN', 'reason': str(exc)}
    correction_counts = collections.Counter()
    for path in sorted(STATE.glob('slot-*/clock-corrections.json')):
        try:
            correction = read(path)
            records = correction.get('records', [])
            if correction.get('status') == 'UNKNOWN':
                correction_counts['UNKNOWN'] += 1
                issues.append(path.parent.name + ': retained clock correction unknown')
            for row in records:
                correction_counts[row.get('status', 'UNKNOWN')] += 1
                if row.get('status') != 'DERIVED_FROM_RETAINED_RAW':
                    issues.append(path.parent.name + ': retained clock correction unverified')
        except (OSError, ValueError, TypeError) as exc:
            issues.append(path.parent.name + ': clock correction unreadable: ' + str(exc))
    try:
        raw = run(['/opt/kod/venv/bin/python', str(CODE / 'combined_view.py'),
                   '--plan', str(plan_path), '--expected-plan-sha256', expected])
        view = json.loads(raw)
    except (RuntimeError, ValueError) as exc:
        issues.append('Combined evidence view could not verify: ' + str(exc))
        view = {'verification_failed': True, 'rows': []}
    for row in view.get('rows', view.get('slots', [])):
        if parse(row['scheduled_at']) > now:
            continue
        if row.get('status') != 'CAPTURED' and (now - parse(row['scheduled_at'])).total_seconds() > 900:
            issues.append(f"{row['origin']} {row['scheduled_at']}: {row['status']}")
        if row.get('status') == 'CAPTURED' and row.get('capture_verified') is not True:
            issues.append(f"{row['origin']} {row['scheduled_at']}: unverified capture")
        issues.extend(f"{row['scheduled_at']}: {message}" for message in row.get('issues', []))
    if (STATE / 'HALTED.json').exists():
        issues.append('Supplement HALTED; operator review required')
    try:
        if now <= parse(plan['end_at']) and units['kod-supplement-v1.timer'].get('ActiveState') != 'active':
            issues.append('Supplement timer not active before end of declared schedule')
    except (ValueError, TypeError, KeyError) as exc:
        issues.append('Supplement end boundary unreadable: ' + str(exc))
    if units['kod-supplement-v1.service'].get('Result', 'success') != 'success':
        issues.append('Supplement collector service failed')
    if shutil.disk_usage('/').free < 1024 ** 3:
        issues.append('Less than 1 GiB free disk')
    previous = read(OPS / 'last-push.json') if (OPS / 'last-push.json').exists() else {}
    if previous and time.time() - previous.get('epoch', 0) > 7200:
        issues.append('Supplement offsite recovery acknowledgement older than two hours')
    result = {'schema': 'KOD_SUPPLEMENT_GUARD_V1', 'as_of': now.isoformat(),
              'issues': sorted(set(issues)), 'units': units, 'source_check': checked,
              'original_controls_unchanged': not changed, 'plan_sha256': expected,
              'current_clock': current_clock, 'retained_clock_correction_statuses': dict(correction_counts),
              'view': view, 'backup_branch': BRANCH,
              'last_acknowledged_backup': previous or None,
              'limitations': ['Local supplement monitor has no separate external notification integration.',
                 'Existing original-cohort remote watchdog continues monitoring the host heartbeat.',
                 'Supplement branch pushes do not invoke the original main-branch CI workflow.']}
    return result, None


RESTORE = '''# Supplemental observation recovery

This branch is separate from the original thirty-slot cohort on main. Never
restore supplement files over original controls, plans, source, or evidence.

1. Obtain original frozen source commit dbb27ea5c6a16c5b37c6f94b938a1509c2a9148e
   or the original main-branch recovery snapshot. Verify its source manifest.
   The original guard excludes hidden source files. In staging only, complete
   that recovered source using source-recovery-addendum.json's four base64
   source files (.env.example, .gitattributes, .gitignore, .lfsconfig), each pinned
   to its frozen manifest SHA-256. This contains repository templates/metadata,
   no live credentials. Run the full source checker before using recovered code.
2. Run verify_archive() from backup_supplement.py against each archive listed
   in INDEX.json. All members are regular files with a SHA-256 in MANIFEST.json.
3. Extract verified archives into an empty staging directory, never / directly.
   Restore only /opt/kod/supplement-v1, its four listed unit files, and
   /var/lib/kod/supplement-v1. Configure ownership as in INSTALLATION.json and
   OPERATIONS.md. Preserve the original cohort separately and unchanged.
4. Preserve PIN.json, all begin/end receipts, and HALTED.json. A begun slot must
   never be recollected. Missing historical slots are MISSED; no backfill.
5. Run combined_view.py with the frozen plan hash. Verify retained raw evidence,
   clock corrections, and explicit failed/blocked/interrupted states before any
   operator-reviewed resume. A HALTED supplement stays halted pending review.
6. Reuse existing authorized access only. Never restore keys or credential files
   from these archives; none are included. Source/strategy remains unchanged.

Recovery point: completed slots are delta-archived and pushed hourly, with
earlier pushes for health changes. An outage before acknowledgement can lose
up to one hour of supplemental observations. The original cohort recovery is
independent. No absolute-time or profitability proof is established.
'''


def backup(current, force=False):
    previous = read(OPS / 'last-push.json') if (OPS / 'last-push.json').exists() else {}
    if (not force and previous.get('issues') == current['issues']
            and time.time() - previous.get('epoch', 0) < 3600):
        return {'pushed': False, 'reason': 'Hourly batch not due; health unchanged'}
    prepare_repository()
    for name in ('controls', 'slots', 'state'):
        (REPO / name).mkdir(exist_ok=True)
    control, signature, hashes = archive_files(control_files(), REPO / 'controls')
    index = {'schema': 'KOD_SUPPLEMENT_DELTA_INDEX_V1',
             'controls': {'archive': str(control.relative_to(REPO)), 'signature': signature,
                          'sha256': sha(control.read_bytes()), 'files': len(hashes)},
             'original_source_commit': 'dbb27ea5c6a16c5b37c6f94b938a1509c2a9148e',
             'original_recovery': 'main branch snapshots; unchanged and not copied here', 'slots': []}
    for folder in sorted(STATE.glob('slot-*')):
        if not re.fullmatch(r'slot-\d{3}', folder.name) or not (folder / 'begin.json').is_file():
            continue
        paths = regular_files(folder)
        archive, signature, hashes = archive_files(paths, REPO / 'slots' / folder.name)
        if regular_files(folder) != paths:
            raise RuntimeError('Completed slot membership changed during recovery snapshot')
        completed = (folder / 'end.json').is_file()
        status = read(folder / 'end.json')['status'] if completed else 'STARTED_WITHOUT_COMPLETION'
        index['slots'].append({'slot': folder.name, 'status': status, 'completed': completed,
            'archive': str(archive.relative_to(REPO)), 'signature': signature,
            'sha256': sha(archive.read_bytes()), 'files': len(hashes)})
    state_files = [STATE / name for name in ('PIN.json', 'HALTED.json') if (STATE / name).is_file()]
    if state_files:
        archive, signature, hashes = archive_files(state_files, REPO / 'state')
        index['state'] = {'archive': str(archive.relative_to(REPO)), 'signature': signature,
                          'sha256': sha(archive.read_bytes()), 'files': len(hashes)}
    atomic(REPO / 'INDEX.json', index)
    atomic(REPO / 'HEALTH.json', current)
    (REPO / 'RESTORE.md').write_text(RESTORE)
    git('add', 'INDEX.json', 'HEALTH.json', 'RESTORE.md', 'controls', 'slots', 'state')
    if git('status', '--porcelain'):
        git('commit', '-m', 'Supplement delta recovery and health ' + current['as_of'])
    git('push', 'origin', 'HEAD:refs/heads/' + BRANCH)
    head = git('rev-parse', 'HEAD')
    remote = git('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH)
    if not remote or remote.split()[0] != head:
        raise RuntimeError('Supplement offsite acknowledgement mismatch')
    acknowledgement = {'epoch': time.time(), 'commit': head, 'issues': current['issues'],
                       'branch': BRANCH, 'completed_slots': sum(x['completed'] for x in index['slots']),
                       'begun_slots_archived': len(index['slots'])}
    atomic(OPS / 'last-push.json', acknowledgement)
    return {'pushed': True, **acknowledgement}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', default=str(CODE / 'plan.json'))
    parser.add_argument('--expected-plan-sha256', required=True)
    parser.add_argument('--force-backup', action='store_true')
    args = parser.parse_args()
    OPS.mkdir(parents=True, exist_ok=True)
    with (OPS / 'monitor.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        current, reason = health(args.plan, args.expected_plan_sha256, dt.datetime.now(UTC))
        if reason:
            print(json.dumps({'deferred': True, 'reason': reason}))
            return
        atomic(OPS / 'HEALTH.json', current)
        try:
            result = backup(current, args.force_backup)
        except Exception as exc:
            current['issues'].append('Supplement backup failed: ' + str(exc)[:2000])
            atomic(OPS / 'HEALTH.json', current)
            raise
        print(json.dumps({'issues': current['issues'], 'backup': result}))


if __name__ == '__main__':
    main()
