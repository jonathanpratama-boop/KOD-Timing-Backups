import copy
import datetime as dt
import json
from pathlib import Path
import tempfile
import unittest

from combined_view import build, coverage, grid, sha, source_verifier, stamp, SOURCE_COMMIT, UTC


START = dt.datetime(2026, 11, 4, 17, 30, tzinfo=UTC)
END = START + dt.timedelta(hours=3, minutes=30)


def fixtures():
    original = {'slots': ['2026-11-04T17:00:00Z', stamp(END)]}
    dates = [stamp(START + dt.timedelta(minutes=30*n)) for n in range(8)]
    supplement = {'start_at': stamp(START), 'end_at': stamp(END),
                  'slots': dates[:-1], 'symbols': ['BTCUSDT', 'ETHUSDT']}
    return supplement, original


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))


def verifier(path, evidence):
    result = json.loads(Path(path).read_text())
    result['capture_sha256'] = sha(Path(path).read_bytes())
    return result


def bar(opened, symbol='BTCUSDT', close='1'):
    return {'venue': 'BINANCE_SPOT', 'symbol': symbol, 'interval': '1m',
            'open_time': stamp(opened), 'bar_end_at': stamp(opened+dt.timedelta(minutes=1)),
            'complete': True, 'close': close}


class CombinedViewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.original_state = self.root/'original-state'
        self.original_runtime = self.root/'original-runtime'
        self.state = self.root/'supplement-state'
        self.plan, self.original = fixtures()

    def tearDown(self):
        self.temp.cleanup()

    def build(self, now=END):
        return build(self.plan, self.original, self.original_state, self.state, now,
                     original_runtime=self.original_runtime, verify_capture=verifier,
                     supplement_plan_sha256='supplement-pin')

    def capture(self, n, scheduled, origin='SUPPLEMENT', status='CAPTURED', bars=None):
        is_original = origin=='ORIGINAL_REFERENCE'
        folder = self.original_state/f'slot-{n:02d}' if is_original else self.state/f'slot-{n:03d}'
        runtime = self.original_runtime if is_original else folder/'runtime'
        attempt = 'attempt_'+str(n)+('a' if is_original else 'b')
        capture = {'scheduled_at': scheduled,
                   'status': {'CAPTURED': 'COLLECTED', 'PARTIAL': 'PARTIAL', 'BLOCKED': 'BLOCKED'}[status],
                   'window_start_at': stamp(START-dt.timedelta(hours=1)),
                   'window_end_at': scheduled, 'bars': bars or [],
                   'requests': [], 'quotes': [], 'depth': []}
        plan_hash = sha(json.dumps(self.original,sort_keys=True).encode()) if is_original else 'supplement-pin'
        write(folder/'end.json', {'slot': n,'scheduled_at': scheduled,'status': status,'plan_sha256': plan_hash})
        write(folder/'integrity.json', {'integrity': {'ok': True},'summary': {'records': [{'id': attempt}]}})
        capture_path=runtime/'timing/captures'/f'{attempt}.json'
        write(capture_path,capture)
        result_capture=copy.deepcopy(capture)
        result_capture['capture_sha256']=sha(capture_path.read_bytes())
        write(folder/'result.json', {'attempt_id': attempt,'capture': result_capture})
        return folder, runtime

    def test_grid_excludes_original_without_duplicate_slot(self):
        dates = grid(self.plan,self.original)
        self.assertEqual(len(dates),8)
        self.assertNotIn(stamp(END),self.plan['slots'])
        self.assertEqual(self.build()['origins'],{'SUPPLEMENT':7,'ORIGINAL_REFERENCE':1})
        bad=copy.deepcopy(self.plan);bad['slots'].append(stamp(END))
        with self.assertRaises(ValueError):grid(bad,self.original)

    def test_original_failure_remains_failed_and_has_reference(self):
        folder=self.original_state/'slot-02'
        write(folder/'end.json',{'slot':2,'scheduled_at':stamp(END),'status':'FAILED',
              'plan_sha256':sha(json.dumps(self.original,sort_keys=True).encode())})
        before=(folder/'end.json').read_bytes()
        row=self.build()['slots'][-1]
        self.assertEqual(row['status'],'FAILED')
        self.assertFalse(row['capture_verified'])
        self.assertEqual(row['origin'],'ORIGINAL_REFERENCE')
        self.assertIn('end',row['references'])
        self.assertEqual((folder/'end.json').read_bytes(),before)

    def test_verified_original_and_supplement_share_no_capture(self):
        self.capture(1,stamp(START),bars=[bar(START-dt.timedelta(minutes=1))])
        self.capture(2,stamp(END),origin='ORIGINAL_REFERENCE',bars=[bar(END-dt.timedelta(minutes=1))])
        report=self.build()
        self.assertEqual(report['verified_captured_observations'],2)
        self.assertTrue(report['slots'][-1]['capture_verified'])
        self.assertIn('capture',report['slots'][-1]['references'])
        self.assertEqual(report['coverage']['unique_candle_identities'],2)

    def test_tampered_result_cannot_supply_coverage(self):
        folder,_=self.capture(1,stamp(START),bars=[bar(START-dt.timedelta(minutes=1))])
        value=json.loads((folder/'result.json').read_text())
        value['capture']['bars'][0]['close']='tampered'
        write(folder/'result.json',value)
        report=self.build()
        self.assertEqual(report['verified_captured_observations'],0)
        self.assertEqual(report['coverage']['unique_candle_identities'],0)
        self.assertEqual(report['slots'][0]['status'],'CAPTURED')
        self.assertFalse(report['slots'][0]['capture_verified'])
        self.assertIn('differs',report['slots'][0]['issues'][0])

    def test_wrong_plan_pin_not_verified(self):
        folder,_=self.capture(1,stamp(START))
        value=json.loads((folder/'end.json').read_text());value['plan_sha256']='bad'
        write(folder/'end.json',value)
        self.assertFalse(self.build()['slots'][0]['receipt_verified'])

    def test_partial_and_blocked_statuses_not_counted_as_captured(self):
        self.capture(1,stamp(START),status='PARTIAL',bars=[bar(START-dt.timedelta(minutes=1))])
        self.capture(2,self.plan['slots'][1],status='BLOCKED')
        report=self.build()
        self.assertEqual(report['verified_captured_observations'],0)
        self.assertEqual(report['counts']['PARTIAL'],1)
        self.assertEqual(report['counts']['BLOCKED'],1)
        self.assertEqual(report['coverage']['unique_candle_identities'],1)

    def test_missed_and_interrupted_do_not_invent_capture(self):
        folder=self.state/'slot-001'
        write(folder/'end.json',{'slot':1,'scheduled_at':stamp(START),'status':'MISSED','plan_sha256':'supplement-pin'})
        write(folder/'result.json',{'id':'attempt_missed'})
        write(folder/'integrity.json',{'integrity':{'ok':True},'summary':{'records':[{'id':'attempt_missed'}]}})
        write(self.state/'slot-002/begin.json',{})
        report=self.build()
        self.assertTrue(report['slots'][0]['receipt_verified'])
        self.assertFalse(report['slots'][0]['capture_verified'])
        self.assertEqual(report['slots'][1]['status'],'STARTED_WITHOUT_COMPLETION')

    def test_overlap_is_deduplicated_and_actual_gap_reported(self):
        rows=[bar(START),bar(START),bar(START+dt.timedelta(minutes=2))]
        report=coverage(rows,['BTCUSDT'],START,START+dt.timedelta(minutes=3))
        self.assertEqual(report['retained_bar_rows'],3)
        self.assertEqual(report['unique_candle_identities'],2)
        self.assertEqual(report['overlapping_bar_rows'],1)
        gaps=report['by_symbol'][0]['gaps_in_due_lookback_target']
        self.assertEqual(gaps,[{'start_at':stamp(START+dt.timedelta(minutes=1)),
                              'end_at':stamp(START+dt.timedelta(minutes=2)), 'missing_minutes':1}])

    def test_same_identity_different_price_flagged(self):
        report=coverage([bar(START),bar(START,close='2')],['BTCUSDT'],START,START)
        self.assertEqual(report['conflicting_candle_identities'],1)

    def test_future_slots_pending_no_false_gap(self):
        report=self.build(now=START-dt.timedelta(seconds=1))
        self.assertEqual(report['counts'],{'PENDING':8})
        self.assertEqual(report['coverage']['by_symbol'][0]['gaps_in_due_lookback_target'],[])

    def test_clock_unknown_without_additive_file(self):
        self.capture(1,stamp(START))
        clock=self.build()['slots'][0]['clock']
        self.assertEqual(clock['status'],'UNKNOWN_LEGACY_OFFSET_INVALID')
        self.assertIsNone(clock['system_correction_seconds'])

    def test_clock_correction_explicit_with_hashed_reference(self):
        folder,_=self.capture(1,stamp(START))
        write(folder/'clock-corrections.json', {'records':[
            {'status':'DERIVED_FROM_RETAINED_RAW','system_correction_seconds':'0.000001',
             'original_sha256':'clock-hash','observed_at':stamp(START)}]})
        row=self.build()['slots'][0]
        self.assertEqual(row['clock']['status'],'DERIVED_FROM_RETAINED_RAW')
        self.assertEqual(row['clock']['system_correction_seconds'],'0.000001')
        self.assertIn('clock_corrections',row['references'])

    def test_source_mutation_rejected_before_verifier_import(self):
        source=self.root/'source'
        write(source/'SOURCE_MANIFEST.json', {'commit':SOURCE_COMMIT,'files':{'intraday.py':{'sha256':'pinned'}}})
        (source/'intraday.py').write_text('tampered')
        with self.assertRaisesRegex(ValueError,'integrity mismatch'):
            source_verifier(source)


if __name__=='__main__':
    unittest.main()
