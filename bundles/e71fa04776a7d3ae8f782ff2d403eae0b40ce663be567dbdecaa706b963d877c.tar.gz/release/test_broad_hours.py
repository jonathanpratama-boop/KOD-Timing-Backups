"""Offline complete-hour/availability tests; no collector or provider requests."""
import copy
import datetime as dt
from decimal import Decimal
import json
import unittest

from broad_observer.hours import assemble_hour

UTC = dt.timezone.utc
EPOCH = dt.datetime(1970, 1, 1, tzinfo=UTC)


def iso(value):
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


def millis(value):
    return int((value - EPOCH).total_seconds()) * 1000


def record(hour, minute, *, received=None, symbol="BTCUSDT"):
    opening = hour + dt.timedelta(minutes=minute)
    receipt = received or opening + dt.timedelta(minutes=1, milliseconds=7)
    t = millis(opening)
    price = Decimal("100.00") + Decimal(minute) / 10
    candle = {"s": symbol, "i": "1m", "x": True, "t": t, "T": t + 59999,
        "o": str(price), "h": str(price + 2), "l": str(price - 1), "c": str(price + 1),
        "v": "0.10", "q": "10.25", "V": "0.04", "Q": "4.10",
        "n": minute + 1, "f": minute * 100, "L": minute * 100 + minute}
    source = {"stream": symbol.lower() + "@kline_1m", "data": {
        "e": "kline", "s": symbol, "E": t + 60001, "k": candle}}
    return {"symbol": symbol, "received_at": iso(receipt), "first_received_at": iso(receipt),
        "open_at": iso(opening), "close_at": iso(opening + dt.timedelta(milliseconds=59999)),
        "source": source, "raw": json.dumps(source, separators=(",", ":")).encode()}


def replace_candle(item, **changes):
    value = copy.deepcopy(item)
    value["source"]["data"]["k"].update(changes)
    value["raw"] = json.dumps(value["source"], separators=(",", ":")).encode()
    return value


class ReceivedHourTests(unittest.TestCase):
    def setUp(self):
        self.start = dt.datetime(2026, 11, 5, 12, tzinfo=UTC)
        self.boundary = self.start + dt.timedelta(hours=1)
        self.records = [record(self.start, minute) for minute in range(60)]
        self.cutoff = self.boundary + dt.timedelta(seconds=1)

    def hour(self, records=None, as_of=None):
        return assemble_hour(self.records if records is None else records, "BTCUSDT",
                             self.start, self.cutoff if as_of is None else as_of)

    def test_exact_sixty_minutes_aggregate_all_fields(self):
        result = self.hour()
        self.assertEqual(result["status"], "COMPLETE")
        self.assertEqual(result["available_minutes"], 60)
        self.assertEqual(result["available_at"], iso(self.boundary + dt.timedelta(milliseconds=7)))
        hour = result["hour"]
        expected = {"open": "100", "high": "107.9", "low": "99", "close": "106.9",
                    "base_volume": "6", "quote_volume": "615", "taker_buy_base_volume": "2.4",
                    "taker_buy_quote_volume": "246"}
        for field, value in expected.items():
            self.assertEqual(Decimal(hour[field]), Decimal(value), field)
        self.assertEqual(hour["trades"], sum(range(1, 61)))
        self.assertEqual(hour["source_minutes"], 60)
        self.assertEqual(hour["first_received_at"], result["available_at"])
        self.assertFalse(result["strategy_enrollment"])

    def test_one_missing_minute_is_unknown_with_no_partial_sums(self):
        result = self.hour(self.records[:17] + self.records[18:])
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertEqual(result["available_minutes"], 59)
        self.assertEqual(result["missing_minutes"], [iso(self.start + dt.timedelta(minutes=17))])
        self.assertIsNone(result["hour"])
        self.assertIsNone(result["available_at"])

    def test_late_rest_minute_cannot_repair_an_earlier_asof_view(self):
        late_time = self.boundary + dt.timedelta(hours=2)
        records = copy.deepcopy(self.records)
        records[17] = record(self.start, 17, received=late_time)
        records[17]["origin"] = "REST_BACKFILL"
        before = self.hour(records)
        self.assertEqual(before["status"], "UNKNOWN")
        self.assertIsNone(before["hour"])
        after = self.hour(records, late_time + dt.timedelta(seconds=1))
        self.assertEqual(after["status"], "COMPLETE")
        self.assertEqual(after["available_at"], iso(late_time))
        self.assertIn("LATE_MINUTE_AVAILABILITY", after["quality_flags"])
        self.assertEqual(self.hour(records), before)

    def test_future_record_not_parsed_and_cannot_change_prior_view(self):
        expected = self.hour()
        future = {"received_at": iso(self.cutoff + dt.timedelta(hours=1)),
                  "raw": object(), "source_conflict": True}
        self.assertEqual(self.hour(self.records + [future]), expected)

    def test_source_hour_open_is_not_receipt_or_availability(self):
        result = self.hour()
        self.assertNotEqual(result["available_at"], result["hour_open_at"])
        self.assertNotEqual(result["available_at"], result["hour_close_at"])
        self.assertGreater(result["available_at"], result["hour_completed_boundary"])

    def test_out_of_order_input_and_identical_duplicates_keep_first(self):
        duplicate = copy.deepcopy(self.records[10])
        duplicate["received_at"] = iso(self.boundary + dt.timedelta(milliseconds=50))
        duplicate["source"]["data"]["E"] += 40000
        duplicate["raw"] = json.dumps(duplicate["source"], separators=(",", ":")).encode()
        records = self.records + [duplicate]
        result = self.hour(records)
        self.assertEqual(result, self.hour(list(reversed(records))))
        self.assertEqual(result["hour"], self.hour()["hour"])
        self.assertEqual(result["duplicate_minutes"], [{"open_at": iso(self.start + dt.timedelta(minutes=10)),
                                                       "additional_identical_records": 1}])

    def test_later_conflicting_values_do_not_overwrite_first_minute(self):
        changed = replace_candle(self.records[59], c="150", h="200")
        changed["received_at"] = iso(self.boundary + dt.timedelta(milliseconds=20))
        result = self.hour([changed] + self.records)
        self.assertEqual(result["status"], "COMPLETE")
        self.assertEqual(Decimal(result["hour"]["close"]), Decimal("106.9"))
        self.assertEqual(result["available_at"], self.hour()["available_at"])
        self.assertEqual(len(result["conflicting_records"]), 1)
        self.assertIn("SOURCE_CONFLICTS_RETAIN_FIRST", result["quality_flags"])

    def test_archived_conflict_alone_cannot_replace_missing_authority(self):
        changed = replace_candle(self.records[17], c="150", h="200")
        changed["source_conflict"] = True
        records = self.records[:17] + [changed] + self.records[18:]
        result = self.hour(records)
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertEqual(result["available_minutes"], 59)
        self.assertEqual(len(result["conflicting_records"]), 1)

    def test_equal_clock_conflicting_first_versions_are_unknown(self):
        changed = replace_candle(self.records[17], c="150", h="200")
        result = self.hour(self.records + [changed])
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertEqual(result["available_minutes"], 59)
        self.assertIn("AMBIGUOUS_EQUAL_RECEIPT_FIRST_VERSIONS",
                      [item["reason"] for item in result["conflicting_records"]])

    def test_later_duplicate_claim_does_not_backdate_unretained_source(self):
        receipt = self.boundary + dt.timedelta(hours=1)
        records = copy.deepcopy(self.records)
        records[17]["received_at"] = iso(receipt)
        # Earlier claim is present, but its original raw record is not retained.
        self.assertEqual(self.hour(records)["status"], "UNKNOWN")
        after = self.hour(records, receipt)
        self.assertEqual(after["status"], "COMPLETE")
        self.assertEqual(after["available_at"], iso(receipt))
        self.assertIn("UNPROVEN_FIRST_RECEIPT_CLAIMS", after["quality_flags"])

    def test_invalid_source_utc_grid_and_T_leave_minute_missing(self):
        for changes in ({"t": self.records[17]["source"]["data"]["k"]["t"] + 1},
                        {"T": self.records[17]["source"]["data"]["k"]["T"] + 1}):
            records = copy.deepcopy(self.records)
            records[17] = replace_candle(records[17], **changes)
            result = self.hour(records)
            self.assertEqual(result["status"], "UNKNOWN")
            self.assertEqual(len(result["invalid_records"]), 1)

    def test_interim_and_hourly_warmup_are_not_sixty_closed_minutes(self):
        records = copy.deepcopy(self.records)
        records[17] = replace_candle(records[17], x=False)
        self.assertEqual(self.hour(records)["status"], "UNKNOWN")
        hourly = replace_candle(self.records[0], i="1h", T=millis(self.boundary) - 1)
        result = self.hour([hourly] * 60)
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertEqual(result["available_minutes"], 0)
        self.assertFalse(result["warmup_rest_hour_adapter_implemented"])

    def test_receipt_before_source_close_is_not_usable(self):
        records = copy.deepcopy(self.records)
        records[17]["received_at"] = records[17]["open_at"]
        result = self.hour(records)
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertEqual(result["available_minutes"], 59)

    def test_cannot_complete_hour_before_boundary(self):
        result = self.hour(as_of=self.boundary - dt.timedelta(milliseconds=1))
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertEqual(result["reason"], "HOUR_NOT_COMPLETED_AT_AS_OF")

    def test_exact_decimal_sums_exceed_default28digit_precision(self):
        coefficient = "123456789012345678901234567890123456789"
        fraction = "0." + coefficient
        records = [replace_candle(item, v=fraction, V="0") for item in self.records]
        result = self.hour(records)
        expected = Decimal(str(int(coefficient) * 60) + "e-" + str(len(coefficient)))
        self.assertEqual(result["status"], "COMPLETE")
        self.assertEqual(Decimal(result["hour"]["base_volume"]), expected)

    def test_extreme_decimal_and_boolean_trade_count_are_invalid(self):
        for changes in ({"v": "1e1000000"}, {"n": True}, {"Q": "100"}):
            records = copy.deepcopy(self.records)
            records[17] = replace_candle(records[17], **changes)
            self.assertEqual(self.hour(records)["status"], "UNKNOWN")

    def test_raw_and_decoded_source_mismatch_cannot_create_bar(self):
        records = copy.deepcopy(self.records)
        records[17]["source"]["data"]["k"]["q"] = "12345"
        self.assertEqual(self.hour(records)["status"], "UNKNOWN")

    def test_normalized_closed_minutes_and_raw_reconstruction_agree(self):
        flat = []
        names = {"open": "o", "high": "h", "low": "l", "close": "c", "base_volume": "v",
                 "quote_volume": "q", "taker_buy_base_volume": "V", "taker_buy_quote_volume": "Q"}
        for record_ in self.records:
            k = record_["source"]["data"]["k"]
            flat.append({"symbol": "BTCUSDT", "closed": True, "open_ms": k["t"], "close_ms": k["T"],
                "received_at": record_["received_at"], "first_received_at": record_["first_received_at"],
                "trades": k["n"], "first_trade_id": k["f"], "last_trade_id": k["L"],
                **{field: k[native] for field, native in names.items()}})
        self.assertEqual(self.hour(flat), self.hour())

    def test_naive_clocks_and_nonhour_open_are_rejected(self):
        with self.assertRaises(ValueError):
            assemble_hour(self.records, "BTCUSDT", self.start.replace(tzinfo=None), self.cutoff)
        with self.assertRaises(ValueError):
            assemble_hour(self.records, "BTCUSDT", self.start + dt.timedelta(minutes=1), self.cutoff)


if __name__ == "__main__":
    unittest.main()
