# R2 prospective research start — operational amendment

Recorded 5 November 2026, before the new research release and prospective start.

The owner was informed that the cloud collector was a reliability test and that
the 30-day research study had not started. The owner then repeatedly instructed
“turn it on” and “Fix it for me.” This amendment implements that instruction by
starting a separately identified prospective research period once the research
runner and essential resource, integrity and isolation checks are ready. It
replaces the earlier requirement to wait for a successful 48-hour capacity verdict.

The capacity run that began at 2026-11-05T08:27:00Z has **not passed**. Its original
48-hour denominator, missing observations, interruptions, repairs and actual
closure remain preserved. Its data are engineering observations, never admissions
or outcomes in the new prospective cohort. At handoff, only that new capacity
collector and its own housekeeping may be stopped to avoid duplicate acquisition.
The original and supplemental collectors, their frozen files, state, accounts,
services, schedules and watchdogs remain untouched.

`PROTOCOL_R2.md` remains preserved at SHA-256
`0950356e3f7c894cab0d98eef3c9e030c24cca7c4efdd03df76fb19464a1e4f2`.
The amendment changes launch ordering only. The fixed universe, causal hourly
trigger and cooldown, receipt-time replay, schedule phases, first-fresh-quote
rules, common event exit deadlines, control selection, missingness, costs and
24-hour primary / 120-hour secondary / 72-hour diagnostic outcomes remain R2.
The experiment is paper research and has no orders or automatic trading promotion.

A new future whole-minute T0 is bound in the release/configuration before its first
prospective observation. Admissions end exactly 30 days later. Quote collection
ends at T0 + 35 days + 120 seconds; any subsequent finalization is write-only.
Historical hourly/daily warmup may initialize features only after its actual
receipt and before T0. It cannot create pre-T0 discoveries, repair missed live
observations or suppress inconvenient later events. Missing warmup remains UNKNOWN.

The measured full-period storage projection, hard byte/file/inode limits, combined
192 MiB memory / 10% one-core CPU envelope, 2 GiB free reserve, provider stop rules,
immutable raw evidence, non-overlap and protected-worker checks remain essential.
No new credentials, access grants, paid resources, paid model calls or account
allocation are authorized by this amendment. Backups use the already authorized
private repository and key, under a separate research branch.

Incomplete operational demonstrations and unmet coverage targets remain visible
in research health. Restoration, independent monitor execution and stopped-feed
alert evidence are reported individually; configured routes are not claims that
delivery was demonstrated. Starting research does not retrospectively satisfy any
of those checks or certify flawless reliability. Poor coverage limits the usable
comparisons and must be reported, without retuning, extending the admission period
or silently repairing history.

The official GMX source lane is separately reported. Source collection is not
semantic acceptance. No economic episode is enrolled without its complete
evidence, actual adjudication delay, declared liquidity/history eligibility and
valid fresh entry. An uncovered or unready source remains NOT_COVERED or pending;
it does not become a negative catalyst observation.

The launch receipt must identify the exact release, protocol/amendment, universe,
source, warmup and replay hashes; T0 and fixed end times; capacity closure; first
captured data and actual prospective runner records; backup acknowledgement;
resource measurements; and original/supplement preservation results. An enabled
timer or a running capture process alone is not a live-research claim.
