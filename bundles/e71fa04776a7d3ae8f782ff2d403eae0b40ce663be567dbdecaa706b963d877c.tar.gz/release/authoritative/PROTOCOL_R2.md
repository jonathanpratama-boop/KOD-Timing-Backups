# AUTHORITATIVE REVISED PROTOCOL R2 — 5 November 2026

This protocol replaces prior incremental design instructions wherever they conflict. The user's attached “Pasted text(5).txt”, Library ID `libfile_9f2ad234facc819194b89e8964cdacfd`, is controlling intent. Its verified SHA-256 is `145a17f1c9714c32b97ae50e1973e58921acd829443fd3e23c27e11d4328e780`. Preserve prior prototypes/protocols as superseded, unlaunched work. Do not run competing primary tests.

## Authorization and boundary

Trusted user history: “Get the machine to test current market live and set the period. Is that best?”; “Surely there are at least some big movers right? and i need the machine to learn as fast as it can. I need you to decide the proper variables of this experiment”; “i want to make use of my paid cloud server too”; “apply this”; “do not make any mistakes”. The last two messages concern the attached revised design.

Implement only a NEW isolated observation/capacity trial and later cohort. Do not modify, restart, reconfigure, reschedule or write into either existing original/supplement collector, their frozen releases, accounts or watchdogs. No orders, account allocation, new credentials/access, paid services or additional paid model calls without required approval. Continue permitted work, and report exact denied/pending/uncertain actions rather than circumventing restrictions. Do not claim perfection or LIVE without evidence.

## 1. Purpose and scientific limit

Measure data reliability, actual information/detection delay and remaining market opportunity. This is not another optimized price/volume/pressure/listing entry strategy. Preserve the closed research decision. Recording OHLCV, trades and taker-buy fields is allowed; creating a new minute-pressure rule is not part of this protocol. Use the unchanged causal IGNITION detector for timing replay only. A large observed peak is not an achieved fill or profit, and millions of correlated quotes are not independent trials. No alpha pass or trading promotion from this short study.

## 2. Phases and clocks

First run a fixed 48-hour isolated capacity trial, with a technical checkpoint at 24 hours. Choose and record a fresh future Tcap only after its basic tests, manifests, source access and safety setup are ready. Capacity observations are engineering evidence and will never be relabelled as the later primary cohort. A real 24-hour connection renewal, daily rotations and backup cycles must be observed.

After all capacity gates pass, freeze the final release/protocol/universe/source/replay hashes and choose a new future T0. Admit new market events and economic cases for exactly 30 days. Continue collecting through T0+35 days plus the fixed 120-second endpoint tolerance. End admissions on schedule; no extension to rescue outcomes. Day 7 of the full cohort reports coverage, event frequency and timing. Final outcomes mature around day 35. If sources are sparse, report that instead of postponing the whole market study indefinitely.

## 3. Fixed universe and detail panel

Select up to 150 TRADING spot-USDT assets before outcomes using at least 90 completed daily bars and the preceding 30 completed days' median quote volume of at least 1,000,000 USDT. Rank by that median, with deterministic symbol tie-break. Exclude stablecoins, leveraged tokens and wrapped duplicates through an explicit manifest. Verify history for all otherwise eligible candidates, not a shortlist chosen by today's gain. Disclose unavailable histories; do not claim exhaustive ranking if incomplete. BTCUSDT and ETHUSDT are collected as benchmarks regardless of rank. Preserve delistings, outages and membership changes; do not substitute later winners into the fixed primary universe.

Choose five detail assets before Tcap: BTC, ETH and GMX where valid, plus the next highest-liquidity eligible names until five are filled. If one required name is unavailable, document it and fill deterministically from the ranking. Keep the panel fixed through the trial/cohort unless a technical failure requires a separately versioned, disclosed change. The GMX source case may have a separately declared fixed quote pair outside the primary 150, but no hidden expansion.

## 4. Collection architecture

Use one isolated observer architecture and shared evidence archive, reusing tested components.

- Broad panel: completed one-minute OHLCV, base/quote volume, trade count and available taker-buy base/quote volume. Retain exchange bar-open/bar-close clocks plus actual first receipt. A combined kline websocket is a candidate, not a presumed capacity pass: measure all partial-update wire/parse load, retain closed-bar evidence, handle documented ping/pong and 24-hour renewal. A bounded REST adapter is an acceptable transport alternative if measured safer. Never infer earlier knowledge from later historical retrieval.
- Retain a lightweight one-minute BBO capture for the primary universe, so first eligible recorded quotes exist beyond the five detail assets.
- Detail panel: target five-second BBO, displayed bid/ask sizes and request/receipt clocks for the fixed five. This is conditional on capacity, not a reason to begin detail capture only after a spike.
- Source collection: fixed independent official GMX/economic feeds, target five-minute polling where permitted, with publication, first receipt, approval, implementation, purchase and acceptance separately recorded. Collection must not depend on whether the token moved. Freeze verified protocol/token/source identities. Unknown or uncovered evidence remains NOT_COVERED, not 'no catalyst'.
- Hourly activity statistics and daily filtered metadata are context. Include BTC/ETH in each split BBO batch, with deterministic benchmark deduplication. No stale cached benchmark legs. Quote-unit cash and the liquidity floor are denominated in USDT, not guaranteed USD.

## 5. Capacity acceptance and safety

At 150 assets over 48 hours, expect 432,000 closed minute bars. On-time means first receipt of a complete final bar no later than 60 seconds after its close. Require at least 99% on-time coverage overall AND per primary asset. Report eventual completeness separately; late recovery never repairs on-time history or earlier replay availability. All induced restart/alert-test gaps remain counted.

For an enabled five-second detail panel, target at least 99% valid expected slots and report latency/missingness separately. Source coverage is separate per registered feed, never pooled into millions of price records.

Require no OOM, increasing backlog or interference with protected collectors; measured full 35-day storage, backup and temporary-space fit; actual restart recovery and restored-byte verification; and an off-server heartbeat check with a demonstrated stopped-collection alert. A local health file alone is not an external alert. Test stopping ONLY the new trial collector, then recover it, preserving the gap.

Use measured conservative caps: target total observer processes within 192 MiB and at most 10% CPU; projected new disk footprint including raw data, derived state, backup copy and temporary packing at most 25% of prelaunch free disk, with at least 2 GiB free reserve. If these cannot be enforced/verified safely, report the exact issue. Prefer reducing duplicate retention or expensive enrichment, or changing transport, before cadence. The attachment permits a declared five-minute fallback if necessary; freeze and disclose it, and do not claim one-minute observability reconstructed from five-minute receipt batches.

Respect provider limits and denials. Do not switch hosts around an access restriction. No overlapping jobs or unbounded catch-up. Record misses and failures. Raw responses may be content-addressed/compressed; derived caches may be bounded/rebuildable. Avoid full-archive rehashing on every tick. Back up immutable chunks incrementally, not repeated complete growing snapshots. Verify the entire footprint and restoration through existing authorized capability.

## 6. Unchanged detector and replay

Use the causal trigger and 72-hour per-token cooldown from IGNITION_SCAN_v0, source commit `c7c84127e94b6debf691d321fa553377dc4af575`, `hermes/ignition_v0/scan_v0.py`. Implement a separately identified prospective adapter with fixture equivalence tests; do not run its whole historical backtest.

Exact hourly trigger: C[t]/C[t−3]−1≥0.10; (Q[t]+Q[t−1]+Q[t−2])/(3×base)≥5; C[t−3]/C[t−171]−1≤0.30; base≥20,000 USDT/hour. base=sum Q[t−170..t−3]/168, requiring at least 150 finite hourly volumes. Preserve the 72-hour trigger-hour cooldown. Minute intake does not turn this into an intra-hour signal. Complete hourly bars come from received closed minutes or declared warmup; missing history remains explicit. Binance's bar-open timestamp is not its close or receipt time.

The historical script's future ±72-hour control exclusion, future-outcome truncation and next-hour-open simulated fills MUST NOT be imported. Warmup known before T0 is allowed but produces no pre-T0 prospective events. Late/corrected data never rewrites already emitted decisions; retain quality flags and unavailable comparisons.

Replay the same received stream at periods 1, 5, 30 and 240 minutes, with schedule phases fixed from T0 before outcomes. At each cutoff reveal only data actually received by that cutoff. Preserve chronological processing and the detector's causal state/cooldown; do not invent missed signals by discarding history or fabricate early knowledge from candle times. Report detection delay, late detections and missed observable opportunities separately. Hourly triggers may make aligned schedules identical; that is a legitimate result. This delayed-information replay does not prove what a separate slower poll would retrieve after ephemeral content disappeared. Do not optimize schedule phases.

## 7. Entry, outcomes, controls and costs

Primary market outcome is 24-hour return; 120-hour return is secondary; 72-hour is diagnostic only. Continuous returns are the main reporting; descriptive +10% at 24h and +20% at 120h labels do not select entries or rescue results.

For timing arms, define the reference event time as when the causal trigger first became observable in the actually received stream. Every arm uses that SAME event time+24h exit deadline, and analogous +120h/+72h deadlines. Each arm's entry is its first eligible fresh recorded BBO after its own decision cutoff. Do not reset the exit clock for slower entry. A valid quote must be newly requested at/after eligibility and received within 120 seconds; choose the first valid one, not the best. At exit, likewise use the first newly requested valid BBO on/after the common deadline and received within 120 seconds. Require finite positive bid/ask, ask≥bid and positive displayed sizes; preserve spreads and request/receipt intervals. Missing entries/exits/benchmark legs remain unavailable, never zero.

For the separate GMX economic case, require actual complete-evidence acceptance, then the first eligible fresh quote under the same 120-second rule. The earlier assumed extra five-minute delay is SUPERSEDED. Its 24h/120h/72h case horizons begin at actual entry; do not mix this denominator with common-deadline timing arms. Retain actual manual/adjudication delay.

Use midpoint-to-midpoint return minus the fixed TWO-PERCENTAGE-POINT all-in round-trip assumption ONCE as the modeled net reference. Show gross token return, nominal cash=0, and fixed-initial-weight 50/50 BTC/ETH gross benchmark over corresponding observed intervals. Do not separately deduct spread in this midpoint-minus-two calculation. A separate ask-entry/bid-exit scenario is quote-based gross execution context, excluding unverified fees/slippage unless explicitly modeled; never call BBO a verified fill.

Choose up to five same-time controls using ONLY preceding momentum and liquidity, before outcomes: preceding 24-hour return and preceding 30 completed days' median quote volume, deterministic nearest percentile-rank distance with symbol tie-break. Exclude the event token, not future movers. Freeze controls at reference-event time and keep them across schedule arms. Retain missing controls/quotes; do not replace them with later convenient examples. Controls and subgroup results cannot rescue the primary outcome.

## 8. Economic eligibility and reporting

GMX remains a separate source case, not the success condition for the market study. Qualifying new policies require verified old/new policy, implementation, actual native-token purchase and external-fee funding evidence. Repeated purchases under one unchanged historical policy are not independent new episodes. Deduplicate by protocol/token/policy version. Historical/bootstrap policies are not new discoveries. Complete acceptance AND valid entry must occur before the 30-day cutoff; late cases stay excluded-late without extension.

Keep all scheduled attempts, losses, rejected/pending cases, unavailable entries, censored outcomes and missing sources in their proper denominators. Show quote count, distinct assets, events, policy episodes and dates separately. Account for token/date dependence; do not promise significance from a short timer. 'Information before future return' is separate from 'before confirmation' or 'before any reaction'. Preserve prior observed return/path and missing warmup; do not infer an unexplained cause.

Prepare compact evidence packets and matured outcomes for later LLM review, retaining original judgments. Do not alter frozen LLM_ARM schedules/call budgets or launch paid analysis per candle. New strategy changes require a later prospective version, not edits to this active cohort.

## 9. Launch evidence and next report

Before claiming the capacity trial is running, show its exact release/protocol/manifest hashes, Tcap/end times, selected symbols, measured transport/load/footprint, tested restart/no-overlap/gap behavior, verified backup/restore route, external monitor route, unchanged original/supplement invariants and actual first captured slots. Distinguish tests passed, failed and not yet run. The 48-hour pass can only be claimed after 48 hours of observations and all required demonstrations. Then freeze and start the 30-day cohort without another design-choice question if every gate passes and no new approval is required. Report material blockers promptly and do not silently weaken this protocol.
