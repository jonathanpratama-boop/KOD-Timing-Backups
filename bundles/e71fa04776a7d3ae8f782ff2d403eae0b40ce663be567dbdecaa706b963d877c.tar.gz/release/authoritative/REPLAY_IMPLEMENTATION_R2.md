# R2 replay implementation precision

These details are fixed before the prospective T0. They make receipt handling and
missing-data behavior explicit; they are not selected from future returns.

* The first eligible signal hour opens at the first whole UTC hour on or after
  T0. A partial first hour is not synthesized. Historical warmup initializes
  features only and creates neither historical admissions nor historical cooldowns.
* An hour that is incomplete at its evaluation deadline is UNKNOWN. The reference
  stream settles a missing hour at its close plus 120 seconds so one permanent
  data gap cannot block every subsequent hour. A later completion is retained as
  `LATE_COMPLETE_HOUR` and never rewrites the earlier reference decision. A slower
  arm can therefore have an unmatched trigger; that remains visible rather than
  acquiring an invented earlier reference event. Report this policy and the
  resulting unavailable comparisons alongside complete-hour coverage.
* The four replay schedules have periods 1, 5, 30 and 240 minutes and phases fixed
  from T0. Replay processing waits a fixed 300-second archive grace and advances
  in whole-minute watermarks. This allows the shared acquisition archive to commit
  received packets. Eligibility uses the original actual receipt times, while
  processing/checkpoint clocks remain separately recorded. This is a replay of
  delayed information, not proof that a live order or analyst decision occurred
  at a replay cutoff. Inputs arriving behind a committed watermark are retained
  as late; prior decisions are not rewritten.
* Pre-event momentum for matching is the return between the last complete
  received hourly close and the corresponding close 24 hours earlier. Liquidity
  is the median quote volume of the preceding 30 complete UTC daily bars known
  at the event. Both values must be available; missing values are not substituted
  from later history. Complete received hours may form a daily bar only when all
  24 hours are present. Controls minimize Euclidean distance between average-tie
  percentile ranks of these two features, with symbol tie-break, excluding only
  the event token. Controls are fixed at the reference event and shared by arms.
* First eligible quotes are ordered by actual receipt, with newly initiated
  requests at or after eligibility and receipt within the unchanged inclusive
  120-second window. Actual source timestamps are unknown for bookTicker.
  Benchmarks come from the same batch; a missing benchmark leg leaves excess
  unavailable. Event and quote times, archive time, replay cutoff and processing
  time remain separate.
* Raw packet bytes, configuration, warmup responses and receipt manifests remain
  immutable evidence. The research ledger has append-only transaction boundaries
  and a hash chain. Incremental ledger chunks preserve exact decisions and input
  order for deterministic rebuild. Mutable SQLite working tables are caches;
  they are not repeatedly copied as a growing historical backup.
  Derived minute-coverage deltas use per-index bitmasks in the frozen manifest's
  symbol order. Decoding restores the same observed/missing/on-time sets. Original
  per-message arrival order, source bytes, quote clocks and attempt records remain
  in their immutable packets and are not removed by this representation change.
* The new archive uses deterministic gzip level 9. This changes compression only;
  original source bytes, clocks and validation remain intact. Hourly activity
  context requests exactly the fixed primary symbols, including BTC and ETH, in
  one `symbols` array. It makes no all-exchange activity claim. Minute candles,
  minute broad quotes, five-second detail quotes and official-source cadences
  are unchanged. The public `GET /api/v3/ticker/24hr` array parameter is documented
  in Binance's [official REST specification](https://github.com/binance/binance-spot-api-docs/blob/master/rest-api.md#24hr-ticker-price-change-statistics).
* After the finite capture endpoint, the service may process already received
  records for up to six additional minutes beyond the write-only candle drain.
  It opens no further acquisition window. Final outcomes are committed from the
  closed archive, including observations received in the last endpoint tolerance.

The original trigger equations, 72-hour trigger-hour cooldown, admissions cutoff,
common exit deadlines and all-in two-percentage-point cost assumption remain
unchanged. Source collection continues independently; economic enrollment remains
disabled until its separate evidence and eligibility requirements are met.
