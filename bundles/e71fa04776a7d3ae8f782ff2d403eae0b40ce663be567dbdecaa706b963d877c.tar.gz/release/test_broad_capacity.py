import datetime as dt
from concurrent.futures import Future
import json
from pathlib import Path
import tempfile
import unittest

from broad_observer.capacity import CapacityController, OverlappingWorker, read_closed_messages
from broad_observer.packets import unpack_attempts,pack_attempts
from broad_observer.store import BroadStore, canonical, iso, UTC, IntegrityError


class Clock:
    def __init__(self): self.value = dt.datetime(2026, 11, 5, 8, tzinfo=UTC)
    def __call__(self): return self.value
    def mono(self): return self.value.timestamp()
    def advance(self, seconds): self.value += dt.timedelta(seconds=seconds)


class InlineExecutor:
    def submit(self, callback, **kwargs):
        future = Future()
        try: future.set_result(callback(**kwargs))
        except BaseException as exc: future.set_exception(exc)
        return future


class HeldExecutor:
    def __init__(self): self.tasks = []
    def submit(self, callback, **kwargs):
        future = Future(); self.tasks.append((future, callback, kwargs)); return future


class Stream:
    def __init__(self): self.queue = []; self.events = []; self.state = 'NEW'; self.renewal = False; self.starts = 0; self.stops = 0
    def start(self): self.starts += 1; self.state = 'CONNECTED'
    def stop(self): self.stops += 1; self.state = 'STOPPED'
    def drain(self, max_items=300): result,self.queue=self.queue[:max_items],self.queue[max_items:]; return result
    def drain_events(self, max_items=512): result,self.events=self.events[:max_items],self.events[max_items:]; return result
    def health(self): return {'state': self.state, 'renewal_due': self.renewal, 'provider_blocked': False, 'queue_items': len(self.queue), 'queue_bytes': 0}
    poll = health


class Rest:
    def __init__(self, clock): self.clock = clock; self.calls = []
    def _call(self, kind, symbols, target_at):
        self.calls.append((kind, target_at))
        started = self.clock(); self.clock.advance(.02)
        rows = [{'symbol': symbol, 'bid': '1', 'ask': '2', 'bidQty': '3', 'askQty': '4'} for symbol in symbols]
        return {'status': 'OK', 'raw_http': [{'body': canonical(rows), 'request_started_at': iso(started),
                'received_at': iso(self.clock()), 'status': 'OK', 'http_status': 200}], 'summary': {'rows': rows}}
    def broad(self, **kwargs): return self._call('broad', **kwargs)
    def detailed(self, **kwargs): return self._call('detailed', **kwargs)


class MemoryStore:
    """Fast journal interface for the fixed-duration state-machine test only."""
    def __init__(self, root, clock): self.root=Path(root); self.root.mkdir(); self.clock=clock; self.events=[]; self.summaries={}
    def append_batch(self, identity, scheduled_at, status, raw_http, summary, *, kind):
        day=iso(scheduled_at)[:10];seq=sum(event['day']==day for event in self.events)
        ref={'id':len(self.events)};self.summaries[ref['id']]=json.loads(canonical(summary))
        event={'day':day,'seq':seq,'kind':kind,'normalized_object':ref,'recorded_at':iso(self.clock()),'status':status,'batch_id':identity}
        self.events.append(event);return event
    def iter_batches(self, day, after_seq=0, limit=10000): return [event for event in self.events if event['day']==day and event['seq']>=after_seq][:limit]
    def read_summary(self, receipt): return self.summaries[receipt['normalized_object']['id']]


class CapacityTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(); self.addCleanup(self.directory.cleanup)
        self.clock = Clock(); self.t0 = self.clock()
        self.store = BroadStore(Path(self.directory.name)/'store', clock=self.clock)
        self.rest = Rest(self.clock); self.streams = []
        self.config = {'trial_id': 'test-capacity', 't0': iso(self.t0), 'duration_hours': 48,
            'primary_symbols': ['BTCUSDT', 'ETHUSDT'],
            'detailed_symbols': ['BTCUSDT', 'ETHUSDT', 'GMXUSDT', 'BNBUSDT', 'SOLUSDT'],
            'selection_manifest_sha256': 'a'*64}
        self.controllers = []
        self.addCleanup(lambda: [controller.close() for controller in self.controllers])

    def factory(self, symbols):
        stream = Stream(); self.streams.append(stream); return stream

    def controller(self, **kwargs):
        controller = CapacityController(self.config, self.store, self.factory, self.rest,
            clock=self.clock, monotonic=self.clock.mono, executor=kwargs.pop('executor', InlineExecutor()), **kwargs)
        self.controllers.append(controller); return controller

    def bar(self, symbol, minute=0, receipt=None, raw=None):
        opened = self.t0+dt.timedelta(minutes=minute); closed = opened+dt.timedelta(seconds=59, milliseconds=999)
        source={'s':symbol,'E':int((closed+dt.timedelta(milliseconds=10)).timestamp()*1000),
                'k':{'x':True,'t':int(opened.timestamp()*1000),'T':int(closed.timestamp()*1000),
                     'o':'1','h':'2','l':'1','c':'2','v':'3','q':'4','n':5,'V':'1','Q':'2'}}
        return {'symbol': symbol, 'closed': True, 'open_at': iso(opened), 'close_at': iso(closed),
            'source_event_at': iso(closed+dt.timedelta(milliseconds=10)),
            'received_at': iso(receipt or self.clock()), 'raw': raw or canonical(source),
            'open':'1','high':'2','low':'1','close':'2','base_volume':'3','quote_volume':'4',
            'trades':5,'taker_buy_base_volume':'1','taker_buy_quote_volume':'2'}

    def first_minute(self, controller):
        controller.step()
        for slot in range(1, 12):
            self.clock.value = self.t0+dt.timedelta(seconds=5*slot); controller.step()
        self.clock.value = self.t0+dt.timedelta(seconds=60)
        for symbol in self.config['primary_symbols']: self.streams[-1].queue.append(self.bar(symbol))
        controller.step()
        self.clock.value = self.t0+dt.timedelta(seconds=120); controller.step()

    def end_events(self):
        return [event for event in self.store.iter_batches('2026-11-05') if event['kind']=='capacity_minute_end']

    def test_exact_source_and_receipt_clock_coverage_and_one_minute_container(self):
        controller = self.controller(); self.first_minute(controller)
        coverage = controller.coverage()
        self.assertEqual(coverage['settled_minutes'], 1)
        self.assertEqual(coverage['pooled_on_time_coverage'], 1)
        self.assertTrue(coverage['every_detailed_at_least_99pct'])
        event = self.end_events()[0]
        self.assertEqual(len(event['requests']), 1)
        packed = self.store.read_object(event['requests'][0]['body_object'])
        members = unpack_attempts(packed)
        self.assertEqual(len(members), 14)  # 12 fixed-five + 1 broad + 1 WS bundle
        self.assertEqual(pack_attempts(members)[0],packed)
        summary=self.store.read_summary({'normalized_object':event['normalized_object']})
        self.assertNotIn('raw_member_index',summary)
        self.assertEqual(summary['raw_member_count'],14)
        self.assertTrue(all('valid_received_symbols' not in attempt for attempt in summary['http_attempts']))
        self.assertEqual(next(attempt for attempt in summary['http_attempts'] if attempt['kind']=='broad')['valid_received_symbol_count'],2)
        self.assertEqual(len(summary['delta']['broad']),2)
        ws = members[-1]
        self.assertNotIn('request_started_at', ws)
        self.assertEqual(ws['message_count'], 2)
        for record in ws['closed_message_map']:
            raw=ws['body'][record['raw_offset']:record['raw_offset']+record['raw_length']]
            self.assertEqual(json.loads(raw)['s'], record['symbol'])
            self.assertIn('source_event_at', record)

    def test_late_closed_bar_never_repairs_on_time(self):
        controller=self.controller();controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=120, milliseconds=1)
        self.streams[0].queue.append(self.bar('BTCUSDT'))
        controller.step();report=controller.coverage()
        self.assertEqual(report['closed_bars']['BTCUSDT']['eventual'],1)
        self.assertEqual(report['closed_bars']['BTCUSDT']['on_time'],0)
        self.assertFalse(report['every_primary_at_least_99pct'])

    def test_pooled_99_does_not_hide_one_missing_asset(self):
        self.config['primary_symbols']=['X%03dUSDT'%index for index in range(150)]
        controller=self.controller();controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=60)
        self.streams[0].queue.extend(self.bar(symbol) for symbol in self.config['primary_symbols'][:-1])
        controller.step();self.clock.value=self.t0+dt.timedelta(seconds=120);controller.step()
        coverage=controller.coverage()
        self.assertTrue(coverage['pooled_at_least_99pct'])
        self.assertFalse(coverage['every_primary_at_least_99pct'])

    def test_duplicate_final_does_not_double_count(self):
        controller=self.controller();controller.step();self.clock.value=self.t0+dt.timedelta(seconds=60)
        self.streams[0].queue.extend([self.bar('BTCUSDT'),self.bar('BTCUSDT')]);controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=120);controller.step()
        self.assertEqual(controller.coverage()['closed_bars']['BTCUSDT']['eventual'],1)
        rows=read_closed_messages(self.store,self.end_events()[0])
        self.assertEqual([row['classification'] for row in rows],['ON_TIME','DUPLICATE'])
        self.assertEqual(rows[0]['quote_volume'],'4')
        self.assertEqual(rows[0]['trades'],5)
        self.assertEqual(rows[0]['taker_buy_base_volume'],'1')
        summary=self.store.read_summary({'normalized_object':self.end_events()[0]['normalized_object']})
        self.assertNotIn('closed_messages',summary)
        self.assertEqual(summary['closed_message_count'],2)

    def test_no_overlapping_worker_or_same_lane_http(self):
        held=HeldExecutor();first=self.controller(executor=held);first.step()
        second=self.controller()
        with self.assertRaises(OverlappingWorker): second.start()
        self.clock.value=self.t0+dt.timedelta(seconds=5);first.step()
        self.assertEqual(len(held.tasks),2)
        self.assertEqual(first.buckets[0]['attempts']['detailed:1']['status'],'MISSED_BUSY')

    def test_durable_start_precedes_http(self):
        controller=self.controller()
        original=self.rest.detailed
        def inspected(**kwargs):
            progress=json.loads(controller.progress_path.read_bytes())
            self.assertEqual(progress['minutes']['0']['attempts']['detailed:0']['status'],'STARTED')
            self.assertTrue(any(event['kind']=='capacity_minute_begin' for event in self.store.iter_batches('2026-11-05')))
            return original(**kwargs)
        self.rest.detailed=inspected
        controller.step()
        self.assertEqual(controller.buckets[0]['attempts']['detailed:0']['status'],'OK')

    def test_idle_poll_does_not_reserialize_or_rewrite_progress(self):
        controller=self.controller();controller.step()
        before=controller.progress_path.stat().st_mtime_ns
        writes=controller.progress_atomic_writes
        self.clock.advance(.25);controller.step()
        self.clock.advance(.25);controller.step()
        self.assertEqual(controller.progress_path.stat().st_mtime_ns,before)
        self.assertEqual(controller.progress_atomic_writes,writes)

    def test_begin_cache_is_shared_but_target_and_actual_clocks_remain_in_journal(self):
        controller=self.controller();controller.step()
        self.clock.value=self.t0+dt.timedelta(minutes=1);controller.step()
        begins=[event for event in self.store.iter_batches('2026-11-05') if event['kind']=='capacity_minute_begin']
        self.assertEqual(len(begins),2)
        self.assertEqual(begins[0]['normalized_object'],begins[1]['normalized_object'])
        for event in begins:
            summary=self.store.read_summary({'normalized_object':event['normalized_object']})
            self.assertEqual(summary['schema'],'CAPACITY_BEGIN_V2_SHARED_CONTENT')
            self.assertEqual(event['batch_id'].split(':begin:')[1][:10],'2026-11-05')
            self.assertTrue(event['recorded_at'])
            self.assertNotIn('target_minute_at',summary);self.assertNotIn('started_at',summary)

    def test_provider_block_is_persistent_and_stops_all_other_starts(self):
        class Blocked(Exception): provider_blocked=True;raw_handshake=b'HTTP/1.1 451 blocked\r\n\r\n'
        def blocked(symbols): raise Blocked('blocked')
        controller=self.controller();controller.stream_factory=blocked
        report=controller.step()
        self.assertEqual(report['phase'],'PROVIDER_STOPPED')
        self.assertEqual(self.rest.calls,[])
        self.assertTrue(controller.provider_path.exists())
        controller.close()
        restored=self.controller();restored.start()
        self.assertEqual(restored.state['phase'],'PROVIDER_STOPPED')
        self.assertEqual(len(self.streams),0)

    def test_operator_pause_prevents_connection_and_rest(self):
        (self.store.root/'PAUSED.json').write_text('{}')
        controller=self.controller();report=controller.step()
        self.assertEqual(report['phase'],'PAUSED');self.assertEqual(self.rest.calls,[]);self.assertEqual(self.streams,[])

    def test_renewal_closes_old_connection_then_requires_new_closed_receipt(self):
        controller=self.controller();controller.step()
        original=self.streams[0];original.renewal=True
        self.clock.advance(5);controller.step()
        self.assertEqual(original.stops,1);self.assertEqual(len(self.streams),2)
        self.assertEqual(controller.state['renewals_started'],1)
        self.assertEqual(controller.state['renewals_completed'],0)
        self.clock.value=self.t0+dt.timedelta(seconds=60)
        self.streams[1].queue.append(self.bar('BTCUSDT'));controller.step()
        self.assertEqual(controller.state['renewals_completed'],1)

    def test_queue_overflow_is_visible_not_no_events(self):
        controller=self.controller();controller.step()
        self.streams[0].events.append({'kind':'queue_overflow','count':3,'received_at':iso(self.clock())})
        controller.step()
        self.assertEqual(controller.heartbeat()['queue_overflows'],3)

    def test_crash_after_raw_commit_replays_delta_without_refetch(self):
        controller=self.controller();controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=60)
        self.streams[0].queue.append(self.bar('BTCUSDT'));controller.step()
        saved=controller._save_state
        def crash():
            if controller.state['next_minute']:
                raise RuntimeError('after durable raw batch, before state checkpoint')
            return saved()
        controller._save_state=crash
        self.clock.value=self.t0+dt.timedelta(seconds=120)
        with self.assertRaises(RuntimeError):controller.step()
        # Model process death: release OS resources without a graceful state save.
        controller._save_state=saved
        controller.close_sources();controller._release_job_lock()
        restored=self.controller();restored.start()
        self.assertEqual(restored.state['next_minute'],1)
        self.assertEqual(restored.coverage()['closed_bars']['BTCUSDT']['on_time'],1)
        self.assertEqual(len(self.end_events()),1)

    def test_restart_retains_lost_inflight_attempt_as_unknown(self):
        first=self.controller();first.step();first.close()
        before=len(self.rest.calls)
        self.clock.value=self.t0+dt.timedelta(seconds=3)
        restored=self.controller();restored.step()
        self.assertEqual(len(self.rest.calls),before)
        self.assertEqual(restored.buckets[0]['attempts']['detailed:0']['status'],'LOST_RECEIPT_OR_UNCERTAIN_AFTER_RESTART')

    def test_source_windows_reject_old_future_and_nonfinal(self):
        controller=self.controller();controller.step();self.clock.value=self.t0+dt.timedelta(seconds=60)
        old=self.bar('BTCUSDT',minute=-1);future=self.bar('BTCUSDT',minute=3000);nonfinal=self.bar('BTCUSDT');nonfinal['closed']=False
        self.streams[0].queue.extend([old,future,nonfinal]);controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=120);controller.step()
        self.assertEqual(controller.coverage()['closed_bars']['BTCUSDT']['eventual'],0)

    def test_source_conflict_or_unknown_first_cannot_count_on_time(self):
        controller=self.controller();controller.step();self.clock.value=self.t0+dt.timedelta(seconds=60)
        conflict=self.bar('BTCUSDT');conflict['source_conflict']=True
        unknown=self.bar('ETHUSDT');unknown['old_bar_first_receipt_unknown']=True
        self.streams[0].queue.extend([conflict,unknown]);controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=120);controller.step()
        self.assertEqual(controller.coverage()['pooled_on_time_coverage'],0)

    def test_cached_before_target_http_is_not_fresh(self):
        controller=self.controller()
        attempt={'status':'OK','target_at':iso(self.t0),'request_started_at':iso(self.t0-dt.timedelta(seconds=1)),
            'receipt_at':iso(self.t0+dt.timedelta(seconds=1)),
            'result_summary':{'rows':[{'symbol':'BTCUSDT','bid':'1','ask':'2','bidQty':'1','askQty':'1'}]}}
        self.assertEqual(controller._valid_symbols(attempt,['BTCUSDT'],5),[])

    def test_source_notice_binary_payload_survives_raw_container(self):
        controller=self.controller();controller.step()
        self.streams[0].events.append({'kind':'server_shutdown','received_at':iso(self.clock()),'raw':b'{"shutdown":true}'})
        controller.step();self.clock.value=self.t0+dt.timedelta(seconds=120);controller.step()
        event=self.end_events()[0]
        members=unpack_attempts(self.store.read_object(event['requests'][0]['body_object']))
        self.assertTrue(any(member.get('body')==b'{"shutdown":true}' for member in members))

    def test_context_quotes_cannot_fill_broad_denominator_and_source_denial_is_local(self):
        controller=self.controller();controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=5)
        def catalyst(**kwargs):
            return {'status':'NOT_COVERED','requires_operator_review':True,'raw_http':[],
                    'summary':{'source_feed_quality':{'gmx-forum':'DENIED'},'source_archive_event_ref':'evidence:123'}}
        self.rest.catalyst=catalyst
        controller.step()
        self.assertFalse(controller.provider_path.exists())
        self.assertEqual(controller.state['latest_registered_feed_coverage'],{'gmx-forum':'DENIED'})
        fake=self.rest.broad(symbols=self.config['primary_symbols'],target_at=iso(self.t0))
        controller.buckets[0]['attempts']['broad:0']['status']='FAILED'
        controller.buckets[0]['attempts']['stats:0']={'kind':'stats','slot':0,'status':'OK','target_at':iso(self.t0),
            'request_started_at':iso(self.t0),'receipt_at':iso(self.clock()),'result_summary':fake['summary']}
        self.clock.value=self.t0+dt.timedelta(seconds=120);controller.step()
        self.assertEqual(controller.coverage()['broad_bbo']['BTCUSDT']['valid_received'],0)
        summary=self.store.read_summary({'normalized_object':self.end_events()[0]['normalized_object']})
        source=[attempt for attempt in summary['http_attempts'] if attempt['kind']=='catalyst'][0]
        self.assertEqual(source['context_summary']['source_archive_event_ref'],'evidence:123')

    def test_48h_sources_stop_and_60s_receipt_only_tail_is_finite(self):
        self.store=MemoryStore(Path(self.directory.name)/'finite-fast-store',self.clock)
        controller=self.controller();controller.step()
        self.clock.value=controller.end
        before=len(self.rest.calls);controller.step()
        self.assertEqual(controller.state['phase'],'DRAINING');self.assertEqual(len(self.rest.calls),before)
        self.clock.value=controller.drain_end
        for _ in range(60):
            controller.step()
            if controller.state['phase']=='COMPLETE':break
        self.assertEqual(controller.state['phase'],'COMPLETE')
        self.assertEqual(controller.state['next_minute'],2880)
        self.assertEqual(controller.heartbeat()['coverage']['closed_bars']['BTCUSDT']['expected'],2880)
        before=len(self.rest.calls);self.clock.advance(86400);controller.step();self.assertEqual(len(self.rest.calls),before)

    def test_config_cannot_change_after_initialization(self):
        controller=self.controller();controller.start();controller.close()
        before=controller.state_path.read_bytes()
        self.config['primary_symbols']=['BTCUSDT']
        with self.assertRaises(IntegrityError):self.controller().start()
        self.assertEqual(controller.state_path.read_bytes(),before)

    def test_exact_unicode_exchange_identity_is_retained(self):
        self.config['primary_symbols']=['币安人生USDT']
        controller=self.controller();controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=60)
        self.streams[0].queue.append(self.bar('币安人生USDT'));controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=120);controller.step()
        self.assertEqual(controller.coverage()['closed_bars']['币安人生USDT']['on_time'],1)

    def test_completed_response_after_final_commit_is_diagnostic_not_dropped(self):
        controller=self.controller();controller.start()
        controller.state['next_minute']=2880;controller.state['phase']='COMPLETE'
        future=Future();future.set_result(self.rest.detailed(symbols=self.config['detailed_symbols'],target_at=iso(self.t0)))
        controller.futures['detailed']={'future':future,'index':0,'key':'detailed:0'}
        controller._collect_futures()
        events=[event for event in self.store.iter_batches('2026-11-05') if event['kind']=='capacity_diagnostic']
        self.assertEqual(len(events),1)
        members=unpack_attempts(self.store.read_object(events[0]['requests'][0]['body_object']))
        self.assertTrue(members[0]['body'])
        self.assertEqual(controller.state['next_minute'],2880)

    def test_running_request_keeps_job_lock_until_completed_bytes_are_retained(self):
        held=HeldExecutor();controller=self.controller(executor=held);controller.step()
        future,callback,kwargs=held.tasks[0]
        self.assertTrue(future.set_running_or_notify_cancel())
        controller.close()
        second=self.controller()
        with self.assertRaises(OverlappingWorker):second.start()
        future.set_result(callback(**kwargs))
        self.assertIsNone(controller.lock_fd)
        diagnostics=[event for event in self.store.iter_batches('2026-11-05') if event['kind']=='capacity_diagnostic']
        self.assertTrue(diagnostics)
        members=unpack_attempts(self.store.read_object(diagnostics[-1]['requests'][0]['body_object']))
        self.assertTrue(members[0]['body'])
        second.start()

    def test_graceful_stop_drains_already_received_closed_queue(self):
        controller=self.controller();controller.step()
        self.clock.value=self.t0+dt.timedelta(seconds=60)
        self.streams[0].queue.append(self.bar('BTCUSDT'))
        controller.close()
        diagnostics=[event for event in self.store.iter_batches('2026-11-05') if event['kind']=='capacity_diagnostic']
        self.assertTrue(any(read_closed_messages(self.store,event) for event in diagnostics))
        restored=self.controller();restored.start()
        self.clock.value=self.t0+dt.timedelta(seconds=120);restored.step()
        self.assertEqual(restored.coverage()['closed_bars']['BTCUSDT']['on_time'],1)

    def test_old_connection_stop_race_cannot_satisfy_renewal_receipt(self):
        controller=self.controller();controller.step();old=self.streams[0]
        self.clock.value=self.t0+dt.timedelta(seconds=60)
        stop=old.stop
        def stop_with_final_read(): old.queue.append(self.bar('BTCUSDT'));stop()
        old.stop=stop_with_final_read;old.renewal=True
        controller.step()
        self.assertEqual(controller.state['renewals_completed'],0)
        self.streams[-1].queue.append(self.bar('ETHUSDT'));controller.step()
        self.assertEqual(controller.state['renewals_completed'],1)

    def test_context_lanes_reserve_one_worker_for_detail(self):
        controller=self.controller();controller.step()
        held=HeldExecutor();controller.executor=held
        self.rest.catalyst=lambda **kwargs:{'status':'NOT_COVERED','raw_http':[],'summary':{}}
        self.rest.stats=lambda **kwargs:{'status':'OK','raw_http':[],'summary':{}}
        self.rest.metadata=lambda **kwargs:{'status':'OK','raw_http':[],'summary':{}}
        self.clock.value=self.t0+dt.timedelta(seconds=1);controller.step()
        self.assertEqual(set(controller.futures),{'catalyst'})
        self.clock.value=self.t0+dt.timedelta(seconds=5);controller.step()
        self.assertEqual(set(controller.futures),{'catalyst','detailed'})
        self.assertEqual(len(held.tasks),2)

    def test_complete_utc_hours_exclude_partial_edges_and_require_all_60(self):
        self.t0=self.t0+dt.timedelta(minutes=15);self.config['t0']=iso(self.t0)
        self.clock.value=self.t0+dt.timedelta(hours=48,seconds=60)
        controller=self.controller();controller.start();controller.state['next_minute']=2880
        for symbol in controller.symbols:
            controller.bar_seen[symbol][:]=b'\xff'*len(controller.bar_seen[symbol])
            controller.bar_ontime[symbol][:]=b'\xff'*len(controller.bar_ontime[symbol])
        hour=controller.coverage()['complete_utc_hour_quality']
        self.assertEqual(hour['full_utc_hours_in_declared_48h_window'],47)
        self.assertEqual(hour['matured_utc_hours'],47)
        self.assertEqual(hour['per_asset']['BTCUSDT']['all_60_on_time'],47)
        missed=52;controller.bar_ontime['BTCUSDT'][missed//8]&=~(1<<(missed%8))
        coverage=controller.coverage();hour=coverage['complete_utc_hour_quality']
        self.assertTrue(coverage['every_primary_at_least_99pct'])
        self.assertEqual(hour['per_asset']['BTCUSDT']['all_60_on_time'],46)
        self.assertEqual(hour['per_asset']['BTCUSDT']['all_60_eventual'],47)

    def test_utc_hour_is_not_mature_before_final_bar_receipt_deadline(self):
        controller=self.controller();controller.start();controller.state['next_minute']=60
        self.clock.value=self.t0+dt.timedelta(hours=1,seconds=59)
        self.assertEqual(controller.coverage()['complete_utc_hour_quality']['matured_utc_hours'],0)
        self.clock.advance(1)
        self.assertEqual(controller.coverage()['complete_utc_hour_quality']['matured_utc_hours'],1)


if __name__=='__main__':unittest.main()
