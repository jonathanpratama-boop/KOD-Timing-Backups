"""Offline causal-equation checks; the historical harness is never imported."""
import ast
import copy
import datetime as dt
import hashlib
import inspect
import math
from pathlib import Path
import random
import unittest

from broad_observer.trigger import (CausalTriggerTracker, SOURCE_SHA256,
                                    evaluate_causal, verify_legacy_source)

ROOT = Path(__file__).resolve().parent
LEGACY = ROOT / "authoritative/legacy-ignition-c7c84127/scan_v0.py"
UTC = dt.timezone.utc


def fixture(length=172):
    closes, volumes = [100.0] * length, [20000.0] * length
    closes[-1] = 110.0
    volumes[-3:] = [100000.0] * 3
    return closes, volumes


class At:
    """One grid position for executing only the source's scalar equations."""
    def __init__(self, series, index):
        self.series, self.index = series, index

    def value(self):
        return float(self.series[self.index])

    def __truediv__(self, other):
        return self.value() / other

    def __add__(self, other):
        return self.value() + other


def source_oracle(closes, volumes, index):
    """Execute selected pinned arithmetic AST nodes, not dataset/strategy code.

    The source's prefix-difference baseline is reproduced independently. Only
    finite/NaN market-volume fixtures are used for arithmetic equivalence;
    malformed/infinite inputs have separate UNKNOWN quality tests.
    """
    source = LEGACY.read_bytes()
    if hashlib.sha256(source).hexdigest() != SOURCE_SHA256:
        raise AssertionError("reference source differs")
    tree = ast.parse(source)
    assignments = {node.targets[0].id: node for node in tree.body
                   if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}
    spec = {item.arg: ast.literal_eval(item.value)
            for item in assignments["SPEC"].value.keywords}
    selected = [assignments[name] for name in ("r3", "q3", "vmult", "prior", "liquid", "trig")]
    lo, hi = index - 170, index - 2
    prefix = [0.0]
    finite = []
    for value in volumes[:hi]:
        value = float("nan") if value is None else float(value)
        finite.append(math.isfinite(value))
        prefix.append(prefix[-1] + (value if math.isfinite(value) else 0.0))
    count = sum(finite[lo:hi]) if lo >= 0 else 0
    base = (prefix[hi] - prefix[lo]) / 168.0 if lo >= 0 and count >= 150 else math.nan

    def shift(current, lag):
        position = current.index - lag
        if position < 0:
            return math.nan
        value = current.series[position]
        return float("nan") if value is None else float(value)

    env = {"C": At(closes, index), "Q": At(volumes, index), "shift": shift,
           "base": base, "SPEC": spec}
    module = ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[]))
    exec(compile(module, "<pinned-causal-assignments-only>", "exec"), {"__builtins__": {}}, env)
    return {name: env[name] for name in ("r3", "q3", "vmult", "prior", "liquid", "trig")} | {"base": base}


def source_cooldown(hours_by_symbol):
    """Execute only the original cooldown if/assignment in an isolated loop."""
    tree = ast.parse(LEGACY.read_bytes())
    outer = next(node for node in tree.body if isinstance(node, ast.For)
                 and isinstance(node.target, ast.Name) and node.target.id == "e_t")
    inner = next(node for node in outer.body if isinstance(node, ast.For))
    check, update = copy.deepcopy(inner.body[:2])
    accepted = ast.parse("accepted.append((i, e_t))").body[0]
    loop = ast.For(target=ast.Tuple(elts=[ast.Name(id="i", ctx=ast.Store()),
                                       ast.Name(id="e_t", ctx=ast.Store())], ctx=ast.Store()),
                   iter=ast.Name(id="hours", ctx=ast.Load()),
                   body=[check, update, accepted], orelse=[])
    module = ast.fix_missing_locations(ast.Module(body=[loop], type_ignores=[]))
    env = {"hours": hours_by_symbol, "accepted": [], "last": {}, "SPEC": {"cooldown_h": 72}}
    exec(compile(module, "<pinned-cooldown-only>", "exec"), {"__builtins__": {}}, env)
    return env["accepted"]


class CausalTriggerTests(unittest.TestCase):
    def test_exact_legacy_source_bytes_and_blob_identity(self):
        result = verify_legacy_source()
        self.assertEqual(result["sha256"], SOURCE_SHA256)
        self.assertEqual(result["bytes"], 6023)
        self.assertFalse(result["source_executed"])
        self.assertEqual(LEGACY.stat().st_mode & 0o777, 0o444)

    def test_known_positive_fixture_matches_source_causal_assignments(self):
        closes, volumes = fixture()
        actual = evaluate_causal(closes, volumes)
        reference = source_oracle(closes, volumes, 171)
        self.assertIs(actual["raw_trigger"], True)
        self.assertEqual(actual["raw_trigger"], reference["trig"])
        for key, name in (("return_3h", "r3"), ("quote_volume_3h", "q3"),
                          ("average_hourly_quote_volume", "base"),
                          ("volume_multiple", "vmult"), ("prior_return_168h", "prior")):
            self.assertEqual(actual["features"][key], reference[name])

    def test_deterministic_finite_fixture_equivalence(self):
        rng = random.Random(7)
        for case in range(120):
            length = rng.randrange(172, 700)
            closes = [100.0] * length
            volumes = [rng.uniform(15000, 50000) for _ in range(length)]
            closes[-1] = (109, 110, 120)[case % 3]
            closes[-172] = (90, 100, 120)[case % 3]
            volumes[-3:] = [rng.uniform(50000, 300000) for _ in range(3)]
            actual = evaluate_causal(closes, volumes)
            self.assertEqual(actual["raw_trigger"], source_oracle(closes, volumes, length - 1)["trig"])

    def test_no_epsilon_repair_of_legacy_float_threshold(self):
        closes, volumes = fixture()
        closes[-4], closes[-172], closes[-1] = 130.0, 100.0, 150.0
        result = evaluate_causal(closes, volumes)
        self.assertGreater(result["features"]["prior_return_168h"], .30)
        self.assertFalse(result["raw_trigger"])
        self.assertEqual(result["raw_trigger"], source_oracle(closes, volumes, 171)["trig"])

    def test_baseline_is_168_fixed_divisor_with_150_finite_cells(self):
        closes, volumes = fixture()
        volumes[:169] = [22400.0] * 169
        for index in range(10, 28):
            volumes[index] = None
        result = evaluate_causal(closes, volumes)
        self.assertEqual(result["features"]["finite_baseline_hours"], 150)
        self.assertEqual(result["features"]["average_hourly_quote_volume"], 20000)
        self.assertTrue(result["raw_trigger"])
        self.assertEqual(result["raw_trigger"], source_oracle(closes, volumes, 171)["trig"])

    def test_baseline_edges_are_t_minus170_through_t_minus3(self):
        closes, volumes = fixture()
        volumes[0] = 1000000000.0  # t-171: outside the baseline.
        volumes[1], volumes[168] = 21000.0, 28000.0
        result = evaluate_causal(closes, volumes)
        expected = (166 * 20000.0 + 21000.0 + 28000.0) / 168
        self.assertEqual(result["features"]["average_hourly_quote_volume"], expected)
        self.assertEqual(result["features"]["average_hourly_quote_volume"],
                         source_oracle(closes, volumes, 171)["base"])

    def test_149_finite_cells_are_unknown_not_false_economic_rejection(self):
        closes, volumes = fixture()
        volumes[:169] = [30000.0] * 169
        for index in range(10, 29):
            volumes[index] = math.nan
        result = evaluate_causal(closes, volumes)
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertIsNone(result["raw_trigger"])
        self.assertEqual(result["features"]["finite_baseline_hours"], 149)

    def test_fully_observed_zero_liquidity_is_known_false_not_warmup(self):
        closes, volumes = fixture()
        volumes[:169] = [0.0] * 169
        result = evaluate_causal(closes, volumes)
        self.assertEqual(result["status"], "FALSE")
        self.assertFalse(result["raw_trigger"])
        self.assertEqual(result["features"]["average_hourly_quote_volume"], 0)
        self.assertIsNone(result["features"]["volume_multiple"])

    def test_fresh_48_hour_trial_has_unknown_warmup(self):
        result = evaluate_causal(*fixture(48))
        self.assertEqual(result["status"], "UNKNOWN")
        self.assertIn("172_HOURLY", result["reason"])
        self.assertEqual(evaluate_causal([], [])["status"], "UNKNOWN")

    def test_incomplete_or_invalid_required_data_are_unknown(self):
        for field, position, value in (("close", -1, None), ("close", -4, 0),
                                        ("volume", -1, math.inf), ("volume", -2, -1)):
            closes, volumes = fixture()
            (closes if field == "close" else volumes)[position] = value
            result = evaluate_causal(closes, volumes)
            self.assertEqual(result["status"], "UNKNOWN")

    def test_infinite_or_malformed_baseline_cannot_create_a_trigger(self):
        for invalid in (math.inf, -math.inf, True, {}, "not a source number"):
            closes, volumes = fixture()
            volumes[:169] = [22400.0] * 169
            volumes[10] = invalid
            result = evaluate_causal(closes, volumes)
            self.assertEqual(result["status"], "UNKNOWN")
            self.assertIsNone(result["raw_trigger"])

    def test_dataset_end_does_not_suppress_current_trigger(self):
        closes, volumes = fixture()
        self.assertTrue(evaluate_causal(closes, volumes)["raw_trigger"])
        # The exact historical harness's separate horizon mask would erase it.
        self.assertFalse(171 < len(closes) - 72 - 1)

    def test_future_rows_unavailable_never_filter_current_trigger(self):
        class FutureUnavailable:
            def __float__(self):
                raise AssertionError("future source data was read")
        closes, volumes = fixture()
        expected = evaluate_causal(closes, volumes, 171)
        closes += [FutureUnavailable()] * 300
        volumes += [FutureUnavailable()] * 300
        self.assertEqual(expected, evaluate_causal(closes, volumes, 171))

    def test_future_quotes_outcomes_controls_are_not_arguments(self):
        signature = str(inspect.signature(evaluate_causal))
        for name in ("outcome", "entry", "quote", "control"):
            self.assertNotIn(name, signature.replace("quote_volumes", "volumes"))
        result = evaluate_causal(*fixture())
        self.assertFalse(result["future_data_required"])
        self.assertFalse(result["strategy_enrollment"])

    def test_per_coin_cooldown_matches_exact_source_loop(self):
        events = [("A", 171), ("A", 172), ("B", 172), ("A", 242),
                  ("A", 243), ("B", 244), ("A", 314), ("A", 315)]
        expected = source_cooldown(events)
        tracker = CausalTriggerTracker()
        origin = dt.datetime(2026, 1, 1, tzinfo=UTC)
        actual = []
        for symbol, hour in events:
            opened = origin + dt.timedelta(hours=hour)
            record = tracker.observe(symbol, opened, *fixture(),
                       received_at=opened + dt.timedelta(hours=1))
            if record["emitted"]:
                actual.append((symbol, hour))
        self.assertEqual(actual, expected)

    def test_closed_hour_actual_availability_gate_preserves_state(self):
        tracker = CausalTriggerTracker()
        opened = dt.datetime(2026, 1, 1, tzinfo=UTC)
        early = tracker.observe("A", opened, *fixture(),
                                received_at=opened + dt.timedelta(minutes=59))
        self.assertEqual(early["status"], "UNKNOWN")
        self.assertFalse(early["emitted"])
        self.assertEqual(tracker.export_state()["coins"], {})
        final = tracker.observe("A", opened, *fixture(),
                                received_at=opened + dt.timedelta(hours=1, seconds=3))
        self.assertTrue(final["emitted"])
        self.assertEqual(final["bar_receipt_delay_seconds"], 3)

    def test_restart_and_duplicate_preserve_first_received_clock(self):
        opened = dt.datetime(2026, 1, 1, tzinfo=UTC)
        tracker = CausalTriggerTracker()
        original = tracker.observe("A", opened, *fixture(), received_at=opened + dt.timedelta(hours=1))
        tracker = CausalTriggerTracker(state=tracker.export_state())
        duplicate = tracker.observe("A", opened, *fixture(), received_at=opened + dt.timedelta(hours=2))
        self.assertTrue(duplicate["duplicate"])
        self.assertEqual(duplicate["received_at"], original["received_at"])
        suppressed = tracker.observe("A", opened + dt.timedelta(hours=71), *fixture(),
                     received_at=opened + dt.timedelta(hours=72))
        self.assertEqual(suppressed["status"], "COOLDOWN")
        accepted = tracker.observe("A", opened + dt.timedelta(hours=72), *fixture(),
                   received_at=opened + dt.timedelta(hours=73))
        self.assertTrue(accepted["emitted"])

    def test_prestart_bars_cannot_be_new_diagnostic_discoveries(self):
        start = dt.datetime(2026, 1, 2, tzinfo=UTC)
        tracker = CausalTriggerTracker(start_at=start)
        opened = start - dt.timedelta(hours=1)
        old = tracker.observe("A", opened, *fixture(), received_at=start)
        self.assertEqual(old["status"], "BOOTSTRAP_NOT_ENROLLED")
        self.assertFalse(old["emitted"])
        new = tracker.observe("A", start, *fixture(), received_at=start + dt.timedelta(hours=1))
        self.assertTrue(new["emitted"])
        self.assertFalse(new["strategy_enrollment"])

    def test_conflict_and_out_of_order_cannot_rewrite_diagnostic(self):
        tracker = CausalTriggerTracker()
        opened = dt.datetime(2026, 1, 1, tzinfo=UTC)
        tracker.observe("A", opened, *fixture(), received_at=opened + dt.timedelta(hours=1))
        before = tracker.export_state()
        closes, volumes = fixture()
        closes[-1] = 120
        with self.assertRaisesRegex(ValueError, "conflicting duplicate"):
            tracker.observe("A", opened, closes, volumes, received_at=opened + dt.timedelta(hours=2))
        with self.assertRaisesRegex(ValueError, "out-of-order"):
            tracker.observe("A", opened - dt.timedelta(hours=1), *fixture(), received_at=opened)
        self.assertEqual(before, tracker.export_state())


if __name__ == "__main__":
    unittest.main()
