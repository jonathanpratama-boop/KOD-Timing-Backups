"""Length-delimited immutable minute containers; exact member bytes survive."""
import base64,hashlib,json,struct
MAGIC=b'KOD-CAPACITY-PACK-V1\x00'
MAX_MEMBERS=32
MAX_BYTES=16*1024*1024
def _jsonable(v):
    if isinstance(v,bytes):return {'__capacity_bytes_base64__':base64.b64encode(v).decode('ascii')}
    if isinstance(v,dict):return {k:_jsonable(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [_jsonable(x) for x in v]
    return v
def _restore(v):
    if isinstance(v,dict):
        if set(v)=={'__capacity_bytes_base64__'}:return base64.b64decode(v['__capacity_bytes_base64__'],validate=True)
        return {k:_restore(x) for k,x in v.items()}
    if isinstance(v,list):return [_restore(x) for x in v]
    return v
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pack_attempts(attempts):
    if not isinstance(attempts,list) or len(attempts)>MAX_MEMBERS:raise ValueError('bounded minute members required')
    output=bytearray(MAGIC+struct.pack('>I',len(attempts)));index=[]
    for i,a in enumerate(attempts):
        if not isinstance(a,dict):raise ValueError('attempt dictionary required')
        body=a.get('body',b'')
        if not isinstance(body,bytes):raise ValueError('exact body bytes required')
        meta={'metadata':_jsonable({k:v for k,v in a.items() if k!='body'}),'body_present':'body' in a,
              'body_sha256':hashlib.sha256(body).hexdigest(),'body_bytes':len(body)}
        encoded=canonical(meta)
        if len(encoded)>1024*1024:raise ValueError('member metadata cap')
        output.extend(struct.pack('>I',len(encoded)));output.extend(encoded);output.extend(struct.pack('>Q',len(body)))
        offset=len(output);output.extend(body);index.append({'member':i,'raw_offset':offset,'raw_bytes':len(body),'raw_sha256':meta['body_sha256']})
        if len(output)>MAX_BYTES:raise ValueError('minute container cap')
    return bytes(output),index
def unpack_attempts(raw):
    if not isinstance(raw,bytes) or len(raw)>MAX_BYTES or not raw.startswith(MAGIC):raise ValueError('invalid minute container')
    pos=len(MAGIC)
    def take(n):
        nonlocal pos
        if n<0 or pos+n>len(raw):raise ValueError('truncated minute container')
        b=raw[pos:pos+n];pos+=n;return b
    count=struct.unpack('>I',take(4))[0]
    if count>MAX_MEMBERS:raise ValueError('member count cap')
    result=[]
    for _ in range(count):
        n=struct.unpack('>I',take(4))[0]
        if n>1024*1024:raise ValueError('metadata cap')
        encoded=take(n);meta=json.loads(encoded)
        if canonical(meta)!=encoded:raise ValueError('noncanonical member metadata')
        body=take(struct.unpack('>Q',take(8))[0])
        if len(body)!=meta['body_bytes'] or hashlib.sha256(body).hexdigest()!=meta['body_sha256']:raise ValueError('member bytes changed')
        item=_restore(meta['metadata'])
        if meta['body_present']:item['body']=body
        elif body:raise ValueError('unexpected body')
        result.append(item)
    if pos!=len(raw):raise ValueError('unexpected trailing container bytes')
    return result
def minute_raw(attempts):
    body,index=pack_attempts(attempts)
    receipts=[a['received_at'] for a in attempts if a.get('received_at')]
    return [{'transport':'immutable-shared-minute-container-v1','body':body,'member_count':len(attempts),
             'received_at':max(receipts) if receipts else None,
             'clock_semantics':'Member send/receipt clocks are authoritative; container is local archival framing.'}],index
