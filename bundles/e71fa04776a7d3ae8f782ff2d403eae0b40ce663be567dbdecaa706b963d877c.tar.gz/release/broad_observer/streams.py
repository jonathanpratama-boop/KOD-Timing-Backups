"""Bounded stdlib Binance combined closed-minute stream for capacity testing.

No strategy, orders, subscriptions to accounts, host fallback, or autonomous
reconnection. The caller owns a finite schedule, durable batches, provider-stop
latch, reconnect backoff and externally checked heartbeat. Interim messages are
parsed/counted, while only closed messages enter the bounded raw-data queue.
"""
from __future__ import annotations
import base64
from collections import deque, OrderedDict
import datetime as dt
from decimal import Decimal, InvalidOperation
import hashlib
import json
import os
import socket
import ssl
import struct
import threading
import time
import urllib.parse

HOST='stream.binance.com'
PORT=443
MAX_SYMBOLS=150
MAX_MESSAGE_BYTES=4*1024*1024
MAX_PENDING_BYTES=4*1024*1024
MAX_PENDING_CLOSED=300
MAX_EVENTS=512
MAX_HEADER_BYTES=16*1024
RENEW_AFTER_SECONDS=23*3600+55*60
SILENCE_SECONDS=70
_GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
UTC=dt.timezone.utc


class ProtocolError(RuntimeError):pass
class PayloadError(ProtocolError):pass
class ConnectionClosed(ProtocolError):pass
class RenewalRequired(ProtocolError):pass
class ProviderBlocked(ProtocolError):
    provider_blocked=True
    def __init__(self,message,*,status=None,headers=None,raw_handshake=b''):
        super().__init__(message)
        self.status,self.headers,self.raw_handshake=status,headers or {},raw_handshake


def utcnow():return dt.datetime.now(UTC)


def iso(value):
    if isinstance(value,str):
        value=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
    if not isinstance(value,dt.datetime) or value.tzinfo is None:
        raise ValueError('aware UTC receipt clock required')
    return value.astimezone(UTC).isoformat(timespec='microseconds').replace('+00:00','Z')


def _millisecond(value):
    if not isinstance(value,int) or isinstance(value,bool) or value<0:
        raise ValueError('source timestamp requires nonnegative integer milliseconds')
    try:return iso(dt.datetime.fromtimestamp(value/1000,UTC))
    except (ValueError,OverflowError,OSError):raise ValueError('source timestamp out of bounds') from None


def _symbols(values):
    if not isinstance(values,(tuple,list)) or not 1<=len(values)<=MAX_SYMBOLS:
        raise ValueError('one to150 frozen stream symbols required')
    if any(not isinstance(s,str) or not 1<=len(s)<=40 or not s.isalnum() or s!=s.upper() for s in values):
        raise ValueError('exact uppercase Unicode-alphanumeric exchange identity required')
    if len(set(values))!=len(values):raise ValueError('duplicate stream symbol')
    return tuple(values)


def combined_path(symbols):
    names='/'.join(symbol.lower()+'@kline_1m' for symbol in _symbols(symbols))
    path='/stream?streams='+urllib.parse.quote(names,safe='/@')
    if len(path.encode('ascii'))>MAX_HEADER_BYTES//2:
        raise ValueError('combined stream URL exceeds fixed byte cap')
    return path


def _number(value,positive=False):
    if not isinstance(value,str) or len(value)>128:
        raise ValueError('source decimal must be a bounded string')
    try:number=Decimal(value)
    except InvalidOperation:raise ValueError('invalid decimal') from None
    if not number.is_finite() or number<0 or (positive and number<=0):
        raise ValueError('source decimal outside bounds')
    return number


class ClosedKlineIngestor:
    def __init__(self,symbols,*,clock=utcnow,monotonic=time.monotonic,
                 max_pending_closed=MAX_PENDING_CLOSED,max_pending_bytes=MAX_PENDING_BYTES):
        self.symbols=_symbols(symbols)
        if (not isinstance(max_pending_closed,int) or isinstance(max_pending_closed,bool)
                or not 1<=max_pending_closed<=MAX_PENDING_CLOSED
                or not isinstance(max_pending_bytes,int) or isinstance(max_pending_bytes,bool)
                or not 1<=max_pending_bytes<=MAX_PENDING_BYTES):
            raise ValueError('queue limits exceed frozen capacity bounds')
        self.clock,self.monotonic=clock,monotonic
        self.max_pending_closed,self.max_pending_bytes=max_pending_closed,max_pending_bytes
        self._streams={s.lower()+'@kline_1m':s for s in self.symbols}
        self._queue,self._events=deque(),deque()
        self._pending_bytes=0
        self._first=OrderedDict()
        self._highest={}
        self._lock=threading.RLock()
        self._stats={'application_messages':0,'application_bytes':0,'data_frame_wire_bytes':0,
            'interim_messages':0,'closed_messages':0,'closed_queued':0,'closed_dropped':0,
            'duplicate_closed_messages':0,'old_closed_messages':0,'invalid_messages':0,
            'conflicting_closed_messages':0,'clock_anomalies':0,
            'events_dropped':0,'processing_cpu_seconds':0.0,'queue_high_water_items':0,
            'queue_high_water_bytes':0,'last_receipt_at':None}

    def event(self,kind,**payload):
        with self._lock:
            if len(self._events)>=MAX_EVENTS:
                self._events.popleft();self._stats['events_dropped']+=1
            self._events.append({'kind':kind,'received_at':iso(self.clock()),**payload})

    def feed_message(self,raw,received_at=None,*,received_monotonic=None,wire_bytes=None):
        cpu_start=time.thread_time()
        if not isinstance(raw,bytes) or len(raw)>MAX_MESSAGE_BYTES:
            raise PayloadError('application message exceeds byte cap or is not exact bytes')
        received_at=iso(received_at or self.clock())
        received_monotonic=self.monotonic() if received_monotonic is None else received_monotonic
        wire_bytes=len(raw) if wire_bytes is None else wire_bytes
        if not isinstance(wire_bytes,int) or isinstance(wire_bytes,bool) or wire_bytes<len(raw):
            raise ValueError('wire byte count must include complete application bytes')
        with self._lock:
            self._stats['application_messages']+=1;self._stats['application_bytes']+=len(raw)
            self._stats['data_frame_wire_bytes']+=wire_bytes;self._stats['last_receipt_at']=received_at
            try:
                obj=json.loads(raw)
                if not isinstance(obj,dict) or not isinstance(obj.get('data'),dict):
                    raise ValueError('combined object/data missing')
                data=obj['data']
                if obj.get('stream')=='!serverShutdown' and data.get('e')=='serverShutdown':
                    event_at=_millisecond(data.get('E'))
                    self.event('server_shutdown',raw=raw,source_event_at=event_at,received_at=received_at)
                    raise RenewalRequired('serverShutdown received; reconnect through controller')
                stream=obj.get('stream')
                if not isinstance(stream,str) or stream not in self._streams:
                    raise ValueError('stream identity not frozen')
                symbol=self._streams[stream];k=data.get('k')
                if (data.get('e')!='kline' or data.get('s')!=symbol or not isinstance(k,dict)
                        or k.get('s')!=symbol or k.get('i')!='1m' or not isinstance(k.get('x'),bool)):
                    raise ValueError('kline identity/interval/closed flag mismatch')
                event_at=_millisecond(data.get('E'));open_at=_millisecond(k.get('t'));close_at=_millisecond(k.get('T'))
                if k['t']%60000 or k['T']!=k['t']+59999:
                    raise ValueError('source bar not exact UTC minute')
                fields={'open':k.get('o'),'high':k.get('h'),'low':k.get('l'),'close':k.get('c'),
                    'base_volume':k.get('v'),'quote_volume':k.get('q'),
                    'taker_buy_base_volume':k.get('V'),'taker_buy_quote_volume':k.get('Q')}
                numbers={key:_number(value,positive=key in ('open','high','low','close')) for key,value in fields.items()}
                if (numbers['high']<max(numbers['open'],numbers['close'],numbers['low'])
                        or numbers['low']>min(numbers['open'],numbers['close'])
                        or numbers['taker_buy_base_volume']>numbers['base_volume']
                        or numbers['taker_buy_quote_volume']>numbers['quote_volume']):
                    raise ValueError('source OHLCV inequalities invalid')
                n=k.get('n')
                if not isinstance(n,int) or isinstance(n,bool) or n<0:
                    raise ValueError('trade count invalid')
                for name in ('f','L'):
                    value=k.get(name)
                    if not isinstance(value,int) or isinstance(value,bool) or value<(-1 if n==0 else 0):
                        raise ValueError('trade identity invalid')
                if not k['x']:
                    self._stats['interim_messages']+=1
                    return None
                self._stats['closed_messages']+=1
                semantic={'symbol':symbol,'open_ms':k['t'],'close_ms':k['T'],
                    'trades':n,'first_trade_id':k['f'],'last_trade_id':k['L'],**fields}
                semantic_hash=hashlib.sha256(json.dumps(semantic,sort_keys=True,ensure_ascii=False,
                    separators=(',',':')).encode()).hexdigest()
                receipt_ms=dt.datetime.fromisoformat(received_at.replace('Z','+00:00')).timestamp()*1000
                local_clock_anomaly=receipt_ms<k['T']
                if local_clock_anomaly:self._stats['clock_anomalies']+=1
                identity=(symbol,k['t']);first_entry=self._first.get(identity)
                duplicate=first_entry is not None
                old=not duplicate and k['t']<=self._highest.get(symbol,-1)
                conflict=duplicate and semantic_hash!=first_entry['semantic_bar_sha256']
                if duplicate:self._stats['duplicate_closed_messages']+=1
                elif old:self._stats['old_closed_messages']+=1
                else:
                    first_entry={'received_at':received_at,'semantic_bar_sha256':semantic_hash,
                                 'clock_anomaly':local_clock_anomaly}
                    self._first[identity]=first_entry
                    self._highest[symbol]=k['t']
                    while len(self._first)>MAX_PENDING_CLOSED:self._first.popitem(last=False)
                if conflict:
                    self._stats['conflicting_closed_messages']+=1
                    self.event('conflicting_final_bar',symbol=symbol,open_at=open_at,
                        semantic_bar_sha256=semantic_hash,
                        first_authoritative_bar_sha256=first_entry['semantic_bar_sha256'],
                        first_authoritative_received_at=first_entry['received_at'],received_at=received_at)
                # Only identical bar values may reuse their original first clock.
                # Conflicting values retain their current receipt and cannot
                # acquire an earlier availability time from the bar identifier.
                first=None if old or conflict else first_entry['received_at']
                authoritative_first=None if first_entry is None else first_entry['received_at']
                clock_anomaly=local_clock_anomaly or (first_entry is not None and first_entry['clock_anomaly'])
                record={'raw':raw,'symbol':symbol,'closed':True,'source_event_at':event_at,
                    'source_event_ms':data['E'],'source_timestamp':event_at,'open_at':open_at,'close_at':close_at,
                    'open_ms':k['t'],'close_ms':k['T'],'received_at':received_at,
                    'received_monotonic':received_monotonic,'wire_bytes':wire_bytes,
                    'first_received_at':first,'duplicate_final':duplicate,'old_bar_first_receipt_unknown':old,
                    'semantic_bar_sha256':semantic_hash,'source_conflict':conflict,
                    'first_authoritative_bar_sha256':None if first_entry is None else first_entry['semantic_bar_sha256'],
                    'first_authoritative_received_at':authoritative_first,
                    'current_value_received_at':received_at,'clock_anomaly':clock_anomaly,
                    'local_receipt_before_source_close':local_clock_anomaly,
                    'availability_status':('UNKNOWN_SOURCE_CONFLICT' if conflict else 'UNKNOWN_CLOCK_ANOMALY'
                        if clock_anomaly else 'UNKNOWN_OLD_BAR_FIRST_RECEIPT' if old else 'FIRST_RECEIPT_KNOWN'),
                    'on_time_first_receipt':None if first is None or clock_anomaly else (
                        dt.datetime.fromisoformat(first.replace('Z','+00:00')).timestamp()*1000<=k['T']+60000),
                    'network_latency_ms':None,'clock_difference_semantics':'Source E and local receipt are distinct clocks; no synchronized one-way latency assumed.',
                    'trades':n,'first_trade_id':k['f'],'last_trade_id':k['L'],**fields}
                if len(self._queue)>=self.max_pending_closed or self._pending_bytes+len(raw)>self.max_pending_bytes:
                    self._stats['closed_dropped']+=1
                    self.event('closed_queue_overflow',symbol=symbol,open_at=open_at,close_at=close_at,
                        raw_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),received_at=received_at)
                    return None
                self._queue.append(record);self._pending_bytes+=len(raw);self._stats['closed_queued']+=1
                self._stats['queue_high_water_items']=max(self._stats['queue_high_water_items'],len(self._queue))
                self._stats['queue_high_water_bytes']=max(self._stats['queue_high_water_bytes'],self._pending_bytes)
                return record
            except RenewalRequired:
                raise
            except (ValueError,TypeError,KeyError,InvalidOperation,RecursionError) as exc:
                self._stats['invalid_messages']+=1
                self.event('invalid_application_payload',error=f'{type(exc).__name__}: {str(exc)[:200]}',
                    raw_prefix=raw[:4096],raw_prefix_truncated=len(raw)>4096,
                    raw_sha256=hashlib.sha256(raw).hexdigest(),received_at=received_at)
                raise PayloadError(str(exc)) from exc
            finally:
                self._stats['processing_cpu_seconds']+=time.thread_time()-cpu_start

    def drain(self,max_items=MAX_PENDING_CLOSED):
        if not isinstance(max_items,int) or isinstance(max_items,bool) or not 1<=max_items<=MAX_PENDING_CLOSED:
            raise ValueError('bounded positive drain count required')
        with self._lock:
            records=[]
            while self._queue and len(records)<max_items:
                record=self._queue.popleft();self._pending_bytes-=len(record['raw']);records.append(record)
            return records

    def drain_events(self,max_items=MAX_EVENTS):
        if not isinstance(max_items,int) or isinstance(max_items,bool) or not 1<=max_items<=MAX_EVENTS:
            raise ValueError('bounded positive event drain count required')
        with self._lock:
            events=[]
            while self._events and len(events)<max_items:events.append(self._events.popleft())
            return events

    def health(self):
        with self._lock:
            return {**self._stats,'queue_items':len(self._queue),'queue_bytes':self._pending_bytes,
                'pending_events':len(self._events),'frozen_symbol_count':len(self.symbols),
                'first_receipt_cache_items':len(self._first),'per_symbol_high_water_items':len(self._highest),
                'wire_bytes_semantics':'Unencrypted RFC6455 data-frame bytes including headers, excluding TLS/TCP/IP; control/handshake tracked separately.'}


class WebSocketConnection:
    def __init__(self,symbols,*,connector=None,clock=utcnow,monotonic=time.monotonic):
        self.symbols=_symbols(symbols);self.path=combined_path(self.symbols)
        self.connector=connector or self._tls_connect
        self.clock,self.monotonic=clock,monotonic
        self.sock=None;self.buffer=bytearray();self.connected_at=None
        self.last_frame_mono=None;self.last_receipt_at=None
        self.frame_wire_bytes=0;self.control_wire_bytes=0;self.client_control_wire_bytes=0
        self.data_frames=0;self.pings=0;self.pongs=0;self.client_controls=0
        self.handshake_request=b'';self.handshake_response=b''
        self._fragment=None;self._fragment_wire=0;self._sent_controls=deque();self._send_lock=threading.Lock()

    @staticmethod
    def _tls_connect(host,port,timeout):
        if (host,port)!=(HOST,PORT):raise ValueError('fixed official WS host/port required')
        plain=socket.create_connection((host,port),timeout=timeout)
        try:return ssl.create_default_context().wrap_socket(plain,server_hostname=host)
        except BaseException:plain.close();raise

    def connect(self):
        if self.sock is not None:raise ProtocolError('connection already open')
        self.sock=self.connector(HOST,PORT,10)
        key=base64.b64encode(os.urandom(16)).decode('ascii')
        request=(f'GET {self.path} HTTP/1.1\r\nHost: {HOST}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n'
                 f'Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n').encode('ascii')
        self.handshake_request=request;deadline=self.monotonic()+10
        try:
            self.sock.settimeout(10);self.sock.sendall(request)
            while b'\r\n\r\n' not in self.buffer:
                if self.monotonic()>=deadline:raise TimeoutError('WS handshake deadline')
                self.sock.settimeout(max(0.001,deadline-self.monotonic()))
                chunk=self.sock.recv(min(4096,MAX_HEADER_BYTES+1-len(self.buffer)))
                if not chunk:raise ConnectionClosed('EOF during handshake')
                self.buffer.extend(chunk)
                if len(self.buffer)>MAX_HEADER_BYTES:raise ProtocolError('handshake response cap')
            boundary=self.buffer.index(b'\r\n\r\n')+4
            header=bytes(self.buffer[:boundary]);del self.buffer[:boundary]
            self.handshake_response=header
            lines=header.decode('iso-8859-1').split('\r\n')
            pieces=lines[0].split(' ',2)
            if len(pieces)<2 or pieces[0] not in ('HTTP/1.1','HTTP/1.0') or not pieces[1].isdigit():
                raise ProtocolError('invalid HTTP upgrade status')
            status=int(pieces[1]);headers={}
            for line in lines[1:]:
                if not line:continue
                if ':' not in line:raise ProtocolError('invalid upgrade header')
                name,value=line.split(':',1);name=name.lower().strip()
                if name in headers:raise ProtocolError('duplicated upgrade header')
                headers[name]=value.strip()
            if status in (418,429,403,451) or 'retry-after' in headers or 300<=status<400:
                raise ProviderBlocked('WS provider block/Retry-After/redirect; no host fallback',status=status,headers=headers,raw_handshake=header+bytes(self.buffer))
            expected=base64.b64encode(hashlib.sha1((key+_GUID).encode('ascii')).digest()).decode('ascii')
            if (status!=101 or headers.get('upgrade','').lower()!='websocket'
                    or 'upgrade' not in [token.strip().lower() for token in headers.get('connection','').split(',')]
                    or headers.get('sec-websocket-accept')!=expected
                    or headers.get('sec-websocket-extensions') or headers.get('sec-websocket-protocol')):
                raise ProtocolError('unverified websocket upgrade or unsolicited extension/protocol')
            self.connected_at=self.monotonic();self.last_frame_mono=self.connected_at
            self.sock.settimeout(1)
            return {'host':HOST,'port':PORT,'path':self.path,'http_status':status,
                'received_at':iso(self.clock()),'raw_handshake':header,'request':request,
                'response_body_complete':True,'tls_verified':True,'source_timestamp':None}
        except BaseException:
            self.close(send_close=False);raise

    def _fill(self,count):
        while len(self.buffer)<count:
            if self.sock is None:raise ConnectionClosed('socket not connected')
            chunk=self.sock.recv(min(64*1024,count-len(self.buffer)))
            if not chunk:raise ConnectionClosed('stream EOF')
            self.buffer.extend(chunk)

    def _frame(self):
        self._fill(2);first,second=self.buffer[0],self.buffer[1]
        fin=bool(first&0x80);opcode=first&0x0f;short=second&0x7f
        if first&0x70 or second&0x80:raise ProtocolError('RSV extension or masked server frame rejected')
        header=2
        if short==126:
            self._fill(4);length=struct.unpack('!H',self.buffer[2:4])[0];header=4
            if length<126:raise ProtocolError('noncanonical frame length')
        elif short==127:
            self._fill(10);length=struct.unpack('!Q',self.buffer[2:10])[0];header=10
            if length<65536 or length>>63:raise ProtocolError('noncanonical/invalid64bit length')
        else:length=short
        if opcode not in (0,1,2,8,9,10):raise ProtocolError('reserved websocket opcode')
        if opcode>=8 and (not fin or length>125):raise ProtocolError('fragmented/oversized control frame')
        if length>MAX_MESSAGE_BYTES:raise ProtocolError('frame byte cap')
        self._fill(header+length);payload=bytes(self.buffer[header:header+length]);del self.buffer[:header+length]
        self.frame_wire_bytes+=header+length
        if opcode>=8:self.control_wire_bytes+=header+length
        else:self.data_frames+=1
        self.last_frame_mono=self.monotonic();self.last_receipt_at=iso(self.clock())
        return fin,opcode,payload,header+length

    def _send_control(self,opcode,payload=b''):
        if opcode not in (8,10) or not isinstance(payload,bytes) or len(payload)>125:
            raise ProtocolError('only bounded close/pong controls allowed')
        with self._send_lock:
            now=self.monotonic()
            while self._sent_controls and self._sent_controls[0]<=now-1:self._sent_controls.popleft()
            if len(self._sent_controls)>=5:raise ProviderBlocked('client control5/sec safety cap reached')
            self._sent_controls.append(now)
            mask=os.urandom(4);masked=bytes(byte^mask[i%4] for i,byte in enumerate(payload))
            frame=bytes([0x80|opcode,0x80|len(payload)])+mask+masked
            if self.sock is None:raise ConnectionClosed('control on disconnected socket')
            self.sock.sendall(frame);self.client_controls+=1;self.client_control_wire_bytes+=len(frame)

    def recv_message(self):
        if self.connected_at is None:raise ConnectionClosed('connection not established')
        if self.monotonic()-self.connected_at>=RENEW_AFTER_SECONDS:raise RenewalRequired('proactive23h55m renewal before24h expiry')
        try:fin,opcode,payload,wire=self._frame()
        except socket.timeout:
            if self.monotonic()-self.last_frame_mono>SILENCE_SECONDS:raise ConnectionClosed('no frame/ping for70seconds')
            return None
        if opcode==9:
            self.pings+=1;self._send_control(10,payload);return None
        if opcode==10:self.pongs+=1;return None
        if opcode==8:
            if len(payload)==1:raise ProtocolError('invalid one-byte close payload')
            code=struct.unpack('!H',payload[:2])[0] if payload else None
            if len(payload)>2:
                try:payload[2:].decode('utf-8')
                except UnicodeDecodeError:raise ProtocolError('invalid UTF8 close reason') from None
            self._send_control(8,payload)
            if code in (1008,1013):raise ProviderBlocked(f'provider policy/rate close code {code}')
            raise ConnectionClosed(f'provider close code {code}')
        if opcode==2:raise ProtocolError('binary application frame not supported')
        if opcode==1:
            if self._fragment is not None:raise ProtocolError('new message before fragmented message complete')
            if fin:return payload,self.last_receipt_at,wire
            self._fragment=bytearray(payload);self._fragment_wire=wire;return None
        if self._fragment is None:raise ProtocolError('continuation without fragmented message')
        self._fragment.extend(payload);self._fragment_wire+=wire
        if len(self._fragment)>MAX_MESSAGE_BYTES:raise ProtocolError('fragmented message byte cap')
        if not fin:return None
        raw=bytes(self._fragment);wire=self._fragment_wire;self._fragment=None;self._fragment_wire=0
        return raw,self.last_receipt_at,wire

    def close(self,*,send_close=True):
        sock,self.sock=self.sock,None
        if sock is None:return
        if send_close:
            # Avoid racing a read or bypassing the shared control rate accounting.
            self.sock=sock
            try:self._send_control(8,struct.pack('!H',1000))
            except Exception:pass
            self.sock=None
        try:sock.shutdown(socket.SHUT_RDWR)
        except (OSError,AttributeError):pass
        sock.close()

    def health(self):
        return {'connected':self.sock is not None,'frame_wire_bytes':self.frame_wire_bytes,
            'control_wire_bytes':self.control_wire_bytes,'client_control_wire_bytes':self.client_control_wire_bytes,
            'data_frames':self.data_frames,'server_pings':self.pings,'server_pongs':self.pongs,
            'client_controls':self.client_controls,'last_frame_at':self.last_receipt_at,
            'handshake_request_bytes':len(self.handshake_request),'handshake_response_bytes':len(self.handshake_response),
            'connected_monotonic':self.connected_at,'host':HOST,'port':PORT,'url_path':self.path}


class KlineStream:
    def __init__(self,symbols,*,connector=None,clock=utcnow,monotonic=time.monotonic,
                 max_pending_closed=MAX_PENDING_CLOSED,max_pending_bytes=MAX_PENDING_BYTES):
        self.symbols=_symbols(symbols);self.clock,self.monotonic=clock,monotonic
        self.ingestor=ClosedKlineIngestor(self.symbols,clock=clock,monotonic=monotonic,
            max_pending_closed=max_pending_closed,max_pending_bytes=max_pending_bytes)
        self.connection=WebSocketConnection(self.symbols,connector=connector,clock=clock,monotonic=monotonic)
        self._stop=threading.Event();self._thread=None;self._state='NEW';self.provider_blocked=False
        self._reader_cpu_seconds=0.0

    def start(self):
        if self._state!='NEW':raise ProtocolError('stream instances start once; controller owns reconnection')
        self.ingestor.event('connection_attempt',host=HOST,port=PORT,path=self.connection.path)
        try:
            receipt=self.connection.connect();self.ingestor.event('connected',**receipt)
        except BaseException as exc:
            self._state='DISCONNECTED';self.provider_blocked=bool(getattr(exc,'provider_blocked',False))
            self.ingestor.event('connection_failed',error=f'{type(exc).__name__}: {str(exc)[:240]}',
                provider_blocked=self.provider_blocked,raw_handshake=getattr(exc,'raw_handshake',b''),
                http_status=getattr(exc,'status',None),headers=getattr(exc,'headers',{}))
            raise
        self._state='CONNECTED';self._thread=threading.Thread(target=self._read_loop,name='kod-capacity-kline-reader',daemon=True)
        self._thread.start();return self.health()

    def _read_loop(self):
        cpu_start=time.thread_time()
        try:
            while not self._stop.is_set():
                result=self.connection.recv_message()
                if result is not None:
                    raw,received_at,wire=result
                    self.ingestor.feed_message(raw,received_at,received_monotonic=self.monotonic(),wire_bytes=wire)
                self._reader_cpu_seconds=time.thread_time()-cpu_start
        except RenewalRequired as exc:
            self._state='RENEWAL_DUE';self.ingestor.event('renewal_required',reason=str(exc))
        except BaseException as exc:
            self.provider_blocked=bool(getattr(exc,'provider_blocked',False))
            self._state='DISCONNECTED'
            self.ingestor.event('disconnected',error=f'{type(exc).__name__}: {str(exc)[:240]}',provider_blocked=self.provider_blocked,
                last_frame_at=self.connection.last_receipt_at)
        finally:
            self._reader_cpu_seconds=time.thread_time()-cpu_start
            self.connection.close(send_close=not self.provider_blocked)
            if self._state=='CONNECTED':self._state='STOPPED'

    def feed_message(self,*args,**kwargs):return self.ingestor.feed_message(*args,**kwargs)
    def drain(self,max_items=MAX_PENDING_CLOSED):return self.ingestor.drain(max_items)
    def drain_events(self,max_items=MAX_EVENTS):return self.ingestor.drain_events(max_items)
    def poll(self):return self.health()

    def health(self):
        return {**self.ingestor.health(),**self.connection.health(),'state':self._state,
            'provider_blocked':self.provider_blocked,'renewal_due':self._state=='RENEWAL_DUE',
            'reader_alive':self._thread is not None and self._thread.is_alive(),
            'reader_cpu_seconds_completed':self._reader_cpu_seconds,
            'reader_cpu_seconds':self._reader_cpu_seconds,
            'reconnection_policy':'No autonomous reconnect or host fallback; durable finite controller owns backoff/provider stop.'}

    def stop(self):
        self._stop.set();self.connection.close()
        if self._thread is not None and self._thread is not threading.current_thread():self._thread.join(timeout=2)
        self._state='STOPPED'
