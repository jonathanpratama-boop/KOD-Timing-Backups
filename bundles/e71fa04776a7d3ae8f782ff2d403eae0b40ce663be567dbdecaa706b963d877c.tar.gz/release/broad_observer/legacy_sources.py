"""Bounded public-source and midpoint adapters for the isolated paper trial.

No source object is an eligibility decision. Every candidate requires a later
manual economic adjudication. Bodies are captured before parsing and all
request outcomes, including failures and caps, are returned to the journal.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import math
import time
import urllib.error
import urllib.parse
import urllib.request
from decimal import Decimal, InvalidOperation

UTC = dt.timezone.utc
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_PAGES = 3
PAGE_SIZE = 100
REQUEST_TIMEOUT = 10.0
MAX_RUNTIME = 120.0
MAX_DETAIL_REQUESTS = 6
SYMBOLS = ('GMXUSDT', 'BTCUSDT', 'ETHUSDT')
DOCUMENTS = {
    'gmx-docs-rewards': 'https://docs.gmx.io/docs/tokenomics/rewards/',
    'gmx-docs-governance': 'https://docs.gmx.io/docs/governance/proposal-process/',
}


def _obj(value):
    return value if isinstance(value, dict) else {}


def utcnow():
    return dt.datetime.now(UTC)


def iso(value):
    if isinstance(value, str):
        value = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if not isinstance(value, dt.datetime):
        raise ValueError('timestamp must be an aware datetime or ISO string')
    if value.tzinfo is None:
        raise ValueError('timezone required')
    return value.astimezone(UTC).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def source_iso(value):
    """Normalize source timestamps without inventing a receipt/publication clock."""
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError('boolean timestamp')
    if isinstance(value, (int, float)):
        if not math.isfinite(value):
            raise ValueError('non-finite timestamp')
        return iso(dt.datetime.fromtimestamp(value, UTC))
    return iso(value)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _transport(url, method, body, timeout, max_bytes):
    req = urllib.request.Request(url, data=body, method=method, headers={
        'Accept': 'application/json', 'Accept-Encoding': 'identity',
        'User-Agent': 'KOD-Economic-Paper-Trial/1 (public research; no orders)',
        **({'Content-Type': 'application/json'} if body is not None else {})})
    try:
        response = urllib.request.build_opener(_NoRedirect).open(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        raw = response.read(max_bytes + 1)
        return {'status': response.status, 'headers': dict(response.headers),
                'body': raw, 'response_url': response.geturl()}


class PublicAdapters:
    """Dependency-injectable stdlib implementation; capture is Store.put_raw."""
    def __init__(self, capture=None, source_config=None, transport=None,
                 now_fn=utcnow, monotonic=time.monotonic, audit=None):
        self.capture = capture or (lambda raw: hashlib.sha256(raw).hexdigest())
        self.transport = transport or _transport
        self.now_fn, self.monotonic = now_fn, monotonic
        self.audit = audit
        self._request_sequence = 0
        cfg = source_config or {}
        self.snapshot_space = cfg.get('snapshot_space', 'gmx.eth')
        self.forum_base = cfg.get('forum_base', 'https://gov.gmx.io').rstrip('/')
        self.snapshot_url = cfg.get('snapshot_url', 'https://hub.snapshot.org/graphql')
        self.price_base = cfg.get('price_base', 'https://api.binance.com').rstrip('/')
        # Frozen allowlist; config cannot turn this reader into an arbitrary URL fetcher.
        if (self.forum_base != 'https://gov.gmx.io' or
                self.snapshot_url != 'https://hub.snapshot.org/graphql' or
                self.price_base != 'https://api.binance.com' or
                self.snapshot_space != 'gmx.eth'):
            raise ValueError('source identity outside frozen adapter allowlist')
        self.max_detail_requests = MAX_DETAIL_REQUESTS

    def _request(self, url, *, body=None, deadline=None, label=None, expect_json=True):
        start = iso(self.now_fn())
        monotonic_start = self.monotonic()
        self._request_sequence += 1
        request_record = {'source_id': label, 'url': url,
                          'method': 'POST' if body is not None else 'GET',
                          'request_started_at': start,
                          'monotonic_started_seconds': monotonic_start,
                          'instance_request_sequence': self._request_sequence}
        if body is not None:
            encoded = json.dumps(body, sort_keys=True, separators=(',', ':')).encode()
            request_record['request_body_sha256'] = hashlib.sha256(encoded).hexdigest()
        request_id = hashlib.sha256(json.dumps(request_record, sort_keys=True).encode()).hexdigest()
        request_record['request_id'] = request_id
        # Audit callbacks deliberately sit outside the exception conversion below.
        # A storage/integrity failure must halt, never become a source outage.
        if self.audit is not None:
            self.audit('request_started', request_record)
        data, attempt = self._request_inner(url, body=body, deadline=deadline,
                                           label=label, expect_json=expect_json,
                                           started_at=start)
        attempt['request_id'] = request_id
        attempt['elapsed_seconds_monotonic'] = self.monotonic() - monotonic_start
        if self.audit is not None:
            self.audit('request_finished', attempt)
        return data, attempt

    def _request_inner(self, url, *, body=None, deadline=None, label=None,
                       expect_json=True, started_at=None):
        start = started_at or iso(self.now_fn())
        method = 'POST' if body is not None else 'GET'
        attempt = {'source_id': label, 'url': url, 'method': method,
                   'request_started_at': start, 'received_at': None,
                   'source_timestamp': None, 'status': 'FAILED'}
        if body is not None:
            body = json.dumps(body, sort_keys=True, separators=(',', ':')).encode()
            attempt['request_body_sha256'] = hashlib.sha256(body).hexdigest()
        remaining = REQUEST_TIMEOUT if deadline is None else deadline - self.monotonic()
        if remaining <= 0:
            attempt.update(status='RUNTIME_CAP', error='operation deadline reached',
                           received_at=iso(self.now_fn()))
            return None, attempt
        capture_in_progress = False
        try:
            result = self.transport(url, method, body, min(REQUEST_TIMEOUT, remaining), MAX_RESPONSE_BYTES)
            raw = result['body']
            if not isinstance(raw, bytes):
                raise ValueError('transport must return exact bytes')
            attempt['http_status'] = int(result['status'])
            attempt['response_url'] = result.get('response_url', url)
            hdrs = {str(k).lower(): str(v) for k, v in result.get('headers', {}).items()}
            attempt['headers'] = {k: v for k, v in hdrs.items() if k in (
                'date', 'content-type', 'content-length', 'etag', 'last-modified', 'retry-after')}
            attempt['received_at'] = iso(self.now_fn())
            attempt['bytes_observed'] = len(raw)
            attempt['raw_truncated'] = len(raw) > MAX_RESPONSE_BYTES
            retained = raw[:MAX_RESPONSE_BYTES]
            capture_in_progress = True
            attempt['raw_sha256'] = self.capture(retained)
            capture_in_progress = False
            attempt['bytes_retained'] = len(retained)
            if attempt['raw_truncated']:
                attempt.update(status='RESPONSE_CAP', error='raw prefix retained; response incomplete')
                return None, attempt
            if attempt['response_url'] != url:
                # Redirected response is retained but not accepted as frozen source identity.
                attempt.update(status='REDIRECT_REJECTED', error='response URL differs from fixed request URL')
                return None, attempt
            if not 200 <= attempt['http_status'] < 300:
                attempt.update(status='HTTP_ERROR')
                return None, attempt
            data = json.loads(raw) if expect_json else raw.decode('utf-8')
            attempt['status'] = 'OK'
            return data, attempt
        except Exception as exc:
            if capture_in_progress:
                raise
            attempt.update(status='FAILED', error=f'{type(exc).__name__}: {str(exc)[:300]}',
                           received_at=iso(self.now_fn()))
            return None, attempt

    def collect(self, now=None, bootstrap=False, seen_ids=None, *, slot_at=None, deadline=None):
        """Read a bounded overlapping current feed, not a historical backfill.

        Snapshot pagination is ordered created descending (stable ties retained and
        deduplicated by ID); forum pagination follows activity-ranked latest pages.
        Bounded feeds are explicitly partial coverage even on successful requests.
        """
        observed_at = iso(now or slot_at or self.now_fn())
        deadline = min(deadline, self.monotonic() + MAX_RUNTIME) if deadline is not None else self.monotonic() + MAX_RUNTIME
        attempts, observations, seen = [], [], set()
        coverage = {'scope': 'bounded_current_feeds', 'exhaustive': False,
                    'bootstrap': bool(bootstrap), 'max_pages_per_source': MAX_PAGES,
                    'max_records_per_page': PAGE_SIZE, 'max_detail_requests': MAX_DETAIL_REQUESTS,
                    'sources': {}, 'missed_intervals_backfilled': False}
        self._snapshot(observations, attempts, seen, deadline, coverage)
        self._forum(observations, attempts, seen, deadline, coverage, seen_ids or set())
        self._documents(observations, attempts, deadline, coverage)
        for item in observations:
            item['bootstrap'] = bool(bootstrap)
            item['token_id'] = 'gmx-arbitrum'
            item['policy_version'] = None  # Human establishes an economic policy identity.
            item['semantic_status'] = 'PENDING_MANUAL_REVIEW'
            item['already_seen'] = item['candidate_id'] in (seen_ids or set())
        bad = any(a['status'] != 'OK' for a in attempts)
        source_bad = any(v.get('status') != 'OK_BOUNDED' for v in coverage['sources'].values())
        return {'status': 'PARTIAL_COVERAGE' if bad or source_bad else 'OK_BOUNDED',
                'observed_at': observed_at, 'received_at': iso(self.now_fn()),
                'observations': observations, 'candidates': observations,
                'source_attempts': attempts, 'attempts': attempts, 'coverage': coverage}

    @staticmethod
    def _time(item, field, errors):
        try:
            return source_iso(item.get(field))
        except (ValueError, TypeError, OverflowError, OSError) as exc:
            errors.append(f'{field}: {type(exc).__name__}')
            return None

    def _snapshot(self, output, attempts, seen, deadline, coverage):
        status, count, exhausted = 'OK_BOUNDED', 0, False
        for page in range(MAX_PAGES):
            query = '''query Proposals($skip: Int!, $first: Int!) {
              proposals(first: $first, skip: $skip, where: {space_in: ["gmx.eth"]},
                orderBy: "created", orderDirection: desc) {
                id title body created start end state link author space { id }
              }
            }'''
            data, a = self._request(self.snapshot_url, body={'query': query,
                'variables': {'skip': page * PAGE_SIZE, 'first': PAGE_SIZE}},
                deadline=deadline, label='gmx-snapshot')
            a['page'] = page
            attempts.append(a)
            if data is None:
                status = a['status']; break
            items = _obj(_obj(data).get('data')).get('proposals')
            if not isinstance(data, dict) or data.get('errors') or not isinstance(items, list) or len(items) > PAGE_SIZE:
                a.update(status='SCHEMA_ERROR', error='Snapshot errors/missing list/page exceeds cap')
                status = a['status']; break
            a['records'] = len(items)
            for item in items:
                if not isinstance(item, dict) or not isinstance(item.get('id'), str) or _obj(item.get('space')).get('id') != self.snapshot_space:
                    a.update(status='SCHEMA_ERROR', error='proposal identity differs from fixed space')
                    status = a['status']; continue
                candidate_id = 'gmx-snapshot:' + item['id']
                if candidate_id in seen:
                    continue
                seen.add(candidate_id)
                errors = []
                published = self._time(item, 'created', errors)
                start, end = self._time(item, 'start', errors), self._time(item, 'end', errors)
                output.append({'source_id': 'gmx-snapshot', 'candidate_id': candidate_id,
                    'id': item['id'], 'published_at': published, 'voting_start_at': start,
                    'voting_end_at': end, 'received_at': a['received_at'],
                    'raw_sha256': a['raw_sha256'], 'raw_pointer': {'page': page, 'proposal_id': item['id']},
                    'body': item, 'timestamp_errors': errors,
                    'publication_independently_verified': False})
                count += 1
            if len(items) < PAGE_SIZE:
                exhausted = True; break
        if not exhausted and status == 'OK_BOUNDED':
            status = 'PAGE_CAP'
        coverage['sources']['gmx-snapshot'] = {'status': status, 'records': count,
            'feed_exhausted_within_cap': exhausted,
            'limitations': 'Created-order feed does not enumerate later edits or independently prove publication time.'}

    def _forum(self, output, attempts, seen, deadline, coverage, seen_ids):
        status, count, exhausted, topics = 'OK_BOUNDED', 0, False, []
        for page in range(MAX_PAGES):
            url = f'{self.forum_base}/latest.json?page={page}'
            data, a = self._request(url, deadline=deadline, label='gmx-forum')
            a['page'] = page; attempts.append(a)
            if data is None:
                status = a['status']; break
            listing = _obj(_obj(data).get('topic_list'))
            items = listing.get('topics')
            if not isinstance(items, list) or len(items) > PAGE_SIZE:
                a.update(status='SCHEMA_ERROR', error='forum topics missing or page exceeds cap'); status = a['status']; break
            a['records'] = len(items)
            for item in items:
                if not isinstance(item, dict) or not isinstance(item.get('id'), int) or isinstance(item.get('id'), bool) or item['id'] <= 0:
                    a.update(status='SCHEMA_ERROR', error='invalid forum topic id'); status = a['status']; continue
                candidate_id = f"gmx-forum:{item['id']}"
                if candidate_id in seen:
                    continue
                seen.add(candidate_id)
                errors = []
                published = self._time(item, 'created_at', errors)
                updated = self._time(item, 'last_posted_at', errors)
                observation = {'source_id': 'gmx-forum', 'candidate_id': candidate_id,
                    'id': str(item['id']), 'published_at': published, 'last_posted_at': updated,
                    'received_at': a['received_at'], 'raw_sha256': a['raw_sha256'],
                    'raw_pointer': {'page': page, 'topic_id': item['id']}, 'body': item,
                    'timestamp_errors': errors, 'publication_independently_verified': False,
                    'detail_status': 'NOT_FETCHED_DETAIL_CAP', 'detail_complete': False}
                output.append(observation); topics.append(observation); count += 1
            if not items or not listing.get('more_topics_url'):
                exhausted = True; break
        if not exhausted and status == 'OK_BOUNDED':
            status = 'PAGE_CAP'
        # Deterministic details for oldest uncollected topic-version, never based on price/keywords.
        for t in topics:
            marker = t['candidate_id'] + '@' + (t['last_posted_at'] or '')
            if marker in seen_ids:
                t.update(detail_complete=True, detail_status='PREVIOUSLY_COMPLETE_RETAINED',
                         detail_version_marker=marker)
        pending = [t for t in topics if t['candidate_id'] + '@' + (t['last_posted_at'] or '') not in seen_ids]
        # New topics take precedence; then activity newest first. The durable caller
        # supplies candidate@version markers only after complete detail retention.
        pending.sort(key=lambda t: (t['last_posted_at'] or '', int(t['id'])), reverse=True)
        detail_requests = 0
        for item in pending:
            if detail_requests >= MAX_DETAIL_REQUESTS:
                break
            url = f"{self.forum_base}/t/{int(item['id'])}.json"
            data, a = self._request(url, deadline=deadline, label='gmx-forum-topic')
            detail_requests += 1
            a['candidate_id'] = item['candidate_id']; attempts.append(a)
            item['detail_status'] = a['status']
            if data is None:
                continue
            stream = _obj(_obj(data).get('post_stream'))
            posts, ids = stream.get('posts'), stream.get('stream')
            if not isinstance(data, dict) or data.get('id') != int(item['id']) or not isinstance(posts, list) or not isinstance(ids, list):
                a.update(status='SCHEMA_ERROR', error='topic identity/post stream missing'); item['detail_status'] = a['status']; continue
            if any(not isinstance(p, dict) or not isinstance(p.get('id'), int)
                   or isinstance(p.get('id'), bool) or p['id'] <= 0 for p in posts):
                a.update(status='SCHEMA_ERROR', error='forum posts require positive integer ids')
                item['detail_status'] = a['status']; continue
            post_ids = {p['id'] for p in posts}
            if (len(post_ids) != len(posts) or any(not isinstance(i, int) or isinstance(i, bool) or i <= 0 for i in ids)
                    or len(set(ids)) != len(ids) or not post_ids.issubset(set(ids))):
                a.update(status='SCHEMA_ERROR', error='invalid or duplicated forum post stream ids')
                item['detail_status'] = a['status']; continue
            raw_parts = [a['raw_sha256']]
            missing = [i for i in ids if i not in post_ids]
            while missing and detail_requests < MAX_DETAIL_REQUESTS:
                chunk = missing[:20]
                query = urllib.parse.urlencode([('post_ids[]', i) for i in chunk])
                post_url = f"{self.forum_base}/t/{int(item['id'])}/posts.json?{query}"
                extra, pa = self._request(post_url, deadline=deadline, label='gmx-forum-posts')
                detail_requests += 1
                pa['candidate_id'] = item['candidate_id']; attempts.append(pa)
                if extra is None:
                    break
                more_posts = _obj(_obj(extra).get('post_stream')).get('posts')
                if not isinstance(more_posts, list) or any(not isinstance(p, dict)
                        or not isinstance(p.get('id'), int) or isinstance(p.get('id'), bool)
                        or p['id'] <= 0 for p in more_posts):
                    pa.update(status='SCHEMA_ERROR', error='paginated forum posts require positive integer ids')
                    break
                returned_ids = {p['id'] for p in more_posts}
                if not isinstance(more_posts, list) or returned_ids != set(chunk) or len(more_posts) != len(chunk):
                    pa.update(status='SCHEMA_ERROR', error='post pagination did not return exact requested ids')
                    break
                posts.extend(more_posts); post_ids.update(returned_ids)
                raw_parts.append(pa['raw_sha256'])
                missing = [i for i in ids if i not in post_ids]
            complete = bool(len(post_ids) == len(ids) and set(ids) == post_ids)
            item.update(detail_status='OK_COMPLETE' if complete else 'OK_PARTIAL_POST_STREAM',
                detail_complete=complete, detail_raw_sha256=a['raw_sha256'],
                detail_received_at=a['received_at'], detail_body=data,
                detail_raw_sha256s=raw_parts, detail_posts=posts,
                detail_posts_retained=len(posts), detail_post_ids_declared=len(ids),
                detail_version_marker=item['candidate_id'] + '@' + (item['last_posted_at'] or ''))
        incomplete = sum(not t['detail_complete'] for t in topics)
        if incomplete and status == 'OK_BOUNDED':
            status = 'DETAIL_PARTIAL'
        coverage['sources']['gmx-forum'] = {'status': status, 'records': count,
            'feed_exhausted_within_cap': exhausted, 'detail_requests': detail_requests,
            'details_incomplete': incomplete,
            'details_pending_due_cap': sum(t['detail_status'] == 'NOT_FETCHED_DETAIL_CAP' for t in topics),
            'limitations': 'Latest pages are ranked by activity and may shift during sequential requests. Detail queue uses last_posted_at; edits without new replies may not trigger refetch. Bounded details and omitted post streams are partial.'}

    def _documents(self, output, attempts, deadline, coverage):
        for source_id, url in DOCUMENTS.items():
            body, a = self._request(url, deadline=deadline, label=source_id, expect_json=False)
            attempts.append(a)
            coverage['sources'][source_id] = {'status': 'OK_BOUNDED' if body is not None else a['status'],
                'limitations': 'Mutable current document; no independent publication clock or version history.'}
            if body is not None:
                output.append({'source_id': source_id, 'candidate_id': source_id + ':' + a['raw_sha256'],
                    'id': a['raw_sha256'], 'published_at': None, 'received_at': a['received_at'],
                    'raw_sha256': a['raw_sha256'], 'body': body,
                    'publication_independently_verified': False, 'timestamp_errors': []})

    def quote_batch(self, symbols=None):
        symbols = list(symbols or SYMBOLS)
        if symbols != list(SYMBOLS):
            raise ValueError('fixed quote batch must be GMXUSDT, BTCUSDT, ETHUSDT in frozen order')
        start, monotonic_start = iso(self.now_fn()), self.monotonic()
        deadline = monotonic_start + 60
        quotes, attempts, errors = {}, [], []
        for symbol in symbols:
            url = self.price_base + '/api/v3/ticker/bookTicker?' + urllib.parse.urlencode({'symbol': symbol})
            data, a = self._request(url, deadline=deadline, label='binance_spot_book_ticker')
            a['symbol'] = symbol; attempts.append(a)
            if data is None:
                errors.append(f'{symbol}:{a["status"]}'); continue
            try:
                if not isinstance(data, dict) or data.get('symbol') != symbol:
                    raise ValueError('symbol identity differs')
                bid, ask = Decimal(str(data['bidPrice'])), Decimal(str(data['askPrice']))
                if not bid.is_finite() or not ask.is_finite() or bid <= 0 or ask <= 0 or bid > ask:
                    raise ValueError('invalid/crossed bid/ask')
                quotes[symbol] = {'bid': str(bid), 'ask': str(ask), 'mid': str((bid + ask) / 2),
                    'request_started_at': a['request_started_at'], 'received_at': a['received_at'],
                    'source_timestamp': None, 'raw_sha256': a['raw_sha256'],
                    'venue': 'Binance public spot', 'quote_currency': 'USDT',
                    'research_proxy': True}
            except (ValueError, KeyError, TypeError, InvalidOperation) as exc:
                a.update(status='QUOTE_INVALID', error=str(exc)[:200]); errors.append(f'{symbol}:QUOTE_INVALID')
        end = iso(self.now_fn())
        duration = (dt.datetime.fromisoformat(end.replace('Z', '+00:00')) - dt.datetime.fromisoformat(start.replace('Z', '+00:00'))).total_seconds()
        monotonic_duration = self.monotonic() - monotonic_start
        if duration < 0 or duration > 60 or monotonic_duration < 0 or monotonic_duration > 60:
            errors.append('BATCH_CLOCK_WINDOW')
        return {'status': 'OK' if not errors and len(quotes) == 3 else 'FAILED',
            'quotes': quotes, 'started_at': start, 'received_at': end,
            'source_timestamp': None, 'sequential': True, 'duration_seconds': duration,
            'duration_seconds_monotonic': monotonic_duration,
            'source_attempts': attempts, 'attempts': attempts, 'errors': errors,
            'limitations': 'Midpoint research proxies; no broker access/fills or verified owner fees. USDT is not guaranteed USD.'}

    quote = quote_batch


Adapters = PublicAdapters
LiveAdapters = PublicAdapters
