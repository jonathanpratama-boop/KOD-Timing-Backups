"""Bounded Binance public batch readers; no orders, credentials or fallback.

The caller stores each returned raw_http envelope once with BroadStore. Rows are
normalizations of the exact all-symbol response under a supplied metadata frame;
no row is an admission decision. Frozen cohort members are never substituted.
"""
from __future__ import annotations
import datetime as dt
from decimal import Decimal, InvalidOperation, localcontext
import hashlib
import json
import math
import time
import urllib.error
import urllib.parse
import urllib.request

UTC = dt.timezone.utc
BASE = 'https://api.binance.com'
ENDPOINTS = {'metadata': '/api/v3/exchangeInfo?showPermissionSets=false', 'bbo': '/api/v3/ticker/bookTicker',
             'stats': '/api/v3/ticker/24hr'}
MAX_BYTES = 16 * 1024 * 1024
MAX_RECORDS = 10000
MAX_COHORT = 150
TIMEOUTS = {'metadata': 15.0, 'bbo': 10.0, 'stats': 15.0}
SELECTED_HEADERS = {'date', 'content-type', 'content-length', 'retry-after',
                    'x-mbx-used-weight', 'x-mbx-used-weight-1m',
                    'x-sapi-used-ip-weight-1m', 'x-mbx-order-count-10s',
                    'x-mbx-order-count-1d'}


def utcnow():
    return dt.datetime.now(UTC)


def iso(value):
    if not isinstance(value, dt.datetime) or value.tzinfo is None:
        raise ValueError('aware datetime clock required')
    return value.astimezone(UTC).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def _valid_symbol(value):
    # Binance currently lists Unicode token names. Preserve exact exchange
    # identity; do not transliterate, case-fold or silently substitute symbols.
    return isinstance(value, str) and 1 <= len(value) <= 40 and value.isalnum() and value == value.upper()


def _decimal(value, *, positive=False, nonnegative=False):
    if isinstance(value, (bool, dict, list, type(None))):
        raise ValueError('numeric field has invalid type')
    if len(str(value))>128:
        raise ValueError('numeric field exceeds128-character cap')
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError('numeric field is not decimal') from None
    if not number.is_finite() or (positive and number <= 0) or (nonnegative and number < 0):
        raise ValueError('numeric field is nonfinite or outside bounds')
    return number


def _epoch_ms(value):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError('source clock must be nonnegative integer milliseconds')
    try:
        return iso(dt.datetime.fromtimestamp(value / 1000, UTC))
    except (ValueError, OSError, OverflowError):
        raise ValueError('source clock outside supported range') from None


def _permission(row):
    """Retain all declared flags; require explicit positive spot permission.

    Modern empty permissions arrays are valid when permissionSets has SPOT.
    isSpotTradingAllowed false is an explicit nonexecution flag even if an older
    SPOT permission label remains. Missing flags never create positive eligibility.
    """
    declared = {}
    labels = set()
    errors = []
    if 'permissions' in row:
        values = row['permissions']; declared['permissions'] = values
        if not isinstance(values, list) or any(not isinstance(x, str) for x in values):
            errors.append('invalid_permissions')
        else:
            labels.update(values)
    if 'permissionSets' in row:
        values = row['permissionSets']; declared['permissionSets'] = values
        if not isinstance(values, list) or any(not isinstance(group, list)
                or any(not isinstance(x, str) for x in group) for group in values):
            errors.append('invalid_permissionSets')
        else:
            for group in values:
                labels.update(group)
    flag = row.get('isSpotTradingAllowed')
    if 'isSpotTradingAllowed' in row:
        declared['isSpotTradingAllowed'] = flag
        if not isinstance(flag, bool):
            errors.append('invalid_isSpotTradingAllowed')
    positive = flag is True or 'SPOT' in labels
    if flag is False or errors:
        positive = False
    return positive, declared, errors


def normalize_metadata(data):
    """Normalize current quote-USDT metadata; preserve nontrading rows and flags."""
    if not isinstance(data, dict) or not isinstance(data.get('symbols'), list):
        raise ValueError('exchangeInfo must contain symbols array')
    items = data['symbols']
    if len(items) > MAX_RECORDS:
        raise ValueError('metadata records cap')
    seen, normalized, errors = set(), [], []
    for index, item in enumerate(items):
        if not isinstance(item, dict) or not _valid_symbol(item.get('symbol')):
            raise ValueError(f'invalid metadata symbol identity at index {index}')
        symbol = item['symbol']
        if symbol in seen:
            raise ValueError('duplicate metadata symbol identity')
        seen.add(symbol)
        if (not isinstance(item.get('baseAsset'), str) or not isinstance(item.get('quoteAsset'), str)
                or not isinstance(item.get('status'), str)):
            raise ValueError('metadata requires baseAsset quoteAsset and status')
        if item['quoteAsset'] != 'USDT':
            continue
        row_errors = []
        if symbol != item['baseAsset'] + item['quoteAsset']:
            row_errors.append('symbol_asset_identity_mismatch')
        permission, declared, permission_errors = _permission(item)
        row_errors.extend(permission_errors)
        executable = item['status'] == 'TRADING' and permission and not row_errors
        normalized.append({'symbol': symbol, 'base_asset': item['baseAsset'],
            'quote_asset': item['quoteAsset'], 'status': item['status'],
            'spot_permission': permission, 'permission_fields': declared,
            'execution_eligible': executable, 'metadata_errors': row_errors})
        errors.extend({'symbol': symbol, 'reason': error} for error in row_errors)
    normalized.sort(key=lambda item: item['symbol'])
    server_time, source_clock_error = None, None
    if 'serverTime' in data:
        try: server_time = _epoch_ms(data['serverTime'])
        except ValueError as exc: source_clock_error = str(exc)
    return {'schema': 'broad-spot-usdt-metadata-v1', 'symbols': normalized,
        'all_symbol_identities': sorted(seen),
        'raw_symbol_count': len(items), 'normalized_spot_usdt_count': len(normalized),
        'execution_eligible_count': sum(row['execution_eligible'] for row in normalized),
        'metadata_errors': errors, 'source_timestamp': server_time,
        'source_clock_error': source_clock_error, 'universe_policy': 'All quote-USDT metadata retained; TRADING and explicit spot permission gate execution only.',
        'membership_change_policy': 'Current frame metadata does not substitute or add frozen cohort members.'}


def _metadata_rows(metadata):
    if not isinstance(metadata, dict) or metadata.get('schema') != 'broad-spot-usdt-metadata-v1':
        raise ValueError('normalized pinned metadata frame required')
    rows = metadata.get('symbols')
    if not isinstance(rows, list) or len(rows) > MAX_RECORDS:
        raise ValueError('invalid pinned metadata rows')
    identities = metadata.get('all_symbol_identities')
    if (not isinstance(identities,list) or len(identities)>MAX_RECORDS
            or any(not _valid_symbol(symbol) for symbol in identities)
            or len(set(identities))!=len(identities)):
        raise ValueError('complete pinned metadata identity set required')
    seen = set()
    for item in rows:
        if (not isinstance(item, dict) or not _valid_symbol(item.get('symbol'))
                or item.get('quote_asset') != 'USDT' or not isinstance(item.get('status'), str)
                or not isinstance(item.get('execution_eligible'), bool)
                or not isinstance(item.get('spot_permission'), bool)):
            raise ValueError('invalid pinned metadata row')
        if item['symbol'] in seen:
            raise ValueError('duplicate pinned metadata row')
        seen.add(item['symbol'])
    if not seen.issubset(set(identities)):
        raise ValueError('USDT metadata identity absent from complete symbol set')
    return rows


def _cohort_symbols(cohort):
    if not isinstance(cohort, (list, tuple)) or len(cohort) > MAX_COHORT:
        raise ValueError('frozen cohort must contain at most150 supplied symbols')
    if any(not _valid_symbol(symbol) for symbol in cohort) or len(set(cohort)) != len(cohort):
        raise ValueError('cohort symbol identity invalid or duplicated')
    return tuple(cohort)


def _index_batch(data):
    if not isinstance(data, list) or len(data) > MAX_RECORDS:
        raise ValueError('all-symbol response must be bounded array')
    index, duplicates, malformed = {}, set(), 0
    for item in data:
        if not isinstance(item, dict) or not _valid_symbol(item.get('symbol')):
            malformed += 1
            continue
        symbol = item['symbol']
        if symbol in index:
            duplicates.add(symbol)
        else:
            index[symbol] = item
    return index, duplicates, malformed


def normalize_batch(data, metadata, kind, cohort=()):
    """Normalize one batch; no per-symbol requests, journals or substitutions."""
    if kind not in ('bbo', 'stats'):
        raise ValueError('unknown normalization kind')
    metadata_rows = _metadata_rows(metadata)
    cohort = _cohort_symbols(cohort)
    index, duplicates, malformed = _index_batch(data)
    rows, missing, invalid = [], [], []
    for meta in metadata_rows:
        symbol = meta['symbol']
        row = {'symbol': symbol, 'metadata_status': meta['status'],
            'spot_permission': meta['spot_permission'],
            'execution_eligible': meta['execution_eligible'],
            'metadata_execution_eligible': meta['execution_eligible'],
            'membership': 'FROZEN_COHORT' if symbol in cohort else 'OBSERVATION_UNIVERSE',
            'status': 'OK', 'source_timestamp': None}
        if kind == 'bbo':
            row.update(quote_valid=False,positive_size=False,observed_quote_usable=False)
        item = index.get(symbol)
        if item is None:
            row['status'] = 'MISSING_RESPONSE_SYMBOL'
            missing.append({'symbol': symbol, 'reason': row['status']})
        elif symbol in duplicates:
            row['status'] = 'DUPLICATE_RESPONSE_SYMBOL'
            invalid.append({'symbol': symbol, 'reason': row['status']})
        else:
            try:
                if kind == 'bbo':
                    # Keep exact source decimal strings, then validate for proxy use.
                    row.update({name: item.get(name) for name in ('bidPrice','bidQty','askPrice','askQty')})
                    bid, ask = _decimal(item.get('bidPrice'),nonnegative=True), _decimal(item.get('askPrice'),nonnegative=True)
                    bid_qty = _decimal(item.get('bidQty'),nonnegative=True)
                    ask_qty = _decimal(item.get('askQty'),nonnegative=True)
                    if bid <= 0 or ask <= 0:
                        if meta['execution_eligible']:
                            raise ValueError('nonpositive book for metadata-eligible symbol')
                        row['status']='NONEXECUTABLE_BOOK'
                        row['unusable_reason']='NONPOSITIVE_BOOK_FOR_NONEXECUTABLE_METADATA'
                    elif bid > ask:
                        raise ValueError('crossed bid/ask')
                    else:
                        with localcontext() as context:
                            context.prec=130
                            row['mid'] = str((bid+ask)/2)
                        row['quote_valid'] = True
                        row['positive_size'] = bid_qty > 0 and ask_qty > 0
                        row['observed_quote_usable'] = row['metadata_execution_eligible'] and row['positive_size']
                else:
                    numbers = ('priceChange','priceChangePercent','weightedAvgPrice','prevClosePrice',
                        'lastPrice','lastQty','bidPrice','bidQty','askPrice','askQty',
                        'openPrice','highPrice','lowPrice','volume','quoteVolume')
                    row.update({name:item.get(name) for name in numbers})
                    for name in numbers:
                        _decimal(item.get(name),nonnegative=name not in ('priceChange','priceChangePercent'))
                    open_time, close_time = item.get('openTime'),item.get('closeTime')
                    row['statistics_open_at'] = _epoch_ms(open_time)
                    row['statistics_close_at'] = _epoch_ms(close_time)
                    if close_time < open_time:
                        raise ValueError('statistics close precedes open')
                    count = item.get('count')
                    if not isinstance(count,int) or isinstance(count,bool) or count < 0:
                        raise ValueError('statistics count invalid')
                    for name in ('firstId','lastId','count'):
                        value = item.get(name)
                        if not isinstance(value,int) or isinstance(value,bool) or value < (-1 if count==0 and name!='count' else 0):
                            raise ValueError('statistics count/id invalid')
                        row[name] = value
                    row['statistics_valid'] = True
                    row['source_timestamp'] = row['statistics_close_at']
            except (ValueError, InvalidOperation) as exc:
                row['status'] = 'INVALID_RESPONSE_FIELDS'
                row['field_error'] = str(exc)
                row['quote_valid' if kind == 'bbo' else 'statistics_valid'] = False
                invalid.append({'symbol':symbol,'reason':row['status']})
        if not row['execution_eligible']:
            row['nonexecution_reason'] = ('STATUS_' + meta['status'] if meta['status'] != 'TRADING'
                                         else 'SPOT_PERMISSION_OR_METADATA_UNVERIFIED')
        rows.append(row)
    meta_index = {row['symbol']:row for row in metadata_rows}
    cohort_status = []
    normalized_index = {row['symbol']:row for row in rows}
    for symbol in cohort:
        if symbol not in meta_index:
            cohort_status.append({'symbol':symbol,'status':'MISSING_PINNED_METADATA','execution_eligible':False})
        else:
            row = normalized_index[symbol]
            cohort_status.append({'symbol':symbol,'status':row['status'],
                'metadata_status':row['metadata_status'],'execution_eligible':row['execution_eligible']})
    expected = set(meta_index)
    all_metadata_symbols = metadata.get('all_symbol_identities')
    if (not isinstance(all_metadata_symbols,list) or len(all_metadata_symbols)>MAX_RECORDS
            or any(not _valid_symbol(symbol) for symbol in all_metadata_symbols)
            or len(set(all_metadata_symbols))!=len(all_metadata_symbols)):
        raise ValueError('complete pinned metadata identity set required')
    all_metadata_symbols = set(all_metadata_symbols)
    unmatched = [{'symbol':symbol,'status':'MISSING_PINNED_METADATA',
                  'execution_eligible':False,'raw_fields':item}
                 for symbol,item in sorted(index.items()) if symbol not in all_metadata_symbols]
    return {'schema':'broad-spot-usdt-' + kind + '-v1','rows':rows,
        'raw_symbol_count':len(data),'normalized_spot_usdt_count':len(rows),
        'raw_unmatched_metadata_count':len(unmatched),'unmatched_rows':unmatched,
        'raw_known_non_usdt_count':sum(symbol in all_metadata_symbols and symbol not in expected for symbol in index),
        'raw_malformed_record_count':malformed,'duplicate_symbols':sorted(duplicates),
        'missing':missing,'invalid':invalid,'cohort_status':cohort_status,
        'execution_eligible_count':sum(row['execution_eligible'] for row in rows),
        'metadata_execution_eligible_count':sum(row['metadata_execution_eligible'] for row in rows),
        'observed_quote_usable_count':sum(row.get('observed_quote_usable',False) for row in rows),
        'valid_response_count':sum(row['status']=='OK' for row in rows),
        'nonexecutable_book_count':sum(row['status']=='NONEXECUTABLE_BOOK' for row in rows),
        'source_timestamp':None, 'source_timestamp_semantics':('No source quote timestamp in bookTicker; UTC receipt is local observation.' if kind=='bbo'
            else 'Per-row closeTime describes rolling statistics window, not an execution quote clock.'),
        'membership_change_policy':'No frozen member is automatically added, replaced or removed.'}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _transport(url, timeout, max_bytes):
    deadline = time.monotonic() + timeout
    req = urllib.request.Request(url,method='GET',headers={
        'Accept':'application/json','Accept-Encoding':'identity',
        'User-Agent':'KOD-Broad-Paper-Observer/1 (public read-only batch research)'})
    try:
        response = urllib.request.build_opener(_NoRedirect).open(req,timeout=timeout)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        chunks, retained, error = [], 0, None
        while retained <= max_bytes:
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                error = 'request wall deadline reached'; break
            # urllib's socket timeout normally applies per read. Tighten it to
            # the remaining operation budget so a slow body cannot renew it.
            sock = getattr(getattr(getattr(response,'fp',None),'raw',None),'_sock',None)
            if sock is not None:
                sock.settimeout(remaining)
            try:
                reader = getattr(response,'read1',None) or response.read
                chunk = reader(min(64*1024,max_bytes+1-retained))
            except Exception as exc:
                error = f'{type(exc).__name__}: {str(exc)[:160]}'; break
            if not chunk:
                break
            chunks.append(chunk);retained += len(chunk)
        raw = b''.join(chunks)
        return {'status':response.status,'headers':dict(response.headers),
                'body':raw,'response_url':response.geturl(),
                'response_incomplete':error is not None,'transport_error':error}


class PublicBatchAdapters:
    def __init__(self, *, transport=None, now_fn=utcnow, monotonic=time.monotonic,
                 audit=None, max_bytes=MAX_BYTES):
        if not isinstance(max_bytes,int) or isinstance(max_bytes,bool) or not 1 <= max_bytes <= MAX_BYTES:
            raise ValueError('response cap must be positive and no greater than16MiB')
        self.transport = transport or _transport
        self.now_fn,self.monotonic,self.audit = now_fn,monotonic,audit
        self.max_bytes = max_bytes
        self.halted = False
        self.halt_reason = None
        self.sequence = 0

    def _request(self,kind,*,symbols=None,timeout=None):
        if kind not in ENDPOINTS:
            raise ValueError('unknown fixed endpoint')
        url = BASE + ENDPOINTS[kind]
        if symbols is not None:
            if kind != 'bbo':
                raise ValueError('symbols query permitted only for explicit BBO batch')
            symbols = _cohort_symbols(symbols)
            if not symbols:
                raise ValueError('explicit BBO symbol batch must not be empty')
            url += '?' + urllib.parse.urlencode({'symbols':json.dumps(symbols,ensure_ascii=False,separators=(',',':'))})
        timeout = TIMEOUTS[kind] if timeout is None else min(float(timeout),TIMEOUTS[kind])
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError('positive bounded timeout required')
        start = iso(self.now_fn()); monotonic_start = self.monotonic(); self.sequence += 1
        attempt = {'kind':kind,'url':url,'method':'GET','request_started_at':start,
            'received_at':None,'source_timestamp':None,'http_status':None,'status':'FAILED',
            'attempted':False,'headers':{},'body':b'','raw_truncated':False,
            'response_body_complete':False,'capture_status':'NO_RESPONSE_CAPTURED',
            'max_response_bytes':self.max_bytes,'timeout_seconds':timeout}
        if symbols is not None:
            attempt['request_symbols']=list(symbols)
            attempt['transport_mode']='EXPLICIT_FROZEN_SYMBOL_BATCH'
        attempt['request_id'] = hashlib.sha256((url+start+str(self.sequence)).encode()).hexdigest()
        if self.halted:
            attempt.update(status='BLOCKED_LATCHED',received_at=iso(self.now_fn()),
                block_reason=self.halt_reason,requires_operator_review=True,
                elapsed_seconds_monotonic=0)
            return None,attempt
        if self.audit:
            self.audit('request_started',{key:value for key,value in attempt.items() if key!='body'})
        # Errors from audit callbacks remain fatal; source failures cannot hide a
        # durable-store failure. No retries or alternate endpoints exist here.
        try:
            attempt['attempted'] = True
            transport_started=self.monotonic()
            result = self.transport(url,timeout,self.max_bytes)
            attempt['received_at']=iso(self.now_fn())
            attempt['transport_elapsed_seconds_monotonic']=self.monotonic()-transport_started
            raw = result['body']
            if not isinstance(raw,bytes):
                raise ValueError('transport must return exact response bytes')
            attempt['http_status'] = int(result['status'])
            attempt['response_url'] = result.get('response_url',url)
            headers = {str(k).lower():str(v) for k,v in result.get('headers',{}).items()}
            attempt['headers'] = {key:value for key,value in headers.items() if key in SELECTED_HEADERS or key.startswith('x-mbx-used-weight-')}
            attempt['bytes_observed'] = len(raw)
            attempt['body'] = raw[:self.max_bytes]
            attempt['bytes_retained'] = len(attempt['body'])
            attempt['raw_sha256'] = hashlib.sha256(attempt['body']).hexdigest()
            attempt['raw_truncated'] = len(raw)>self.max_bytes
            attempt['response_incomplete'] = bool(result.get('response_incomplete'))
            attempt['response_body_complete'] = not attempt['raw_truncated'] and not attempt['response_incomplete']
            attempt['capture_status'] = ('RESPONSE_CAP_PREFIX' if attempt['raw_truncated']
                else 'INCOMPLETE_RESPONSE_PREFIX' if attempt['response_incomplete'] else 'COMPLETE_RESPONSE_BYTES')
            if result.get('transport_error'):
                attempt['transport_error'] = str(result['transport_error'])[:200]
            blocked = (attempt['http_status'] in (418,429,403,451)
                       or 'retry-after' in headers or 300 <= attempt['http_status'] < 400
                       or attempt['response_url'] != url)
            if blocked:
                attempt.update(status='BLOCKED',block_reason='provider_block_or_retry_after_or_redirect',requires_operator_review=True)
                self.halted,self.halt_reason = True,attempt['block_reason']
                data = None
            elif attempt['raw_truncated']:
                attempt.update(status='RESPONSE_CAP',error='bounded response prefix retained; incomplete raw response')
                data = None
            elif attempt['response_incomplete']:
                attempt.update(status='INCOMPLETE_RESPONSE');data=None
            elif not 200 <= attempt['http_status'] < 300:
                attempt.update(status='HTTP_ERROR');data = None
            else:
                data = json.loads(raw)
                if isinstance(data,dict) and isinstance(data.get('code'),int) and data['code'] < 0:
                    attempt.update(status='API_ERROR',api_error_code=data['code'])
                    if data['code'] == -1003:
                        attempt.update(status='BLOCKED',block_reason='provider_rate_limit_api_error',requires_operator_review=True)
                        self.halted,self.halt_reason = True,attempt['block_reason']
                    data = None
                else:
                    attempt['status']='OK'
        except Exception as exc:
            attempt.update(status='FAILED',error=f'{type(exc).__name__}: {str(exc)[:240]}')
            data = None
        if attempt['received_at'] is None:
            attempt['received_at'] = iso(self.now_fn())
        attempt['processing_finished_at']=iso(self.now_fn())
        attempt['elapsed_seconds_monotonic'] = self.monotonic()-monotonic_start
        if attempt['elapsed_seconds_monotonic'] < 0:
            attempt.update(status='CLOCK_ERROR');data=None
        elif attempt['elapsed_seconds_monotonic'] > timeout:
            attempt['request_time_cap_exceeded']=True
            if attempt['status'] != 'BLOCKED':
                attempt['status']='REQUEST_TIME_CAP'
            data=None
        if self.audit:
            self.audit('request_finished',{key:value for key,value in attempt.items() if key!='body'})
        return data,attempt

    def metadata(self):
        data,attempt = self._request('metadata')
        summary = None
        if data is not None:
            try: summary=normalize_metadata(data)
            except ValueError as exc: attempt.update(status='SCHEMA_ERROR',error=str(exc))
        status=attempt['status']
        if summary is not None:
            status='PARTIAL' if summary['metadata_errors'] or summary['source_clock_error'] else 'OK'
            summary['raw_sha256']=attempt['raw_sha256']
            summary['received_at']=attempt['received_at']
            summary['source_timestamp']=summary.get('source_timestamp')
        return {'kind':'metadata','status':status,'raw_http':[attempt], 'summary':summary,
                'requires_operator_review':self.halted}

    def _frame(self,kind,metadata,cohort):
        # Validate pinned inputs before using any public request budget.
        _metadata_rows(metadata);_cohort_symbols(cohort)
        data,attempt = self._request(kind)
        summary=None
        if data is not None:
            try: summary=normalize_batch(data,metadata,kind,cohort)
            except ValueError as exc: attempt.update(status='SCHEMA_ERROR',error=str(exc))
        status=attempt['status']
        if summary is not None:
            status='PARTIAL' if (summary['missing'] or summary['invalid'] or summary['duplicate_symbols']
                or summary['raw_malformed_record_count'] or summary['raw_unmatched_metadata_count']
                or any(row['status']=='MISSING_PINNED_METADATA' for row in summary['cohort_status'])) else 'OK'
            summary.update(raw_sha256=attempt['raw_sha256'],received_at=attempt['received_at'],
                pinned_metadata_raw_sha256=metadata.get('raw_sha256'),
                pinned_metadata_received_at=metadata.get('received_at'))
        return {'kind':kind,'status':status,'raw_http':[attempt], 'summary':summary,
                'requires_operator_review':self.halted}

    def bbo(self,metadata,cohort=()):return self._frame('bbo',metadata,cohort)
    def stats24h(self,metadata,cohort=()):return self._frame('stats',metadata,cohort)

    def bbo_symbols_frame(self,metadata,planned_symbols,*,batch_size=150,max_batches=6,
                          cohort=(),frame_timeout=55.0):
        """Read an explicitly frozen symbol plan; never an automatic fallback.

        The caller freezes the transport mode and full membership before T0.
        Each symbol's local clocks identify its actual sequential request batch.
        A provider stop ends the frame immediately and leaves remaining chunks
        explicitly unattempted. The durable orchestrator must persist that stop.
        """
        _metadata_rows(metadata);cohort=_cohort_symbols(cohort)
        if (not isinstance(batch_size,int) or isinstance(batch_size,bool) or not 1<=batch_size<=150
                or not isinstance(max_batches,int) or isinstance(max_batches,bool) or not 1<=max_batches<=6):
            raise ValueError('explicit frame permits at most6 batches of at most150 symbols')
        if (not isinstance(planned_symbols,(list,tuple)) or not planned_symbols
                or len(planned_symbols)>batch_size*max_batches
                or any(not _valid_symbol(symbol) for symbol in planned_symbols)
                or len(set(planned_symbols))!=len(planned_symbols)
                or list(planned_symbols)!=sorted(planned_symbols)):
            raise ValueError('planned symbols must be nonempty frozen sorted unique membership within batch cap')
        if isinstance(frame_timeout,bool) or not isinstance(frame_timeout,(int,float)) or not math.isfinite(frame_timeout) or not 0<frame_timeout<=60:
            raise ValueError('frame deadline must be positive and at most60 seconds')
        planned=tuple(planned_symbols);planned_set=set(planned)
        chunks=[planned[i:i+batch_size] for i in range(0,len(planned),batch_size)]
        start=iso(self.now_fn());monotonic_start=self.monotonic();deadline=monotonic_start+frame_timeout
        raw_http,combined,unattempted,batch_map=[],[],[],{}
        for batch_id,chunk in enumerate(chunks):
            if self.halted or self.monotonic()>=deadline:
                reason='PROVIDER_STOP' if self.halted else 'FRAME_TIME_CAP'
                for skipped_id,skipped_chunk in enumerate(chunks[batch_id:],batch_id):
                    unattempted.append({'batch_id':skipped_id,'symbols':list(skipped_chunk),'reason':reason})
                    for symbol in skipped_chunk:
                        batch_map[symbol]={'batch_id':skipped_id,'status':'NOT_REQUESTED_'+reason,
                            'request_started_at':None,'received_at':None}
                break
            data,attempt=self._request('bbo',symbols=chunk,timeout=deadline-self.monotonic())
            attempt['batch_id']=batch_id;raw_http.append(attempt)
            for symbol in chunk:
                batch_map[symbol]={'batch_id':batch_id,'status':attempt['status'],
                    'request_started_at':attempt['request_started_at'],'received_at':attempt['received_at']}
            if data is not None:
                try:
                    indexed,duplicates,malformed=_index_batch(data)
                    unexpected=sorted(set(indexed)-set(chunk))
                    if duplicates or malformed or unexpected:
                        attempt.update(status='SCHEMA_ERROR',error='explicit batch returned duplicate, malformed or unrequested identity',
                            unexpected_symbols=unexpected,duplicate_symbols=sorted(duplicates),malformed_records=malformed)
                        for symbol in chunk:batch_map[symbol]['status']='SCHEMA_ERROR'
                    else:
                        combined.extend(data)
                except ValueError as exc:
                    attempt.update(status='SCHEMA_ERROR',error=str(exc))
                    for symbol in chunk:batch_map[symbol]['status']='SCHEMA_ERROR'
        subset=dict(metadata,symbols=[row for row in metadata['symbols'] if row['symbol'] in planned_set])
        summary=normalize_batch(combined,subset,'bbo',[symbol for symbol in cohort if symbol in planned_set])
        for row in summary['rows']:
            source=batch_map[row['symbol']]
            row.update(batch_id=source['batch_id'],request_started_at=source['request_started_at'],
                received_at=source['received_at'],source_batch_status=source['status'])
            if source['status']!='OK':
                row['status']=('MISSING_SOURCE_BATCH' if source['request_started_at'] is not None else source['status'])
                row['source_failure_reason']=source['status'];row['observed_quote_usable']=False
        metadata_symbols={row['symbol'] for row in metadata['symbols']}
        summary.update(transport_mode='EXPLICIT_FROZEN_SYMBOL_BATCHES',planned_symbols=list(planned),
            planned_batch_count=len(chunks),attempted_batch_count=len(raw_http),unattempted_batches=unattempted,
            missing_requested_metadata=[symbol for symbol in planned if symbol not in metadata_symbols],
            cohort_not_requested=[symbol for symbol in cohort if symbol not in planned_set],
            started_at=start,received_at=iso(self.now_fn()),
            sequential_span_seconds_monotonic=self.monotonic()-monotonic_start,
            pinned_metadata_raw_sha256=metadata.get('raw_sha256'),pinned_metadata_received_at=metadata.get('received_at'),
            frame_timeout_seconds=frame_timeout,
            normalized_spot_usdt_count=len(summary['rows']),
            observed_quote_usable_count=sum(row['observed_quote_usable'] for row in summary['rows']))
        bad=(summary['missing'] or summary['invalid'] or summary['missing_requested_metadata'] or unattempted
             or any(attempt['status']!='OK' for attempt in raw_http))
        status='BLOCKED' if self.halted else 'PARTIAL' if bad else 'OK'
        return {'kind':'bbo','status':status,'raw_http':raw_http,'summary':summary,
                'requires_operator_review':self.halted}


BatchAdapters = PublicBatchAdapters
