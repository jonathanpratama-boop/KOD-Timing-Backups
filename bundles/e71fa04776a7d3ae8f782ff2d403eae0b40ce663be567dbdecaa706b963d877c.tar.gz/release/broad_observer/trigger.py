"""Causal diagnostic extracted from a pinned legacy source, never a strategy.

Inputs are CLOSED ONE-HOUR bars on a dense hourly grid. Missing cells stay
missing. A one-minute candle is not one element of this detector's hourly grid.
The caller must mask every bar not actually received by the evaluation's as-of
time, including delayed/backfilled bars with older source timestamps. Numeric
arrays alone cannot establish those per-bar availability clocks.
The legacy dataset-end mask, future control exclusions, assumed next-hour fills,
costs and outcome functions are deliberately absent.

Only indices <= ``index`` are read. The baseline retains the legacy sequential
float-prefix arithmetic (including its rounding), fixed /168 denominator and
minimum 150 finite observations. Input-quality UNKNOWN is retained separately
from a known false condition. No tolerance or threshold is fitted here.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
from pathlib import Path

UTC = dt.timezone.utc
SOURCE_COMMIT = "c7c84127e94b6debf691d321fa553377dc4af575"
SOURCE_PATH = "hermes/ignition_v0/scan_v0.py"
SOURCE_SHA256 = "960279f9cbddeb45f82e6fd565b79b55ddd60fbd13b0ea739bc298660025646e"
SOURCE_BLOB_SHA1 = "34dcdc4d5c33b8decaf695cff048e07f74a7622d"
VERSION = "LEGACY_CAUSAL_TRIGGER_DIAGNOSTIC_V1"
COOLDOWN_HOURS = 72
PARAMETERS = {
    "return_3h_gte": 0.10,
    "volume_multiple_gte": 5.0,
    "prior_return_168h_lte": 0.30,
    "average_hourly_quote_volume_gte": 20000.0,
    "baseline_hours": 168,
    "minimum_finite_baseline_hours": 150,
    "cooldown_hours": COOLDOWN_HOURS,
}


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode()


def _stamp(value):
    if isinstance(value, str):
        value = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if not isinstance(value, dt.datetime) or value.tzinfo is None:
        raise ValueError("aware timestamp required")
    return value.astimezone(UTC)


def _iso(value):
    return _stamp(value).isoformat(timespec="microseconds").replace("+00:00", "Z")


def verify_legacy_source(root=None):
    """Verify exact retained bytes without importing/executing the harness."""
    root = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    path = root / "authoritative/legacy-ignition-c7c84127/scan_v0.py"
    raw = path.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    blob = hashlib.sha1(("blob " + str(len(raw)) + "\0").encode() + raw).hexdigest()
    if sha != SOURCE_SHA256 or blob != SOURCE_BLOB_SHA1:
        raise ValueError("retained legacy source differs from pinned identities")
    return {"sha256": sha, "git_blob_sha1": blob, "bytes": len(raw),
            "commit": SOURCE_COMMIT, "source_executed": False}


def _finite(value):
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def _base_result(index):
    return {
        "version": VERSION,
        "source_commit": SOURCE_COMMIT,
        "source_sha256": SOURCE_SHA256,
        "input_interval": "CLOSED_1H_DENSE_GRID",
        "index": index,
        "status": "UNKNOWN",
        "raw_trigger": None,
        "reason": None,
        "features": {"return_3h": None, "quote_volume_3h": None,
                     "average_hourly_quote_volume": None, "volume_multiple": None,
                     "prior_return_168h": None, "finite_baseline_hours": None},
        "windows": {"close_offsets_hours": [0, -3, -171],
                    "trigger_quote_offsets_hours": [-2, -1, 0],
                    "baseline_quote_offsets_inclusive": [-170, -3],
                    "baseline_fixed_divisor": 168},
        "diagnostic_only": True,
        "strategy_enrollment": False,
        "future_data_required": False,
        "whole_legacy_harness_equivalence_claim": False,
    }


def evaluate_causal(closes, quote_volumes, index=None):
    """Evaluate the pinned causal equations at one completed hourly position.

    Numeric source strings are accepted. Missing/NaN baseline volume cells count
    as missing and contribute zero, while division remains by 168 (not the
    observed count). Infinite/malformed volume, invalid trigger prices, negative source
    volume or fewer than 150 finite baseline cells yields UNKNOWN. No future
    quote, outcome, dataset-end eligibility or control-pool argument exists.
    """
    if len(closes) != len(quote_volumes):
        raise ValueError("close and quote-volume grids must have the same length")
    if index is None:
        index = len(closes) - 1
    if isinstance(index, bool) or not isinstance(index, int):
        raise ValueError("integer hourly grid index required")
    if index < 0:
        if index != -1 or len(closes):
            raise ValueError("hourly grid index outside available input")
    elif index >= len(closes):
        raise ValueError("hourly grid index outside available input")
    result = _base_result(index)
    if index < 171:
        result["reason"] = "WARMUP_REQUIRES_172_HOURLY_GRID_POSITIONS"
        return result

    prices = [_finite(closes[position]) for position in (index, index - 3, index - 171)]
    if any(value is None or value <= 0 for value in prices):
        result["reason"] = "MISSING_OR_INVALID_REQUIRED_CLOSE"
        return result
    volume3 = [_finite(quote_volumes[position]) for position in (index, index - 1, index - 2)]
    if any(value is None or value < 0 for value in volume3):
        result["reason"] = "MISSING_OR_INVALID_TRIGGER_VOLUME"
        return result

    lo, hi = index - 170, index - 2  # hi exclusive; source [t-170, t-3].
    running, prefix_lo, finite_count = 0.0, 0.0, 0
    for position in range(hi):
        if position == lo:
            prefix_lo = running
        source_value = quote_volumes[position]
        value = _finite(source_value)
        if value is None and source_value is not None:
            try:
                missing_nan = not isinstance(source_value, bool) and math.isnan(float(source_value))
            except (ValueError, TypeError, OverflowError):
                missing_nan = False
            if not missing_nan:
                result["reason"] = "INVALID_BASELINE_OR_PREFIX_VOLUME"
                return result
        if lo <= position < hi:
            if value is not None:
                if value < 0:
                    result["reason"] = "NEGATIVE_BASELINE_VOLUME"
                    return result
                finite_count += 1
        # Equivalent to legacy nan_to_num for ordinary finite/NaN volume data.
        # Infinite source values are unavailable rather than fabricated liquidity.
        running += value if value is not None else 0.0
    result["features"]["finite_baseline_hours"] = finite_count
    if finite_count < 150:
        result["reason"] = "INSUFFICIENT_FINITE_BASELINE_HOURS"
        return result
    base = (running - prefix_lo) / 168.0
    if not math.isfinite(base) or base < 0:
        result["reason"] = "INVALID_OR_UNREPRESENTABLE_BASELINE"
        return result
    r3 = prices[0] / prices[1] - 1
    q3 = volume3[0] + volume3[1] + volume3[2]
    prior = prices[1] / prices[2] - 1
    if not all(math.isfinite(value) for value in (r3, q3, prior)):
        result["reason"] = "UNREPRESENTABLE_CAUSAL_FEATURE"
        return result
    if base == 0:
        # A fully observed zero-liquidity baseline is a known false condition.
        # NumPy's ratio would be inf/NaN, but the legacy liquidity conjunct is
        # false regardless; never turn that known failure into missing warmup.
        result["features"].update(return_3h=r3, quote_volume_3h=q3,
                                  average_hourly_quote_volume=0.0,
                                  prior_return_168h=prior)
        result.update(status="FALSE", raw_trigger=False,
                      reason="BASELINE_BELOW_MINIMUM_LIQUIDITY")
        return result
    multiple = q3 / (3 * base)
    if not math.isfinite(multiple):
        result["reason"] = "UNREPRESENTABLE_CAUSAL_FEATURE"
        return result
    result["features"].update(return_3h=r3, quote_volume_3h=q3,
                              average_hourly_quote_volume=base,
                              volume_multiple=multiple, prior_return_168h=prior)
    raw = r3 >= 0.10 and multiple >= 5.0 and prior <= 0.30 and base >= 20000
    result.update(status="TRUE" if raw else "FALSE", raw_trigger=raw,
                  reason="CAUSAL_EQUATIONS_SATISFIED" if raw else "CAUSAL_EQUATIONS_NOT_SATISFIED")
    return result


class CausalTriggerTracker:
    """Serializable per-coin diagnostic cooldown, with no paper enrollment.

    ``bar_open_at`` is the legacy hourly grid's OPEN timestamp, not detection
    time. The final hour must actually have been received after open+1h. Passing
    ``start_at`` additionally classifies earlier bars as bootstrap; they do not
    create new emitted events or alter post-start cooldown. A separately checked
    historical cooldown state can be supplied explicitly; it is never inferred
    from future prices/outcomes. Persist exported state beside evidence records.
    """
    def __init__(self, start_at=None, state=None):
        self.start = _stamp(start_at) if start_at is not None else None
        identity = hashlib.sha256(_canonical({"version": VERSION,
                    "source_sha256": SOURCE_SHA256,
                    "start_at": _iso(self.start) if self.start else None,
                    "parameters": PARAMETERS})).hexdigest()
        self.state = json.loads(_canonical(state)) if state is not None else {
            "schema": "LEGACY_CAUSAL_TRIGGER_STATE_V1", "identity": identity, "coins": {}}
        if (self.state.get("schema") != "LEGACY_CAUSAL_TRIGGER_STATE_V1"
                or self.state.get("identity") != identity
                or not isinstance(self.state.get("coins"), dict)):
            raise ValueError("diagnostic state does not match pinned configuration")

    def export_state(self):
        return json.loads(_canonical(self.state))

    def observe(self, symbol, bar_open_at, closes, quote_volumes, *, received_at, index=None):
        if not isinstance(symbol, str) or not symbol or len(symbol) > 80 or any(c.isspace() for c in symbol):
            raise ValueError("stable explicit symbol identity required")
        opened, received = _stamp(bar_open_at), _stamp(received_at)
        if opened.minute or opened.second or opened.microsecond:
            raise ValueError("legacy bar open must lie on a UTC hour boundary")
        completed = opened + dt.timedelta(hours=1)
        result = evaluate_causal(closes, quote_volumes, index=index)
        fingerprint = hashlib.sha256(_canonical(result)).hexdigest()
        record = {**result, "symbol": symbol, "bar_open_at": _iso(opened),
                  "hour_completed_boundary": _iso(completed), "received_at": _iso(received),
                  "bar_receipt_delay_seconds": (received - completed).total_seconds(),
                  "emitted": False, "duplicate": False, "state_changed": False,
                  "cooldown_hours": COOLDOWN_HOURS, "last_emitted_bar_open_at": None}
        if received < completed:
            record.update(status="UNKNOWN", raw_trigger=None,
                          reason="HOUR_NOT_COMPLETED_AT_ACTUAL_RECEIPT")
            return record
        prior = self.state["coins"].get(symbol)
        if prior is not None:
            last_seen = _stamp(prior["bar_open_at"])
            if opened < last_seen:
                raise ValueError("out-of-order diagnostic hour; retain an explicit correction instead")
            if opened == last_seen:
                if fingerprint != prior["input_fingerprint"]:
                    raise ValueError("conflicting duplicate diagnostic hour; prior record retained")
                duplicate = json.loads(_canonical(prior["record"]))
                duplicate.update(duplicate=True, state_changed=False)
                return duplicate
        last_emitted = prior.get("last_emitted_bar_open_at") if prior else None
        record["last_emitted_bar_open_at"] = last_emitted
        if self.start is not None and (opened < self.start or received < self.start):
            record.update(status="BOOTSTRAP_NOT_ENROLLED", reason="PRESTART_BAR_NOT_A_NEW_DIAGNOSTIC_DISCOVERY")
        elif result["raw_trigger"] is True:
            elapsed = ((opened - _stamp(last_emitted)).total_seconds() / 3600
                       if last_emitted is not None else None)
            record["hours_since_last_emitted"] = elapsed
            if elapsed is not None and elapsed < COOLDOWN_HOURS:
                record.update(status="COOLDOWN", reason="PER_COIN_72H_COOLDOWN")
            else:
                last_emitted = _iso(opened)
                record.update(emitted=True, last_emitted_bar_open_at=last_emitted)
        record["state_changed"] = True
        self.state["coins"][symbol] = {"bar_open_at": _iso(opened),
            "last_emitted_bar_open_at": last_emitted,
            "input_fingerprint": fingerprint, "record": json.loads(_canonical(record))}
        return record


causal_trigger = evaluate_causal
