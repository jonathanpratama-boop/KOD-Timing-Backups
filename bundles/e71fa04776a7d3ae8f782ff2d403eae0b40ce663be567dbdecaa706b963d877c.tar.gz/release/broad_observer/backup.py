"""Local incremental backup of BroadStore inventory; no network or Git writes.

Only previously unretained immutable objects are read. Repeated references reuse
regular content-addressed backup objects with matching sizes without rehashing
their old source or backup bytes. Active daily controls are
captured under the store lock, then that lock is released before large immutable
catch-up inventories are hashed. An atomic backup HEAD commits immutable delta
manifests. Uncommitted crash objects/manifests remain harmless and are reused.

Immutable gzip blobs can be hardlinked on one filesystem, avoiding another
near-incompressible working-tree copy. Such links share an inode: they are not
an independent disaster copy. A future Git pack/off-host destination adds its
own storage/transfer cost; capacity and repository quotas are not established by
this local implementation. Old source bytes are not reverified incrementally;
full_verify()/restoration is the explicit full-integrity boundary.
"""
from contextlib import contextmanager
import datetime as dt
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile

CHUNK_BYTES = 65536
SCHEMA = 'BROAD_OBSERVER_BACKUP_DELTA_V1'
ZERO = '0' * 64


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def valid_hash(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def safe_relative(value):
    path = PurePosixPath(value)
    if (not isinstance(value, str) or not path.parts or path.is_absolute()
            or '..' in path.parts or str(path) != value or '\\' in value):
        raise ValueError('unsafe backup member')
    return path


def fsync_directory(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def immutable_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        if path.is_symlink() or not path.is_file() or path.read_bytes() != data:
            raise ValueError('immutable backup bytes differ')
        return False
    descriptor, temporary = tempfile.mkstemp(dir=path.parent, prefix='.pending-')
    try:
        with os.fdopen(descriptor, 'wb') as target:
            target.write(data)
            target.flush()
            os.fsync(target.fileno())
        os.chmod(temporary, 0o444)
        os.link(temporary, path)
        fsync_directory(path.parent)
    finally:
        os.unlink(temporary)
    return True


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(dir=path.parent, prefix='.head-')
    try:
        with os.fdopen(descriptor, 'wb') as target:
            target.write(canonical(value) + b'\n')
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, path)
        fsync_directory(path.parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def stream_hash(path):
    full, size = hashlib.sha256(), 0
    with path.open('rb') as source:
        while block := source.read(CHUNK_BYTES):
            full.update(block)
            size += len(block)
    return full.hexdigest(), size


class IncrementalBackup:
    def __init__(self, repository, *, fault=None):
        self.root = Path(repository)
        self.root.mkdir(parents=True, exist_ok=True)
        if self.root.is_symlink():
            raise ValueError('backup repository must not be a symlink')
        self.fault = fault or (lambda stage: None)

    @contextmanager
    def lock(self):
        with (self.root / '.backup.lock').open('a+b') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            yield

    def _object(self, digest):
        if not valid_hash(digest):
            raise ValueError('invalid backup object hash')
        return self.root / 'objects' / digest[:2] / digest

    def _manifest(self, digest):
        if not valid_hash(digest):
            raise ValueError('invalid backup manifest hash')
        path = self.root / 'manifests' / (digest + '.json')
        if path.is_symlink() or not path.is_file():
            raise ValueError('missing regular backup manifest')
        raw = path.read_bytes()
        if sha(raw) != digest:
            raise ValueError('backup manifest hash differs')
        value = json.loads(raw)
        if canonical(value) + b'\n' != raw or value.get('schema') != SCHEMA:
            raise ValueError('noncanonical or unknown backup manifest')
        return value

    def _head(self):
        path = self.root / 'HEAD.json'
        if not path.exists():
            if any((self.root / 'manifests').glob('*.json')):
                # A first-operation crash before HEAD is recoverable explicitly;
                # blindly treating an established missing HEAD as empty is unsafe.
                raise ValueError('backup HEAD absent with retained manifests; reconcile uncommitted recovery')
            return None
        if path.is_symlink() or not path.is_file():
            raise ValueError('backup HEAD is not regular')
        raw = path.read_bytes()
        head = json.loads(raw)
        unsigned = {key: value for key, value in head.items() if key != 'hash'}
        if raw != canonical(head) + b'\n' or sha(canonical(unsigned)) != head.get('hash'):
            raise ValueError('backup HEAD integrity differs')
        manifest = self._manifest(head['manifest'])
        if (manifest['seq'] != head['seq'] or manifest['cursor_after'] != head['cursor']
                or manifest['mutable_files'] != head['mutable_files']):
            raise ValueError('backup HEAD and manifest disagree')
        return head

    def _source(self, root, relative):
        path = root.joinpath(*safe_relative(relative).parts)
        for parent in (path, *path.parents):
            if parent == root:
                break
            if parent.is_symlink():
                raise ValueError('symlink in source inventory')
        if not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
            raise ValueError('source inventory member is not a contained regular file')
        return path

    def _capture(self, root, item, stats):
        if (not valid_hash(item['sha256']) or not isinstance(item['bytes'], int)
                or isinstance(item['bytes'], bool) or item['bytes'] < 0):
            raise ValueError('invalid source inventory identity')
        immutable = item.get('immutable') is True
        if item.get('rebuild') not in (None,'ACTIVE_CHECKPOINT_FROM_JOURNAL'):
            raise ValueError('unknown source reconstruction descriptor')
        if item.get('rebuild') == 'ACTIVE_CHECKPOINT_FROM_JOURNAL':
            if immutable or not item['path'].endswith('/CHECKPOINT.json'):
                raise ValueError('only an active checkpoint may use journal reconstruction')
            path = self._source(root,item['path'])
            raw = path.read_bytes()
            if sha(raw) != item['sha256'] or len(raw) != item['bytes']:
                raise ValueError('active checkpoint source bytes differ')
            value = json.loads(raw)
            anchor = item.get('anchor',{})
            keys = ('day','base_prev','next_seq','tip','byte_offset','last_event_offset')
            if (any(anchor.get(key) != value.get(key) for key in keys)
                    or anchor.get('expected_sha256') != item['sha256'] or anchor.get('expected_bytes') != item['bytes']):
                raise ValueError('active checkpoint reconstruction anchor differs')
            stats['source_bytes_read'] += len(raw)
            stats['reconstructible_checkpoint_bytes_not_copied'] += len(raw)
            return dict(item,objects=[],immutable=False)
        if immutable:
            existing = self._object(item['sha256'])
            if existing.exists() or existing.is_symlink():
                if (existing.is_symlink() or not existing.is_file()
                        or existing.stat().st_size != item['bytes']):
                    raise ValueError('previously retained immutable backup object is not regular or size differs')
                # Local object publication was atomic and verified on first
                # creation. This is prefix assurance, not fresh byte assurance;
                # full_verify detects subsequent same-length byte corruption.
                stats['reused_objects'] += 1
                stats['reused_previously_verified_bytes'] += item['bytes']
                return dict(item, objects=[{'sha256': item['sha256'], 'bytes': item['bytes']}], immutable=True)
        path = self._source(root, item['path'])
        full, size, objects = hashlib.sha256(), 0, []
        # A whole immutable object permits an inode-sharing backup reference.
        # Mutable daily journals always use fixed chunks to retain append deltas.
        if immutable:
            actual, observed = stream_hash(path)
            stats['source_bytes_read'] += observed
            if actual != item['sha256'] or observed != item['bytes']:
                raise ValueError('source inventory bytes differ')
            obj = self._object(actual)
            obj.parent.mkdir(parents=True, exist_ok=True)
            if obj.exists() or obj.is_symlink():
                if obj.is_symlink() or not obj.is_file() or stream_hash(obj) != (actual, observed):
                    raise ValueError('existing immutable backup object differs')
                stats['reused_objects'] += 1
            else:
                linked = False
                if not (path.stat().st_mode & 0o222):
                    try:
                        os.link(path, obj)
                        linked = True
                    except OSError as exc:
                        if exc.errno != errno.EXDEV:
                            raise
                if linked:
                    stats['hardlinked_bytes'] += observed
                else:
                    descriptor, temporary = tempfile.mkstemp(dir=obj.parent, prefix='.copy-')
                    try:
                        copied, copied_size = hashlib.sha256(), 0
                        with os.fdopen(descriptor, 'wb') as target, path.open('rb') as source:
                            while block := source.read(CHUNK_BYTES):
                                target.write(block)
                                copied.update(block)
                                copied_size += len(block)
                            target.flush()
                            os.fsync(target.fileno())
                        if copied.hexdigest() != actual or copied_size != observed:
                            raise ValueError('immutable source changed during backup copy')
                        os.chmod(temporary, 0o444)
                        os.link(temporary, obj)
                    finally:
                        os.unlink(temporary)
                    stats['copied_object_bytes'] += observed
                fsync_directory(obj.parent)
                stats['new_objects'] += 1
            objects = [{'sha256': actual, 'bytes': observed}]
            full_sha, size = actual, observed
        else:
            with path.open('rb') as source:
                while block := source.read(CHUNK_BYTES):
                    digest = sha(block)
                    if immutable_write(self._object(digest), block):
                        stats['new_objects'] += 1
                        stats['copied_object_bytes'] += len(block)
                    else:
                        stats['reused_objects'] += 1
                    full.update(block)
                    size += len(block)
                    stats['source_bytes_read'] += len(block)
                    objects.append({'sha256': digest, 'bytes': len(block)})
            full_sha = full.hexdigest()
        if full_sha != item['sha256'] or size != item['bytes']:
            raise ValueError('source inventory bytes differ')
        result = {key: value for key, value in item.items() if key not in ('sha256', 'bytes')}
        result.update(sha256=full_sha, bytes=size, objects=objects, immutable=immutable)
        return result

    def snapshot(self, store, *, now=None):
        """Commit a verified inventory delta; never execute remote publication."""
        with self.lock():
            head = self._head()
            cursor = head['cursor'] if head else None
            stats = {'source_bytes_read': 0, 'new_objects': 0, 'reused_objects': 0,
                     'hardlinked_bytes': 0, 'copied_object_bytes': 0,
                     'reused_previously_verified_bytes': 0,
                     'reconstructible_checkpoint_bytes_not_copied': 0}
            captured, immutable = {}, []
            with store.lock():
                inventory = store.inventory_since(cursor)
                paths = [item['path'] for item in inventory['files']]
                if len(paths) != len(set(paths)):
                    raise ValueError('duplicate source inventory paths')
                for item in inventory['files']:
                    safe_relative(item['path'])
                    if item.get('immutable') is True:
                        immutable.append(item)
                    else:
                        captured[item['path']] = self._capture(Path(store.root), item, stats)
            # Immutable publications are fsynced before exporter cursors advance.
            # Collection need not wait for an initial/month-long backup catch-up.
            for item in immutable:
                captured[item['path']] = self._capture(Path(store.root), item, stats)
            mutable_files = {name: row for name, row in captured.items() if not row['immutable']}
            if head and inventory['cursor'] == cursor:
                if immutable or mutable_files != head['mutable_files']:
                    raise ValueError('source changed without advancing inventory cursor')
                return {'status': 'NO_CHANGE', 'manifest': head['manifest'], 'seq': head['seq'],
                        'cursor': cursor, 'newly_verified_only': True, **stats}
            self.fault('after_objects')
            instant = now or dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00', 'Z')
            manifest = {'schema': SCHEMA, 'seq': head['seq'] + 1 if head else 0,
                        'previous': head['manifest'] if head else ZERO, 'created_at': instant,
                        'cursor_before': cursor, 'cursor_after': inventory['cursor'],
                        'metadata': inventory.get('metadata', {}), 'files': captured,
                        'mutable_files': mutable_files,
                        'integrity_scope': 'newly retained bytes and current active controls; repeated immutable objects reuse prior verification; full history verification is separate'}
            raw = canonical(manifest) + b'\n'
            identity = sha(raw)
            immutable_write(self.root / 'manifests' / (identity + '.json'), raw)
            self.fault('after_manifest')
            next_head = {'schema': SCHEMA, 'manifest': identity, 'seq': manifest['seq'],
                         'cursor': inventory['cursor'], 'mutable_files': mutable_files}
            next_head['hash'] = sha(canonical(next_head))
            atomic_json(self.root / 'HEAD.json', next_head)
            self.fault('after_head')
            return {'status': 'COMMITTED_LOCAL', 'manifest': identity, 'seq': manifest['seq'],
                    'cursor': inventory['cursor'], 'files_in_delta': len(captured),
                    'newly_verified_only': True, 'offhost_acknowledged': False, **stats}

    def _file_blocks(self, expected):
        if expected.get('rebuild'):
            raise ValueError('reconstructible checkpoint needs its retained journal')
        full, observed = hashlib.sha256(), 0
        for reference in expected['objects']:
            obj = self._object(reference['sha256'])
            if obj.is_symlink() or not obj.is_file() or obj.stat().st_size != reference['bytes']:
                raise ValueError('backup object missing or length differs')
            partial, size = hashlib.sha256(), 0
            with obj.open('rb') as source:
                while block := source.read(CHUNK_BYTES):
                    partial.update(block)
                    full.update(block)
                    observed += len(block)
                    size += len(block)
                    yield block
            if partial.hexdigest() != reference['sha256'] or size != reference['bytes']:
                raise ValueError('backup object digest differs')
        if full.hexdigest() != expected['sha256'] or observed != expected['bytes']:
            raise ValueError('reconstructed backup file differs')

    def _checkpoint_bytes(self, expected, journal=None, *, journal_path=None):
        from broad_observer.store import rebuild_checkpoint_from_journal
        if (expected.get('rebuild') != 'ACTIVE_CHECKPOINT_FROM_JOURNAL' or expected.get('objects') != []
                or expected.get('immutable') is not False):
            raise ValueError('unknown reconstructible backup descriptor')
        relative = safe_relative(expected['path'])
        if len(relative.parts) != 3 or relative.parts[0] != 'days' or relative.parts[2] != 'CHECKPOINT.json':
            raise ValueError('unsafe active checkpoint descriptor path')
        def reconstruct(path):
            raw = rebuild_checkpoint_from_journal(path,expected['anchor'])
            if sha(raw) != expected['sha256'] or len(raw) != expected['bytes']:
                raise ValueError('rebuilt active checkpoint bytes differ')
            return raw
        if journal_path is not None:
            return reconstruct(journal_path)
        if journal is None or journal['path'] != str(relative.parent/'events.jsonl'):
            raise ValueError('reconstructible checkpoint journal missing')
        # Full verification is explicit. Materialize only one bounded daily
        # journal, never the historical raw object set or a complete archive.
        with tempfile.TemporaryDirectory(prefix='.verify-active-checkpoint-',dir=self.root) as temporary:
            path = Path(temporary)/'events.jsonl'
            with path.open('xb') as output:
                for block in self._file_blocks(journal): output.write(block)
            return reconstruct(path)

    def _chain(self):
        head = self._head()
        if head is None:
            raise ValueError('no committed backup')
        result, seen, identity = [], set(), head['manifest']
        while identity != ZERO:
            if identity in seen:
                raise ValueError('cyclic backup manifest chain')
            seen.add(identity)
            value = self._manifest(identity)
            result.append(value)
            identity = value['previous']
        result.reverse()
        cursor, latest, immutable = None, {}, {}
        versions = 0
        for seq, manifest in enumerate(result):
            if manifest['seq'] != seq or manifest['cursor_before'] != cursor:
                raise ValueError('backup manifest sequence or cursor chain differs')
            cursor = manifest['cursor_after']
            for name, record in manifest['files'].items():
                safe_relative(name)
                if record.get('path') != name:
                    raise ValueError('manifest member path differs')
                if name in immutable and (immutable[name] != record['sha256'] or not record['immutable']):
                    raise ValueError('immutable source path changed across backup manifests')
                if not record.get('rebuild'):
                    for _ in self._file_blocks(record): pass
                if record['immutable']:
                    immutable[name] = record['sha256']
                latest[name] = record
                versions += 1
            for name,record in manifest['files'].items():
                if record.get('rebuild'):
                    journal_name = str(safe_relative(name).parent/'events.jsonl')
                    self._checkpoint_bytes(record,latest.get(journal_name))
        if cursor != head['cursor'] or len(result) != head['seq'] + 1:
            raise ValueError('backup tip differs')
        return head, latest, versions

    def full_verify(self):
        with self.lock():
            head, latest, versions = self._chain()
            return {'verified': True, 'manifest': head['manifest'], 'manifests': head['seq'] + 1,
                    'file_versions_verified': versions, 'retained_files': len(latest),
                    'integrity_scope': 'all committed manifest versions and referenced object bytes'}

    def restore(self, destination, *, verify_store=None):
        """Restore into new staging and verify every backup version and store."""
        destination = Path(destination)
        if destination.exists() or destination.is_symlink():
            raise ValueError('restore destination must not exist')
        if destination.resolve() == Path('/') or destination.resolve().is_relative_to(self.root.resolve()):
            raise ValueError('restore destination must be independent staging')
        with self.lock():
            head, latest, versions = self._chain()
            destination.mkdir(parents=True, mode=0o700)
            directories = {destination}
            for name, record in latest.items():
                if record.get('rebuild'): continue
                target = destination.joinpath(*safe_relative(name).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                parent = target.parent
                while parent != destination:
                    directories.add(parent)
                    parent = parent.parent
                with target.open('xb') as output:
                    for block in self._file_blocks(record):
                        output.write(block)
                    output.flush()
                    os.fsync(output.fileno())
                if record['immutable']:
                    target.chmod(0o444)
            for name,record in latest.items():
                if not record.get('rebuild'): continue
                target = destination.joinpath(*safe_relative(name).parts)
                journal = target.with_name('events.jsonl')
                raw = self._checkpoint_bytes(record,journal_path=journal)
                with target.open('xb') as output:
                    output.write(raw); output.flush(); os.fsync(output.fileno())
            for directory in sorted(directories, key=lambda path: len(path.parts), reverse=True):
                fsync_directory(directory)
            fsync_directory(destination.parent)
            if verify_store is None:
                from broad_observer.store import BroadStore
                verify_store = lambda path: BroadStore(path).full_verify()
            verification = verify_store(destination)
            return {'restored': True, 'byte_identical': True, 'files': len(latest),
                    'file_versions_verified': versions, 'manifest': head['manifest'],
                    'store_verification': verification, 'offhost_acknowledged': False}
