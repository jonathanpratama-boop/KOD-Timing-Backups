"""Offline, receipt-causal assembly of one completed UTC hour.

This does not fetch or synthesize bars and does not enroll a strategy. Callers
provide a bounded minute-record window from the retained archive. Source minute
opens/closes and actual receipt clocks remain separate. A later REST retrieval
can make an hour available later; it cannot repair an earlier as-of view.
Declared REST *hourly* warmup is a separate input path, not implemented here.
"""
from __future__ import annotations

from collections import defaultdict
from decimal import Decimal, DecimalException, Inexact, localcontext
import datetime as dt
import hashlib
import json

UTC = dt.timezone.utc
EPOCH = dt.datetime(1970, 1, 1, tzinfo=UTC)
MAX_INPUT_RECORDS = 10000
MAX_NUMERIC_CHARS = 128
MAX_ADJUSTED_EXPONENT = 100
MAX_TRADES_PER_MINUTE = (1 << 63) - 1
FIELDS = ("open", "high", "low", "close", "base_volume", "quote_volume",
          "taker_buy_base_volume", "taker_buy_quote_volume")
NATIVE = dict(zip(FIELDS, ("o", "h", "l", "c", "v", "q", "V", "Q")))


def _stamp(value):
    if isinstance(value, str):
        value = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if not isinstance(value, dt.datetime) or value.tzinfo is None:
        raise ValueError("aware actual receipt/as-of timestamp required")
    return value.astimezone(UTC)


def _iso(value):
    return _stamp(value).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _epoch_ms(value):
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError("source t/T must be nonnegative integer milliseconds")
    try:
        return EPOCH + dt.timedelta(milliseconds=value)
    except OverflowError:
        raise ValueError("source t/T outside supported timestamp range") from None


def _decimal(value, *, positive=False):
    if isinstance(value, bool) or not isinstance(value, (str, int, Decimal)):
        raise ValueError("exact source decimal string/integer required")
    text = str(value)
    if not 0 < len(text) <= MAX_NUMERIC_CHARS:
        raise ValueError("source decimal field exceeds character bound")
    try:
        number = Decimal(text)
    except DecimalException:
        raise ValueError("invalid source decimal") from None
    if (not number.is_finite() or number < 0 or (positive and number <= 0)
            or (number and abs(number.adjusted()) > MAX_ADJUSTED_EXPONENT)):
        raise ValueError("source decimal outside finite nonnegative/bounded range")
    return number


def _numeric_text(number):
    # Exact normalization for semantic identity, with no default28-digit rounding.
    with localcontext() as context:
        context.prec = 512
        context.Emax, context.Emin = 1000, -1000
        context.traps[Inexact] = True
        return str(number.normalize())


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode()


def _source(record):
    raw, supplied = record.get("raw"), record.get("source")
    if raw is not None:
        if not isinstance(raw, bytes) or len(raw) > 4 * 1024 * 1024:
            raise ValueError("bounded exact retained raw message bytes required")
        source = json.loads(raw)
        if supplied is not None and source != supplied:
            raise ValueError("decoded source differs from retained raw message")
    else:
        source = supplied
    if source is not None:
        if not isinstance(source, dict):
            raise ValueError("source kline message must be an object")
        data = source.get("data", source)
        if not isinstance(data, dict) or not isinstance(data.get("k"), dict):
            raise ValueError("source minute kline object required")
        return data, data["k"]
    return None, None


def _minute(record, received):
    data, candle = _source(record)
    if candle is not None:
        if data.get("e") not in (None, "kline"):
            raise ValueError("source event is not a minute kline")
        symbol = candle.get("s", data.get("s"))
        if data.get("s") not in (None, symbol) or record.get("symbol") not in (None, symbol):
            raise ValueError("source/archival symbol identities differ")
        if candle.get("i") != "1m" or candle.get("x") is not True:
            raise ValueError("only closed one-minute source klines are allowed")
        opening, closing = candle.get("t"), candle.get("T")
        values = {field: candle.get(native) for field, native in NATIVE.items()}
        trades = candle.get("n")
        first_id, last_id = candle.get("f"), candle.get("L")
    else:
        symbol = record.get("symbol")
        if record.get("closed") is not True or record.get("interval", "1m") != "1m":
            raise ValueError("only explicitly closed one-minute records are allowed")
        opening, closing = record.get("open_ms", record.get("t")), record.get("close_ms", record.get("T"))
        values = {field: record.get(field) for field in FIELDS}
        trades = record.get("trades")
        first_id, last_id = record.get("first_trade_id"), record.get("last_trade_id")
    if not isinstance(symbol, str) or not symbol or len(symbol) > 80:
        raise ValueError("explicit source symbol required")
    opened, closed = _epoch_ms(opening), _epoch_ms(closing)
    if opening % 60000 or closing != opening + 59999:
        raise ValueError("source t/T is not an exact closed UTC minute")
    if record.get("open_at") is not None and _stamp(record["open_at"]) != opened:
        raise ValueError("archival open clock differs from source t")
    if record.get("close_at") is not None and _stamp(record["close_at"]) != closed:
        raise ValueError("archival close clock differs from source T")
    if record.get("open_ms") is not None and record["open_ms"] != opening:
        raise ValueError("archival open milliseconds differ from source t")
    if record.get("close_ms") is not None and record["close_ms"] != closing:
        raise ValueError("archival close milliseconds differ from source T")
    if received < closed or record.get("clock_anomaly") is True:
        raise ValueError("actual receipt/source-close clock anomaly")
    numbers = {field: _decimal(value, positive=field in ("open", "high", "low", "close"))
               for field, value in values.items()}
    if (numbers["high"] < max(numbers["open"], numbers["close"], numbers["low"])
            or numbers["low"] > min(numbers["open"], numbers["close"])
            or numbers["taker_buy_base_volume"] > numbers["base_volume"]
            or numbers["taker_buy_quote_volume"] > numbers["quote_volume"]):
        raise ValueError("source OHLCV/taker inequalities invalid")
    if (not isinstance(trades, int) or isinstance(trades, bool)
            or not 0 <= trades <= MAX_TRADES_PER_MINUTE):
        raise ValueError("bounded nonnegative integer source trade count required")
    for identity in (first_id, last_id):
        if identity is not None and (not isinstance(identity, int) or isinstance(identity, bool)
                or identity < (-1 if trades == 0 else 0) or identity > MAX_TRADES_PER_MINUTE):
            raise ValueError("source trade identifier invalid")
    semantic = {"symbol": symbol, "open_ms": opening, "close_ms": closing,
                "trades": trades, "first_trade_id": first_id, "last_trade_id": last_id,
                **{key: _numeric_text(number) for key, number in numbers.items()}}
    return {"symbol": symbol, "open_ms": opening, "close_ms": closing,
            "opened": opened, "closed": closed, "received": received,
            "numbers": numbers, "trades": trades,
            "semantic_sha256": hashlib.sha256(_canonical(semantic)).hexdigest(),
            "source_conflict": record.get("source_conflict") is True,
            "old_first_unknown": record.get("old_bar_first_receipt_unknown") is True,
            "first_claim": record.get("first_received_at"),
            "origin": str(record.get("origin", record.get("evidence_kind", record.get("transport", "RECORDED_MINUTE"))))[:160]}


def assemble_hour(records, symbol, hour_open_at, as_of):
    """Return COMPLETE only for sixty distinct valid, received closed minutes.

    Input order never selects a later correction over an earlier retained bar.
    Later receipts are excluded before parsing their values. ``first_received_at``
    on a later duplicate is a provenance claim, never permission to reveal the
    duplicate before its actual retained ``received_at``. Conflicts remain flags
    and never rewrite the first retained minute. Equal-clock conflicting first
    versions are ambiguous and leave that minute unavailable.
    """
    if not isinstance(symbol, str) or not symbol or len(symbol) > 80:
        raise ValueError("explicit bounded symbol required")
    start, cutoff = _stamp(hour_open_at), _stamp(as_of)
    if start.minute or start.second or start.microsecond:
        raise ValueError("hour open must be an exact UTC hour boundary")
    boundary = start + dt.timedelta(hours=1)
    expected = [start + dt.timedelta(minutes=offset) for offset in range(60)]
    expected_ms = {int((opened - EPOCH).total_seconds()) * 1000: index
                   for index, opened in enumerate(expected)}
    grouped, invalid, flagged_conflicts = defaultdict(list), [], []
    for position, record in enumerate(records):
        if position >= MAX_INPUT_RECORDS:
            raise ValueError("bounded hourly input window exceeded")
        if not isinstance(record, dict):
            invalid.append({"reason": "minute record must be an object"})
            continue
        try:
            received = _stamp(record.get("received_at"))
        except (ValueError, TypeError, OverflowError) as exc:
            invalid.append({"reason": str(exc), "symbol": record.get("symbol")})
            continue
        if received > cutoff:
            continue  # Do not even inspect future values, conflicts or raw bytes.
        try:
            minute = _minute(record, received)
        except (ValueError, TypeError, KeyError, DecimalException, OverflowError, RecursionError) as exc:
            invalid.append({"reason": str(exc)[:240], "symbol": record.get("symbol"),
                            "received_at": _iso(received)})
            continue
        if minute["symbol"] != symbol or minute["open_ms"] not in expected_ms:
            continue
        if minute["source_conflict"]:
            flagged_conflicts.append({"open_at": _iso(minute["opened"]),
                "received_at": _iso(received), "new_semantic_sha256": minute["semantic_sha256"],
                "reason": "ARCHIVED_SOURCE_CONFLICT_NEVER_REPLACES_FIRST"})
            continue
        grouped[minute["open_ms"]].append(minute)

    chosen, duplicates, conflicts, claims, late, unknown_first = {}, [], list(flagged_conflicts), [], [], []
    for opening, candidates in grouped.items():
        candidates.sort(key=lambda item: (item["received"], item["semantic_sha256"]))
        earliest = candidates[0]["received"]
        first_versions = {item["semantic_sha256"] for item in candidates if item["received"] == earliest}
        opened = candidates[0]["opened"]
        if len(first_versions) != 1:
            conflicts.append({"open_at": _iso(opened), "received_at": _iso(earliest),
                "reason": "AMBIGUOUS_EQUAL_RECEIPT_FIRST_VERSIONS",
                "semantic_sha256s": sorted(first_versions)})
            continue
        first = candidates[0]
        chosen[opening] = first
        same = sum(item["semantic_sha256"] == first["semantic_sha256"] for item in candidates)
        if same > 1:
            duplicates.append({"open_at": _iso(opened), "additional_identical_records": same - 1})
        for item in candidates:
            if item["semantic_sha256"] != first["semantic_sha256"]:
                conflicts.append({"open_at": _iso(opened), "first_received_at": _iso(earliest),
                    "received_at": _iso(item["received"]), "first_semantic_sha256": first["semantic_sha256"],
                    "new_semantic_sha256": item["semantic_sha256"],
                    "reason": "LATER_CONFLICT_NEVER_REPLACES_FIRST"})
            if item["first_claim"] is not None:
                try:
                    claim = _stamp(item["first_claim"])
                    if claim < earliest:
                        claims.append({"open_at": _iso(opened), "claimed_first_received_at": _iso(claim),
                            "first_retained_received_at": _iso(earliest),
                            "reason": "EARLIER_FIRST_RECEIPT_CLAIM_NOT_RETAINED_IN_THIS_VIEW"})
                    elif claim > item["received"]:
                        claims.append({"open_at": _iso(opened), "reason": "FIRST_RECEIPT_CLAIM_AFTER_CURRENT_RECEIPT"})
                except (ValueError, TypeError, OverflowError):
                    claims.append({"open_at": _iso(opened), "reason": "INVALID_FIRST_RECEIPT_CLAIM"})
        delay = (first["received"] - first["closed"]).total_seconds()
        if delay > 60:
            late.append({"open_at": _iso(opened), "first_retained_received_at": _iso(earliest),
                         "seconds_after_source_close": delay})
        if first["old_first_unknown"]:
            unknown_first.append(_iso(opened))

    missing = [_iso(opened) for opened in expected if int((opened - EPOCH).total_seconds()) * 1000 not in chosen]
    flags = []
    for present, flag in ((invalid, "INVALID_SOURCE_RECORDS"), (conflicts, "SOURCE_CONFLICTS_RETAIN_FIRST"),
                          (duplicates, "IDENTICAL_DUPLICATES"), (claims, "UNPROVEN_FIRST_RECEIPT_CLAIMS"),
                          (late, "LATE_MINUTE_AVAILABILITY"), (unknown_first, "UNKNOWN_ORIGINAL_FIRST_RECEIPT")):
        if present:
            flags.append(flag)
    ordered = [chosen[key] for key in sorted(chosen)]
    result = {"schema": "RECEIVED_COMPLETE_UTC_HOUR_V1", "status": "UNKNOWN", "symbol": symbol,
        "hour_open_at": _iso(start), "hour_close_at": _iso(boundary - dt.timedelta(milliseconds=1)),
        "hour_completed_boundary": _iso(boundary), "as_of": _iso(cutoff),
        "expected_minutes": 60, "available_minutes": len(ordered), "missing_minutes": missing,
        "available_at": None, "hour": None, "reason": "MISSING_RECEIVED_CLOSED_MINUTES",
        "quality_flags": sorted(flags), "duplicate_minutes": sorted(duplicates, key=lambda item: item["open_at"]),
        "conflicting_records": sorted(conflicts, key=lambda item: _canonical(item)),
        "invalid_records": sorted(invalid, key=lambda item: _canonical(item)),
        "first_receipt_claims": sorted(claims, key=lambda item: _canonical(item)),
        "late_minutes": sorted(late, key=lambda item: item["open_at"]),
        "unknown_original_first_receipt_minutes": sorted(unknown_first),
        "minute_receipts": [{"open_at": _iso(item["opened"]), "first_retained_received_at": _iso(item["received"]),
            "semantic_sha256": item["semantic_sha256"], "origin": item["origin"]} for item in ordered],
        "later_data_repairs_prior_view": False, "strategy_enrollment": False,
        "warmup_rest_hour_adapter_implemented": False}
    if cutoff < boundary:
        result["reason"] = "HOUR_NOT_COMPLETED_AT_AS_OF"
        return result
    if missing:
        return result
    available = max(item["received"] for item in ordered)
    if available < boundary:
        result["reason"] = "HOUR_RECEIPTS_PRECEDE_COMPLETION_BOUNDARY"
        return result
    try:
        with localcontext() as context:
            context.prec = 512
            context.Emax, context.Emin = 1000, -1000
            context.traps[Inexact] = True
            hour = {"open": str(ordered[0]["numbers"]["open"]),
                    "high": str(max(item["numbers"]["high"] for item in ordered)),
                    "low": str(min(item["numbers"]["low"] for item in ordered)),
                    "close": str(ordered[-1]["numbers"]["close"]),
                    **{field: str(sum((item["numbers"][field] for item in ordered), Decimal(0)))
                       for field in FIELDS if field not in ("open", "high", "low", "close")},
                    "trades": sum(item["trades"] for item in ordered)}
    except DecimalException:
        result["reason"] = "EXACT_DECIMAL_AGGREGATION_NOT_REPRESENTABLE"
        return result
    hour.update(symbol=symbol, interval="1h", closed=True,
                open_at=_iso(start), close_at=result["hour_close_at"],
                first_received_at=_iso(available), received_at=_iso(available),
                source_timestamp=None, source_minutes=60,
                availability_semantics="maximum first retained actual receipt across all60minutes",
                source="RECEIVED_CLOSED_1M_AGGREGATION")
    result.update(status="COMPLETE", available_at=_iso(available), hour=hour,
                  reason="ALL_60_CLOSED_MINUTES_RECEIVED_BY_AS_OF")
    return result
