"""Segmented acquisition storage; this module makes no scientific admission decisions.

Hot-path assurance is deliberately bounded: validate the active checkpoint and its
last journal record, then any complete post-checkpoint suffix. It does NOT rehash
an old active prefix, sealed days, or previously retained object bytes. Run
``full_verify`` independently before analysis or asserting a restored store valid.
Local checkpoints are not independent publication/timestamp anchors.
"""
from __future__ import annotations

from collections import Counter, OrderedDict
from contextlib import contextmanager
import datetime as dt
from dataclasses import dataclass
import fcntl
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import time
import uuid

UTC = dt.timezone.utc
ZERO = '0' * 64
MAX_RECOVERY_BYTES = 8 * 1024 * 1024
MAX_OBJECT_BYTES = 64 * 1024 * 1024
MAX_DAY_BATCHES = 10000
MAX_DAYS = 4096


class IntegrityError(RuntimeError):
    pass


@dataclass(frozen=True)
class PreparedBatch:
    """Immutable-byte reference handle, useful for explicit fixture/replay work.

    Reusing a handle reuses source bytes, not a fresh market observation. A caller
    must label simulated/replayed receipts as such; this store makes no live claim.
    """
    store_id: str
    payload: bytes
    payload_sha256: str


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def timestamp(value):
    result = value if isinstance(value, dt.datetime) else dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('aware UTC-compatible timestamp required')
    return result.astimezone(UTC)


def iso(value):
    return timestamp(value).isoformat(timespec='microseconds').replace('+00:00', 'Z')


def _directory_sync(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _checked(value):
    if not isinstance(value, dict):
        raise IntegrityError('record dictionary required')
    unsigned = {key: child for key, child in value.items() if key != 'hash'}
    if value.get('hash') != digest(canonical(unsigned)):
        raise IntegrityError('canonical record hash mismatch')
    return value


def _signed(value):
    value = dict(value)
    value['hash'] = digest(canonical(value))
    return value


def _read_json(path):
    try:
        raw = path.read_bytes()
        value = json.loads(raw)
        if raw != canonical(value) + b'\n':
            raise IntegrityError('noncanonical checkpoint: ' + str(path))
        return _checked(value)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        raise IntegrityError('unreadable checkpoint: ' + str(path)) from exc


def _file_hash(path):
    hasher = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            hasher.update(chunk)
    return hasher.hexdigest()


class BroadStore:
    def __init__(self, root, clock=None):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        for part in ('days', 'objects/raw', 'objects/normalized'):
            (self.root / part).mkdir(parents=True, exist_ok=True)
        for directory in (self.root, self.root/'days', self.root/'objects',
                          self.root/'objects/raw', self.root/'objects/normalized'):
            _directory_sync(directory.parent)
        self.clock = clock or (lambda: dt.datetime.now(UTC))
        self.catalog_path = self.root / 'CATALOG.json'
        self._lock_fd = None
        self._day_cache = None
        self._object_cache = OrderedDict()
        self.metrics = Counter()

    def now(self):
        return timestamp(self.clock())

    @contextmanager
    def lock(self, timeout=10):
        if self._lock_fd is not None:
            raise RuntimeError('nested external store lock forbidden')
        descriptor = os.open(self.root / '.operation.lock', os.O_CREAT | os.O_RDWR, 0o600)
        until = time.monotonic() + timeout
        try:
            while True:
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= until:
                        raise TimeoutError('broad observer operation lock held')
                    time.sleep(.02)
            self._lock_fd = descriptor
            yield self
        finally:
            self._lock_fd = None
            fcntl.flock(descriptor, fcntl.LOCK_UN)
            os.close(descriptor)

    @contextmanager
    def _operation(self):
        if self._lock_fd is not None:
            yield self
        else:
            with self.lock():
                yield self

    def _atomic(self, path, value):
        raw = canonical(value) + b'\n'
        owner = path.stat() if path.exists() else path.parent.stat()
        descriptor, temporary = tempfile.mkstemp(prefix='.checkpoint-', dir=path.parent)
        try:
            with os.fdopen(descriptor, 'wb') as stream:
                os.fchmod(stream.fileno(), stat.S_IMODE(owner.st_mode) if path.exists() else 0o600)
                if os.geteuid() == 0:
                    os.fchown(stream.fileno(), owner.st_uid, owner.st_gid)
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            _directory_sync(path.parent)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def _immutable(self, path, raw):
        if path.exists():
            if path.is_symlink() or path.read_bytes() != raw:
                raise IntegrityError('immutable object collision/change: ' + str(path))
            return
        descriptor, temporary = tempfile.mkstemp(prefix='.object-', dir=path.parent)
        try:
            with os.fdopen(descriptor, 'wb') as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
                os.fchmod(stream.fileno(), 0o444)
            try:
                os.link(temporary, path)
            except FileExistsError:
                if path.read_bytes() != raw:
                    raise IntegrityError('concurrent immutable object differs')
            _directory_sync(path.parent)
        finally:
            os.unlink(temporary)

    def _put_object(self, lane, raw):
        if not isinstance(raw, bytes) or len(raw) > MAX_OBJECT_BYTES:
            raise ValueError('bounded exact bytes required')
        plain_hash = digest(raw)
        key = (lane, plain_hash)
        if key in self._object_cache:
            reference = self._object_cache[key]
            self._check_reference_exists(reference)
            self.metrics['object_cache_hits'] += 1
            self._object_cache.move_to_end(key)
            return reference
        stream = io.BytesIO()
        with gzip.GzipFile(fileobj=stream, mode='wb', filename='', compresslevel=6, mtime=0) as compressor:
            compressor.write(raw)
        packed = stream.getvalue()
        packed_hash = digest(packed)
        relative = f'objects/{lane}/{packed_hash}.gz'
        self._immutable(self.root / relative, packed)
        reference = {'path': relative, 'sha256': packed_hash, 'bytes': len(packed),
                     'uncompressed_sha256': plain_hash, 'uncompressed_bytes': len(raw),
                     'encoding': 'gzip', 'lane': lane}
        self._object_cache[key] = reference
        if len(self._object_cache) > 64:
            self._object_cache.popitem(last=False)
        self.metrics['new_objects_checked_or_written'] += 1
        return reference

    def _check_reference_exists(self, reference):
        try:
            if (reference['lane'] not in ('raw', 'normalized')
                    or not re.fullmatch('[0-9a-f]{64}', reference['sha256'])
                    or reference['path'] != f"objects/{reference['lane']}/{reference['sha256']}.gz"):
                raise IntegrityError('invalid compressed object identity')
            path = self.root / reference['path']
            if path.is_symlink() or not stat.S_ISREG(path.stat().st_mode) or path.stat().st_size != reference['bytes']:
                raise IntegrityError('cached immutable object missing/size differs')
        except (OSError, KeyError, TypeError) as exc:
            raise IntegrityError('cached immutable object missing/invalid') from exc

    def _verify_object(self, reference):
        try:
            relative = reference['path']
            if (not re.fullmatch('[0-9a-f]{64}', reference['sha256'])
                    or not re.fullmatch('[0-9a-f]{64}', reference['uncompressed_sha256'])):
                raise IntegrityError('invalid object hash')
            expected = f"objects/{reference['lane']}/{reference['sha256']}.gz"
            if relative != expected or reference['lane'] not in ('raw', 'normalized'):
                raise IntegrityError('object identity/path mismatch')
            path = self.root / relative
            if path.is_symlink() or path.stat().st_size != reference['bytes'] or _file_hash(path) != reference['sha256']:
                raise IntegrityError('compressed object differs: ' + relative)
            size = reference['uncompressed_bytes']
            if not isinstance(size, int) or not 0 <= size <= MAX_OBJECT_BYTES:
                raise IntegrityError('invalid object expansion bound')
            with gzip.open(path, 'rb') as stream:
                raw = stream.read(size + 1)
                if len(raw) != size or stream.read(1):
                    raise IntegrityError('object expansion size differs')
            if digest(raw) != reference['uncompressed_sha256']:
                raise IntegrityError('uncompressed exact bytes differ')
            if reference['lane'] == 'normalized':
                if canonical(json.loads(raw)) != raw:
                    raise IntegrityError('normalized object is not canonical JSON')
            self.metrics['full_objects_verified'] += 1
            return raw
        except (OSError, ValueError, TypeError, KeyError, EOFError) as exc:
            raise IntegrityError('invalid/missing compressed object') from exc

    @staticmethod
    def _references(event):
        for request in event['requests']:
            if request.get('body_object') is not None:
                yield request['body_object']
        yield event['normalized_object']

    def _catalog(self):
        if not self.catalog_path.exists():
            if any((self.root / 'days').iterdir()):
                raise IntegrityError('catalog missing from nonempty store')
            value = _signed({'schema': 'BROAD_CATALOG_V1', 'store_id': str(uuid.uuid4()),
                             'generation': 0, 'active_day': None, 'days': []})
            self._atomic(self.catalog_path, value)
        value = _read_json(self.catalog_path)
        if value.get('schema') != 'BROAD_CATALOG_V1' or len(value.get('days', [])) > MAX_DAYS:
            raise IntegrityError('invalid catalog schema/bound')
        days = value['days']
        for day in days:
            self._paths(day['day'])
            if not re.fullmatch('[0-9a-f]{64}', day['base_prev']):
                raise IntegrityError('invalid catalog previous tip')
        names = [day['day'] for day in days]
        if names != sorted(set(names)):
            raise IntegrityError('catalog day order/identity differs')
        active = [day['day'] for day in days if not day['sealed']]
        if active != ([value['active_day']] if value['active_day'] else []):
            raise IntegrityError('catalog active day differs')
        if value['active_day'] and self._paths(value['active_day'])[3].exists():
            # Crash after immutable seal fsync but before catalog publication.
            value = self._seal(value)
            self.metrics['recovered_day_seals'] += 1
        return value

    def _save_catalog(self, catalog):
        value = {key: child for key, child in catalog.items() if key != 'hash'}
        value['generation'] += 1
        value = _signed(value)
        self._atomic(self.catalog_path, value)
        return value

    def _paths(self, day):
        if not isinstance(day, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', day):
            raise IntegrityError('invalid segment day path')
        try:
            dt.date.fromisoformat(day)
        except ValueError as exc:
            raise IntegrityError('invalid segment date') from exc
        directory = self.root / 'days' / day
        return directory, directory / 'events.jsonl', directory / 'CHECKPOINT.json', directory / 'SEAL.json'

    @staticmethod
    def _fingerprint(path):
        info = path.stat()
        return info.st_ino, info.st_size, info.st_mtime_ns

    def _read_event(self, journal, offset, length=None):
        self.metrics['journal_records_read'] += 1
        with journal.open('rb') as stream:
            stream.seek(offset)
            raw = stream.read(length) if length is not None else stream.readline()
        if not raw.endswith(b'\n'):
            raise IntegrityError('incomplete append retained; quarantine/operator recovery required')
        try:
            event = json.loads(raw)
            if canonical(event) + b'\n' != raw:
                raise IntegrityError('noncanonical event')
            _checked(event)
            return event, len(raw)
        except (ValueError, TypeError, KeyError) as exc:
            raise IntegrityError('invalid batch event') from exc

    def _add_index(self, checkpoint, event, offset, length):
        if (event.get('schema') != 'BROAD_BATCH_V1' or event['day'] != checkpoint['day']
                or event['seq'] != checkpoint['next_seq'] or event['prev'] != checkpoint['tip']
                or event['batch_id'] in checkpoint['index']):
            raise IntegrityError('batch chain/sequence/identity differs')
        payload = {key: event[key] for key in ('batch_id', 'kind', 'scheduled_at', 'status', 'requests', 'normalized_object')}
        if digest(canonical(payload)) != event['input_sha256']:
            raise IntegrityError('batch input fingerprint differs')
        timestamp(event['scheduled_at']); timestamp(event['recorded_at'])
        if iso(event['scheduled_at']) != event['scheduled_at'] or event['scheduled_at'][:10] != event['day']:
            raise IntegrityError('normalized scheduling clock/day differs')
        checkpoint['index'][event['batch_id']] = {'seq': event['seq'], 'hash': event['hash'],
            'input_sha256': event['input_sha256'], 'offset': offset, 'length': length}
        checkpoint.update(next_seq=event['seq']+1, tip=event['hash'], byte_offset=offset+length,
                          last_event_offset=offset)
        if checkpoint['next_seq'] > MAX_DAY_BATCHES:
            raise IntegrityError('daily index implementation bound exceeded')

    def _save_checkpoint(self, checkpoint):
        unsigned = {key: child for key, child in checkpoint.items() if key != 'hash'}
        checkpoint = _signed(unsigned)
        path = self._paths(checkpoint['day'])[2]
        self._atomic(path, checkpoint)
        self._day_cache = checkpoint, self._fingerprint(path)
        return checkpoint

    def _load_day(self, entry, recover=True):
        day = entry['day']
        directory, journal, path, seal_path = self._paths(day)
        if journal.is_symlink() or path.is_symlink():
            raise IntegrityError('segment symlink forbidden')
        if self._day_cache and self._day_cache[0]['day'] == day and self._day_cache[1] == self._fingerprint(path):
            checkpoint = self._day_cache[0]
            self.metrics['active_checkpoint_cache_hits'] += 1
        else:
            checkpoint = _read_json(path)
            self.metrics['active_checkpoint_loads'] += 1
        if (checkpoint.get('schema') != 'BROAD_DAY_CHECKPOINT_V1' or checkpoint['day'] != day
                or checkpoint['base_prev'] != entry['base_prev']
                or not 0 <= checkpoint['next_seq'] <= MAX_DAY_BATCHES
                or len(checkpoint['index']) != checkpoint['next_seq']):
            raise IntegrityError('invalid daily checkpoint')
        size = journal.stat().st_size
        if size < checkpoint['byte_offset']:
            raise IntegrityError('journal tail deleted beyond checkpoint')
        if checkpoint['next_seq']:
            final, length = self._read_event(journal, checkpoint['last_event_offset'])
            if (final['hash'] != checkpoint['tip'] or final['seq'] != checkpoint['next_seq']-1
                    or checkpoint['last_event_offset']+length != checkpoint['byte_offset']
                    or checkpoint['index'].get(final['batch_id'], {}).get('hash') != final['hash']):
                raise IntegrityError('checkpoint anchor differs')
        elif checkpoint['byte_offset'] != 0 or checkpoint['tip'] != checkpoint['base_prev']:
            raise IntegrityError('invalid empty checkpoint')
        trailing = size-checkpoint['byte_offset']
        if trailing:
            if entry['sealed'] or not recover or trailing > MAX_RECOVERY_BYTES:
                raise IntegrityError('sealed/unbounded suffix requires independent recovery')
            # Work on a copy: failed suffix parsing cannot pollute the cached head.
            checkpoint = json.loads(canonical(checkpoint))
            offset = checkpoint['byte_offset']
            while offset < size:
                event, length = self._read_event(journal, offset)
                for reference in self._references(event):
                    self._verify_object(reference)
                self._add_index(checkpoint, event, offset, length)
                offset += length
            checkpoint = self._save_checkpoint(checkpoint)
            self.metrics['recovered_complete_suffixes'] += 1
        self._day_cache = checkpoint, self._fingerprint(path)
        return checkpoint

    def _new_day(self, catalog, day):
        if len(catalog['days']) >= MAX_DAYS:
            raise IntegrityError('catalog implementation bound exceeded')
        previous = catalog['days'][-1]['tip'] if catalog['days'] else ZERO
        directory, journal, checkpoint_path, seal = self._paths(day)
        directory.mkdir(exist_ok=True)
        _directory_sync(directory.parent)
        if journal.exists() and journal.stat().st_size:
            raise IntegrityError('uncatalogued nonempty day requires recovery')
        if not journal.exists():
            descriptor = os.open(journal, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.fsync(descriptor); os.close(descriptor)
            _directory_sync(directory)
        checkpoint = {'schema': 'BROAD_DAY_CHECKPOINT_V1', 'day': day, 'base_prev': previous,
                      'next_seq': 0, 'tip': previous, 'byte_offset': 0, 'last_event_offset': 0, 'index': {}}
        if checkpoint_path.exists():
            prior = _read_json(checkpoint_path)
            if prior != _signed(checkpoint):
                raise IntegrityError('uncatalogued day checkpoint differs')
        else:
            self._save_checkpoint(checkpoint)
        catalog['days'].append({'day': day, 'sealed': False, 'base_prev': previous})
        catalog['active_day'] = day
        return self._save_catalog(catalog)

    def _file_reference(self, path, immutable):
        return {'path': path.relative_to(self.root).as_posix(), 'sha256': _file_hash(path),
                'bytes': path.stat().st_size, 'immutable': immutable}

    def _seal(self, catalog):
        entry = catalog['days'][-1]
        checkpoint = self._load_day(entry)
        directory, journal, checkpoint_path, seal_path = self._paths(entry['day'])
        seal = _signed({'schema': 'BROAD_DAY_SEAL_V1', 'day': entry['day'],
                        'base_prev': entry['base_prev'], 'tip': checkpoint['tip'],
                        'next_seq': checkpoint['next_seq'], 'byte_offset': checkpoint['byte_offset'],
                        'files': [self._file_reference(journal, True), self._file_reference(checkpoint_path, True)]})
        self._immutable(seal_path, canonical(seal)+b'\n')
        for path in (journal, checkpoint_path):
            path.chmod(0o444)
        entry.update(sealed=True, tip=checkpoint['tip'], next_seq=checkpoint['next_seq'],
                     byte_offset=checkpoint['byte_offset'], seal_sha256=_file_hash(seal_path),
                     files=seal['files']+[self._file_reference(seal_path, True)])
        catalog['active_day'] = None
        self._day_cache = None
        return self._save_catalog(catalog)

    def _prepare(self, raw_http, summary):
        if not isinstance(raw_http, list) or len(raw_http) > 32:
            raise ValueError('bounded raw HTTP batch list required')
        requests = []
        for request in raw_http:
            if not isinstance(request, dict):
                raise ValueError('HTTP attempt dictionary required')
            metadata = {key: value for key, value in request.items() if key != 'body'}
            for name in ('request_started_at', 'received_at'):
                if metadata.get(name) is not None:
                    metadata[name] = iso(metadata[name])
            if metadata.get('request_started_at') and metadata.get('received_at'):
                if timestamp(metadata['received_at']) < timestamp(metadata['request_started_at']):
                    raise ValueError('HTTP receipt precedes request')
            if 'body' in request:
                metadata['body_object'] = self._put_object('raw', request['body'])
            requests.append(metadata)
        normalized = self._put_object('normalized', canonical(summary))
        return requests, normalized

    def append_batch(self, batch_id, scheduled_at, status, raw_http, summary, *, kind='bbo'):
        with self._operation():
            requests, normalized = self._prepare(raw_http, summary)
            return self._append_references(batch_id, scheduled_at, status, requests, normalized, kind=kind)

    def prepare_batch(self, raw_http, summary):
        with self._operation():
            requests, normalized = self._prepare(raw_http, summary)
            catalog = self._catalog()
            payload = canonical({'requests': requests, 'normalized_object': normalized})
            return PreparedBatch(catalog['store_id'], payload, digest(payload))

    def append_prepared(self, batch_id, scheduled_at, status, prepared, *, kind='bbo', request_clocks=None):
        with self._operation():
            catalog = self._catalog()
            if (not isinstance(prepared, PreparedBatch) or prepared.store_id != catalog['store_id']
                    or digest(prepared.payload) != prepared.payload_sha256):
                raise IntegrityError('prepared handle belongs to another store or differs')
            value = json.loads(prepared.payload)
            requests, normalized = value['requests'], value['normalized_object']
            for request in requests:
                request['prepared_payload_reuse'] = True
                request['receipt_clocks_overridden'] = request_clocks is not None
                request['original_request_clocks'] = {key: request.get(key) for key in ('request_started_at', 'received_at')}
            if request_clocks is not None:
                if len(request_clocks) != len(requests):
                    raise ValueError('one explicit request clock pair per retained HTTP attempt required')
                for request, clocks in zip(requests, request_clocks):
                    if set(clocks) != {'request_started_at', 'received_at'}:
                        raise ValueError('prepared replay may replace only the two explicit receipt clocks')
                    request.update({key: iso(child) for key, child in clocks.items()})
                    if timestamp(request['received_at']) < timestamp(request['request_started_at']):
                        raise ValueError('prepared receipt precedes request')
            for reference in [normalized] + [request['body_object'] for request in requests if 'body_object' in request]:
                self._check_reference_exists(reference)
            return self._append_references(batch_id, scheduled_at, status, requests, normalized, kind=kind)

    def _append_references(self, batch_id, scheduled_at, status, requests, normalized, *, kind):
        if not isinstance(batch_id, str) or not 0 < len(batch_id) <= 256 or '\n' in batch_id:
            raise ValueError('bounded stable batch ID required')
        if not isinstance(kind, str) or not kind or len(kind) > 32 or not isinstance(status, str) or not status or len(status) > 64:
            raise ValueError('explicit batch kind and status required')
        scheduled = iso(scheduled_at)
        day = scheduled[:10]
        with self._operation():
            catalog = self._catalog()
            matching = next((entry for entry in catalog['days'] if entry['day'] == day), None)
            if matching is None:
                if catalog['days'] and day < catalog['days'][-1]['day']:
                    raise ValueError('out-of-order uncatalogued day forbidden')
                if catalog['active_day'] is not None:
                    catalog = self._seal(catalog)
                catalog = self._new_day(catalog, day)
                matching = catalog['days'][-1]
            checkpoint = self._load_day(matching)
            payload = {'batch_id': batch_id, 'kind': kind, 'scheduled_at': scheduled,
                       'status': status, 'requests': requests, 'normalized_object': normalized}
            fingerprint = digest(canonical(payload))
            previous = checkpoint['index'].get(batch_id)
            if previous:
                if previous['input_sha256'] != fingerprint:
                    raise IntegrityError('conflicting duplicate batch ID; prior observation retained')
                event, _ = self._read_event(self._paths(day)[1], previous['offset'], previous['length'])
                return self._receipt(event, duplicate=True)
            if matching['sealed']:
                raise ValueError('sealed day cannot accept new batches; use an explicit current correction record')
            event = _signed(dict(payload, schema='BROAD_BATCH_V1', day=day,
                seq=checkpoint['next_seq'], prev=checkpoint['tip'], recorded_at=iso(self.now()), input_sha256=fingerprint))
            raw = canonical(event)+b'\n'
            journal = self._paths(day)[1]
            descriptor = os.open(journal, os.O_WRONLY | os.O_APPEND)
            try:
                offset = 0
                while offset < len(raw):
                    offset += os.write(descriptor, raw[offset:])
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            # Never mutate the cached head until the durable event exists.
            checkpoint = json.loads(canonical(checkpoint))
            self._add_index(checkpoint, event, checkpoint['byte_offset'], len(raw))
            self._save_checkpoint(checkpoint)
            self.metrics['batches_appended'] += 1
            return self._receipt(event, duplicate=False)

    @staticmethod
    def _receipt(event, duplicate):
        return {'day': event['day'], 'seq': event['seq'], 'batch_id': event['batch_id'],
                'kind': event['kind'], 'status': event['status'], 'hash': event['hash'],
                'scheduled_at': event['scheduled_at'], 'recorded_at': event['recorded_at'],
                'normalized_object': event['normalized_object'],
                'raw_objects': [item['body_object'] for item in event['requests'] if 'body_object' in item],
                'duplicate': duplicate}

    def lookup(self, batch_id, scheduled_at):
        day = iso(scheduled_at)[:10]
        with self._operation():
            catalog = self._catalog()
            entry = next((item for item in catalog['days'] if item['day'] == day), None)
            if entry is None:
                return None
            checkpoint = self._load_day(entry)
            position = checkpoint['index'].get(batch_id)
            if position is None:
                return None
            event, _ = self._read_event(self._paths(day)[1], position['offset'], position['length'])
            return self._receipt(event, duplicate=True)

    def read_summary(self, receipt):
        with self._operation():
            return json.loads(self._verify_object(receipt['normalized_object']))

    def read_object(self, reference):
        """Verify and return this one exact object; not a full-history assertion."""
        with self._operation():
            return self._verify_object(reference)

    def iter_batches(self, day, after_seq=0, limit=MAX_DAY_BATCHES):
        """Return a bounded day's records at seq >= after_seq.

        Each returned record and contiguous chain is checked against the retained
        daily checkpoint. Previously retained source objects are not implicitly
        rehashed; use read_object for selected frames or full_verify independently.
        """
        if not isinstance(after_seq, int) or after_seq < 0 or not isinstance(limit, int) or not 1 <= limit <= MAX_DAY_BATCHES:
            raise ValueError('bounded nonnegative sequence and positive limit required')
        with self._operation():
            catalog = self._catalog()
            entry = next((item for item in catalog['days'] if item['day'] == day), None)
            if entry is None:
                return []
            checkpoint = self._load_day(entry)
            positions = sorted(checkpoint['index'].values(), key=lambda value: value['seq'])
            selected = [position for position in positions if position['seq'] >= after_seq][:limit]
            if not selected:
                return []
            previous = positions[selected[0]['seq']-1]['hash'] if selected[0]['seq'] else checkpoint['base_prev']
            result = []
            for position in selected:
                event, length = self._read_event(self._paths(day)[1], position['offset'], position['length'])
                if (event['hash'] != position['hash'] or event['seq'] != position['seq']
                        or event['prev'] != previous or length != position['length']):
                    raise IntegrityError('selected batch range/checkpoint chain differs')
                result.append(event)
                previous = event['hash']
            return result

    def append_missing(self, batch_id, scheduled_at, reason, *, kind='bbo', correction_at=None):
        """A sealed past minute needs an explicit current-day correction clock.

        The target clock remains in the normalized record, and no source body or
        historical quote is invented. Without correction_at, sealed days reject it.
        """
        return self.append_batch(batch_id, correction_at or scheduled_at, 'MISSING', [],
                                 {'reason': reason, 'backfilled': False,
                                  'target_scheduled_at': iso(scheduled_at),
                                  'correction_record': correction_at is not None}, kind=kind)

    def _cursor_day(self, entry, checkpoint):
        return {'next_seq': checkpoint['next_seq'], 'tip': checkpoint['tip'],
                'byte_offset': checkpoint['byte_offset'], 'last_event_offset': checkpoint['last_event_offset'],
                'sealed': entry['sealed'], 'seal_sha256': entry.get('seal_sha256')}

    def inventory_since(self, cursor=None):
        """Bounded incremental export under the operation lock.

        Older sealed days acknowledged by the cursor are checked against catalog
        identities without opening their bytes. The first export scans retained
        journals; later exports read only new ranges and current daily metadata.
        """
        with self._operation():
            catalog = self._catalog()
            if cursor is not None:
                if (cursor.get('schema') != 'BROAD_EXPORT_CURSOR_V1' or cursor.get('store_id') != catalog['store_id']
                        or not isinstance(cursor.get('catalog_generation'), int)
                        or not 0 <= cursor['catalog_generation'] <= catalog['generation']):
                    raise IntegrityError('unknown/ahead export cursor')
            prior_days = cursor.get('days', {}) if cursor else {}
            if not set(prior_days).issubset({item['day'] for item in catalog['days']}):
                raise IntegrityError('export cursor references removed day')
            output, next_days = {}, {}
            for entry in catalog['days']:
                day, prior = entry['day'], prior_days.get(entry['day'])
                if prior and prior['sealed']:
                    if (not entry['sealed'] or prior.get('seal_sha256') != entry.get('seal_sha256')
                            or prior['tip'] != entry.get('tip') or prior['next_seq'] != entry.get('next_seq')
                            or prior['byte_offset'] != entry.get('byte_offset')):
                        raise IntegrityError('acknowledged sealed day regressed/changed')
                    next_days[day] = prior
                    continue
                checkpoint = self._load_day(entry)
                directory, journal, cp_path, seal_path = self._paths(day)
                offset = 0
                if prior:
                    if (prior['next_seq'] > checkpoint['next_seq'] or prior['byte_offset'] > checkpoint['byte_offset']
                            or prior['next_seq'] < 0 or prior['byte_offset'] < 0):
                        raise IntegrityError('export cursor ahead of retained day')
                    if prior['next_seq']:
                        anchor, length = self._read_event(journal, prior['last_event_offset'])
                        if (anchor['hash'] != prior['tip'] or anchor['seq'] != prior['next_seq']-1
                                or prior['last_event_offset']+length != prior['byte_offset']):
                            raise IntegrityError('export cursor prefix differs')
                    elif prior['tip'] != checkpoint['base_prev'] or prior['byte_offset'] != 0:
                        raise IntegrityError('invalid empty export cursor')
                    offset = prior['byte_offset']
                while offset < checkpoint['byte_offset']:
                    event, length = self._read_event(journal, offset)
                    for reference in self._references(event):
                        output[reference['path']] = {key: reference[key] for key in ('path', 'sha256', 'bytes')} | {'immutable': True}
                    offset += length
                if entry['sealed']:
                    for reference in entry['files']:
                        output[reference['path']] = reference
                else:
                    for path in (journal, cp_path):
                        reference = self._file_reference(path, False)
                        if path == cp_path:
                            reference['rebuild'] = 'ACTIVE_CHECKPOINT_FROM_JOURNAL'
                            reference['anchor'] = {key: checkpoint[key] for key in
                                ('day', 'base_prev', 'next_seq', 'tip', 'byte_offset', 'last_event_offset')}
                            reference['anchor'].update(expected_sha256=reference['sha256'], expected_bytes=reference['bytes'])
                        output[reference['path']] = reference
                next_days[day] = self._cursor_day(entry, checkpoint)
            catalog_ref = self._file_reference(self.catalog_path, False)
            output[catalog_ref['path']] = catalog_ref
            next_cursor = {'schema': 'BROAD_EXPORT_CURSOR_V1', 'store_id': catalog['store_id'],
                           'catalog_generation': catalog['generation'], 'days': next_days}
            return {'cursor': next_cursor, 'files': sorted(output.values(), key=lambda value: value['path']),
                    'metadata': {'store_id': catalog['store_id'], 'active_day': catalog['active_day'],
                                 'days': len(catalog['days']), 'hot_path_scope': 'checkpoint_anchor_and_new_suffix_only',
                                 'object_references_may_repeat': True,
                                 'backup_must_skip_previously_committed_immutable_identities_without_rereading_source': True,
                                 'full_verification_required_before_analysis': True}}

    def full_verify(self):
        """Independent complete journal/chain/index/seal and referenced-byte scan."""
        with self._operation():
            catalog = self._catalog()
            checked_objects, counts, statuses, previous = set(), Counter(), Counter(), ZERO
            files, total_events, total_raw, total_normalized = {}, 0, 0, 0
            for entry in catalog['days']:
                checkpoint = self._load_day(entry)
                if entry['base_prev'] != previous:
                    raise IntegrityError('cross-day chain differs')
                directory, journal, cp_path, seal_path = self._paths(entry['day'])
                rebuilt = {'schema': 'BROAD_DAY_CHECKPOINT_V1', 'day': entry['day'], 'base_prev': previous,
                           'next_seq': 0, 'tip': previous, 'byte_offset': 0, 'last_event_offset': 0, 'index': {}}
                offset = 0
                while offset < journal.stat().st_size:
                    event, length = self._read_event(journal, offset)
                    self._add_index(rebuilt, event, offset, length)
                    for reference in self._references(event):
                        if reference['path'] not in checked_objects:
                            self._verify_object(reference)
                            checked_objects.add(reference['path'])
                            if reference['lane'] == 'raw':
                                total_raw += reference['bytes']
                            else:
                                total_normalized += reference['bytes']
                    counts[event['kind']] += 1
                    statuses[event['status']] += 1
                    total_events += 1
                    offset += length
                if _signed(rebuilt) != checkpoint:
                    raise IntegrityError('independent rebuilt checkpoint/index differs')
                previous = checkpoint['tip']
                if entry['sealed']:
                    seal = _read_json(seal_path)
                    if (seal['tip'] != checkpoint['tip'] or seal['base_prev'] != entry['base_prev']
                            or entry['tip'] != checkpoint['tip'] or _file_hash(seal_path) != entry['seal_sha256']):
                        raise IntegrityError('day seal differs')
                    for reference in entry['files']:
                        path = self.root / reference['path']
                        if path.stat().st_size != reference['bytes'] or _file_hash(path) != reference['sha256']:
                            raise IntegrityError('sealed segment bytes differ')
            actual_objects = {path.relative_to(self.root).as_posix()
                              for lane in ('raw', 'normalized') for path in (self.root/'objects'/lane).glob('*.gz')}
            return {'status': 'OK', 'store_id': catalog['store_id'], 'events': total_events,
                    'batches_by_kind': dict(counts), 'days': len(catalog['days']), 'tip': previous,
                    'batch_status_counts': dict(statuses),
                    'referenced_objects': len(checked_objects), 'raw_gzip_bytes': total_raw,
                    'normalized_gzip_bytes': total_normalized, 'orphan_objects': sorted(actual_objects-checked_objects),
                    'verification_scope': 'all_retained_journals_indices_seals_and_referenced_object_bytes',
                    'independent_publication_or_timestamp_proof': False}


Store = BroadStore


def rebuild_checkpoint_from_journal(journal_path, anchor):
    """Read-only exact reconstruction of one ACTIVE daily index checkpoint.

    Historical descriptors may refer to a prefix of a later retained journal.
    Read only that bounded prefix; verify its chain, event/input hashes, object
    identity structure and anchor, then reproduce the original canonical bytes.
    This does not verify object contents. Restoration must subsequently call
    BroadStore.full_verify() before asserting restored archive integrity.
    """
    path = Path(journal_path)
    if path.is_symlink() or not path.is_file():
        raise IntegrityError('checkpoint reconstruction needs a regular journal')
    day = anchor.get('day')
    if not isinstance(day, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', day):
        raise IntegrityError('invalid checkpoint reconstruction day')
    try: dt.date.fromisoformat(day)
    except ValueError as exc: raise IntegrityError('invalid checkpoint reconstruction date') from exc
    for key in ('base_prev', 'tip', 'expected_sha256'):
        if not isinstance(anchor.get(key), str) or re.fullmatch('[0-9a-f]{64}', anchor[key]) is None:
            raise IntegrityError('invalid checkpoint reconstruction hash')
    for key in ('next_seq', 'byte_offset', 'last_event_offset', 'expected_bytes'):
        if not isinstance(anchor.get(key), int) or isinstance(anchor[key], bool) or anchor[key] < 0:
            raise IntegrityError('invalid checkpoint reconstruction bound')
    if (anchor['next_seq'] > MAX_DAY_BATCHES or anchor['byte_offset'] > 64*1024*1024
            or anchor['byte_offset'] > path.stat().st_size):
        raise IntegrityError('checkpoint reconstruction prefix outside daily bound')
    rebuilt = {'schema': 'BROAD_DAY_CHECKPOINT_V1', 'day': day, 'base_prev': anchor['base_prev'],
               'next_seq': 0, 'tip': anchor['base_prev'], 'byte_offset': 0, 'last_event_offset': 0, 'index': {}}
    offset = 0
    with path.open('rb') as stream:
        while offset < anchor['byte_offset']:
            raw = stream.readline(anchor['byte_offset']-offset)
            if not raw.endswith(b'\n'):
                raise IntegrityError('checkpoint prefix contains an incomplete append')
            try:
                event = json.loads(raw)
                if canonical(event)+b'\n' != raw:
                    raise IntegrityError('noncanonical checkpoint-prefix event')
                _checked(event)
                for reference in BroadStore._references(event):
                    lane, hash_ = reference.get('lane'), reference.get('sha256')
                    if (lane not in ('raw', 'normalized') or not isinstance(hash_, str)
                            or not re.fullmatch('[0-9a-f]{64}', hash_)
                            or reference.get('path') != f'objects/{lane}/{hash_}.gz'
                            or not isinstance(reference.get('uncompressed_sha256'), str)
                            or not re.fullmatch('[0-9a-f]{64}', reference['uncompressed_sha256'])):
                        raise IntegrityError('invalid checkpoint-prefix object identity')
                    for key in ('bytes', 'uncompressed_bytes'):
                        if not isinstance(reference.get(key), int) or isinstance(reference[key], bool) or reference[key] < 0:
                            raise IntegrityError('invalid checkpoint-prefix object size')
                    if reference['uncompressed_bytes'] > MAX_OBJECT_BYTES:
                        raise IntegrityError('checkpoint-prefix object expansion bound exceeded')
                # This method mutates only the provided plain checkpoint dictionary.
                BroadStore._add_index(None, rebuilt, event, offset, len(raw))
            except (KeyError, TypeError, ValueError) as exc:
                raise IntegrityError('invalid checkpoint-prefix record') from exc
            offset += len(raw)
    if any(rebuilt[key] != anchor[key] for key in ('next_seq', 'tip', 'byte_offset', 'last_event_offset')):
        raise IntegrityError('reconstructed checkpoint differs from compact anchor')
    encoded = canonical(_signed(rebuilt))+b'\n'
    if len(encoded) != anchor['expected_bytes'] or digest(encoded) != anchor['expected_sha256']:
        raise IntegrityError('reconstructed checkpoint bytes/hash differ from source descriptor')
    return encoded
