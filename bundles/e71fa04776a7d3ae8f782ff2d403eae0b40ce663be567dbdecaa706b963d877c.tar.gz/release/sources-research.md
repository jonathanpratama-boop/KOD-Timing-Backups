# Source verification for the isolated economic-event cohort

Prepared 5 November 2026. **GMX on Arbitrum is the only proposed member.** This choice uses source quality and mechanism evidence from the two-case research. No price outcome, return, volume, attention measure or convenient event count was used to select it. SUSHI is excluded: the April 2026 mint was verified, but its attribution to the December 2025 ceiling change was unresolved, and issuance is outside the native-token market-purchase hypothesis.

`sources.json` is the machine-readable mapping. `sources-bootstrap/` retains successful and failed requests, receipt clocks, raw bytes and SHA-256 hashes. All of these are **bootstrap**, never new live discoveries. The parent must include the final mapping and bootstrap manifest in the release hash and independent anchoring workflow before admissions begin.

## Verified identity and sources

- Official token docs name Arbitrum One GMX `0xfc5A1A6EB076a2C7aD06eD22C90d7E710E35ad0a`. A new public RPC request returned chain ID `0xa4b1` (42161). The official `gmx-io/gmx-synthetics` FeeHandler deployment JSON names `0x7EB417637a3E6d1C19E6d69158c47610b7a5d9B3` and has the same GMX token in its constructor arguments.
- Snapshot `gmx.eth` returns name GMX, network 42161, symbol GMX. Its identity is corroborated by the official GMX forum's original 2024 policy topic, and the old buyback proposal's matching Snapshot/Tally crosslinks. The current official proposal-process docs direct users to `gov.gmx.io` and formal onchain Tally governance. Snapshot is therefore a discovery source, **not an exhaustive policy or implementation feed**.
- Frozen discovery endpoints are Snapshot GraphQL, the official Discourse forum, official rewards docs and official governance-process docs. Tally is not an automated source in this small cohort. Coverage is explicitly `PARTIAL_MANUAL`, including when every configured request succeeds. A protocol decision may occur elsewhere or be delayed in an observed source.
- Fixed public spot pairs are GMXUSDT, BTCUSDT and ETHUSDT. Parent independently tested bookTicker access from the actual cloud host; see `evidence/host-preflight.json`. The Mac's exchangeInfo probe reset its connection, and that failure is retained. The official token identity and exchange ticker metadata are distinct: no broker fill, access, deposit entitlement, current fee or USDT/USD parity is established.

Direct official sources:

- https://docs.gmx.io/docs/tokenomics/gmx-token/
- https://docs.gmx.io/docs/tokenomics/rewards/
- https://docs.gmx.io/docs/governance/proposal-process/
- https://gov.gmx.io/t/3693.json
- https://gov.gmx.io/t/5179.json
- https://hub.snapshot.org/graphql
- https://raw.githubusercontent.com/gmx-io/gmx-synthetics/main/deployments/arbitrum/FeeHandler.json

## Actual adapter probes

The Mac's local Python trust store failed certificate verification. Those failures are retained. A subsequent bounded `curl` acquisition used the Mac's existing verified TLS trust store and succeeded; no security setting or credential changed. Cloud-host adapters must use their own verified trust store and pass actual-host checks.

1. Snapshot queries with `first:10`, `skip:0` then `skip:10`, `orderBy:created`, `orderDirection:desc`, and `space_in:["gmx.eth"]` returned HTTP 200, ten records per page and no shared IDs. Both returned consistent source identity. The latest returned Snapshot proposal was already from June 2026; October operational announcements are therefore not covered by Snapshot alone. Runtime caps are three pages of 100; reaching a cap or an ambiguous ordering boundary is partial coverage. Pagination failure must be retained separately from a valid no-event result.
2. `https://gov.gmx.io/latest.json?page=0` and page 1 each returned HTTP 200, 30 topics and disjoint IDs. `topic_list.more_topics_url` advertised the next page. Topic 3693 returned only 20 `post_stream.posts` for 68 IDs in `post_stream.stream`, demonstrating that topic JSON alone is incomplete. A request for missing post IDs 8951 and 8952 returned exactly those two posts at `/t/3693/posts.json?post_ids%5B%5D=8951&post_ids%5B%5D=8952`. Missing posts, a topic/content cap or failure must be visible as partial coverage. New replies and edited known topics can contain implementation evidence; checking only newly created topic IDs is insufficient.
3. Current topic 5179 returned all 17 listed post IDs. Official token/rewards/governance documents and the official FeeHandler deployment JSON all returned HTTP 200 with raw bytes retained. Changed document bytes create a watch candidate, not automatic eligibility.
4. The public Arbitrum RPC returned the successful historical buyback receipt. It matches transaction `0xa25c3e5d32e359e28400ab58363a07ed111066d04ef6b168489656ee38de0d3a`, block 267455173, status `0x1`. Log 133 transfers 25 GMX to FeeHandler; log 134 transfers 566.648207 USDC from FeeHandler to the same supplier. This confirms the retained historical mechanism and identity; it does not create a prospective event.

## Historical policies stay outside prospective admissions

The 2024 change retained 30% of V1 / 27% of V2 fees for stakers while changing payment from ETH/AVAX to purchased GMX. This is fee-funded purchase and redistribution, with zero increase in fee percentage and no permanent burn. Official activation article publication on 4 November 2024 and its stated earlier operational date are separate clocks. The exact old buyback transaction was freshly re-fetched as a reproducibility check; a new receipt clock does not make old implementation new.

GMLabs-003 was announced on 21 October 2026. It proposed routing remaining Solana protocol revenue after GT buybacks into GMX purchases and a 180-day unstaking delay, with 28 October planned as implementation. Forum replies on 3 November state operational implementation and expressly say this was not a Snapshot vote. The official rewards docs describe treasury accumulation and suspended distributions pending GMX reaching $90. The exact Solana funding-to-purchase chain has not been independently established in this pass. In every case it is known pre-window history/watch context, not an eligible new prospective episode. A later source update about pre-window implementation stays excluded.

## Required semantic adjudication

The collector creates watch candidates without keyword eligibility. A human economic reviewer must accept or exclude each candidate additively, preserving the actual adjudication delay. Acceptance requires: precise old/new policy, official authorization or operational authority, new implemented external-fee-funded native-token market purchase, actual public funding and purchase evidence, correct contract/token identity, implementation and actual discovery both inside the prospective admission window, and no earlier admitted episode for the same protocol/token/policy version. A vote, statement, future plan, treasury transfer, supply mint, old implementation or additional transaction in an already accepted policy episode does not suffice.

Receipt/publication/adjudication/quote clocks remain distinct. Source publication fields are source claims. Earliest references and local hashes do not independently prove original public availability. An unseen source, cap, failure or delayed manual review cannot be silently transformed into an exhaustive no-event observation. Manual adjudication has no promised maximum turnaround; missing the admission/quote window means no paper entry.

## Sources inspected before mapping

Read the existing local `two-case-verification/REPORT.md`, `gmx/REPORT.md`, `sushi/REPORT.md`, the failed info-magnet `REPORT.md`, and `kod-deploy/docs/TIMING_RESEARCH.md`. They support a distinct mechanism cohort and preservation of failed listing/price/attention studies. Their source statements and historical receipts inform bootstrap engineering, not a newly validated alpha rule.

No real order, account allocation, paid source, new credential, access grant or persistent security change was performed by this source-verification task.
