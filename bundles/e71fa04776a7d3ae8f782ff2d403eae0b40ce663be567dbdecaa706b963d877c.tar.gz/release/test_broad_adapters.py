import copy
import datetime as dt
import hashlib
import json
import unittest
from pathlib import Path
import urllib.parse
from unittest.mock import patch
from broad_observer import adapters as a

NOW=dt.datetime(2026,11,5,12,tzinfo=dt.timezone.utc)


def metadata_row(symbol='AAAUSDT',status='TRADING',spot=True,**extra):
    return {'symbol':symbol,'baseAsset':symbol[:-4] if symbol.endswith('USDT') else 'AAA',
            'quoteAsset':'USDT' if symbol.endswith('USDT') else 'BTC','status':status,
            'isSpotTradingAllowed':spot,'permissions':[],**extra}


def metadata():
    result=a.normalize_metadata({'serverTime':1793870000000,'symbols':[
        metadata_row('AAAUSDT'),metadata_row('BBBUSDT',status='BREAK'),
        metadata_row('CCCUSDT',spot=False),metadata_row('AAABTC')]})
    result.update(raw_sha256='b'*64,received_at='2026-11-05T11:00:00Z')
    return result


def bbo(symbol='AAAUSDT',**extra):
    return {'symbol':symbol,'bidPrice':'1.00000000000000000001','askPrice':'1.00000000000000000003',
            'bidQty':'2','askQty':'3',**extra}


def stats(symbol='AAAUSDT',**extra):
    result={'symbol':symbol,'openTime':1793783600000,'closeTime':1793870000000,
            'firstId':1,'lastId':3,'count':3}
    result.update({key:'1' for key in ('priceChange','priceChangePercent','weightedAvgPrice','prevClosePrice',
        'lastPrice','lastQty','bidPrice','bidQty','askPrice','askQty','openPrice','highPrice','lowPrice','volume','quoteVolume')})
    result.update(extra);return result


class Harness:
    def __init__(self,handler=None):self.calls=[];self.events=[];self.seconds=0;self.handler=handler
    def now(self):return NOW+dt.timedelta(seconds=self.seconds)
    def mono(self):return self.seconds
    def transport(self,url,timeout,maxbytes):
        self.calls.append((url,timeout,maxbytes));self.seconds+=0.1
        if self.handler:
            response=self.handler(url)
            if isinstance(response,Exception):raise response
            if response is not None:return response
        if '/exchangeInfo?' in url:data={'symbols':[metadata_row()]}
        elif '/bookTicker' in url:data=[bbo()]
        else:data=[stats()]
        return self.response(json.dumps(data).encode(),headers={'Date':'Wed, 05 Nov 2026 12:00:00 GMT','X-MBX-USED-WEIGHT-1M':'104'})
    @staticmethod
    def response(body,status=200,headers=None,**extra):return {'body':body,'status':status,'headers':headers or {},**extra}
    def adapter(self,**extra):
        return a.PublicBatchAdapters(transport=self.transport,now_fn=self.now,monotonic=self.mono,
            audit=lambda kind,payload:self.events.append((kind,payload)),**extra)


class BroadAdapterTests(unittest.TestCase):
    def test_metadata_retains_nontrading_and_nonexecution_rows(self):
        result=metadata();self.assertEqual(result['raw_symbol_count'],4)
        self.assertEqual(result['normalized_spot_usdt_count'],3)
        self.assertEqual(result['execution_eligible_count'],1)
        self.assertEqual(result['all_symbol_identities'],['AAABTC','AAAUSDT','BBBUSDT','CCCUSDT'])
        self.assertEqual([row['status'] for row in result['symbols']],['TRADING','BREAK','TRADING'])
        self.assertFalse(result['symbols'][2]['execution_eligible'])

    def test_empty_legacy_permissions_do_not_override_modern_positive_spot(self):
        rows=[metadata_row(permissionSets=[['SPOT','MARGIN']]),metadata_row('BBBUSDT',spot=False,permissionSets=[['SPOT']])]
        result=a.normalize_metadata({'symbols':rows})
        self.assertTrue(result['symbols'][0]['spot_permission'])
        self.assertFalse(result['symbols'][1]['spot_permission'])
        self.assertIn('permissionSets',result['symbols'][0]['permission_fields'])

    def test_unicode_exchange_identity_preserved_exactly_and_safely_encoded(self):
        symbols=['币安人生USDT','牛来USDT']
        result=a.normalize_metadata({'symbols':[metadata_row(symbol) for symbol in symbols]})
        self.assertEqual({row['symbol'] for row in result['symbols']},set(symbols))
        h=Harness()
        def handler(url):
            requested=json.loads(urllib.parse.parse_qs(urllib.parse.urlparse(url).query)['symbols'][0])
            self.assertEqual(requested,sorted(symbols))
            return Harness.response(json.dumps([bbo(symbol) for symbol in requested],ensure_ascii=False).encode())
        h.handler=handler
        frame=h.adapter().bbo_symbols_frame(result,sorted(symbols))
        self.assertEqual(frame['status'],'OK')
        self.assertEqual({row['symbol'] for row in frame['summary']['rows']},set(symbols))
        for invalid in ('AAA/USDT','AA A','AAA\x00USDT'):
            self.assertFalse(a._valid_symbol(invalid))

    def test_bad_metadata_identity_duplicate_and_limits_fail_closed(self):
        for rows in ([metadata_row(),metadata_row()], [{'symbol':[]}],
                     [metadata_row(quoteAsset=[])], [metadata_row() for i in range(a.MAX_RECORDS+1)]):
            with self.subTest(rows=len(rows)):
                with self.assertRaises(ValueError):a.normalize_metadata({'symbols':rows})

    def test_invalid_permission_fields_retained_unexecutable(self):
        for invalid in ({},[{}],[['SPOT'],{}]):
            with self.subTest(invalid=invalid):
                result=a.normalize_metadata({'symbols':[metadata_row(permissionSets=invalid)]})
                self.assertTrue(result['metadata_errors'])
                self.assertFalse(result['symbols'][0]['execution_eligible'])

    def test_all_raw_known_non_usdt_and_unmatched_are_distinct(self):
        result=a.normalize_batch([bbo(),bbo('AAABTC'),bbo('UNKNOWNUSDT')],metadata(),'bbo')
        self.assertEqual(result['raw_known_non_usdt_count'],1)
        self.assertEqual(result['raw_unmatched_metadata_count'],1)
        self.assertEqual(result['unmatched_rows'][0]['symbol'],'UNKNOWNUSDT')
        self.assertEqual(result['unmatched_rows'][0]['raw_fields'],bbo('UNKNOWNUSDT'))
        self.assertFalse(result['unmatched_rows'][0]['execution_eligible'])
        self.assertEqual(result['normalized_spot_usdt_count'],3)
        self.assertEqual(len(result['missing']),2)

    def test_exact_midpoint_and_zero_size_separate_from_metadata_gate(self):
        result=a.normalize_batch([bbo()],metadata(),'bbo')
        row=result['rows'][0]
        self.assertEqual(row['mid'],'1.00000000000000000002')
        self.assertTrue(row['quote_valid']);self.assertTrue(row['positive_size'])
        self.assertTrue(row['observed_quote_usable'])
        result=a.normalize_batch([bbo(bidQty='0')],metadata(),'bbo')
        row=result['rows'][0]
        self.assertTrue(row['metadata_execution_eligible']);self.assertTrue(row['quote_valid'])
        self.assertFalse(row['positive_size']);self.assertFalse(row['observed_quote_usable'])
        self.assertEqual(result['observed_quote_usable_count'],0)

    def test_nontrading_zero_book_retained_without_active_source_failure(self):
        result=a.normalize_batch([bbo(),bbo('BBBUSDT',bidPrice='0',askPrice='0',bidQty='0',askQty='0')],metadata(),'bbo')
        row=result['rows'][1]
        self.assertEqual(row['status'],'NONEXECUTABLE_BOOK')
        self.assertFalse(row['observed_quote_usable'])
        self.assertEqual(result['nonexecutable_book_count'],1)
        self.assertFalse(any(row['symbol']=='BBBUSDT' for row in result['invalid']))

    def test_missing_invalid_crossed_and_duplicate_quotes_cannot_be_usable(self):
        for items in ([],[bbo(bidPrice='2',askPrice='1')],[bbo(bidPrice='NaN')],
                      [bbo(bidQty={})],[bbo(),bbo()]):
            with self.subTest(items=items):
                result=a.normalize_batch(items,metadata(),'bbo')
                self.assertFalse(result['rows'][0]['observed_quote_usable'])
        result=a.normalize_batch([bbo(),bbo()],metadata(),'bbo')
        self.assertEqual(result['duplicate_symbols'],['AAAUSDT'])
        self.assertEqual(result['rows'][0]['status'],'DUPLICATE_RESPONSE_SYMBOL')

    def test_stats_source_clocks_mean_rolling_window_and_zero_trade_sentinel(self):
        result=a.normalize_batch([stats(firstId=-1,lastId=-1,count=0)],metadata(),'stats')
        row=result['rows'][0]
        self.assertTrue(row['statistics_valid'])
        self.assertLess(row['statistics_open_at'],row['statistics_close_at'])
        self.assertEqual(row['source_timestamp'],row['statistics_close_at'])
        self.assertIn('not an execution',result['source_timestamp_semantics'])

    def test_stats_bad_clock_types_and_nonfinite_fields_retained_invalid(self):
        for extra in ({'closeTime':{}},{'openTime':True},{'closeTime':0},{'quoteVolume':'NaN'},{'count':False}):
            with self.subTest(extra=extra):
                result=a.normalize_batch([stats(**extra)],metadata(),'stats')
                self.assertEqual(result['rows'][0]['status'],'INVALID_RESPONSE_FIELDS')

    def test_cohort_frozen_and_missing_member_not_substituted(self):
        cohort=['AAAUSDT','UNLISTEDUSDT'];original=cohort.copy();meta=metadata();before=copy.deepcopy(meta)
        result=a.normalize_batch([bbo(),bbo('NEWUSDT')],meta,'bbo',cohort)
        self.assertEqual(cohort,original);self.assertEqual(meta,before)
        self.assertEqual(result['cohort_status'][1],{'symbol':'UNLISTEDUSDT','status':'MISSING_PINNED_METADATA','execution_eligible':False})
        self.assertEqual(sum(row['membership']=='FROZEN_COHORT' for row in result['rows']),1)
        self.assertFalse(any(row['symbol']=='NEWUSDT' for row in result['rows']))

    def test_bad_pinned_metadata_and_cohort_prevent_network(self):
        h=Harness();adapter=h.adapter()
        for bad in ({},dict(metadata(),all_symbol_identities=[])):
            with self.assertRaises(ValueError):adapter.bbo(bad)
        for cohort in (['AAAUSDT']*2,[str(i)+'USDT' for i in range(151)],['bad.usdt']):
            with self.assertRaises(ValueError):adapter.bbo(metadata(),cohort)
        self.assertEqual(h.calls,[])

    def test_fixed_endpoint_raw_bytes_weight_latency_audit_and_null_quote_clock(self):
        h=Harness();adapter=h.adapter();meta=adapter.metadata();result=adapter.bbo(meta['summary'])
        self.assertEqual(h.calls[0][0],a.BASE+'/api/v3/exchangeInfo?showPermissionSets=false')
        self.assertEqual(h.calls[1][0],a.BASE+'/api/v3/ticker/bookTicker')
        raw=result['raw_http'][0]
        self.assertEqual(hashlib.sha256(raw['body']).hexdigest(),raw['raw_sha256'])
        self.assertEqual(raw['headers']['x-mbx-used-weight-1m'],'104')
        self.assertAlmostEqual(raw['elapsed_seconds_monotonic'],0.1)
        self.assertIsNone(raw['source_timestamp']);self.assertIsNone(result['summary']['rows'][0]['source_timestamp'])
        self.assertEqual([kind for kind,p in h.events],['request_started','request_finished']*2)
        self.assertEqual(h.events[2][1]['request_id'],h.events[3][1]['request_id'])
        self.assertNotIn('body',h.events[3][1])

    def test_429_418_retry_after_and_blocks_latch_without_fallback(self):
        for status,headers in ((429,{}),(418,{}),(403,{}),(451,{}),(200,{'Retry-After':'120'}),(302,{})):
            with self.subTest(status=status,headers=headers):
                h=Harness(lambda url:Harness.response(b'{"code":-1003}',status,headers))
                adapter=h.adapter();first=adapter.metadata();second=adapter.bbo(metadata())
                self.assertEqual(first['status'],'BLOCKED');self.assertTrue(first['requires_operator_review'])
                self.assertEqual(second['status'],'BLOCKED_LATCHED');self.assertEqual(len(h.calls),1)
                self.assertFalse(second['raw_http'][0]['attempted'])
                self.assertEqual(first['raw_http'][0]['body'],b'{"code":-1003}')

    def test_api_rate_error_latches_even_http200(self):
        h=Harness(lambda url:Harness.response(b'{"code":-1003,"msg":"limit"}'))
        self.assertEqual(h.adapter().metadata()['status'],'BLOCKED')

    def test_http_network_json_schema_errors_preserve_attempts_without_fallback(self):
        for response,expected in ((Harness.response(b'error',500),'HTTP_ERROR'),
            (OSError('offline'),'FAILED'),(Harness.response(b'not json'),'FAILED'),
            (Harness.response(b'[]'),'SCHEMA_ERROR')):
            with self.subTest(expected=expected):
                h=Harness(lambda url:response);result=h.adapter().metadata()
                self.assertEqual(result['status'],expected);self.assertEqual(len(h.calls),1)
                self.assertEqual(len(result['raw_http']),1)
                if not isinstance(response,Exception):
                    self.assertEqual(result['raw_http'][0]['body'],response['body'])
                    self.assertTrue(result['raw_http'][0]['response_body_complete'])
                else:
                    self.assertFalse(result['raw_http'][0]['response_body_complete'])
                    self.assertEqual(result['raw_http'][0]['capture_status'],'NO_RESPONSE_CAPTURED')

    def test_cap_prefix_and_incomplete_body_never_normalized(self):
        h=Harness(lambda url:Harness.response(b'123456789'))
        result=h.adapter(max_bytes=8).metadata();raw=result['raw_http'][0]
        self.assertEqual(result['status'],'RESPONSE_CAP');self.assertTrue(raw['raw_truncated'])
        self.assertFalse(raw['response_body_complete']);self.assertEqual(raw['capture_status'],'RESPONSE_CAP_PREFIX')
        self.assertEqual(raw['body'],b'12345678');self.assertIsNone(result['summary'])
        h=Harness(lambda url:Harness.response(b'{"symbols":[]}',response_incomplete=True,transport_error='timeout'))
        result=h.adapter().metadata();self.assertEqual(result['status'],'INCOMPLETE_RESPONSE')
        self.assertEqual(result['raw_http'][0]['body'],b'{"symbols":[]}')

    def test_no_redirect_handler_and_response_url_change_blocked(self):
        self.assertIsNone(a._NoRedirect().redirect_request(None,None,302,'Found',{},'https://other.invalid'))
        h=Harness(lambda url:Harness.response(b'[]',response_url='https://other.invalid'))
        self.assertEqual(h.adapter().metadata()['status'],'BLOCKED')

    def test_schema_malformed_array_and_duplicate_source_rows_retained(self):
        for data in ({},[{'symbol':[]}],[bbo(),bbo()],['invalid']):
            with self.subTest(data=data):
                h=Harness(lambda url:Harness.response(json.dumps(data).encode()))
                result=h.adapter().bbo(metadata())
                self.assertIn(result['status'],('SCHEMA_ERROR','PARTIAL'))
                self.assertEqual(result['raw_http'][0]['body'],json.dumps(data).encode())

    def test_audit_storage_failure_and_interrupt_are_not_source_failures(self):
        h=Harness();events=[]
        def fail(*args):raise RuntimeError('durability failed')
        adapter=a.PublicBatchAdapters(transport=h.transport,audit=fail,now_fn=h.now,monotonic=h.mono)
        with self.assertRaises(RuntimeError):adapter.metadata()
        self.assertEqual(h.calls,[])
        def interrupt(*args):raise KeyboardInterrupt()
        adapter=a.PublicBatchAdapters(transport=interrupt,audit=lambda k,p:events.append((k,p)),now_fn=h.now,monotonic=h.mono)
        with self.assertRaises(KeyboardInterrupt):adapter.metadata()
        self.assertEqual([k for k,p in events],['request_started'])

    def test_request_budget_time_cap_and_limit_config(self):
        h=Harness()
        def slow(url):h.seconds+=16;return Harness.response(b'{"symbols":[]}')
        h.handler=slow
        result=h.adapter().metadata();self.assertEqual(result['status'],'REQUEST_TIME_CAP')
        self.assertEqual(result['raw_http'][0]['body'],b'{"symbols":[]}')
        for cap in (0,True,a.MAX_BYTES+1):
            with self.assertRaises(ValueError):h.adapter(max_bytes=cap)

    def test_explicit_frozen_batches_combined_without_substitution(self):
        h=Harness();plan=['AAAUSDT','BBBUSDT'];before=plan.copy()
        def handler(url):
            symbols=json.loads(urllib.parse.parse_qs(urllib.parse.urlparse(url).query)['symbols'][0])
            return Harness.response(json.dumps([bbo(symbol) for symbol in symbols]).encode())
        h.handler=handler
        result=h.adapter().bbo_symbols_frame(metadata(),plan,batch_size=1,max_batches=2,cohort=['AAAUSDT','CCCUSDT'])
        self.assertEqual(plan,before);self.assertEqual(result['status'],'OK')
        self.assertEqual(len(result['raw_http']),2)
        self.assertEqual(result['summary']['planned_batch_count'],2)
        self.assertEqual(result['summary']['cohort_not_requested'],['CCCUSDT'])
        self.assertEqual([row['batch_id'] for row in result['summary']['rows']],[0,1])
        self.assertNotEqual(result['summary']['rows'][0]['received_at'],result['summary']['rows'][1]['received_at'])
        self.assertTrue(all('symbols=' in url for url,_,_ in h.calls))
        self.assertEqual(result['summary']['transport_mode'],'EXPLICIT_FROZEN_SYMBOL_BATCHES')

    def test_explicit_frame_provider_stop_preserves_unattempted_chunks(self):
        h=Harness()
        def handler(url):
            if len(h.calls)==2:return Harness.response(b'{"code":-1003}',429,{'Retry-After':'30'})
            symbols=json.loads(urllib.parse.parse_qs(urllib.parse.urlparse(url).query)['symbols'][0])
            return Harness.response(json.dumps([bbo(symbol) for symbol in symbols]).encode())
        h.handler=handler
        result=h.adapter().bbo_symbols_frame(metadata(),['AAAUSDT','BBBUSDT','CCCUSDT'],batch_size=1)
        self.assertEqual(result['status'],'BLOCKED');self.assertEqual(len(h.calls),2)
        self.assertEqual(result['summary']['unattempted_batches'],[{'batch_id':2,'symbols':['CCCUSDT'],'reason':'PROVIDER_STOP'}])
        row=result['summary']['rows'][2]
        self.assertEqual(row['status'],'NOT_REQUESTED_PROVIDER_STOP')
        self.assertIsNone(row['received_at']);self.assertFalse(row['observed_quote_usable'])

    def test_explicit_plan_validation_prevents_requests_and_no_unexpected_identity(self):
        h=Harness();adapter=h.adapter()
        for plan in ([],['BBBUSDT','AAAUSDT'],['AAAUSDT']*2,[str(i)+'USDT' for i in range(901)]):
            with self.assertRaises(ValueError):adapter.bbo_symbols_frame(metadata(),plan)
        for kwargs in ({'batch_size':151},{'max_batches':7},{'frame_timeout':61}):
            with self.assertRaises(ValueError):adapter.bbo_symbols_frame(metadata(),['AAAUSDT'],**kwargs)
        self.assertEqual(h.calls,[])
        h.handler=lambda url:Harness.response(json.dumps([bbo('CCCUSDT')]).encode())
        result=adapter.bbo_symbols_frame(metadata(),['AAAUSDT'])
        self.assertEqual(result['status'],'PARTIAL')
        self.assertEqual(result['raw_http'][0]['status'],'SCHEMA_ERROR')
        self.assertEqual(result['summary']['rows'][0]['status'],'MISSING_SOURCE_BATCH')
        self.assertEqual(len(h.calls),1)

    def test_actual_saved_offline_fixtures_normalize_unicode_and_missing_metadata(self):
        fixture=Path(__file__).parent/'evidence/census-smoke-only'
        if not (fixture/'metadata-recovery.raw').exists():self.skipTest('offline capacity fixtures not packaged')
        def transport(url,timeout,maxbytes):
            name=('metadata-recovery.raw' if '/exchangeInfo?' in url else
                  'bbo-1.raw' if '/bookTicker' in url else 'statistics-24h.raw')
            return Harness.response((fixture/name).read_bytes(),response_url=url)
        adapter=a.PublicBatchAdapters(transport=transport)
        meta=adapter.metadata();result=adapter.bbo(meta['summary']);statistics=adapter.stats24h(meta['summary'])
        self.assertEqual(meta['status'],'OK')
        self.assertEqual(meta['summary']['normalized_spot_usdt_count'],775)
        self.assertEqual(meta['summary']['execution_eligible_count'],518)
        self.assertTrue({'币安人生USDT','牛来USDT'}.issubset({row['symbol'] for row in meta['summary']['symbols']}))
        self.assertEqual(result['summary']['observed_quote_usable_count'],518)
        self.assertEqual(result['summary']['raw_unmatched_metadata_count'],3)
        self.assertEqual({row['symbol'] for row in result['summary']['unmatched_rows']},{'AXSBIDR','NBTBIDR','NBTUSDT'})
        self.assertEqual(result['summary']['nonexecutable_book_count'],257)
        self.assertEqual(len(result['summary']['invalid']),0)
        self.assertEqual(statistics['summary']['normalized_spot_usdt_count'],775)
        self.assertEqual(len(statistics['summary']['invalid']),0)


if __name__=='__main__':unittest.main()
