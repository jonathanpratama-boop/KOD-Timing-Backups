import datetime as dt
import json
import tempfile
from pathlib import Path
import unittest
import urllib.parse

from research_r2.capture_runtime import ResearchMarketAdapters, ResearchRestLanes
from broad_observer.adapters import normalize_metadata
from broad_observer.store import BroadStore, iso
from test_broad_adapters import metadata_row, stats, Harness

class ActivityTests(unittest.TestCase):
    def setUp(self):
        self.symbols=['BTCUSDT','ETHUSDT']+['X%03dUSDT'%i for i in range(128)]
        self.metadata=normalize_metadata({'serverTime':1793870000000,'symbols':[metadata_row(s) for s in self.symbols]+[metadata_row('UNRELATEDUSDT')]})
        self.metadata['raw_sha256']='a'*64

    def adapter(self,rows=None,status=200,cap=512*1024):
        raw=json.dumps(rows if rows is not None else [stats(s) for s in self.symbols],separators=(',',':')).encode()
        h=Harness(lambda url:Harness.response(raw,status=status,headers={'X-MBX-USED-WEIGHT-1M':'140'}))
        a=ResearchMarketAdapters(transport=h.transport,now_fn=h.now,monotonic=h.mono,max_bytes=cap)
        return a,h,raw

    def test_one_exact_primary_array_preserves_raw_bytes_and_receipt_clocks(self):
        a,h,raw=self.adapter();result=a.stats_symbols(self.metadata,self.symbols)
        self.assertEqual(result['status'],'OK');self.assertEqual(len(h.calls),1)
        url=h.calls[0][0];parsed=urllib.parse.urlparse(url)
        self.assertEqual(parsed.path,'/api/v3/ticker/24hr')
        self.assertEqual(json.loads(urllib.parse.parse_qs(parsed.query)['symbols'][0]),sorted(self.symbols))
        self.assertNotIn('UNRELATEDUSDT',result['summary']['planned_symbols'])
        self.assertEqual(result['raw_http'][0]['body'],raw)
        self.assertLess(result['raw_http'][0]['request_started_at'],result['raw_http'][0]['received_at'])

    def test_missing_fixed_symbol_is_partial_not_repaired_by_substitute(self):
        a,h,_=self.adapter([stats(s) for s in self.symbols[:-1]])
        result=a.stats_symbols(self.metadata,self.symbols)
        self.assertEqual(result['status'],'PARTIAL');self.assertEqual(len(h.calls),1)
        self.assertIn(self.symbols[-1],{row['symbol'] for row in result['summary']['missing']})

    def test_unrequested_or_duplicate_symbol_rejected_and_raw_retained(self):
        for rows in ([stats(s) for s in self.symbols]+[stats('UNRELATEDUSDT')], [stats(s) for s in self.symbols]+[stats('BTCUSDT')]):
            with self.subTest(extra=rows[-1]['symbol']):
                a,h,raw=self.adapter(rows);result=a.stats_symbols(self.metadata,self.symbols)
                self.assertEqual(result['status'],'SCHEMA_ERROR');self.assertIsNone(result['summary'])
                self.assertEqual(result['raw_http'][0]['body'],raw)

    def test_provider_denial_latches_and_does_not_retry_or_change_host(self):
        a,h,_=self.adapter(status=429)
        first=a.stats_symbols(self.metadata,self.symbols);second=a.stats_symbols(self.metadata,self.symbols)
        self.assertEqual(first['status'],'BLOCKED');self.assertEqual(second['status'],'BLOCKED_LATCHED')
        self.assertEqual(len(h.calls),1)

    def test_caps_fail_closed_without_silently_fetching_all_symbols(self):
        a,h,_=self.adapter(cap=100)
        result=a.stats_symbols(self.metadata,self.symbols)
        self.assertEqual(result['status'],'RESPONSE_CAP');self.assertEqual(len(h.calls),1)
        with self.assertRaises(ValueError):a.stats_symbols(self.metadata,['BTCUSDT'])
        self.assertEqual(len(h.calls),1)

    def test_runtime_context_uses_one_archive_and_omits_duplicate_normalized_rows(self):
        with tempfile.TemporaryDirectory() as temporary:
            raw_metadata=json.dumps({'symbols':[metadata_row(s) for s in self.symbols]}).encode()
            raw=json.dumps([stats(s) for s in self.symbols]).encode()
            h=Harness(lambda url:Harness.response(raw,headers={'X-MBX-USED-WEIGHT-1M':'140'}))
            lanes=ResearchRestLanes(temporary,raw_metadata,primary_symbols=self.symbols,transport=h.transport,clock=h.now)
            result=lanes.stats(symbols=self.symbols,target_at=iso(h.now()))
            self.assertEqual(result['raw_http'],[])
            self.assertNotIn('rows',result['summary'])
            store=BroadStore(temporary);events=list(store.iter_batches('2026-11-05'))
            self.assertEqual(len(events),1);self.assertEqual(events[0]['kind'],'context_stats')
            self.assertEqual(store.read_object(events[0]['requests'][0]['body_object']),raw)
            with self.assertRaises(ValueError):lanes.stats(symbols=['BTCUSDT','ETHUSDT'],target_at=iso(h.now()))

if __name__=='__main__':unittest.main()
