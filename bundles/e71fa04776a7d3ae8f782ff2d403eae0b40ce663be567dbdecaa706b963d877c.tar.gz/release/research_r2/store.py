"""The new study's gzip-9 writer; all raw evidence and framing stay unchanged.

The protected capacity store is untouched. Existing BroadStore readers and
restoration validate the same exact uncompressed bytes and compressed hashes.
"""
import gzip
import io
from broad_observer.store import BroadStore, MAX_OBJECT_BYTES, digest


class ResearchStore(BroadStore):
    def _put_object(self, lane, raw):
        if not isinstance(raw, bytes) or len(raw)>MAX_OBJECT_BYTES:
            raise ValueError('bounded exact bytes required')
        plain_hash=digest(raw); key=(lane,plain_hash)
        if key in self._object_cache:
            reference=self._object_cache[key]
            self._check_reference_exists(reference)
            self.metrics['object_cache_hits']+=1
            self._object_cache.move_to_end(key)
            return reference
        stream=io.BytesIO()
        with gzip.GzipFile(fileobj=stream,mode='wb',filename='',compresslevel=9,mtime=0) as out:
            out.write(raw)
        packed=stream.getvalue(); packed_hash=digest(packed)
        relative=f'objects/{lane}/{packed_hash}.gz'
        self._immutable(self.root/relative,packed)
        reference={'path':relative,'sha256':packed_hash,'bytes':len(packed),
                   'uncompressed_sha256':plain_hash,'uncompressed_bytes':len(raw),
                   'encoding':'gzip','lane':lane}
        self._object_cache[key]=reference
        if len(self._object_cache)>64:self._object_cache.popitem(last=False)
        self.metrics['new_objects_checked_or_written']+=1
        return reference
