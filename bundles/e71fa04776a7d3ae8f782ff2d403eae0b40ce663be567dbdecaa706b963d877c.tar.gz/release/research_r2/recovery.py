"""Off-server restoration of exact R2 decisions from immutable backup chunks.

No network calls. Restore source archive and frozen code/config/warmup first.
The output state directory must be new. This does not start a collector.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

from broad_observer.store import BroadStore
from .engine import archive_items, rebuild_from_exports, iso, stamp, canonical


def input_loader(store,config,warmup_manifest=None):
    warmup={}
    if warmup_manifest:
        manifest=Path(warmup_manifest)
        for r in json.loads(manifest.read_text())['responses']:
            warmup['warmup:'+r['symbol']+':'+r['interval']+':'+r['raw_sha256']]=r
    def events():
        catalog=json.loads((store.root/'CATALOG.json').read_text())
        for day in catalog['days']:
            cursor=0
            while True:
                rows=store.iter_batches(day['day'],after_seq=cursor,limit=100)
                if not rows: break
                for row in rows: yield row
                cursor=rows[-1]['seq']+1
    iterator=events()
    def resolve(ident):
        if ident in warmup:
            r=warmup[ident];path=(manifest.parent/r['raw_path']).resolve()
            if manifest.parent.resolve() not in path.parents: raise ValueError('warmup path escapes frozen directory')
            raw=path.read_bytes()
            if path.suffix=='.gz':raw=gzip.decompress(raw)
            if hashlib.sha256(raw).hexdigest()!=r['raw_sha256']:raise ValueError('restored warmup raw bytes differ')
            received=stamp(r['received_at']);start=stamp(r['started_at']);t0=stamp(config['t0'])
            if start>received or received>=t0:raise ValueError('warmup is not actually prelaunch')
            step={'1h':3600,'1d':86400}[r['interval']];cutoff=min(stamp(r['cutoff_exclusive']),t0,received)
            result=[]
            for row in json.loads(raw):
                opened=float(row[0])/1000
                if opened%step or opened+step>cutoff:continue
                result.append({'kind':'hour_warmup' if step==3600 else 'daily','symbol':r['symbol'],
                    'opened':iso(opened),'received_at':r['received_at'],'quote_volume':row[7],
                    'raw_sha256':r['raw_sha256'],'close':row[4]})
            return result
        for event in iterator:
            if event['hash']==ident:
                return archive_items(store,event) if event['kind'] in ('capacity_minute_end','capacity_diagnostic','research_minute_end','research_diagnostic') else []
        raise ValueError('required original archive packet missing: '+ident)
    return resolve


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True);parser.add_argument('--source-store',required=True)
    parser.add_argument('--ledger-directory',required=True);parser.add_argument('--new-state-directory',required=True)
    args=parser.parse_args();configpath=Path(args.config);config=json.loads(configpath.read_text())
    source=Path(args.source_store)
    if not (source/'CATALOG.json').is_file():raise SystemExit('restored original archive required')
    store=BroadStore(source)
    warmup=configpath.parent/config['warmup_manifest'] if config.get('warmup_manifest') else None
    restored=rebuild_from_exports(args.new_state_directory,config,args.ledger_directory,input_loader(store,config,warmup))
    try: print(canonical({'restored':True,'ledger':restored.verify_ledger(),'health':restored.health()}))
    finally:restored.close()


if __name__=='__main__':main()
