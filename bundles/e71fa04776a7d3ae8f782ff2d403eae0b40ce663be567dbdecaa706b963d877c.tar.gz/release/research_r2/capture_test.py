"""Research acquisition tests: real reconstructed controller, no live source calls."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from research_r2 import capture, capture_ops as ops
from broad_observer.store import BroadStore, canonical, iso, UTC
from broad_observer.backup import IncrementalBackup
import test_broad_capacity as fixture


def config(t0=None):
    t0=t0 or dt.datetime(2026,11,5,8,tzinfo=UTC)
    return {'phase':'RESEARCH35D','trial_id':'research-r2-test','t0':iso(t0),
        'admission_end_at':iso(t0+dt.timedelta(days=30)),
        'end_at':iso(t0+dt.timedelta(days=35)),
        'receipt_drain_end':iso(t0+dt.timedelta(days=35,seconds=120)),
        'finalization_end_at':iso(t0+dt.timedelta(days=35,seconds=180)),
        'scientific_enrollment_enabled':True,'economic_enrollment_enabled':False,
        'initial_free_bytes':24_000_000_000,'initial_free_inodes':3_000_000,
        'projected_35day_all_in_bytes':4_000_000_000,'hard_storage_bytes':4_500_000_000,
        'hard_file_count':800000,'hard_inode_count':800000,'minimum_free_inodes':100000,
        'overshoot_reserve_bytes':1_000_000_000,'overshoot_reserve_inodes':5000,
        'guard_interval_seconds':60,'full35day_gate_status':'PASS_MEASURED',
        'primary_symbols':['BTCUSDT','ETHUSDT'],
        'detailed_symbols':['BTCUSDT','ETHUSDT','GMXUSDT','SOLUSDT','ZECUSDT'],
        'selection_manifest_sha256':'a'*64}


class CaptureTests(unittest.TestCase):
    def setUp(self):
        fixture.CapacityTests.setUp(self)
        self.config=config(self.t0)

    factory=fixture.CapacityTests.factory
    bar=fixture.CapacityTests.bar
    first_minute=fixture.CapacityTests.first_minute
    end_events=fixture.CapacityTests.end_events

    def controller(self, **kwargs):
        value=capture.ResearchCaptureController(self.config,self.store,self.factory,self.rest,
            clock=self.clock,monotonic=self.clock.mono,executor=kwargs.pop('executor',fixture.InlineExecutor()),**kwargs)
        self.controllers.append(value);return value

    def test_research_clock_and_endpoint_tolerance(self):
        c=self.controller();c.start()
        self.assertEqual(c.minutes,50402)
        self.assertEqual(c.detail_slots,604824)
        self.assertEqual(c.admission_end,self.t0+dt.timedelta(days=30))
        self.assertEqual(c.end,self.t0+dt.timedelta(days=35,seconds=120))
        self.assertEqual(c.drain_end,c.end+dt.timedelta(seconds=60))
        self.assertFalse(c.heartbeat()['capacity_trial_only'])
        self.assertTrue(c.heartbeat()['research_engine_enrollment_separate'])

    def test_bitmap_minute_exact_flags_and_raw_pack_unchanged_from_retained_controller(self):
        import importlib.util
        retained=Path(__file__).parents[1]/'repair/cloud-check-20261105/candidate/capacity.py'
        spec=importlib.util.spec_from_file_location('broad_observer._retained_capture_v2',retained)
        old_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(old_module)
        original_store=self.store
        old=old_module.CapacityController(self.config,self.store,self.factory,self.rest,
            clock=self.clock,monotonic=self.clock.mono,executor=fixture.InlineExecutor())
        self.controllers.append(old);self.first_minute(old)
        old_event=self.end_events()[0]
        old_raw=original_store.read_object(old_event['requests'][0]['body_object'])
        old_summary=original_store.read_summary({'normalized_object':old_event['normalized_object']})
        old.close()
        self.clock.value=self.t0;self.rest=fixture.Rest(self.clock);self.streams=[]
        self.store=BroadStore(Path(self.directory.name)/'research-bitmap-store',clock=self.clock)
        new=self.controller();self.first_minute(new);event=self.end_events()[0]
        summary=self.store.read_summary({'normalized_object':event['normalized_object']})
        self.assertEqual(self.store.read_object(event['requests'][0]['body_object']),old_raw)
        self.assertEqual(summary['schema'],'RESEARCH_CAPTURE_MINUTE_V2_BITMAP')
        self.assertEqual(summary['delta']['encoding'],'manifest_bits_v1')
        self.assertEqual(summary['delta']['bars'],[[0,'3','3']])
        self.assertEqual(summary['delta']['broad'],[[0,'3']])
        self.assertEqual(summary['delta']['detailed'],[[i,'1f'] for i in range(12)])
        decoded=capture.decode_delta(summary['delta'],new.symbols,new.details)
        for lane in decoded:
            key=lambda row:(row['index'],row['symbol'])
            self.assertEqual(sorted(decoded[lane],key=key),sorted(old_summary['delta'][lane],key=key))
        self.assertEqual(summary['http_attempts'],old_summary['http_attempts'])
        self.assertEqual(summary['notices'],old_summary['notices'])
        self.assertEqual(len(capture.read_closed_messages(self.store,event)),2)

    def test_bitmap_roundtrip_manifest_order_multiple_indices_and_mixed_ontime(self):
        primary=['X%03dUSDT'%i for i in range(130)][::-1]
        details=['BTCUSDT','ETHUSDT','GMXUSDT','SOLUSDT','ZECUSDT']
        delta={'bars':[{'symbol':primary[0],'index':50001,'ontime':False},
                        {'symbol':primary[-1],'index':50001,'ontime':True},
                        {'symbol':primary[7],'index':0,'ontime':False}],
            'broad':[{'symbol':primary[4],'index':50001},{'symbol':primary[129],'index':50000}],
            'detailed':[{'symbol':details[4],'index':604823},{'symbol':details[0],'index':0}]}
        encoded=capture.encode_delta(delta,primary,details)
        self.assertEqual(encoded['bars'][1],[50001,format(1|(1<<129),'x'),format(1<<129,'x')])
        decoded=capture.decode_delta(encoded,primary,details)
        for lane in delta:
            key=lambda row:(row['index'],row['symbol'])
            self.assertEqual(sorted(decoded[lane],key=key),sorted(delta[lane],key=key))
        self.assertEqual(capture.encode_delta(decoded,primary,details),encoded)

    def test_bitmap_rejects_unknown_bits_invalid_flags_and_duplicate_updates(self):
        import copy
        good=capture.encode_delta({'bars':[{'symbol':'BTCUSDT','index':0,'ontime':False}],
            'broad':[],'detailed':[]},self.config['primary_symbols'],self.config['detailed_symbols'])
        for changed in ([0,'1','2'],[0,'4','0'],[-1,'1','0'],[0,'01','0'],[True,'1','0']):
            bad=copy.deepcopy(good);bad['bars']=[changed]
            with self.subTest(row=changed),self.assertRaises(Exception):
                capture.decode_delta(bad,self.config['primary_symbols'],self.config['detailed_symbols'])
        duplicate={'bars':[{'symbol':'BTCUSDT','index':0,'ontime':False}]*2,'broad':[],'detailed':[]}
        with self.assertRaises(Exception):capture.encode_delta(duplicate,self.config['primary_symbols'],self.config['detailed_symbols'])

    def test_new_identity_cannot_claim_capacity_or_change_frozen_duration(self):
        for key,value in [('phase','CAPACITY48H'),('trial_id','capacity-old'),
                ('admission_end_at',iso(self.t0+dt.timedelta(days=31))),
                ('receipt_drain_end',iso(self.t0+dt.timedelta(days=35,seconds=121)))]:
            with self.subTest(key=key),self.assertRaises(ValueError):
                ops.validate_config(dict(self.config,**{key:value}))

    def test_same_lane_no_overlap_priority_and_missed_slot(self):
        held=fixture.HeldExecutor();first=self.controller(executor=held);first.step()
        self.assertEqual(set(first.futures),{'detailed'})
        with self.assertRaises(capture.OverlappingWorker):self.controller().start()
        self.clock.advance(5);first.step()
        self.assertEqual(first.buckets[0]['attempts']['detailed:1']['status'],'WAITING_BUSY')
        self.clock.advance(5);first.step()
        self.assertEqual(first.buckets[0]['attempts']['detailed:1']['status'],'MISSED_BUSY')
        self.assertEqual(len(held.tasks),1)

    def test_request_collection_stops_at_35day_plus_120(self):
        c=self.controller();c.start()
        self.clock.value=c.end-dt.timedelta(seconds=4);c._connect();c._schedule_current()
        before=len(self.rest.calls)
        self.clock.value=c.end;c._schedule_current()
        self.assertEqual(len(self.rest.calls),before)
        self.assertTrue(all(capture.timestamp(target)<c.end for _,target in self.rest.calls))

    def test_hour_quality_cache_waits_actual_maturity_and_late_delta_invalidates(self):
        c=self.controller();c.start();c.state['next_minute']=60
        self.clock.value=self.t0+dt.timedelta(hours=1,seconds=59)
        self.assertEqual(c.coverage()['complete_utc_hour_quality']['matured_utc_hours'],0)
        self.clock.advance(1)
        c._apply_delta({'bars':[{'symbol':'BTCUSDT','index':i,'ontime':True} for i in range(60)],'detailed':[],'broad':[]})
        q=c.coverage()['complete_utc_hour_quality']
        self.assertEqual(q['matured_utc_hours'],1)
        self.assertEqual(q['per_asset']['BTCUSDT']['all_60_on_time'],1)
        self.assertEqual(q['per_asset']['ETHUSDT']['all_60_on_time'],0)

    def test_full_month_130_asset_state_bounded_and_fast_count(self):
        self.config['primary_symbols']=['X%03dUSDT'%i for i in range(130)]
        c=self.controller();c.start();c.state['next_minute']=c.minutes
        self.clock.value=c.drain_end
        for name in ('bar_seen','bar_ontime','detail_valid','broad_valid'):
            for bits in getattr(c,name).values():bits[:]=b'\xff'*len(bits)
        start=time.perf_counter();coverage=c.coverage();elapsed=time.perf_counter()-start
        self.assertEqual(coverage['pooled_on_time_coverage'],1)
        self.assertEqual(coverage['expected_closed_total'],50402*130)
        c._save_state()
        self.assertLess(c.state_path.stat().st_size,5_000_000)
        self.assertLess(elapsed,2.0)
        c.close();restored=self.controller();restored.start()
        self.assertEqual(restored.coverage()['expected_closed_total'],50402*130)


# Rerun the applicable acquisition invariants against the NEW controller.
for name in (
    'test_late_closed_bar_never_repairs_on_time','test_pooled_99_does_not_hide_one_missing_asset',
    'test_duplicate_final_does_not_double_count','test_durable_start_precedes_http',
    'test_idle_poll_does_not_reserialize_or_rewrite_progress',
    'test_provider_block_is_persistent_and_stops_all_other_starts','test_operator_pause_prevents_connection_and_rest',
    'test_renewal_closes_old_connection_then_requires_new_closed_receipt','test_queue_overflow_is_visible_not_no_events',
    'test_crash_after_raw_commit_replays_delta_without_refetch','test_restart_retains_lost_inflight_attempt_as_unknown',
    'test_source_windows_reject_old_future_and_nonfinal','test_source_conflict_or_unknown_first_cannot_count_on_time',
    'test_cached_before_target_http_is_not_fresh','test_source_notice_binary_payload_survives_raw_container',
    'test_context_quotes_cannot_fill_broad_denominator_and_source_denial_is_local',
    'test_config_cannot_change_after_initialization','test_exact_unicode_exchange_identity_is_retained',
    'test_graceful_stop_drains_already_received_closed_queue','test_old_connection_stop_race_cannot_satisfy_renewal_receipt'):
    setattr(CaptureTests,name,getattr(fixture.CapacityTests,name))


class OperationsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.config=config()
        self.resources={'cpu_fraction':.05,'disk_free_bytes':20_000_000_000,'new_storage_bytes':1000000,
            'memory_current_bytes':80_000_000,'memory_peak_bytes':90_000_000,'oom_kills':0,
            'new_file_count':1000,'new_inode_count':1000,'free_inodes':2_000_000}

    def test_35day_allocated_storage_and_inode_caps_required(self):
        self.assertEqual(ops.assess_resources(self.config,self.resources)['status'],'OK')
        for key,value in [('new_storage_bytes',4_500_000_001),('new_file_count',800001),
                ('new_inode_count',800001),('free_inodes',104999),('cpu_fraction',.101),
                ('memory_peak_bytes',ops.MEMORY_LIMIT_BYTES+1),('oom_kills',1)]:
            with self.subTest(key=key):
                self.assertEqual(ops.assess_resources(self.config,dict(self.resources,**{key:value}))['status'],'FAILED')
        with self.assertRaises(ValueError):ops.validate_config(dict(self.config,full35day_gate_status='FAIL_PENDING_OPTIMIZATION'))
        with self.assertRaises(ValueError):ops.validate_config(dict(self.config,projected_35day_all_in_bytes=4_500_000_001))

    def test_unknown_cpu_does_not_zero_disk_observations(self):
        result=ops.assess_resources(self.config,dict(self.resources,cpu_fraction=None))
        self.assertEqual(result['status'],'PRELIMINARY')
        self.assertEqual(result['issues'],[])

    def test_scoped_bundle_backup_and_byte_restore_two_generations(self):
        store=BroadStore(self.root/'state');backup=self.root/'backup'
        store.append_batch('one','2026-11-05T08:00:00Z','OK',[{'body':b'first original bytes'}],{'n':1},kind='fixture')
        for name in ops.RESEARCH_CONTROL_NAMES[:3]:
            (store.root/name).write_bytes(canonical(self.config if name=='research.json' else {'frozen':name})+b'\n')
        ops.snapshot_research_controls(store.root,backup,self.config)
        ops.research_backup(store,backup,self.config)
        first=ops.scoped_git_backup(backup,self.config,publish=False)
        self.assertEqual(first['backup_format'],'KOD_RESEARCH_BUNDLES_V1')
        self.assertFalse((backup/'repository'/first['bundle']['bundle_path']).exists())
        store.append_batch('two','2026-11-05T08:01:00Z','OK',[{'body':b'second original bytes'}],{'n':2},kind='fixture')
        ops.research_backup(store,backup,self.config)
        second=ops.scoped_git_backup(backup,self.config,publish=False)
        self.assertNotEqual(first['commit'],second['commit'])
        restored=self.root/'restored-backup'
        proof=ops.restore_bundle_repository(backup/'repository',restored,self.config)
        self.assertTrue(proof['byte_identical']);self.assertEqual(proof['bundles_verified'],2)
        archive=self.root/'restored-archive'
        result=IncrementalBackup(restored).restore(archive)
        self.assertTrue(result)
        restored_store=BroadStore(archive)
        events=list(restored_store.iter_batches('2026-11-05'))
        self.assertEqual(len(events),2)
        self.assertEqual(restored_store.read_object(events[1]['requests'][0]['body_object']),b'second original bytes')
        # Repeating publication does not recapture the growing immutable archive.
        again=ops.scoped_git_backup(backup,self.config,publish=False)
        self.assertIsNone(again['bundle']);self.assertFalse(again['committed'])

    def test_retired_staging_dedup_and_index_rebuild_preserve_byte_restore(self):
        store=BroadStore(self.root/'state');backup=self.root/'backup'
        def append(label,body,minute):
            store.append_batch(label,f'2026-11-05T08:{minute:02d}:00Z','OK',[{'body':body}],{'label':label},kind='fixture')
            ops.research_backup(store,backup,self.config)
            return ops.scoped_git_backup(backup,self.config,publish=False)
        first=append('first',b'repeated raw evidence',0)
        repository=backup/'repository'
        self.assertEqual(list((repository/'objects').rglob('*[0-9a-f]')) and
            sum(p.is_file() for p in (repository/'objects').rglob('*')),0)
        second=append('second',b'new evidence',1)
        (repository/'BUNDLED_OBJECTS.sqlite').unlink()
        third=append('third',b'repeated raw evidence',2)
        first_raw={r['path'] for r in first['bundle']['files'] if r['path'].startswith('objects/')}
        third_raw={r['path'] for r in third['bundle']['files'] if r['path'].startswith('objects/')}
        self.assertFalse(first_raw & third_raw)
        recovered=self.root/'recovered';ops.restore_bundle_repository(repository,recovered,self.config)
        destination=self.root/'source-restore';IncrementalBackup(recovered).restore(destination)
        restored=BroadStore(destination);events=list(restored.iter_batches('2026-11-05'))
        self.assertEqual(len(events),3)
        self.assertEqual(restored.read_object(events[-1]['requests'][0]['body_object']),b'repeated raw evidence')

    def test_engine_exports_are_incremental_and_restorable_without_sqlite_generations(self):
        import gzip
        state=self.root/'state';state.mkdir();ledger=state/'engine'/'ledger';ledger.mkdir(parents=True)
        raw=gzip.compress(b'{"seq":1,"kind":"PROCESS_BOUNDARY"}\n',mtime=0)
        sha=hashlib.sha256(raw).hexdigest();name=f'ledger-0000000001-0000000001-{sha}.jsonl.gz'
        (ledger/name).write_bytes(raw)
        repository=self.root/'repository';repository.mkdir()
        first=ops.snapshot_engine_exports(state,repository,self.config)
        second=ops.snapshot_engine_exports(state,repository,self.config)
        self.assertEqual(first['new_chunks'],1);self.assertEqual(second['new_chunks'],0)
        self.assertFalse(first['sqlite_cache_generations_retained'])
        self.assertEqual((repository/'engine'/name).read_bytes(),raw)

    def test_actual_long_engine_export_name_survives_bundle_git_and_restore(self):
        import gzip
        store=BroadStore(self.root/'state');backup=self.root/'backup'
        ledger=store.root/'engine'/'ledger';ledger.mkdir(parents=True)
        raw=gzip.compress(b'{"seq":1,"kind":"RESEARCH_CHECKPOINT"}\n',mtime=0)
        sha=hashlib.sha256(raw).hexdigest();name=f'ledger-0000000001-0000000001-{sha}.jsonl.gz'
        self.assertGreater(len(name.encode()),100)
        (ledger/name).write_bytes(raw)
        store.append_batch('one','2026-11-05T08:00:00Z','OK',[],{'n':1},kind='fixture')
        ops.research_backup(store,backup,self.config)
        receipt=ops.scoped_git_backup(backup,self.config,publish=False)
        self.assertFalse((backup/'repository'/'engine'/name).exists())
        staging=self.root/'restored';ops.restore_bundle_repository(backup/'repository',staging,self.config)
        self.assertEqual((staging/'engine'/name).read_bytes(),raw)
        self.assertEqual((ledger/name).read_bytes(),raw)

    def test_only_explicit_transient_backup_transport_can_retry(self):
        self.assertEqual(ops.classify_backup_git_failure('ls-remote',b'ssh: Could not resolve hostname github.com'), 'TRANSIENT_NETWORK_TRANSPORT')
        self.assertEqual(ops.classify_backup_git_failure('push',b'Connection reset by peer'), 'TRANSIENT_NETWORK_TRANSPORT')
        self.assertEqual(ops.classify_backup_git_failure('push',b'Permission denied (publickey)'), 'ACCESS_OR_POLICY_DENIED')
        self.assertEqual(ops.classify_backup_git_failure('push',b'Host key verification failed'), 'ACCESS_OR_POLICY_DENIED')
        self.assertEqual(ops.classify_backup_git_failure('ls-remote',b'fatal: unknown failure'), 'UNKNOWN_OR_LOCAL_FAILURE')
        self.assertEqual(ops.classify_backup_git_failure('commit',b'Connection timed out'), 'UNKNOWN_OR_LOCAL_FAILURE')

    def test_storage_inventory_prunes_nested_roots_and_counts_hardlink_names(self):
        import os
        root=self.root/'storage';root.mkdir();child=root/'child';child.mkdir()
        (root/'payload').write_bytes(b'a'*5000)
        os.link(root/'payload',child/'same-inode')
        (child/'independent-copy').write_bytes(b'a'*5000)
        once=ops.unique_storage_bytes([root])
        repeated=ops.unique_storage_bytes([child,root,root])
        self.assertEqual(once,repeated)
        self.assertEqual(once['unique_files'],2);self.assertEqual(once['file_paths'],3)
        self.assertEqual(once['unique_logical_bytes'],10000)
        self.assertEqual(once['unique_directories'],2)

    def test_month_inode_identity_inventory_memory_is_bounded(self):
        import tracemalloc
        tracemalloc.start()
        identities={(1<<64)|n for n in range(200000)}
        _,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
        self.assertEqual(len(identities),200000)
        self.assertLess(peak,24*1024**2)

    def test_control_snapshot_restores_original_exact_bytes(self):
        state=self.root/'state';state.mkdir();backup=self.root/'backup'
        for name in ops.RESEARCH_CONTROL_NAMES[:3]:
            (state/name).write_bytes(canonical(self.config if name=='research.json' else {'name':name})+b'\n')
        ops.snapshot_research_controls(state,backup,self.config)
        dest=self.root/'controls'
        result=ops.restore_research_controls(backup,dest,self.config)
        self.assertTrue(result['byte_identical'])
        self.assertEqual((dest/'research.json').read_bytes(),(state/'research.json').read_bytes())

if __name__=='__main__':unittest.main()
