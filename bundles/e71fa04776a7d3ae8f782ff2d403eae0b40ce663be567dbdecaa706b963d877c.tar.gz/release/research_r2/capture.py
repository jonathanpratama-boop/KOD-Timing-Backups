"""Finite research acquisition controller. The research engine owns decisions and entries.

One worker owns the job lock, a bounded WebSocket reader and at most two REST
futures. A durable minute begin and bounded in-flight progress precede requests;
all completed raw attempts and closed messages share one minute-end batch.
"""
from __future__ import annotations

import base64
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile
import threading
import time

from broad_observer.store import canonical, digest, iso, timestamp, UTC, IntegrityError

MINUTE = dt.timedelta(minutes=1)
BAR_GRACE = dt.timedelta(seconds=60)
MAX_PRIMARY = 150
MAX_PENDING_WS_BYTES = 8 * 1024 * 1024
MAX_WS_PER_BUCKET = 600
MAX_HTTP_ATTEMPTS_PER_MINUTE = 64
TERMINAL = {'COMPLETE', 'PAUSED', 'PROVIDER_STOPPED', 'FAILED'}
WS_MAP_KEYS = {'symbol', 'open_at', 'close_at', 'source_event_at', 'source_event_ms',
    'received_at', 'received_monotonic', 'first_received_at', 'current_value_received_at',
    'first_authoritative_received_at', 'first_authoritative_bar_sha256', 'source_conflict',
    'clock_anomaly', 'local_receipt_before_source_close', 'old_bar_first_receipt_unknown',
    'availability_status', 'duplicate_final', 'on_time_first_receipt', 'bar_index',
    'in_trial_window', 'first_retained', 'on_time_first_retained', 'classification'}


def _compact_ws_record(value):
    # OHLCV/trades/taker fields remain exact in the original message bytes. Local
    # receipt clocks and first-authority/quality flags cannot be reconstructed and
    # therefore remain authoritative archival metadata.
    return {key: child for key, child in value.items() if key in WS_MAP_KEYS or isinstance(child, bool)}


def read_closed_messages(store, receipt):
    """Rebuild closed source fields from exact archived messages and compact map."""
    from broad_observer.packets import unpack_attempts
    references = receipt.get('raw_objects')
    if references is None:
        references = [request['body_object'] for request in receipt.get('requests', []) if 'body_object' in request]
    result = []
    for reference in references:
        for member in unpack_attempts(store.read_object(reference)):
            if 'closed_message_map' not in member: continue
            body = member['body']
            for entry in member['closed_message_map']:
                offset, length = entry['raw_offset'], entry['raw_length']
                if not isinstance(offset, int) or not isinstance(length, int) or offset < 0 or length < 0 or offset+length > len(body):
                    raise IntegrityError('closed-message offset outside immutable member')
                raw = body[offset:offset+length]
                source = json.loads(raw)
                data = source.get('data', source)
                candle = data.get('k', {})
                if data.get('s') != entry['symbol'] or candle.get('x') is not True:
                    raise IntegrityError('closed-message source identity/flag differs from archival map')
                rebuilt = dict(entry, raw=raw, source=source,
                    open=candle.get('o'), high=candle.get('h'), low=candle.get('l'), close=candle.get('c'),
                    base_volume=candle.get('v'), quote_volume=candle.get('q'), trades=candle.get('n'),
                    taker_buy_base_volume=candle.get('V'), taker_buy_quote_volume=candle.get('Q'))
                result.append(rebuilt)
    return result


class OverlappingWorker(RuntimeError):
    pass


def _atomic(path, value):
    value = dict(value)
    value.pop('hash', None)
    value['hash'] = digest(canonical(value))
    descriptor, temporary = tempfile.mkstemp(prefix='.capacity-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(canonical(value)+b'\n')
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, path)
        fd = os.open(path.parent, os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    finally:
        if os.path.exists(temporary): os.unlink(temporary)


def _read(path):
    value = json.loads(path.read_bytes())
    unsigned = {key: child for key, child in value.items() if key != 'hash'}
    if value.get('hash') != digest(canonical(unsigned)):
        raise IntegrityError('capacity state/progress hash differs')
    return unsigned


def _bits(size): return bytearray((size+7)//8)
def _has(bits, index): return bool(bits[index//8] & (1 << (index % 8)))
def _set(bits, index): bits[index//8] |= 1 << (index % 8)
def _count(bits, size):
    whole, remainder = divmod(size, 8)
    return int.from_bytes(bits[:whole], 'little').bit_count() + ((bits[whole] & ((1 << remainder)-1)).bit_count() if remainder else 0)


DELTA_ENCODING = 'manifest_bits_v1'


def _delta_manifests(primary_symbols, detailed_symbols):
    primary, detailed = tuple(primary_symbols), tuple(detailed_symbols)
    if (not primary or len(primary)>MAX_PRIMARY or len(primary)!=len(set(primary))
            or len(detailed)!=5 or len(detailed)!=len(set(detailed))):
        raise IntegrityError('delta requires the exact unique frozen primary/detail order')
    return {'bars':primary,'broad':primary,'detailed':detailed}


def encode_delta(delta, primary_symbols, detailed_symbols):
    """Lossless coverage-set encoding; the enclosing config_hash binds order.

    Original source message ordering is retained in raw PACK bytes, not these
    derived bitset updates. Each lane groups its unique symbol/index updates;
    bars keep distinct seen and on-time masks. No observation is added/dropped.
    """
    manifests=_delta_manifests(primary_symbols,detailed_symbols)
    if set(delta)!=set(manifests):raise IntegrityError('unexpected coverage delta keys')
    result={'encoding':DELTA_ENCODING}
    for lane,symbols in manifests.items():
        positions={symbol:position for position,symbol in enumerate(symbols)}
        groups={}
        for item in delta[lane]:
            keys={'symbol','index','ontime'} if lane=='bars' else {'symbol','index'}
            if not isinstance(item,dict) or set(item)!=keys:raise IntegrityError('unexpected coverage delta fields')
            index=item['index'];symbol=item['symbol']
            if not isinstance(index,int) or isinstance(index,bool) or index<0 or symbol not in positions:
                raise IntegrityError('invalid coverage index or foreign manifest symbol')
            if lane=='bars' and not isinstance(item['ontime'],bool):raise IntegrityError('on-time flag must be boolean')
            bit=1<<positions[symbol]
            masks=groups.setdefault(index,[0,0] if lane=='bars' else [0])
            if masks[0]&bit:raise IntegrityError('duplicate symbol/index coverage update')
            masks[0]|=bit
            if lane=='bars' and item['ontime']:masks[1]|=bit
        result[lane]=[[index,*[format(mask,'x') for mask in masks]] for index,masks in sorted(groups.items())]
    return result


def decode_delta(delta, primary_symbols, detailed_symbols):
    """Decode new masks; retain compatibility with prior unlaunched summaries."""
    manifests=_delta_manifests(primary_symbols,detailed_symbols)
    if 'encoding' not in delta:
        # Canonical roundtrip validates older derived deltas without changing raw evidence.
        return decode_delta(encode_delta(delta,primary_symbols,detailed_symbols),primary_symbols,detailed_symbols)
    if delta.get('encoding')!=DELTA_ENCODING or set(delta)!=set(manifests)|{'encoding'}:
        raise IntegrityError('unknown coverage delta encoding')
    result={lane:[] for lane in manifests}
    for lane,symbols in manifests.items():
        prior=-1
        for row in delta[lane]:
            if not isinstance(row,list) or len(row)!=(3 if lane=='bars' else 2):
                raise IntegrityError('malformed coverage bitmask row')
            index=row[0]
            if not isinstance(index,int) or isinstance(index,bool) or index<=prior:
                raise IntegrityError('coverage bitmask indices must be unique increasing nonnegative integers')
            prior=index;masks=[]
            for encoded in row[1:]:
                if (not isinstance(encoded,str) or not encoded or len(encoded)>(len(symbols)+3)//4
                        or not re.fullmatch('0|[1-9a-f][0-9a-f]*',encoded)):
                    raise IntegrityError('coverage mask must be canonical bounded hexadecimal')
                mask=int(encoded,16)
                if mask.bit_length()>len(symbols):raise IntegrityError('coverage mask outside frozen manifest')
                masks.append(mask)
            if not masks[0] or lane=='bars' and masks[1]&~masks[0]:
                raise IntegrityError('empty coverage group or on-time mask outside seen mask')
            for position,symbol in enumerate(symbols):
                if masks[0]&(1<<position):
                    item={'symbol':symbol,'index':index}
                    if lane=='bars':item['ontime']=bool(masks[1]&(1<<position))
                    result[lane].append(item)
    return result


class ResearchCaptureController:
    def __init__(self, config, store, stream_factory, rest, *, clock=None,
                 monotonic=time.monotonic, sleeper=time.sleep, executor=None, packet_packer=None):
        self.config = json.loads(canonical(config))
        self.store, self.root = store, store.root
        self.clock = clock or (lambda: dt.datetime.now(UTC))
        self.monotonic, self.sleeper = monotonic, sleeper
        self.stream_factory, self.rest = stream_factory, rest
        self.packet_packer = packet_packer
        self.t0 = timestamp(config['t0'])
        if self.t0.second or self.t0.microsecond:
            raise ValueError('capacity T0 must be a whole UTC minute')
        from .capture_ops import validate_config
        limits = validate_config(config)
        self.admission_end = limits['admission_end']
        self.study_end = limits['end']
        self.end = limits['drain_end']  # request collection includes endpoint tolerance
        self.drain_end = limits['finalization_end']  # write-only final closed-bar settlement
        self.checkpoint_at = self.t0+dt.timedelta(hours=24)+BAR_GRACE
        self.symbols = tuple(config['primary_symbols'])
        self.details = tuple(config['detailed_symbols'])
        if (not 0 < len(self.symbols) <= MAX_PRIMARY or len(set(self.symbols)) != len(self.symbols)
                or len(self.details) != 5 or len(set(self.details)) != 5
                or any(not isinstance(symbol, str) or not 1 <= len(symbol) <= 40 or not symbol.isalnum()
                       or symbol != symbol.upper() or not symbol.endswith('USDT') for symbol in self.symbols+self.details)):
            raise ValueError('fixed <=150 primary and exactly five detailed spot symbols required')
        if not re.fullmatch('[0-9a-f]{64}', config.get('selection_manifest_sha256', '')):
            raise ValueError('predeclared selection manifest hash required')
        self.config_hash = digest(canonical(config))
        self.minutes = int((self.end-self.t0).total_seconds()//60)
        self.detail_slots = self.minutes*12
        self.state_path = self.root/'RESEARCH_CAPTURE_STATE.json'
        self.heartbeat_path = self.root/'RESEARCH_CAPTURE_HEARTBEAT.json'
        self.progress_path = self.root/'RESEARCH_CAPTURE_INFLIGHT.json'
        self.pause_path, self.provider_path = self.root/'PAUSED.json', self.root/'PROVIDER_STOP.json'
        self.lock_path = self.root/'research-capture-job.lock'
        self.lock_fd = None
        self.executor = executor
        self._owns_executor = executor is None
        self.stream, self.futures, self.buckets = None, {}, {}
        self.progress = {'schema': 'RESEARCH_CAPTURE_INFLIGHT_V1', 'config_hash': self.config_hash, 'minutes': {}}
        self.state = None
        self.bar_seen = {symbol: _bits(self.minutes) for symbol in self.symbols}
        self.bar_ontime = {symbol: _bits(self.minutes) for symbol in self.symbols}
        self.detail_valid = {symbol: _bits(self.detail_slots) for symbol in self.details}
        self.broad_valid = {symbol: _bits(self.minutes) for symbol in self.symbols}
        self._pending_seen = set()
        self._last_heartbeat_mono = -math.inf
        self._stream_notices = []
        self._closing_lock = threading.RLock()
        self._closing = False
        self._initialized = False
        self._heartbeat_cache = None
        self.stop_event = threading.Event()
        self._last_progress_hash = None
        self.progress_atomic_writes = 0
        self._quality_cache = None
        self._quality_generation = 0

    def now(self): return timestamp(self.clock())

    def _save_state(self):
        for name in ('bar_seen', 'bar_ontime', 'detail_valid', 'broad_valid'):
            self.state[name] = {symbol: base64.b64encode(bits).decode() for symbol, bits in getattr(self, name).items()}
        _atomic(self.state_path, self.state)

    def _save_progress(self):
        current_hash = digest(canonical(self.progress))
        if current_hash != self._last_progress_hash:
            _atomic(self.progress_path, self.progress)
            self._last_progress_hash = current_hash
            self.progress_atomic_writes += 1

    def _load_state(self):
        if self.state_path.exists():
            self.state = _read(self.state_path)
            if self.state['config_hash'] != self.config_hash:
                raise IntegrityError('capacity configuration cannot change after initialization')
            for name in ('bar_seen', 'bar_ontime', 'detail_valid', 'broad_valid'):
                expected = getattr(self, name)
                encoded = self.state.get(name, {})
                if set(encoded) != set(expected): raise IntegrityError('capacity bitset membership differs')
                for symbol, bits in expected.items():
                    restored = base64.b64decode(encoded[symbol], validate=True)
                    if len(restored) != len(bits): raise IntegrityError('capacity bitset length differs')
                    expected[symbol] = bytearray(restored)
        else:
            self.state = {'schema': 'RESEARCH_CAPTURE_STATE_V1', 'config_hash': self.config_hash,
                'trial_id': self.config['trial_id'], 'phase': 'WAITING', 'next_minute': 0,
                'last_minute_commit_at': None, 'journal_cursor': {}, 'reconnects': 0,
                'renewals_started': 0, 'renewals_completed': 0, 'awaiting_renewal_receipt': False,
                'next_reconnect_at': None, 'connection_attempts': 0, 'queue_overflows': 0,
                'notices': {}, 'checkpoint_24h': None, 'started_at': None,
                'detail_attempts_completed': 0, 'broad_attempts_completed': 0}
            self._save_state()
        if self.progress_path.exists():
            self.progress = _read(self.progress_path)
            if self.progress['config_hash'] != self.config_hash:
                raise IntegrityError('capacity in-flight identity differs')
            self._last_progress_hash = digest(canonical(self.progress))
        self._replay_committed()

    def _replay_committed(self):
        # At most 36 bounded UTC-day cursors are inspected; only unseen committed batches replay.
        days = {self.now().date()}
        day = self.t0.date()
        while day <= min(self.now(), self.drain_end).date():
            days.add(day); day += dt.timedelta(days=1)
        for day in sorted(days):
            name = day.isoformat()
            after = self.state['journal_cursor'].get(name, -1)+1
            for event in self.store.iter_batches(name, after_seq=after, limit=10000):
                if event['kind'] in ('capacity_minute_end', 'capacity_diagnostic'):
                    summary = self.store.read_summary({'normalized_object': event['normalized_object']})
                    if summary.get('config_hash') != self.config_hash: raise IntegrityError('foreign capacity batch')
                    self._apply_delta(summary['delta'])
                    if event['kind'] == 'capacity_minute_end':
                        self.state['next_minute'] = max(self.state['next_minute'], summary['minute_index']+1)
                        self.state['last_minute_commit_at'] = event['recorded_at']
                    else:
                        self.state['diagnostic_sequence'] = max(self.state.get('diagnostic_sequence', 0), summary['diagnostic_sequence']+1)
                self.state['journal_cursor'][name] = event['seq']
        self._save_state()

    def start(self):
        if self._closing: raise RuntimeError('closed controller instances cannot restart; construct a new finite worker')
        if self.lock_fd is not None: return self.heartbeat()
        descriptor = os.open(self.lock_path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            os.close(descriptor)
            raise OverlappingWorker('another capacity worker owns the complete job') from exc
        self.lock_fd = descriptor
        try:
            self._load_state()
            self._initialized = True
            if self.executor is None: self.executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix='capacity-http')
            if self.provider_path.exists(): self.state['phase'] = 'PROVIDER_STOPPED'
            elif self.pause_path.exists(): self.state['phase'] = 'PAUSED'
            if self.state['phase'] not in TERMINAL and self.now() >= self.t0:
                self.state['started_at'] = self.state['started_at'] or iso(self.now())
            self._save_state()
            return self.heartbeat(force=True)
        except BaseException:
            self.close()
            raise

    def _minute_at(self, index): return self.t0+index*MINUTE
    def _deadline(self, index): return self._minute_at(index)+2*MINUTE-dt.timedelta(milliseconds=1)
    def _minute_index(self, value): return int((timestamp(value)-self.t0).total_seconds()//60)

    def _bucket(self, index):
        if index in self.buckets: return self.buckets[index]
        if not 0 <= index < self.minutes: raise ValueError('minute outside capacity admissions')
        target = self._minute_at(index)
        prior = self.progress['minutes'].get(str(index))
        bucket = {'minute_index': index, 'target_at': iso(target), 'ws': [], 'ws_bytes': 0,
                  'raw_http': [], 'attempts': {}, 'notices': [], 'recovered': prior is not None}
        if prior:
            for key, attempt in prior.get('attempts', {}).items():
                bucket['attempts'][key] = dict(attempt, status='LOST_RECEIPT_OR_UNCERTAIN_AFTER_RESTART',
                    previous_status=attempt.get('status'), raw_unavailable=True)
        else:
            receipt = self.store.append_batch('capacity:'+self.config['trial_id']+':begin:'+iso(target),
                self.now(), 'BEGIN', [], {'schema': 'RESEARCH_CAPTURE_BEGIN_V2_SHARED_CONTENT', 'config_hash': self.config_hash,
                    'expected_closed_symbol_count': len(self.symbols), 'expected_detail_slots': 12,
                    'expected_broad_batches': 1,
                    'fixed_membership_location': 'config_hash binds the predeclared primary/detail symbol lists',
                    'target_clock_location': 'immutable batch_id suffix after :begin:',
                    'actual_begin_clock_location': 'signed journal recorded_at, before HTTP submit',
                    'crash_before_end_means_mid_request_outcomes_uncertain': True}, kind='capacity_minute_begin')
            self.state['journal_cursor'][receipt['day']] = receipt['seq']
        self.buckets[index] = bucket
        self.progress['minutes'][str(index)] = {'target_at': iso(target), 'attempts': bucket['attempts']}
        self._save_progress()
        return bucket

    def _notice(self, notice):
        self._heartbeat_cache = None
        kind = str(notice.get('kind', notice.get('type', 'UNKNOWN')))
        self.state['notices'][kind] = self.state['notices'].get(kind, 0)+1
        if 'overflow' in kind.lower(): self.state['queue_overflows'] += int(notice.get('count', 1))
        if self.state['next_minute'] >= self.minutes:
            raw = [dict(transport='websocket-terminal-notice', body=value, received_at=notice.get('received_at', iso(self.now())))
                   for value in notice.values() if isinstance(value, bytes)]
            self._append_diagnostic(raw, {'bars': [], 'detailed': [], 'broad': []}, 'notice after final minute',
                                    {'notice': {key: value for key, value in notice.items() if not isinstance(value, bytes)}})
            return
        index = min(self.minutes-1, max(self.state['next_minute'], self._minute_index(self.now())))
        if index < self.minutes and self.now() >= self.t0:
            bucket = self._bucket(index)
            plain = {key: value for key, value in notice.items() if not isinstance(value, bytes)}
            for key, raw in notice.items():
                if isinstance(raw, bytes):
                    plain[key+'_sha256'] = digest(raw)
                    bucket['raw_http'].append({'transport': 'websocket-notice', 'body': raw,
                        'status': kind, 'received_at': notice.get('received_at', iso(self.now()))})
            bucket['notices'].append(plain)

    def _provider_stop(self, reason, exception=None):
        self.stop_event.set()
        value = {'schema': 'RESEARCH_CAPTURE_PROVIDER_STOP_V1', 'trial_id': self.config['trial_id'],
                 'stopped_at': iso(self.now()), 'reason': str(reason), 'automatic_retry': False}
        _atomic(self.provider_path, value)
        self.state['phase'] = 'PROVIDER_STOPPED'
        if exception is not None and isinstance(getattr(exception, 'raw_handshake', None), bytes):
            if self.state['next_minute'] >= self.minutes:
                self._append_diagnostic([{'body': exception.raw_handshake, 'transport': 'websocket-handshake',
                    'status': 'PROVIDER_BLOCKED', 'received_at': iso(self.now())}], {'bars': [], 'detailed': [], 'broad': []}, 'terminal provider response')
                return
            index = min(self.minutes-1, max(self.state['next_minute'], self._minute_index(self.now())))
            self._bucket(index)['raw_http'].append({'body': exception.raw_handshake, 'transport': 'websocket-handshake',
                'status': 'PROVIDER_BLOCKED', 'request_started_at': iso(self.now()), 'received_at': iso(self.now())})
        self._save_state()

    def _connect(self):
        now = self.now()
        if now >= self.end or self.stop_event.is_set() or self.provider_path.exists() or self.pause_path.exists(): return
        if self.state['next_reconnect_at'] and now < timestamp(self.state['next_reconnect_at']): return
        self._bucket(min(self.minutes-1, max(self.state['next_minute'], self._minute_index(now))))
        self.state['connection_attempts'] += 1
        self._save_state()
        try:
            stream = self.stream_factory(self.symbols)
            stream.start()
            self.stream = stream
            self.state['next_reconnect_at'] = None
            self.state['reconnects'] += int(self.state['connection_attempts'] > 1)
        except Exception as exc:
            if getattr(exc, 'provider_blocked', False): self._provider_stop('WebSocket provider block', exc)
            else:
                delay = min(30, 2**min(self.state['connection_attempts']-1, 5))
                self.state['next_reconnect_at'] = iso(now+dt.timedelta(seconds=delay))
                self._notice({'kind': 'connection_failed', 'at': iso(now), 'error': type(exc).__name__, 'retry_delay_seconds': delay})
            self._save_state()

    def _drain_stream(self):
        if self.stream is None: return
        for notice in self.stream.drain_events(max_items=512): self._notice(notice)
        for envelope in self.stream.drain(max_items=300):
            self._accept_bar(envelope)
        health = self.stream.poll()
        self.state['last_stream_health'] = health
        if health.get('provider_blocked'):
            self._provider_stop('WebSocket runtime provider block')
        disconnected = health.get('state') in ('DISCONNECTED', 'disconnected', 'FAILED', 'failed', 'STOPPED', 'stopped') or health.get('disconnected') is True
        renewal = bool(health.get('renewal_due'))
        if disconnected or renewal:
            if renewal:
                self.state['renewals_started'] += 1
                self.state['awaiting_renewal_receipt'] = True
                self.state['renewal_required_connection_attempt'] = self.state['connection_attempts']+1
            self._notice({'kind': 'renewal_due' if renewal else 'stream_disconnected', 'at': iso(self.now()), 'health': health})
            self.close_sources()
            if not renewal: self.state['next_reconnect_at'] = iso(self.now()+dt.timedelta(seconds=1))
            self._save_state()

    def _accept_bar(self, envelope):
        raw = envelope.get('raw', envelope.get('rawbytes'))
        if not isinstance(raw, bytes):
            self._notice({'kind': 'malformed_stream_envelope', 'at': iso(self.now())}); return
        if self.state['next_minute'] >= self.minutes:
            self._append_diagnostic([dict({key: value for key, value in envelope.items() if key not in ('raw', 'rawbytes')},
                body=raw, transport='websocket-after-final-window')], {'bars': [], 'detailed': [], 'broad': []}, 'closed message after final minute')
            return
        receipt = timestamp(envelope['received_at'])
        index = self._minute_index(envelope['open_at'])
        symbol = envelope.get('symbol')
        expected_open = self._minute_at(index)
        expected_close = expected_open+MINUTE-dt.timedelta(milliseconds=1)
        in_window = (symbol in self.bar_seen and 0 <= index < self.minutes and envelope.get('closed') is True
                     and timestamp(envelope['open_at']) == expected_open
                     and timestamp(envelope['close_at']) == expected_close and receipt <= self.drain_end)
        already = in_window and (_has(self.bar_seen[symbol], index) or (symbol, index) in self._pending_seen)
        source_unknown = any(envelope.get(key) is True for key in ('source_conflict', 'clock_anomaly',
            'local_receipt_before_source_close', 'old_bar_first_receipt_unknown'))
        ontime = in_window and not already and not source_unknown and expected_close <= receipt <= expected_close+BAR_GRACE
        target_bucket = index if in_window and index >= self.state['next_minute'] else min(self.minutes-1, max(self.state['next_minute'], self._minute_index(receipt)))
        if target_bucket >= self.minutes: return
        bucket = self._bucket(target_bucket)
        if (len(bucket['ws']) >= MAX_WS_PER_BUCKET or
                sum(item['ws_bytes'] for item in self.buckets.values())+len(raw) > MAX_PENDING_WS_BYTES):
            self.state['queue_overflows'] += 1
            bucket['notices'].append({'kind': 'controller_ws_overflow', 'received_at': iso(receipt), 'dropped_bytes': len(raw)})
            return
        record = {key: value for key, value in envelope.items() if key not in ('raw', 'rawbytes')}
        record.update(raw=raw, bar_index=index, in_trial_window=in_window, first_retained=bool(in_window and not already),
                      on_time_first_retained=bool(ontime), classification='DUPLICATE' if already else 'ON_TIME' if ontime else 'LATE' if in_window else 'OUTSIDE_OR_INVALID_WINDOW')
        bucket['ws'].append(record); bucket['ws_bytes'] += len(raw)
        if in_window and not already:
            self._pending_seen.add((symbol, index))
            if (self.state['awaiting_renewal_receipt'] and ontime
                    and self.state['connection_attempts'] >= self.state.get('renewal_required_connection_attempt', self.state['connection_attempts']+1)):
                self.state['renewals_completed'] += 1
                self.state['awaiting_renewal_receipt'] = False
                self.state['first_post_renewal_closed_received_at'] = iso(receipt)

    def _submit(self, kind, index, slot, target):
        bucket = self._bucket(index)
        key = kind+':'+str(slot)
        attempt = bucket['attempts'].get(key)
        if attempt is not None and attempt['status'] != 'WAITING_BUSY': return
        if kind in self.futures or len(self.futures) >= 2:
            # Keep the SAME scheduled target eligible until its original window
            # closes. One busy poll is not a permanent miss; no overlap/backfill.
            if attempt is None:
                bucket['attempts'][key] = {'kind': kind, 'slot': slot, 'target_at': iso(target),
                    'status': 'WAITING_BUSY', 'first_busy_at': iso(self.now())}
                self._save_progress()
            return
        if attempt is None:
            attempt = {'kind': kind, 'slot': slot, 'target_at': iso(target)}
            bucket['attempts'][key] = attempt
        attempt.update(status='STARTED', started_at=iso(self.now()))
        self._save_progress()  # durable BEFORE submit/actual network work
        # Persistence may block: use the actual clock before the network submit.
        if self.now() >= self.end or (kind == 'detailed' and self.now() >= target+dt.timedelta(seconds=5)):
            attempt.update(status='MISSED', finished_at=iso(self.now()), reason='durable start exceeded original request window; no request sent')
            self._save_progress(); return
        if self.stop_event.is_set() or self.pause_path.exists() or self.provider_path.exists():
            attempt.update(status='CANCELLED_BEFORE_EXECUTION', finished_at=iso(self.now()))
            self._save_progress(); return
        callback = getattr(self.rest, kind)
        symbols = self.details if kind == 'detailed' else self.symbols
        kwargs = {'target_at': iso(target)}
        if kind in ('detailed', 'broad', 'stats'): kwargs['symbols'] = symbols
        future = self.executor.submit(callback, **kwargs)
        self.futures[kind] = {'future': future, 'index': index, 'key': key}

    def _collect_futures(self):
        for kind, pending in list(self.futures.items()):
            future = pending['future']
            if not future.done(): continue
            late = pending['index'] < self.state['next_minute']
            destination = min(self.minutes-1, max(self.state['next_minute'], self._minute_index(self.now()))) if late else pending['index']
            if destination < self.state['next_minute']:
                try:
                    result = future.result()
                    if not isinstance(result, dict): raise ValueError('late REST envelope required')
                except Exception as exc:
                    result = {'status': 'FAILED', 'raw_http': [], 'error': type(exc).__name__+': '+str(exc)[:160]}
                self._append_diagnostic(result.get('raw_http', []), {'bars': [], 'detailed': [], 'broad': []},
                    'completed REST response after final minute', {'kind': kind, 'original_minute_index': pending['index'],
                    'attempt_key': pending['key'], 'status': result.get('status'), 'error': result.get('error')})
                self.state['notices']['response_after_final_commit'] = self.state['notices'].get('response_after_final_commit', 0)+1
                del self.futures[kind]
                continue
            bucket = self._bucket(destination)
            if late:
                bucket['attempts'][pending['key']+':late:'+str(pending['index'])] = {'kind': kind, 'slot': 0,
                    'target_at': iso(self._minute_at(pending['index'])), 'status': 'LATE_AFTER_WINDOW', 'original_minute_index': pending['index']}
                pending['key'] += ':late:'+str(pending['index'])
            attempt = bucket['attempts'][pending['key']]
            try:
                result = future.result()
                if not isinstance(result, dict): raise ValueError('REST envelope required')
            except Exception as exc:
                if getattr(exc, 'provider_blocked', False):
                    if kind == 'catalyst':
                        self._notice({'kind': 'catalyst_provider_blocked', 'at': iso(self.now()), 'source_status': 'NOT_COVERED'})
                    else: self._provider_stop('REST provider block', exc)
                result = {'status': 'FAILED', 'raw_http': [], 'summary': None, 'error': type(exc).__name__+': '+str(exc)[:160]}
            attempt.update(status=result.get('status', 'FAILED'), finished_at=iso(self.now()),
                           result_summary=result.get('summary'), error=result.get('error'))
            raw = result.get('raw_http', [])
            if len(bucket['raw_http'])+len(raw) > MAX_HTTP_ATTEMPTS_PER_MINUTE:
                self._provider_stop('minute raw attempt bound exceeded')
                attempt.update(status='RAW_ATTEMPT_CAP', raw_unavailable=True)
            else:
                for item in raw:
                    bucket['raw_http'].append(dict(item, capacity_lane=kind, target_at=attempt['target_at']))
            denied = result.get('requires_operator_review') or any(item.get('http_status') in (403, 418, 429, 451) for item in raw)
            if denied and kind != 'catalyst':
                self._provider_stop('REST provider policy/rate block')
            elif denied:
                self._notice({'kind': 'catalyst_provider_denial', 'at': iso(self.now()), 'source_status': 'NOT_COVERED'})
            attempt['receipt_at'] = max((item.get('received_at') for item in raw if item.get('received_at')), default=attempt['finished_at'])
            attempt['request_started_at'] = min((item.get('request_started_at') for item in raw if item.get('request_started_at')), default=None)
            latency = (timestamp(attempt['receipt_at'])-timestamp(attempt['target_at'])).total_seconds()
            attempt['target_to_receipt_seconds'] = latency
            sources = self.state.setdefault('source_attempt_counts', {})
            for item in raw or [{'source_id': kind, 'status': result.get('status', 'FAILED')}]:
                source = item.get('source_id', kind)
                statuses = sources.setdefault(source, {})
                status = item.get('status', 'UNKNOWN')
                statuses[status] = statuses.get(status, 0)+1
            if kind == 'catalyst' and isinstance(result.get('summary'), dict):
                self.state['latest_registered_feed_coverage'] = result['summary'].get('source_feed_quality', result['summary'].get('feed_coverage', result['summary'].get('coverage', {})))
            stats = self.state.setdefault('latency_by_lane', {}).setdefault(kind, {'count': 0, 'sum_seconds': 0, 'minimum_seconds': None, 'maximum_seconds': None})
            if math.isfinite(latency):
                stats['count'] += 1; stats['sum_seconds'] += latency
                stats['minimum_seconds'] = latency if stats['minimum_seconds'] is None else min(stats['minimum_seconds'], latency)
                stats['maximum_seconds'] = latency if stats['maximum_seconds'] is None else max(stats['maximum_seconds'], latency)
            self.state[kind+'_attempts_completed'] = self.state.get(kind+'_attempts_completed', 0)+1
            del self.futures[kind]
            self._save_progress()

    def _schedule_current(self):
        # Reap work completed during drain/commit/fsync before testing busy lanes.
        self._collect_futures()
        now = self.now()
        # Finalize deferred targets even after a minute rollover or at trial end.
        # The last slot must not remain WAITING forever in a completed minute.
        expired = False
        for pending_bucket in self.buckets.values():
            for attempt in pending_bucket['attempts'].values():
                if (attempt.get('kind') == 'detailed' and attempt.get('status') == 'WAITING_BUSY'
                        and now >= timestamp(attempt['target_at'])+dt.timedelta(seconds=5)):
                    attempt.update(status='MISSED_BUSY', finished_at=iso(now), reason='lane unavailable through original slot window; not backfilled')
                    expired = True
        if expired: self._save_progress()
        if self.stop_event.is_set() or not self.t0 <= now < self.end: return
        index = self._minute_index(now)
        bucket = self._bucket(index)
        missing_changed = False
        elapsed = (now-self._minute_at(index)).total_seconds()
        for slot in range(int(elapsed//5)+1):
            key = 'detailed:'+str(slot)
            prior = bucket['attempts'].get(key)
            if prior is not None and prior['status'] != 'WAITING_BUSY': continue
            target = self._minute_at(index)+dt.timedelta(seconds=slot*5)
            if now-target >= dt.timedelta(seconds=5):
                if prior is not None:
                    prior.update(status='MISSED_BUSY', finished_at=iso(now), reason='lane unavailable through original slot window; not backfilled')
                else:
                    bucket['attempts'][key] = {'kind': 'detailed', 'slot': slot, 'target_at': iso(target), 'status': 'MISSED', 'reason': 'not backfilled'}
                missing_changed = True
            else: self._submit('detailed', index, slot, target)
        # Observe a just-completed first detail (and any provider stop) before
        # deciding whether the lower-priority broad lane may begin.
        self._collect_futures()
        # Reaping/persistence may cross the original minute. Never use the old
        # elapsed clock to admit a lower-priority request into an expired slot.
        now = self.now()
        if now >= min(self._minute_at(index)+MINUTE, self.end):
            if missing_changed: self._save_progress()
            return
        elapsed = (now-self._minute_at(index)).total_seconds()
        first_detail_pending = bucket['attempts'].get('detailed:0', {}).get('status') in (None, 'STARTED', 'WAITING_BUSY')
        if 'broad:0' not in bucket['attempts']:
            if elapsed >= 60:
                bucket['attempts']['broad:0'] = {'kind': 'broad', 'slot': 0, 'target_at': iso(self._minute_at(index)), 'status': 'MISSED'}
                missing_changed = True
            elif not first_detail_pending and not any(kind != 'detailed' for kind in self.futures):
                # Give this minute's first detailed quote its original five-second
                # opportunity before launching the broader HTTPS batch. A failed
                # or missed first slot still releases broad; later detail slots
                # cannot starve it. Actual delayed broad clocks stay authoritative.
                self._submit('broad', index, 0, self._minute_at(index))
        for kind, interval in (('catalyst', 5), ('stats', 60), ('metadata', 1440)):
            if index % interval == 0 and hasattr(self.rest, kind) and kind+':0' not in bucket['attempts']:
                # Reserve one worker for the fixed five-second detail lane.
                # Broad/context jobs share the other worker, with no hidden queue.
                if not first_detail_pending and len(self.futures) < 2 and not any(lane != 'detailed' for lane in self.futures):
                    self._submit(kind, index, 0, self._minute_at(index))
        if missing_changed: self._save_progress()

    @staticmethod
    def _valid_symbols(attempt, symbols, seconds):
        if attempt.get('status') not in ('OK', 'PARTIAL'): return []
        try:
            target, received = timestamp(attempt['target_at']), timestamp(attempt['receipt_at'])
            requested = timestamp(attempt['request_started_at'])
            if not target <= requested <= received < target+dt.timedelta(seconds=seconds): return []
            summary = attempt.get('result_summary') or {}
            rows = summary.get('rows', [])
            index = {row['symbol']: row for row in rows}
            valid = []
            for symbol in symbols:
                row = index.get(symbol, {})
                if (row.get('status', 'OK') != 'OK' or row.get('metadata_execution_eligible') is False
                        or row.get('execution_eligible') is False or row.get('metadata_status', 'TRADING') != 'TRADING'):
                    continue
                bid = float(row.get('bid', row.get('bidPrice', 0)))
                ask = float(row.get('ask', row.get('askPrice', 0)))
                bidqty = float(row.get('bidQty', row.get('bid_qty', row.get('bid_quantity', 0))))
                askqty = float(row.get('askQty', row.get('ask_qty', row.get('ask_quantity', 0))))
                if all(math.isfinite(value) and value > 0 for value in (bid, ask, bidqty, askqty)) and bid <= ask:
                    valid.append(symbol)
            return valid
        except (ValueError, TypeError, KeyError): return []

    def _commit(self, index, early=False):
        bucket = self._bucket(index)
        for slot in range(12):
            bucket['attempts'].setdefault('detailed:'+str(slot), {'kind': 'detailed', 'slot': slot,
                'target_at': iso(self._minute_at(index)+dt.timedelta(seconds=slot*5)), 'status': 'MISSING', 'reason': 'no retained response; never backfilled'})
        bucket['attempts'].setdefault('broad:0', {'kind': 'broad', 'slot': 0, 'target_at': bucket['target_at'], 'status': 'MISSING'})
        for kind, interval in (('catalyst', 5), ('stats', 60), ('metadata', 1440)):
            if index % interval == 0 and hasattr(self.rest, kind):
                bucket['attempts'].setdefault(kind+':0', {'kind': kind, 'slot': 0, 'target_at': bucket['target_at'],
                    'status': 'MISSING', 'reason': 'context lane unavailable before the minute closed; never backfilled'})
        for pending in self.futures.values():
            if pending['index'] == index:
                bucket['attempts'][pending['key']]['status'] = 'INCOMPLETE_AT_WINDOW_END'
        members, ws_bytes, records, updates = list(bucket['raw_http']), bytearray(), [], []
        for item in bucket['ws']:
            raw = item['raw']; offset = len(ws_bytes); ws_bytes.extend(raw); ws_bytes.extend(b'\n')
            record = _compact_ws_record(item)
            record.update(raw_offset=offset, raw_length=len(raw)); records.append(record)
            if item['first_retained']:
                updates.append({'symbol': item['symbol'], 'index': item['bar_index'], 'ontime': item['on_time_first_retained']})
        ws_member = None
        if records:
            ws_member = len(members)
            members.append({'transport': 'websocket-closed-jsonl-with-exact-offsets', 'body': bytes(ws_bytes),
                'status': 'CAPTURED', 'message_count': len(records), 'closed_message_map': records,
                'reception_started_at': min(item['received_at'] for item in records),
                'received_at': max(item['received_at'] for item in records),
                'clock_semantics': 'Actual per-message receipts in closed_message_map; no HTTP request clock is invented.'})
        packer = self.packet_packer
        if packer is None:
            from broad_observer.packets import minute_raw
            packer = minute_raw
        raw_http, member_index = packer(members)
        detailed_updates, broad_updates, attempts = [], [], []
        for key in sorted(bucket['attempts']):
            attempt = bucket['attempts'][key]
            if attempt['kind'] == 'detailed':
                valid = self._valid_symbols(attempt, self.details, 5)
                detailed_updates.extend({'symbol': symbol, 'index': index*12+attempt['slot']} for symbol in valid)
            elif attempt['kind'] == 'broad':
                valid = self._valid_symbols(attempt, self.symbols, 60)
                broad_updates.extend({'symbol': symbol, 'index': index} for symbol in valid)
            else: valid = []
            retained = {key_: value for key_, value in attempt.items() if key_ != 'result_summary'} | {'valid_received_symbol_count': len(valid)}
            if attempt['kind'] not in ('detailed', 'broad') and isinstance(attempt.get('result_summary'), dict):
                retained['context_summary'] = {key_: value for key_, value in attempt['result_summary'].items()
                    if key_ not in ('rows', 'symbols', 'observations', 'candidates', 'body', 'messages', 'raw_http')}
                if len(canonical(retained['context_summary'])) > 65536:
                    raise ValueError('context callback must return a compact status/count/reference summary')
            attempts.append(retained)
        delta = {'bars': updates, 'detailed': detailed_updates, 'broad': broad_updates}
        summary = {'schema': 'RESEARCH_CAPTURE_MINUTE_V2_BITMAP', 'config_hash': self.config_hash, 'minute_index': index,
            'target_minute_at': bucket['target_at'], 'closed_bar_deadline_at': iso(self._deadline(index)),
            'finalized_at': iso(self.now()), 'finalized_early': early,
            'closed_message_count': len(records), 'closed_message_map_member': ws_member,
            'closed_message_map_location': 'immutable raw container member metadata; never duplicated as a normalized cache',
            'http_attempts': attempts, 'notices': bucket['notices'], 'delta': encode_delta(delta,self.symbols,self.details),
            'raw_member_count': len(member_index),
            'raw_member_index_location': 'immutable PACK_V1 framing; per-member byte lengths and SHA-256 verified by unpack_attempts',
            'stream_metrics': {'connection_attempt': self.state['connection_attempts'],
                               'health': self.state.get('last_stream_health', {})},
            'lost_mid_requests_possible': bucket['recovered'], 'capture_only': True, 'research_capture_enabled': True, 'research_decisions_separate': True,
            'scientific_enrollment': False, 'backfilled': False}
        receipt = self.store.append_batch('capacity:'+self.config['trial_id']+':end:'+bucket['target_at'],
            self.now(), 'EARLY_PARTIAL' if early else 'COMPLETE_WINDOW', raw_http, summary, kind='capacity_minute_end')
        self._apply_delta(delta)
        self.state['next_minute'] = max(self.state['next_minute'], index+1)
        self.state['last_minute_commit_at'] = receipt['recorded_at']
        self.state['journal_cursor'][receipt['day']] = receipt['seq']
        self._save_state()  # raw batch is authoritative if this atomic update crashes
        for item in bucket['ws']:
            if item['in_trial_window']: self._pending_seen.discard((item['symbol'], item['bar_index']))
        del self.buckets[index]
        self.progress['minutes'].pop(str(index), None); self._save_progress()

    def _apply_delta(self, delta):
        delta=decode_delta(delta,self.symbols,self.details)
        for lane,rows in delta.items():
            maximum=self.detail_slots if lane=='detailed' else self.minutes
            if any(row['index']>=maximum for row in rows):raise IntegrityError('coverage delta outside frozen finite slots')
        self._quality_generation += 1
        for item in delta['bars']:
            _set(self.bar_seen[item['symbol']], item['index'])
            if item['ontime']: _set(self.bar_ontime[item['symbol']], item['index'])
        for item in delta['detailed']: _set(self.detail_valid[item['symbol']], item['index'])
        for item in delta['broad']: _set(self.broad_valid[item['symbol']], item['index'])

    def _append_diagnostic(self, members, delta, reason, metadata=None):
        """Retain completed stop/late bytes without inventing a minute or entry."""
        packer = self.packet_packer
        if packer is None:
            from broad_observer.packets import minute_raw
            packer = minute_raw
        raw_http, indices = [], []
        for offset in range(0, len(members), 32):
            packed, index = packer(members[offset:offset+32]); raw_http.extend(packed); indices.append(index)
        sequence = self.state.get('diagnostic_sequence', 0)
        summary = {'schema': 'RESEARCH_CAPTURE_DIAGNOSTIC_V2_BITMAP', 'config_hash': self.config_hash,
            'diagnostic_sequence': sequence, 'reason': reason, 'metadata': metadata or {},
            'delta': encode_delta(delta,self.symbols,self.details), 'raw_member_indices': indices, 'scientific_enrollment': False,
            'new_source_requests': False, 'not_a_new_or_repaired_observation_window': True}
        receipt = self.store.append_batch('capacity:'+self.config['trial_id']+':diagnostic:'+str(sequence),
            self.now(), 'DIAGNOSTIC_ONLY', raw_http, summary, kind='capacity_diagnostic')
        self._apply_delta(delta)
        self.state['diagnostic_sequence'] = sequence+1
        self.state['journal_cursor'][receipt['day']] = receipt['seq']
        self._save_state()

    def _preserve_pending_capture(self):
        members, delta = [], {'bars': [], 'detailed': [], 'broad': []}
        for index, bucket in sorted(self.buckets.items()):
            members.extend(bucket['raw_http'])
            data, records = bytearray(), []
            for item in bucket['ws']:
                raw = item['raw']; offset = len(data); data.extend(raw); data.extend(b'\n')
                record = _compact_ws_record(item)
                record.update(raw_offset=offset, raw_length=len(raw)); records.append(record)
                if item['first_retained']:
                    delta['bars'].append({'symbol': item['symbol'], 'index': item['bar_index'], 'ontime': item['on_time_first_retained']})
            if records:
                members.append({'transport': 'websocket-stop-jsonl-with-offsets', 'body': bytes(data),
                    'received_at': max(record['received_at'] for record in records), 'closed_message_map': records})
            for attempt in bucket['attempts'].values():
                if attempt['kind'] == 'detailed':
                    delta['detailed'].extend({'symbol': symbol, 'index': index*12+attempt['slot']}
                        for symbol in self._valid_symbols(attempt, self.details, 5))
                elif attempt['kind'] == 'broad':
                    delta['broad'].extend({'symbol': symbol, 'index': index}
                        for symbol in self._valid_symbols(attempt, self.symbols, 60))
            bucket['raw_http'] = []; bucket['ws'] = []; bucket['ws_bytes'] = 0
        if members:
            self._append_diagnostic(members, delta, 'captured bytes retained during worker stop; minute remains open')

    def _release_job_lock(self):
        if self.lock_fd is not None:
            fcntl.flock(self.lock_fd, fcntl.LOCK_UN); os.close(self.lock_fd); self.lock_fd = None

    def _late_completion(self, _future):
        with self._closing_lock:
            if not self._closing: return
            self._collect_futures()
            self._preserve_pending_capture()
            if not self.futures:
                self._release_job_lock()

    def step(self):
        if self._closing: return self.heartbeat(force=True)
        if self.lock_fd is None: self.start()
        now = self.now()
        if self.state['phase'] in TERMINAL:
            self.close_sources()
            return self.heartbeat(force=True)
        if self.provider_path.exists(): self.state['phase'] = 'PROVIDER_STOPPED'
        elif self.pause_path.exists(): self.state['phase'] = 'PAUSED'; self.stop_event.set()
        if self.state['phase'] in TERMINAL:
            self._collect_futures()
            for index in sorted(self.buckets): self._commit(index, early=True)
            self.close_sources(); self._save_state(); return self.heartbeat(force=True)
        if now < self.t0: return self.heartbeat()
        self.state['phase'] = 'DRAINING' if now >= self.end else 'RUNNING'
        self.state['started_at'] = self.state['started_at'] or iso(now)
        self._collect_futures()
        self._drain_stream()
        if self.state['phase'] in TERMINAL:
            for index in sorted(self.buckets): self._commit(index, early=True)
            self.close_sources(); self._save_state(); return self.heartbeat(force=True)
        # Start the current detail opportunity before slower old-minute commits.
        # The bounded HTTP worker retains its actual source/receipt clocks while
        # the controller persists the prior minute.
        if self.stream is not None and self.state['phase'] not in TERMINAL:
            self._schedule_current()
            self._collect_futures()
        # Finalize due buckets in order, at most 60 missing minutes per call.
        # Use fresh clocks and schedule between commits to avoid catch-up starvation.
        for _ in range(60):
            now = self.now()
            index = self.state['next_minute']
            if index >= self.minutes or now < self._deadline(index): break
            self._commit(index)
            self._collect_futures()
            if self.state['phase'] in TERMINAL: break
            if self.stream is not None and self.now() < self.end: self._schedule_current()
        now = self.now()
        if self.state['phase'] not in TERMINAL and now < self.end:
            if self.stream is None: self._connect()
            if self.state['phase'] not in TERMINAL:
                self._schedule_current()
                self._collect_futures()
            if self.state['phase'] in TERMINAL:
                for index in sorted(self.buckets): self._commit(index, early=True)
                self.close_sources(); self._save_state(); return self.heartbeat(force=True)
        if now >= self.checkpoint_at and self.state['checkpoint_24h'] is None and self.state['next_minute'] >= 1440:
            self.state['checkpoint_24h'] = self.coverage(1440)
            self.state['checkpoint_24h']['frozen_at'] = iso(now)
            self._save_state()
        if now >= self.drain_end and self.state['next_minute'] >= self.minutes:
            self.close_sources(); self.state['phase'] = 'COMPLETE'; self.state['completed_at'] = iso(now); self._save_state()
        return self.heartbeat()

    def coverage(self, minutes=None):
        minutes = min(self.minutes, self.state['next_minute']) if minutes is None else minutes
        bars = {symbol: {'expected': minutes, 'on_time': _count(self.bar_ontime[symbol], minutes),
                         'eventual': _count(self.bar_seen[symbol], minutes)} for symbol in self.symbols}
        for item in bars.values(): item['on_time_coverage'] = item['on_time']/minutes if minutes else None
        slots = minutes*12
        details = {symbol: {'expected': slots, 'valid_received': _count(self.detail_valid[symbol], slots),
                    'coverage': _count(self.detail_valid[symbol], slots)/slots if slots else None} for symbol in self.details}
        broad = {symbol: {'expected': minutes, 'valid_received': _count(self.broad_valid[symbol], minutes),
                    'coverage': _count(self.broad_valid[symbol], minutes)/minutes if minutes else None} for symbol in self.symbols}
        expected = minutes*len(self.symbols)
        pooled = sum(item['on_time'] for item in bars.values())/expected if expected else None
        return {'settled_minutes': minutes, 'closed_bars': bars, 'pooled_on_time_coverage': pooled,
            'expected_closed_total': expected, 'on_time_closed_total': sum(item['on_time'] for item in bars.values()),
            'eventual_closed_total': sum(item['eventual'] for item in bars.values()),
            'fixed_primary_asset_count': len(self.symbols), 'full_capture_expected_closed_total': self.minutes*len(self.symbols),
            'every_primary_at_least_99pct': bool(minutes and all(item['on_time_coverage'] >= .99 for item in bars.values())),
            'pooled_at_least_99pct': bool(expected and pooled >= .99), 'detailed_five': details,
            'every_detailed_at_least_99pct': bool(slots and all(item['coverage'] >= .99 for item in details.values())),
            'broad_bbo': broad, 'late_recovery_repairs_on_time': False,
            'complete_utc_hour_quality': self._hour_quality(minutes),
            'capacity_resource_backup_restart_alert_gates_not_assessed_here': True}

    def _hour_quality(self, minutes):
        # Complete-hour quality only changes when archive deltas/settlement change.
        # Do not rebuild month-sized bitmasks on every five-second heartbeat.
        key = (minutes, self._quality_generation, int((self.now()-BAR_GRACE+dt.timedelta(milliseconds=1)).timestamp()//3600))
        if self._quality_cache is not None and self._quality_cache[0] == key:
            return self._quality_cache[1]
        first = self.t0.replace(minute=0, second=0, microsecond=0)
        if first < self.t0: first += dt.timedelta(hours=1)
        settled_end = min(self.end, self.t0+minutes*MINUTE,
                          self.now()-BAR_GRACE+dt.timedelta(milliseconds=1))
        all_ranges, matured = [], []
        opened = first
        while opened+dt.timedelta(hours=1) <= self.end:
            index = int((opened-self.t0).total_seconds()//60)
            mask = ((1 << 60)-1) << index
            all_ranges.append((opened, mask))
            if opened+dt.timedelta(hours=1) <= settled_end: matured.append((opened, mask))
            opened += dt.timedelta(hours=1)
        assets = {}
        for symbol in self.symbols:
            seen = int.from_bytes(self.bar_seen[symbol], 'little')
            ontime = int.from_bytes(self.bar_ontime[symbol], 'little')
            eventual_hours = sum(seen & mask == mask for _, mask in matured)
            ontime_hours = sum(ontime & mask == mask for _, mask in matured)
            assets[symbol] = {'matured_expected': len(matured), 'all_60_eventual': eventual_hours,
                              'all_60_on_time': ontime_hours,
                              'unknown_or_incomplete_hours': len(matured)-eventual_hours}
        result = {'alignment': 'UTC hour boundaries; all 60 source-open minutes required',
                'full_utc_hours_in_declared_capture_window': len(all_ranges),
                'matured_utc_hours': len(matured), 'per_asset': assets,
                'partial_edge_hours_excluded': True, 'never_sum_59_as_a_complete_hour': True,
                'first_hour_availability_requires_raw_receipt_reconstruction': True,
                'detector_172h_warmup': 'UNKNOWN_WITHOUT_SEPARATELY_DECLARED_WARMUP',
                'warmup_unknown_is_not_a_capacity_failure': True}
        self._quality_cache = (key, result)
        return result

    def heartbeat(self, force=False):
        if self.state is None: return {'phase': 'UNINITIALIZED'}
        if self._heartbeat_cache is not None and self._heartbeat_cache['phase'] != self.state['phase']:
            force = True
        if (not force and self._heartbeat_cache is not None
                and self._heartbeat_cache['phase'] == self.state['phase']
                and self.monotonic()-self._last_heartbeat_mono < 5):
            return self._heartbeat_cache
        health = self.stream.health() if self.stream is not None else {'state': 'NOT_CONNECTED'}
        value = {'schema': 'RESEARCH_CAPTURE_HEARTBEAT_V1', 'trial_id': self.config['trial_id'], 'config_hash': self.config_hash,
            'as_of': iso(self.now()), 'epoch': self.now().timestamp(), 'epoch_seconds': self.now().timestamp(), 'pid': os.getpid(),
            'phase': self.state['phase'], 't0': iso(self.t0), 'end': iso(self.end), 'receipt_drain_end': iso(self.drain_end),
            'checkpoint_at': iso(self.checkpoint_at), 'last_minute_commit_at': self.state['last_minute_commit_at'],
            'coverage': self.coverage(), 'checkpoint_24h': self.state['checkpoint_24h'],
            'stream': health, 'pending_http': sorted(self.futures), 'pending_minutes': len(self.buckets),
            'pending_ws_bytes': sum(item['ws_bytes'] for item in self.buckets.values()),
            'progress_atomic_writes_this_process': self.progress_atomic_writes,
            'reconnects': self.state['reconnects'], 'renewals_started': self.state['renewals_started'],
            'renewals_completed': self.state['renewals_completed'], 'queue_overflows': self.state['queue_overflows'],
            'target_to_receipt_latency_by_lane': self.state.get('latency_by_lane', {}),
            'source_attempt_counts': self.state.get('source_attempt_counts', {}),
            'latest_registered_feed_coverage': self.state.get('latest_registered_feed_coverage', {}),
            'scientific_enrollment': False, 'capacity_trial_only': False, 'capture_only': True, 'research_engine_enrollment_separate': True, 'admission_end_at': iso(self.admission_end), 'study_end_at': iso(self.study_end), 'request_collection_end_at': iso(self.end)}
        value['worker_closing'] = self._closing
        if force or self.monotonic()-self._last_heartbeat_mono >= 5:
            _atomic(self.heartbeat_path, value); self._last_heartbeat_mono = self.monotonic()
        self._heartbeat_cache = value
        return value

    def close_sources(self):
        if self.stream is not None:
            stream, self.stream = self.stream, None
            stream.stop()
            # A graceful stop must retain complete messages already received by
            # the bounded reader queue, including the stop/read race.
            for notice in stream.drain_events(max_items=512): self._notice(notice)
            for envelope in stream.drain(max_items=300): self._accept_bar(envelope)
            if self.state is not None: self.state['last_stream_health'] = stream.health()

    def close(self):
        with self._closing_lock:
            if self.lock_fd is None: return
            self._closing = True
            self.stop_event.set()
            self.close_sources()
            if self.state is not None and self._initialized:
                for kind, pending in list(self.futures.items()):
                    if pending['future'].cancel():
                        bucket = self.buckets.get(pending['index'])
                        if bucket:
                            bucket['attempts'][pending['key']]['status'] = 'CANCELLED_BEFORE_EXECUTION'
                        del self.futures[kind]
                self._collect_futures()
                self._preserve_pending_capture()
                self._save_progress(); self._save_state()
            if self._owns_executor and self.executor is not None:
                self.executor.shutdown(wait=False, cancel_futures=True)
            if self.futures:
                self.state['shutdown_pending_http'] = sorted(self.futures)
                self._save_state()
                # Keep the process/job flock until running requests finish; their
                # done callbacks retain completed bytes before releasing it.
                for pending in list(self.futures.values()):
                    pending['future'].add_done_callback(self._late_completion)
            else: self._release_job_lock()

    def run(self):
        self.start()
        try:
            while self.state['phase'] not in TERMINAL and not self._closing:
                self.step()
                if self.state['phase'] not in TERMINAL: self.sleeper(.25)
            return self.heartbeat(force=True)
        finally: self.close()
