# R2 isolated research deployment

No server changes are made by package construction or `--package` validation. The root agent owns the final measured readiness, frozen configuration, T0, authorization review, actual installation and first-data verification. The old capacity trial is not passed or relabelled.

Build the exact input map without copying the old 29 MB capacity release:

```python
from research_r2.deploy_inputs import package_inputs
from research_r2.deploy import build_package
files, metadata, tests = package_inputs(WORKSPACE, readiness=READINESS_PATH)
package = build_package(NEW_PACKAGE_PATH, frozen_config, files,
                        release_metadata=metadata, test_modules=tests)
```

The helper includes the current research runtime, only shared runtime dependencies, new tests and their fixtures, the pinned causal detector source, source/universe/classification evidence, initial exchange metadata, and exact compressed warmup responses with actual receipts. It excludes acquisition locks and duplicate normalized warmup rows. `research.json` and the release/package hashes are created after copying these inputs. No config/release circular hash exists.

Final configuration must include:

- `trial_id`/`study_id`, fresh minute-aligned `t0`, `frozen_at`, `phase=RESEARCH35D`.
- `admission_end_at=T0+30d`, `end_at=T0+35d`, `receipt_drain_end=T0+35d+120s`, `finalization_end_at=receipt_drain_end+60s`.
- Exact code/state/ops roots `/opt/kod/research-r2`, `/var/lib/kod/research-r2`, `/var/lib/kod-research-r2-ops`.
- Frozen `primary` rows, `primary_symbols`, `detailed_symbols`, `selection_manifest_sha256`, source/protocol/startup-amendment hashes.
- `warmup_manifest=research_r2/warmup/MANIFEST.json` and its digest; warmup remains bootstrap, never prospective data.
- `scientific_enrollment_enabled=true`, `economic_enrollment_enabled=false`, `real_orders_or_capital_allocation=false`, `automatic_extension=false`.
- Measured `initial_free_bytes`, `initial_free_inodes`, `projected_35day_all_in_bytes`, `hard_storage_bytes`, `hard_file_count`, `hard_inode_count`, `minimum_free_inodes`, `overshoot_reserve_bytes`, `overshoot_reserve_inodes`, `guard_interval_seconds<=60`, `full35day_gate_status=PASS_MEASURED`.

Only use `PASS_MEASURED` after the actual whole-period forecast, allocation/inode/temp/Git costs and resource measurements pass. No helper manufactures that evidence.

After transferring the package into a new temporary directory on the existing authorized server, validate it from that directory:

```sh
/usr/bin/python3 -B -m research_r2.deploy --package /tmp/EXACT_NEW_PACKAGE
```

The explicit installation command is:

```sh
/usr/bin/python3 -B -m research_r2.deploy --package /tmp/EXACT_NEW_PACKAGE --install --close-capacity
```

Run both with the transferred package as the working directory, so Python imports those exact reviewed bytes. Installer performs the declared Linux tests and systemd verification before any installation, verifies protected original 527 files and 34 controls, checks fresh T0 and free reserve, and refuses existing new targets or uncertain earlier outcomes.

The handoff waits for the separate capacity backup writer to finish. It preserves old health/state plus final state under new ops `capacity-closure-evidence`, stops only `kod-capacity-r2.service` and its backup timer, and enables/starts only `kod-research-r2.service` and its new backup timer. The new worker is enabled for boot, retains its frozen deadline and state, and never resets missed slots on restart. A failed installation disables only its own new units until the outcome is reconciled. It never controls original/supplement services or watchdogs. The installer verifies that common and pre-existing ancestor CPU/memory ceilings remain unchanged. The new collector and ops share a dedicated 192 MiB/10% CPU leaf slice; the engine runs inside the collector process. A bounded processing-only drain is included. All new timer calendar dates are finite, and operations stop after the configured end guard.

Exact `LAUNCH_RECEIPT.json`, `CAPACITY_CLOSURE.json`, `PREDECESSOR_BACKUP_ACK.json` and `PREDECESSOR_BACKUP_HEAD.json` copies are retained in the new state for incremental control backup. These receipts identify the predecessor as `CLOSED_EARLY_NOT_PASSED`; they do not rewrite its final state or make it complete.

Installation success means **armed**, not verified live. Check actual prospective archive packets, engine protocol/checkpoint records, fresh health/commit clocks, backup ACK, off-host restoration and original invariants before calling it active. If installation errors, preserve the failure receipt and reconcile units/paths before any retry. The installer does not automatically erase or relaunch a failed attempt.

For a separately scoped external checker, publish a new `tools/research_r2_watchdog.py` (from `deploy_watchdog.py`), exact frozen `controls/research-r2/research.json`, and the workflow returned by `deploy.watchdog_workflow(config, config_sha256)` in the existing private backup repository through its authorized workflow. This does not replace either old watchdog. A GitHub check failure is an alert condition; actual notification delivery and scheduled execution must be verified separately.
