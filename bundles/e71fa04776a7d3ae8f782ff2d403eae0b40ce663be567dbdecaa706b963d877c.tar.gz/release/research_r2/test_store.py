import datetime as dt
import gzip
import json
from pathlib import Path
import tempfile
import unittest
from broad_observer.store import BroadStore, IntegrityError, UTC
from broad_observer.backup import IncrementalBackup
from research_r2.store import ResearchStore


class ExactCompression(unittest.TestCase):
    def test_byte_exact_deterministic_and_old_reader_compatible(self):
        raw=(b'{"s":"BTCUSDT","b":"123.12300000","a":"123.12400000"}\n'*1000)
        with tempfile.TemporaryDirectory() as directory:
            store=ResearchStore(Path(directory)/'new')
            first=store.append_batch('one',dt.datetime(2026,11,5,tzinfo=UTC),'OK',
                [{'body':raw}],{'valid':True},kind='research_fixture')
            other=store.append_batch('two',dt.datetime(2026,11,5,0,1,tzinfo=UTC),'OK',
                [{'body':raw}],{'valid':True},kind='research_fixture')
            ref=first['raw_objects'][0]
            self.assertEqual(ref,other['raw_objects'][0])
            self.assertEqual(gzip.decompress((store.root/ref['path']).read_bytes()),raw)
            reader=BroadStore(store.root)
            self.assertEqual(reader.read_object(ref),raw)
            self.assertEqual(reader.read_summary(first),{'valid':True})
            self.assertEqual(reader.full_verify()['events'],2)
            backup=IncrementalBackup(Path(directory)/'backup')
            backup.snapshot(store)
            backup.restore(Path(directory)/'restored')
            restored=BroadStore(Path(directory)/'restored')
            self.assertEqual(restored.read_object(ref),raw)
            self.assertEqual(restored.full_verify()['events'],2)

    def test_retained_compressed_corruption_fails_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            store=ResearchStore(directory)
            item=store.append_batch('one',dt.datetime(2026,11,5,tzinfo=UTC),'OK',
                [{'body':b'exact source bytes'}],{},kind='research_fixture')
            ref=item['raw_objects'][0];path=Path(directory)/ref['path']
            raw=path.read_bytes();path.chmod(0o644);path.write_bytes(raw[:-1]+bytes([raw[-1]^1]))
            with self.assertRaises(IntegrityError):BroadStore(directory).read_object(ref)


if __name__=='__main__':unittest.main()
