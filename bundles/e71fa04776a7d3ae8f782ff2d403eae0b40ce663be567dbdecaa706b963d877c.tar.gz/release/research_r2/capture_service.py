"""Entrypoints for the one isolated R2 research collector and its scoped ops.

The CLI accepts only the three designated new production roots. Test dependency
injection is a Python API, never a command-line permission bypass. This module
does not install units, create credentials, change a frozen schedule, or promote
capacity observations as prospective research or place real orders.
"""
from __future__ import annotations
import argparse
import contextlib
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import threading
import time
from dataclasses import dataclass

from . import capture_ops as ops
from broad_observer.backup import canonical, immutable_write
from .capture import ResearchCaptureController, TERMINAL, _read
from broad_observer.legacy_sources import PublicAdapters
from .capture_runtime import ResearchRestLanes as RestLanes
from .store import ResearchStore as BroadStore
from broad_observer.streams import KlineStream

CODE_ROOT = Path('/opt/kod/research-r2')
STATE_ROOT = Path('/var/lib/kod/research-r2')
OPS_ROOT = Path('/var/lib/kod-research-r2-ops')
CGROUP = Path('/sys/fs/cgroup/kod.slice/kod-research.slice/kod-research-r2.slice')
SSH_COMMAND = ('ssh -i /etc/kod-ops/github_backup -o IdentitiesOnly=yes '
    '-o StrictHostKeyChecking=yes -o UserKnownHostsFile=/etc/kod-ops/github_known_hosts '
    '-o BatchMode=yes -o ConnectTimeout=10')


@dataclass(frozen=True)
class Paths:
    code: Path = CODE_ROOT
    state: Path = STATE_ROOT
    operations: Path = OPS_ROOT
    cgroup: Path = CGROUP


def _json(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('required regular JSON file absent or symlink: ' + path.name)
    return json.loads(path.read_bytes())


def _hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        while block := source.read(65536): h.update(block)
    return h.hexdigest()


def validate_paths(paths, *, test_roots=None):
    expected = (CODE_ROOT, STATE_ROOT, OPS_ROOT) if test_roots is None else tuple(map(Path, test_roots))
    actual = (Path(paths.code), Path(paths.state), Path(paths.operations))
    if len(expected) != 3 or actual != expected:
        raise ValueError('only exact isolated research code/state/ops roots are allowed')
    for path in actual:
        if not path.is_absolute() or path.resolve() != path:
            raise ValueError('research roots must be absolute and free of symlinks')
    if len(set(actual)) != 3 or any(a.is_relative_to(b) for a in actual for b in actual if a != b):
        raise ValueError('research roots must be separate')
    return paths


def _member(root, relative):
    if not isinstance(relative, str): raise ValueError('release member path must be text')
    name = Path(relative)
    if name.is_absolute() or '..' in name.parts or not name.parts or str(name) != relative:
        raise ValueError('unsafe release member')
    path = root / name
    if path.is_symlink() or not path.is_file() or path.resolve() != path or not path.resolve().is_relative_to(root):
        raise ValueError('missing or unsafe release member: ' + relative)
    return path


def verify_release(paths=Paths(), *, test_roots=None):
    """Verify exact frozen bytes before any adapter or collector is constructed."""
    validate_paths(paths, test_roots=test_roots)
    release = _json(paths.code / 'RESEARCH_RELEASE.json')
    package = _json(paths.code / 'PACKAGE.json')
    config = _json(paths.code / 'research.json')
    release_hash = _hash(paths.code / 'RESEARCH_RELEASE.json')
    config_hash = _hash(paths.code / 'research.json')
    if (package.get('release_manifest_sha256') != release_hash
            or config.get('release_manifest_sha256') != release_hash
            or package.get('config_sha256') != config_hash):
        raise ValueError('frozen package/release/config binding differs')
    files = release['files']
    if not isinstance(files, dict) or not files: raise ValueError('empty release file manifest')
    for relative, value in files.items():
        expected = value.get('sha256') if isinstance(value, dict) else value
        if _hash(_member(paths.code, relative)) != expected:
            raise ValueError('release member hash differs: ' + relative)
    runtime = {str(path.relative_to(paths.code)) for folder in ('broad_observer','research_r2') for path in (paths.code/folder).rglob('*.py')}
    if not runtime or runtime - set(files): raise ValueError('unmanifested Python runtime file')
    for relative, expected in (('authoritative/PROTOCOL_R2.md', ops.PROTOCOL_R2_SHA256),
                               ('authoritative/Pasted text(5).txt', ops.ATTACHMENT_SHA256)):
        if relative not in files or _hash(_member(paths.code, relative)) != expected:
            raise ValueError('authoritative R2 or attachment bytes differ')
    if (release.get('protocol_sha256') != ops.PROTOCOL_R2_SHA256
            or release.get('attachment_sha256') != ops.ATTACHMENT_SHA256):
        raise ValueError('release authoritative identities differ')
    for field in ('universe_path','detail_path','baseline_path','metadata_path','source_manifest_path','startup_amendment_path'):
        if release.get(field) not in files: raise ValueError('unmanifested required ' + field)
    universe_path = _member(paths.code, release['universe_path'])
    detail_path = _member(paths.code, release['detail_path'])
    universe, detail = _json(universe_path), _json(detail_path)
    if (_hash(universe_path) != release['universe_sha256']
            or _hash(detail_path) != release['detail_sha256']
            or config.get('selection_manifest_sha256') != release['universe_sha256']
            or config.get('primary_symbols') != universe.get('primary_symbols')
            or config.get('detailed_symbols') != detail.get('symbols')
            or universe.get('certified_top150') is not True or universe.get('blockers')):
        raise ValueError('fixed source-qualified universe or detail identity differs')
    if config.get('primary') != universe.get('primary'):
        raise ValueError('engine primary liquidity rows differ from the frozen universe')
    if config.get('warmup_manifest') and config['warmup_manifest'] not in files:
        raise ValueError('warmup manifest must be in frozen release')
    limits = ops.validate_config(config)
    start = ops.timestamp(config['t0'])
    if (start != limits['start'] or start.second or start.microsecond
            or limits['drain_end'] != limits['end'] + dt.timedelta(seconds=120)
            or config.get('scientific_enrollment_enabled') is not True
            or config.get('economic_enrollment_enabled', False) is not False):
        raise ValueError('fixed minute-aligned R2 research schedule required')
    primary, details = config['primary_symbols'], config['detailed_symbols']
    if (not 0 < len(primary) <= 150 or len(primary) != len(set(primary))
            or len(details) != 5 or len(set(details)) != 5
            or not {'BTCUSDT','ETHUSDT'}.issubset(primary)
            or not {'BTCUSDT','ETHUSDT'}.issubset(details)):
        raise ValueError('fixed primary/detail panels and same-response benchmarks required')
    return {'release':release, 'package':package, 'config':config, 'limits':limits,
            'release_sha256':release_hash, 'config_bytes_sha256':config_hash}


def _record(paths, name, value):
    ops._shared_atomic(paths.state / name, value)


def free_space_guard(paths, config, *, statvfs=os.statvfs, now=None):
    """Cheap five-second reserve guard; aggregate accounting remains explicit.

    This reads filesystem counters, never scans the growing evidence tree. The
    separate root guard checks the allocated bytes/files/inodes of all new roots
    at the frozen interval, with a declared inter-check overshoot reserve.
    """
    if config.get('phase') != 'RESEARCH35D': return {'status':'NOT_DECLARED'}
    value=statvfs(paths.state)
    free_bytes=value.f_bavail*value.f_frsize
    free_inodes=value.f_favail
    byte_stop=ops.MIN_FREE_BYTES+config['overshoot_reserve_bytes']
    inode_stop=config['minimum_free_inodes']+config['overshoot_reserve_inodes']
    issues=[]
    if free_bytes<byte_stop:issues.append('FAST_FREE_DISK_RESERVE_REACHED')
    if free_inodes<inode_stop:issues.append('FAST_FREE_INODE_RESERVE_REACHED')
    instant=ops.timestamp(now or dt.datetime.now(ops.UTC))
    start=ops.timestamp(config['t0']);drain=ops.timestamp(config['receipt_drain_end'])
    if start+dt.timedelta(seconds=120)<=instant<=drain:
        try:
            guard=_json(paths.operations/'RESOURCE_GUARD.json');epoch=guard['epoch']
            valid=(guard.get('trial_id')==config['trial_id']
                and guard.get('config_sha256')==ops.config_hash(config)
                and guard.get('status') in ('OK','PRELIMINARY')
                and isinstance(epoch,(int,float)) and not isinstance(epoch,bool)
                and 0<=instant.timestamp()-epoch<=120)
        except (OSError,ValueError,TypeError,KeyError):valid=False
        if not valid:issues.append('ROOT_AGGREGATE_RESOURCE_GUARD_STALE_OR_UNKNOWN')
    if issues:
        _record_failure(paths,instant,'WORKER_FAST_FREE_SPACE_GUARD',RuntimeError(','.join(issues)))
        return {'status':'FAILED','issues':issues,'disk_free_bytes':free_bytes,'disk_free_inodes':free_inodes}
    return {'status':'OK','disk_free_bytes':free_bytes,'disk_free_inodes':free_inodes}


def verify_cgroup_limits(cgroup, *, membership_path='/proc/self/cgroup'):
    """Read the aggregate envelope; individual process limits are insufficient."""
    group=Path(cgroup)
    maximum=(group/'memory.max').read_text().strip()
    quota,period=(group/'cpu.max').read_text().split()
    if (maximum=='max' or int(maximum)>ops.MEMORY_LIMIT_BYTES or int(maximum)<=0
            or quota=='max' or int(period)<=0 or int(quota)<=0 or int(quota)/int(period)>.10):
        raise ValueError('aggregate new research slice must enforce RAM<=192MiB and CPU<=10percent')
    memberships=Path(membership_path).read_text().splitlines()
    if not any(row.startswith('0::/') and '/kod-research-r2.slice/' in row for row in memberships):
        raise ValueError('process is outside the new aggregate research slice')
    return {'slice':'kod-research-r2.slice','memory_max_bytes':int(maximum),
        'cpu_quota':int(quota),'cpu_period':int(period),'cpu_fraction':int(quota)/int(period),
        'aggregate_not_per_process':True,'process_membership_verified':True}




def wait_for_startup_guard(paths, config, collector, event, *, clock, sleeper=time.sleep,
                           monotonic=time.monotonic, statvfs=os.statvfs):
    """At most 60 seconds before any restarted network intake; real latches stay."""
    instant=clock()
    if collector.state['phase'] in TERMINAL:return {'status':'EXISTING_TERMINAL_STATE'}
    if instant < ops.timestamp(config['t0'])+dt.timedelta(seconds=120):return {'status':'INITIAL_START_WINDOW'}
    deadline=monotonic()+60
    prior_phase=collector.state['phase']
    collector.state['phase']='RECOVERING_RESOURCE_GUARD'
    while not event.is_set():
        if (paths.state/'PAUSED.json').exists() or (paths.state/'PROVIDER_STOP.json').exists():
            return {'status':'EXISTING_STOP_LATCH'}
        fs=statvfs(paths.state)
        if (fs.f_bavail*fs.f_frsize < ops.MIN_FREE_BYTES+config['overshoot_reserve_bytes']
                or fs.f_favail < config['minimum_free_inodes']+config['overshoot_reserve_inodes']):
            raise RuntimeError('startup filesystem reserve failed')
        now=clock()
        try:
            guard=_json(paths.operations/'RESOURCE_GUARD.json')
            valid=(guard.get('trial_id')==config['trial_id']
                and guard.get('config_sha256')==ops.config_hash(config)
                and guard.get('status') in ('OK','PRELIMINARY')
                and isinstance(guard.get('epoch'),(int,float))
                and not isinstance(guard.get('epoch'),bool)
                and 0<=now.timestamp()-guard['epoch']<=120)
        except (OSError,ValueError,TypeError,KeyError):valid=False
        collector.heartbeat()
        if valid:
            collector.state['phase']=prior_phase
            return {'status':'FRESH_AGGREGATE_GUARD','epoch':guard['epoch']}
        if monotonic()>=deadline:raise RuntimeError('startup aggregate guard remained stale after 60 seconds')
        sleeper(.25)
    return {'status':'STOP_REQUESTED'}

def research_engine_worker(paths, config, event, *, clock=None, final_capture_state=None):
    from .engine import ResearchEngine, poll_archive, final_archive_drain
    now=clock or (lambda:dt.datetime.now(ops.UTC))
    engine=None
    try:
        engine=ResearchEngine(paths.state/'engine',config)
        if config.get('warmup_manifest'):
            engine.import_warmup(_member(paths.code,config['warmup_manifest']))
        store=BroadStore(paths.state)
        exported_hour=None
        while not event.is_set():
            instant=now()
            closed_at=(final_capture_state or {}).get('collector_closed_at')
            if closed_at is not None:
                result=final_archive_drain(engine,store,closed_at,limit=30)
            else:
                result=(poll_archive(engine,store,instant,limit=30) if store.catalog_path.exists()
                    else {'status':'WAITING_FOR_FIRST_CAPTURE','ingested_batches':0,'backlog_possible':False,'health':engine.health()})
            hour=int(instant.timestamp()//3600)
            if hour!=exported_hour or result.get('final_archive_drain'):
                # Bounded chunks. A residual export backlog drains in later
                # iterations; no unbounded while-loop can starve collection.
                export=engine.export_incremental(paths.state/'engine'/'ledger',limit=5000)
                if export['records']<5000:exported_hour=hour
                result['ledger_export']=export
            result.update(as_of=ops.iso(instant),epoch=instant.timestamp(),status='COMPLETE' if result.get('complete') else 'RUNNING',
                scientific_enrollment_enabled=config['scientific_enrollment_enabled'],
                new_admissions_open=ops.timestamp(config['t0'])<=instant<ops.timestamp(config['admission_end_at']),
                study_phase=('COMPLETE' if result.get('complete') else 'WAITING' if instant<ops.timestamp(config['t0'])
                    else 'ADMITTING' if instant<ops.timestamp(config['admission_end_at']) else 'OUTCOME_DRAIN'),
                capture_only=False,capacity_pass_claimed=False)
            ops._shared_atomic(paths.state/'RESEARCH_ENGINE_HEALTH.json',result)
            if result.get('complete') and result.get('ledger_export',{}).get('records',0)<5000:break
            if instant>ops.timestamp(config['finalization_end_at'])+dt.timedelta(seconds=300):
                raise RuntimeError('finite engine processing drain did not finish in its bounded window')
            event.wait(1 if result.get('backlog_possible') else 5)
    except Exception as exc:
        _record_failure(paths,now(),'RESEARCH_ENGINE',exc)
        event.set()
    finally:
        if engine is not None:
            # A small bounded final export. Any remaining committed ledger rows
            # persist in SQLite for resumed export, never fabricated as backed up.
            engine.export_incremental(paths.state/'engine'/'ledger',limit=5000)
            engine.close()


def run_trial(paths=Paths(), *, test_roots=None, controller_factory=ResearchCaptureController,
              rest_factory=RestLanes, stream_factory=KlineStream,
              preservation_check=ops.verify_original, clock_check=ops.collect_clock_evidence,
              envelope_check=verify_cgroup_limits, clock=None, sleeper=time.sleep,
              stop=None, install_signals=True, fast_guard=free_space_guard, monotonic=time.monotonic,
              engine_worker=research_engine_worker):
    bundle = verify_release(paths, test_roots=test_roots)
    now = clock or (lambda: dt.datetime.now(ops.UTC))
    paths.state.mkdir(parents=True, exist_ok=True)
    # Restarts retain the frozen clock and all missed slots. A late first launch
    # may not silently reinterpret a stale frozen start as a fresh trial.
    if not (paths.state/'RESEARCH_CAPTURE_STATE.json').exists() and now() >= bundle['limits']['start']:
        raise ValueError('new trial start is no longer future; do not silently replace Tcap')
    preservation = preservation_check(_json(paths.code / bundle['release']['baseline_path']))
    clock_evidence = clock_check()
    envelope = envelope_check(paths.cgroup)
    _record(paths, 'STARTUP_CHECK.json', {'at':ops.iso(now()), 'preservation':preservation,
        'clock':clock_evidence,'aggregate_resource_envelope':envelope,'release_sha256':bundle['release_sha256'],
        'config_bytes_sha256':bundle['config_bytes_sha256'], 'prior_capacity_status':'NOT_PASSED_SEPARATE_STARTUP_AMENDMENT_APPLIED'})
    if preservation.get('unchanged') is not True or clock_evidence.get('sync_status') != 'OK':
        raise ValueError('read-only original preservation or raw clock synchronization gate failed')
    for name in ('research.json','RESEARCH_RELEASE.json','PACKAGE.json'):
        immutable_write(paths.state/name, (paths.code/name).read_bytes())
    event = stop or threading.Event()
    handlers = {}
    if install_signals:
        for sig in (signal.SIGTERM, signal.SIGINT):
            handlers[sig] = signal.getsignal(sig)
            signal.signal(sig, lambda _signum, _frame: event.set())
    collector = None
    engine_thread = None
    final_capture_state = {}
    try:
        store = BroadStore(paths.state)
        rest = rest_factory(paths.state, (paths.code/bundle['release']['metadata_path']).read_bytes(),
            primary_symbols=bundle['config']['primary_symbols'], source_adapter_class=PublicAdapters, clock=now)
        collector = controller_factory(bundle['config'], store, stream_factory, rest, clock=now)
        collector.start()
        engine_thread=threading.Thread(target=engine_worker,args=(paths,bundle['config'],event),
            kwargs={'clock':now,'final_capture_state':final_capture_state},name='research-engine',daemon=True)
        engine_thread.start()
        _record(paths, 'SERVICE_ACTUAL.json', {'at':ops.iso(now()), 'pid':os.getpid(), 'status':'PROCESS_STARTED',
            'first_slot_verified':False, 'prior_capacity_status':'NOT_PASSED_SEPARATE_STARTUP_AMENDMENT_APPLIED'})
        try:
            startup_guard=wait_for_startup_guard(paths,bundle['config'],collector,event,
                clock=now,sleeper=sleeper,monotonic=monotonic)
            _record(paths,'STARTUP_GUARD.json',dict(startup_guard,at=ops.iso(now())))
        except Exception as exc:
            _record_failure(paths,now(),'STARTUP_AGGREGATE_GUARD',exc)
            raise
        next_guard=0
        while not event.is_set() and collector.state['phase'] not in TERMINAL:
            if monotonic()>=next_guard:
                try: fast_guard(paths,bundle['config'])
                except Exception as exc:
                    _record_failure(paths,now(),'WORKER_FAST_FREE_SPACE_GUARD',exc)
                    raise
                next_guard=monotonic()+5
            collector.step()
            if collector.state['phase'] not in TERMINAL: sleeper(.25)
        if collector.state['phase']=='COMPLETE' and not event.is_set():
            # All acquisition is finite. Close/join late HTTP callbacks before
            # declaring the immutable archive complete to the replay thread.
            collector.close()
            until=monotonic()+30
            while collector.futures and monotonic()<until and not event.is_set():sleeper(.25)
            if collector.futures:raise RuntimeError('finite capture still has uncommitted HTTP callbacks')
            final_capture_state['collector_closed_at']=ops.iso(now())
            limit=bundle['limits']['finalization_end']+dt.timedelta(seconds=360)
            while engine_thread.is_alive() and now()<limit and not event.is_set():sleeper(.25)
        return collector.heartbeat(force=True)
    finally:
        event.set()
        if engine_thread is not None:engine_thread.join(timeout=15)
        if collector is not None:
            # close retains completed/pending diagnostics. It does not mark an
            # interrupted finite trial COMPLETE or move its declared deadline.
            collector.close()
            _record(paths, 'SERVICE_ACTUAL.json', {'at':ops.iso(now()),'pid':os.getpid(),
                'status':'PROCESS_EXITED','stop_requested':event.is_set(),
                'last_phase':collector.state.get('phase') if collector.state else 'UNINITIALIZED',
                'research_acceptance':'UNDECIDED'})
        for sig, handler in handlers.items(): signal.signal(sig, handler)


def service_actual_status(*, runner=subprocess.run):
    result = runner(['systemctl','show','kod-research-r2.service','-p','ActiveState','-p','SubState',
        '-p','MainPID','-p','ExecMainStatus','-p','Slice','-p','ControlGroup'],
        capture_output=True, text=True, timeout=10)
    if result.returncode: raise RuntimeError('new research service status unavailable')
    return dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)


@contextlib.contextmanager
def operations_lock(root):
    root.mkdir(parents=True,exist_ok=True)
    with (root/'health-backup.lock').open('a+b') as descriptor:
        try: fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as exc: raise OperationsBusy('new research health/backup already running') from exc
        yield


class OperationsBusy(RuntimeError): pass


def collect_resources(paths, *, now=None):
    previous_path = paths.operations/'CGROUP_SAMPLE.json'
    previous = _json(previous_path) if previous_path.exists() else None
    try: boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    except OSError: boot_id=None
    try: cgroup_inode=paths.cgroup.stat().st_ino
    except OSError: cgroup_inode=None
    generation={'boot_id':boot_id,'cgroup_inode':cgroup_inode}
    reset=False
    if previous is not None and previous.get('generation')!=generation:
        # A new kernel/cgroup generation resets CPU counters. Retain the old
        # sample before starting a preliminary baseline; never substitute zero.
        ops.immutable_write(paths.operations/'resource-sample-history'/
            (hashlib.sha256(canonical(previous)).hexdigest()+'.json'),canonical(previous)+b'\n')
        previous=None;reset=True
    try:
        sample = ops.sample_cgroup(paths.cgroup, previous=previous, now=now)
    except (OSError, ValueError) as exc:
        sample = {'cgroup_status':'UNAVAILABLE', 'cgroup_error':type(exc).__name__}
    sample.update(generation=generation,new_cgroup_generation=reset)
    if 'cpu_usage_usec' in sample:ops._shared_atomic(previous_path,sample)
    allocation = ops.unique_storage_bytes([paths.state,paths.operations,paths.code])
    filesystem=os.statvfs(paths.state)
    # All staging is contained in ops; no uncounted third server restore copy.
    return dict(sample, disk_free_bytes=shutil.disk_usage(paths.state).free,
        new_storage_bytes=allocation['unique_allocated_bytes'], storage_inventory=allocation,
        new_file_count=allocation.get('namespace_entries',
            allocation.get('file_paths',allocation['unique_files'])+allocation['unique_directories']),
        new_inode_count=allocation['unique_files']+allocation['unique_directories'],
        disk_free_inodes=filesystem.f_favail,
        free_inodes=filesystem.f_favail,
        storage_roots=[str(paths.state),str(paths.operations),str(paths.code)],
        temporary_space_policy='staging contained in ops; full restores off-server')


def _record_failure(paths, now, stage, exc):
    """Latch failure locally even when release verification or publication fails."""
    config={}
    for root in (paths.state,paths.code):
        try:
            candidate=_json(root/'research.json')
            if not isinstance(candidate,dict):continue
            config=candidate
            break
        except (OSError,ValueError,TypeError): pass
    trial=config.get('trial_id','research-identity-unverified')
    if not isinstance(trial,str):trial='research-identity-unverified'
    try: config_sha=ops.config_hash(config)
    except (ValueError,TypeError): config_sha='UNVERIFIED'
    reason=stage+':'+type(exc).__name__+':'+str(exc)[:300]
    value={'schema':'KOD_RESEARCH_HEALTH_V1','trial_id':trial,'config_sha256':config_sha,
        'epoch':now.timestamp(),'emitted_at':ops.iso(now),'phase':'FAILED','status':'FAILED',
        'collector_epoch':None,'issues':[reason],'failure_stage':stage,
        'research_acceptance':'UNDECIDED; operation failed, manual review required',
        'automatically_promotes_30_day_study':False,'automatic_resume':False}
    paths.state.mkdir(parents=True,exist_ok=True)
    # Preserve the prior status alongside the new failure; never rewrite the
    # immutable event journal, existing pause reason, release or frozen clock.
    previous=paths.state/'HEALTH.json'
    if previous.is_file() and not previous.is_symlink():
        raw=previous.read_bytes()
        immutable_write(paths.state/'ops-failure-evidence'/(hashlib.sha256(raw).hexdigest()+'.json'),raw)
    ops.write_health(paths.state,value)
    immutable_write(paths.state/'ops-failure-evidence'/(hashlib.sha256(canonical(value)).hexdigest()+'.json'),
        canonical(value)+b'\n')
    return value


def operations_once(paths=Paths(), *, publish=False, force_snapshot=False, archive=True,
                    test_roots=None, clock=None, **dependencies):
    # Validate destinations before enabling the failure handler. An invalid path
    # argument can never turn error reporting into a protected-root write.
    validate_paths(paths,test_roots=test_roots)
    progress={'stage':'FROZEN_RELEASE_VERIFICATION'}
    try:
        return _operations_once(paths,publish=publish,force_snapshot=force_snapshot,archive=archive,
            test_roots=test_roots,clock=clock,_progress=progress,**dependencies)
    except OperationsBusy:
        return {'status':'SKIPPED_ALREADY_RUNNING','research_acceptance':'UNDECIDED'}
    except Exception as exc:
        now=(clock or (lambda:dt.datetime.now(ops.UTC)))()
        _record_failure(paths,now,progress['stage'],exc)
        raise


def _operations_once(paths=Paths(), *, publish=False, force_snapshot=False, archive=True,
                    test_roots=None, clock=None, resource_sampler=collect_resources,
                    preservation_check=ops.verify_original, actual_status=service_actual_status,
                    snapshot=ops.research_backup, publisher=ops.scoped_git_backup,_progress=None):
    bundle=verify_release(paths,test_roots=test_roots)
    now=(clock or (lambda:dt.datetime.now(ops.UTC)))()
    if now > bundle['limits']['finalization_end']+dt.timedelta(hours=1):
        return {'status':'FINITE_OPERATIONS_COMPLETE','ended_at':ops.iso(bundle['limits']['finalization_end'])}
    with operations_lock(paths.operations):
        progress=_progress if _progress is not None else {}
        config=bundle['config'];limits=bundle['limits']
        heartbeat_path=paths.state/'RESEARCH_CAPTURE_HEARTBEAT.json'
        heartbeat=_read(heartbeat_path) if heartbeat_path.exists() else {'trial_id':config['trial_id'],'phase':'UNKNOWN'}
        progress['stage']='ACTUAL_NEW_SERVICE_STATUS'
        actual=actual_status()
        if (limits['start']<=now<=limits['drain_end'] and actual.get('ActiveState') not in ('active','activating')):
            heartbeat=dict(heartbeat,phase='HALTED',service_status_reason='actual systemd collector is not active')
        progress['stage']='AGGREGATE_RESOURCE_SAMPLE'
        try: resources=resource_sampler(paths,now=now.timestamp())
        except (OSError,ValueError,RuntimeError) as exc:
            # Unknown resource measurements fail closed, and the pause is made
            # before any Git/network operation that could itself fail.
            resources={'measurement_error':type(exc).__name__+':'+str(exc)[:300]}
        guard_now=(clock or (lambda:dt.datetime.now(ops.UTC)))()
        ops._shared_atomic(paths.operations/'RESOURCE_GUARD.json',{
            'trial_id':config['trial_id'],'config_sha256':ops.config_hash(config),
            'epoch':guard_now.timestamp(),'resources':resources,
            'status':ops.assess_resources(config,resources)['status']})
        progress['stage']='READ_ONLY_ORIGINAL_PRESERVATION'
        preservation=preservation_check(_json(paths.code/bundle['release']['baseline_path']))
        ack_path=paths.operations/'BACKUP_ACK.json'
        ack=_json(ack_path) if ack_path.exists() else None
        state_path=paths.operations/'OPS_STATE.json'
        previous=_json(state_path) if state_path.exists() else {}
        health=ops.health_record(config,heartbeat,resources,preservation,backup_ack=ack,now=now)
        health['service_actual_status']=actual
        predecessor_receipts={}
        for name in ('LAUNCH_RECEIPT.json','CAPACITY_CLOSURE.json','PREDECESSOR_BACKUP_ACK.json','PREDECESSOR_BACKUP_HEAD.json'):
            path=paths.state/name
            if path.exists():predecessor_receipts[name]={'sha256':_hash(path),'record':_json(path)}
        closure_record=predecessor_receipts.get('CAPACITY_CLOSURE.json',{}).get('record',{})
        closure_verified=bool(closure_record.get('capacity_closed_at') and closure_record.get('capacity_after',{}).get('ActiveState') in ('inactive','failed'))
        health['predecessor_capacity']={'status':'CLOSED_EARLY_NOT_PASSED' if closure_verified else 'CLOSURE_NOT_YET_VERIFIED',
            'receipt_hashes_and_records':predecessor_receipts,'prior_capacity_observations_enrolled':False}

        engine_health_path=paths.state/'RESEARCH_ENGINE_HEALTH.json'
        reported_engine=_json(engine_health_path) if engine_health_path.exists() else {'status':'NOT_YET_REPORTED'}
        health['research_engine']=dict(reported_engine.get('health',{}),
            **{key:value for key,value in reported_engine.items() if key!='health'})
        if limits['start']+dt.timedelta(seconds=120)<=now<=limits['finalization_end']:
            engine_epoch=reported_engine.get('epoch')
            if (not isinstance(engine_epoch,(int,float)) or isinstance(engine_epoch,bool)
                    or not 0<=now.timestamp()-engine_epoch<=120):
                health['issues'].append('RESEARCH_ENGINE_HEARTBEAT_STALE_OR_UNKNOWN')
                health['status']='FAILED'

        evidence_path=paths.operations/'ACCEPTANCE_EVIDENCE.json'
        if evidence_path.exists():
            health['acceptance_evidence']={'path':str(evidence_path),'sha256':_hash(evidence_path),'record':_json(evidence_path)}
        else:
            health['acceptance_evidence']={'status':'NOT_YET_DOCUMENTED',
                'required':['restart and gaps','offhost restored-byte verification','external stopped-collection alert and recovery']}

        health=ops.write_health(paths.state,health)
        due=(force_snapshot or not (paths.operations/'repository/HEAD.json').exists()
             or now.timestamp()-previous.get('last_snapshot_epoch',0)>=3600)
        committed=heartbeat.get('last_minute_commit_at')
        first_live_snapshot=(committed is not None and ops.timestamp(committed)>=limits['start']
            and not previous.get('last_snapshot_collector_commit_at'))
        due=due or first_live_snapshot
        publication_due=(force_snapshot or first_live_snapshot or not (paths.operations/'repository/.git').exists()
                         or now.timestamp()-previous.get('last_publication_epoch',0)>=900)
        if due or publication_due:
            progress['stage']='AUTHORITATIVE_CONTROL_SNAPSHOT'
            ops.snapshot_frozen_release(paths.code,paths.operations/'repository',config)
            capture=getattr(ops,'snapshot_research_controls',None)
            if capture is None: raise RuntimeError('authoritative research control backup helper is not ready')
            capture(paths.state,paths.operations,config)
        snapshot_receipt=None
        if due and archive:
            progress['stage']='INCREMENTAL_ARCHIVE_SNAPSHOT'
            snapshot_receipt=snapshot(BroadStore(paths.state),paths.operations,config)
            previous['last_snapshot_epoch']=now.timestamp()
            previous['last_snapshot_collector_commit_at']=committed
            previous['last_snapshot']=snapshot_receipt
            ops._shared_atomic(state_path,previous)
        health['backup_snapshot_this_call']=snapshot_receipt
        health=ops.write_health(paths.state,health)
        published=None
        if publication_due and (paths.operations/'repository/HEAD.json').exists():
            progress['stage']='SCOPED_OFFHOST_PUBLICATION' if publish else 'SCOPED_LOCAL_GIT_COMMIT'
            try:
                published=publisher(paths.operations,config,health=health,publish=publish,
                    ssh_command=SSH_COMMAND if publish else None)
            except ops.BackupTransportTransient as exc:
                if ack is None or not isinstance(ack.get("epoch"),(int,float)) or not 0<=now.timestamp()-ack["epoch"]<=7200:
                    raise
                failure = {'at':ops.iso(now), 'stage':progress['stage'],
                    'error':type(exc).__name__+':'+str(exc)[:300],
                    'offhost_acknowledged':False, 'prior_ack_unchanged':True}
                ops._shared_atomic(paths.operations/'BACKUP_FAILURE.json', failure)
                health['backup_warning']=failure
                health['status']='DEGRADED_BACKUP_TRANSIENT' if health['status'] not in ('FAILED','PAUSED') else health['status']
                ops.write_health(paths.state,health)
                return {'health':health,'backup':snapshot_receipt,'publication':failure,
                    'status':'BACKUP_RETRY_NEXT_BOUNDED_SLOT'}
            previous['last_publication_epoch']=now.timestamp()
            ops._shared_atomic(state_path,previous)
            if published.get('offhost_acknowledged') is True:
                ack=dict(published,epoch=now.timestamp(),at=ops.iso(now))
                ops._shared_atomic(ack_path,ack)
        return {'health':health,'backup':snapshot_receipt,'publication':published,
                'research_phase':'PROSPECTIVE_RESEARCH'}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('run','backup','health','ops'))
    parser.add_argument('--code-root',type=Path,default=CODE_ROOT)
    parser.add_argument('--state-root',type=Path,default=STATE_ROOT)
    parser.add_argument('--ops-root',type=Path,default=OPS_ROOT)
    parser.add_argument('--publish',action='store_true')
    parser.add_argument('--force-snapshot',action='store_true')
    args=parser.parse_args(argv)
    paths=Paths(args.code_root,args.state_root,args.ops_root)
    validate_paths(paths)
    if not Path(__file__).resolve().is_relative_to(paths.code):
        raise ValueError('execute the verified research release, not an outside module')
    if args.action=='run':
        if args.publish or args.force_snapshot: parser.error('worker run does not publish backups')
        value=run_trial(paths)
    else:
        value=operations_once(paths,publish=args.publish,force_snapshot=args.force_snapshot,
            archive=True)
    if args.action=='run':
        output={key:value.get(key) for key in ('trial_id','phase','as_of','last_minute_commit_at','epoch')}
    else:
        output={'action':args.action,'status':value.get('status',value.get('health',{}).get('status')),
            'trial_id':value.get('health',{}).get('trial_id'),
            'health_path':str(paths.state/'HEALTH.json'),
            'publication_commit':(value.get('publication') or {}).get('commit'),
            'offhost_acknowledged':(value.get('publication') or {}).get('offhost_acknowledged',False)}
    print(json.dumps(output,sort_keys=True,ensure_ascii=False))
    return 0


if __name__=='__main__': main()
