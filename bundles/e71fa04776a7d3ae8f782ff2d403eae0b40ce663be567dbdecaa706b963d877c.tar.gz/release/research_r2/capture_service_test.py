import datetime as dt
import json
from pathlib import Path
import shutil
import tempfile
import threading
import unittest
from unittest.mock import patch

from research_r2 import capture_service as service, capture_ops as ops
from research_r2.capture_test import config
from broad_observer.backup import canonical
from broad_observer.store import BroadStore, iso, UTC

class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name).resolve()
        self.paths=service.Paths(self.root/'code',self.root/'state',self.root/'ops',self.root/'cgroup')
        self.roots=(self.paths.code,self.paths.state,self.paths.operations)
        for path in self.roots:path.mkdir()
        (self.paths.code/'research_r2').mkdir();(self.paths.code/'broad_observer').mkdir()
        (self.paths.code/'authoritative').mkdir()
        self.put('research_r2/fake.py',b'# fixture research runtime\n')
        self.put('broad_observer/fake.py',b'# fixture transport runtime\n')
        for name in ('PROTOCOL_R2.md','Pasted text(5).txt'):
            shutil.copyfile(Path(__file__).parents[1]/'authoritative'/name,self.paths.code/'authoritative'/name)
        self.config=config()
        rows=[{'symbol':symbol,'median_quote_volume_30d':'1000000'} for symbol in self.config['primary_symbols']]
        self.config['primary']=rows
        self.put('universe.json',{'primary':rows,'primary_symbols':self.config['primary_symbols'],'certified_top150':True,'blockers':[]})
        self.put('detail.json',{'symbols':self.config['detailed_symbols']})
        self.put('metadata.raw',{'symbols':[]});self.put('baseline.json',{})
        self.put('sources.json',{'GMX':'SOURCE_NOT_COVERED_UNTIL_VERIFIED'})
        self.put('STARTUP_AMENDMENT.md',b'Capacity not passed. Separate prospective cohort.\n')
        self.release={'files':{},'protocol_sha256':ops.PROTOCOL_R2_SHA256,'attachment_sha256':ops.ATTACHMENT_SHA256,
            'universe_path':'universe.json','universe_sha256':service._hash(self.paths.code/'universe.json'),
            'detail_path':'detail.json','detail_sha256':service._hash(self.paths.code/'detail.json'),
            'baseline_path':'baseline.json','metadata_path':'metadata.raw','source_manifest_path':'sources.json',
            'startup_amendment_path':'STARTUP_AMENDMENT.md'}
        self.config['selection_manifest_sha256']=self.release['universe_sha256']
        self.freeze()

    def put(self,name,value):
        (self.paths.code/name).write_bytes(value if isinstance(value,bytes) else canonical(value)+b'\n')

    def freeze(self):
        self.release['files']={str(p.relative_to(self.paths.code)):service._hash(p)
            for p in self.paths.code.rglob('*') if p.is_file() and p.name not in ('RESEARCH_RELEASE.json','research.json','PACKAGE.json')}
        self.put('RESEARCH_RELEASE.json',self.release)
        self.config['release_manifest_sha256']=service._hash(self.paths.code/'RESEARCH_RELEASE.json')
        self.put('research.json',self.config)
        self.put('PACKAGE.json',{'config_sha256':service._hash(self.paths.code/'research.json'),
            'release_manifest_sha256':self.config['release_manifest_sha256']})

    def verify(self):return service.verify_release(self.paths,test_roots=self.roots)

    def test_exact_new_roots_and_manifested_runtime(self):
        self.assertEqual(self.verify()['config']['phase'],'RESEARCH35D')
        with self.assertRaises(ValueError):service.validate_paths(self.paths)
        for path in ('/var/lib/kod/capacity-r2','/var/lib/kod/timing-forward','/var/lib/kod/supplement-v1'):
            with self.assertRaises(ValueError):service.validate_paths(service.Paths(state=Path(path)))
        self.put('research_r2/unfrozen.py',b'bad')
        with self.assertRaisesRegex(ValueError,'unmanifested Python'):self.verify()

    def test_scientific_universe_and_startup_amendment_required(self):
        self.config['primary'][0]['median_quote_volume_30d']='2000000';self.freeze()
        with self.assertRaisesRegex(ValueError,'liquidity rows'):self.verify()
        self.config['primary'][0]['median_quote_volume_30d']='1000000';self.freeze()
        del self.release['startup_amendment_path'];self.freeze()
        with self.assertRaisesRegex(ValueError,'startup_amendment'):self.verify()

    def test_clock_identity_and_source_file_mutation_fail_closed(self):
        self.put('sources.json',{'changed':True})
        with self.assertRaisesRegex(ValueError,'hash differs'):self.verify()
        self.freeze();self.config['admission_end_at']='2026-12-06T08:00:00Z';self.freeze()
        with self.assertRaisesRegex(ValueError,'30-day'):self.verify()

    def test_frozen_release_backup_contains_runtime_and_source_bytes(self):
        repository=self.paths.operations/'repository';repository.mkdir()
        first=ops.snapshot_frozen_release(self.paths.code,repository,self.config)
        self.assertEqual(first['status'],'SNAPSHOT_LOCAL')
        self.assertEqual((repository/'release/research_r2/fake.py').read_bytes(),b'# fixture research runtime\n')
        second=ops.snapshot_frozen_release(self.paths.code,repository,self.config)
        self.assertEqual(second['status'],'NO_CHANGE')

    def test_cgroup_missing_preserves_real_disk_and_inode_measurements(self):
        result=service.collect_resources(self.paths)
        self.assertGreater(result['disk_free_bytes'],0)
        self.assertGreater(result['free_inodes'],0)
        self.assertEqual(result['cgroup_status'],'UNAVAILABLE')
        self.assertNotIn('memory_current_bytes',result)

    def test_operations_are_finite_without_network_after_final_window(self):
        now=ops.timestamp(self.config['finalization_end_at'])+dt.timedelta(hours=2)
        result=service.operations_once(self.paths,test_roots=self.roots,clock=lambda:now)
        self.assertEqual(result['status'],'FINITE_OPERATIONS_COMPLETE')
        self.assertEqual(list(self.paths.operations.iterdir()),[])

    def test_engine_waits_for_first_archive_instead_of_latching_failure(self):
        now=ops.timestamp(self.config['t0'])-dt.timedelta(seconds=1)
        stop=threading.Event()
        class FakeEngine:
            def __init__(self,*args):pass
            def health(self):return {'processed_receipt_watermark':iso(now)}
            def export_incremental(self,*args,**kwargs):return {'records':0,'last_seq':0}
            def close(self):pass
        original_wait=stop.wait
        def one_wait(timeout):stop.set();return True
        stop.wait=one_wait
        with patch('research_r2.engine.ResearchEngine',FakeEngine):
            service.research_engine_worker(self.paths,self.config,stop,clock=lambda:now)
        value=json.loads((self.paths.state/'RESEARCH_ENGINE_HEALTH.json').read_bytes())
        self.assertTrue(value['scientific_enrollment_enabled'])
        self.assertFalse(value['new_admissions_open'])
        self.assertEqual(value['study_phase'],'WAITING')
        self.assertFalse((self.paths.state/'PAUSED.json').exists())

    def test_restart_waits_bounded_for_new_guard_without_starting_requests(self):
        from types import SimpleNamespace
        current=[ops.timestamp(self.config['t0'])+dt.timedelta(hours=2)]
        elapsed=[0.0];heartbeats=[]
        collector=SimpleNamespace(state={'phase':'RUNNING'},heartbeat=lambda:heartbeats.append(current[0]))
        def sleeper(seconds):
            elapsed[0]+=seconds;current[0]+=dt.timedelta(seconds=seconds)
            if elapsed[0]>=15:
                ops._shared_atomic(self.paths.operations/'RESOURCE_GUARD.json',{
                    'trial_id':self.config['trial_id'],'config_sha256':ops.config_hash(self.config),
                    'status':'OK','epoch':current[0].timestamp()})
        result=service.wait_for_startup_guard(self.paths,self.config,collector,threading.Event(),
            clock=lambda:current[0],monotonic=lambda:elapsed[0],sleeper=sleeper)
        self.assertEqual(result['status'],'FRESH_AGGREGATE_GUARD')
        self.assertEqual(collector.state['phase'],'RUNNING');self.assertGreater(len(heartbeats),0)
        self.assertEqual(elapsed[0],15)
        self.assertFalse((self.paths.state/'PAUSED.json').exists())

    def test_restart_does_not_clear_pause_or_wait_beyond_sixty_seconds(self):
        from types import SimpleNamespace
        current=[ops.timestamp(self.config['t0'])+dt.timedelta(hours=2)];elapsed=[0.0]
        collector=SimpleNamespace(state={'phase':'RUNNING'},heartbeat=lambda:None)
        def sleeper(seconds):elapsed[0]+=seconds;current[0]+=dt.timedelta(seconds=seconds)
        with self.assertRaisesRegex(RuntimeError,'60 seconds'):
            service.wait_for_startup_guard(self.paths,self.config,collector,threading.Event(),
                clock=lambda:current[0],monotonic=lambda:elapsed[0],sleeper=sleeper)
        self.assertEqual(elapsed[0],60)
        (self.paths.state/'PAUSED.json').write_text('{"original":"stop reason"}')
        before=(self.paths.state/'PAUSED.json').read_bytes()
        result=service.wait_for_startup_guard(self.paths,self.config,collector,threading.Event(),
            clock=lambda:current[0],monotonic=lambda:elapsed[0],sleeper=sleeper)
        self.assertEqual(result['status'],'EXISTING_STOP_LATCH')
        self.assertEqual((self.paths.state/'PAUSED.json').read_bytes(),before)

    def test_changed_cgroup_generation_retains_old_sample_and_restarts_cpu_baseline(self):
        group=self.paths.cgroup;group.mkdir()
        for name,value in {'cpu.stat':'usage_usec 100\n','memory.events':'oom 0\noom_kill 0\n',
                'memory.current':'1000000','memory.peak':'2000000'}.items():(group/name).write_text(value)
        old={'epoch':1000,'cpu_usage_usec':999999,'generation':{'boot_id':'old-boot','cgroup_inode':1}}
        ops._shared_atomic(self.paths.operations/'CGROUP_SAMPLE.json',old)
        result=service.collect_resources(self.paths,now=1010)
        self.assertTrue(result['new_cgroup_generation']);self.assertIsNone(result['cpu_fraction'])
        self.assertEqual(result['memory_current_bytes'],1000000)
        evidence=list((self.paths.operations/'resource-sample-history').glob('*.json'))
        self.assertEqual(len(evidence),1);self.assertEqual(json.loads(evidence[0].read_bytes()),old)
        (group/'cpu.stat').write_text('usage_usec 1\n')
        result=service.collect_resources(self.paths,now=1020)
        self.assertEqual(result['cgroup_status'],'UNAVAILABLE')
        self.assertGreater(result['disk_free_bytes'],0)

if __name__=='__main__':unittest.main()
