"""Minimal, explicitly scoped R2 package and one-time isolated installation.

No remote operations are performed when importing or building. Installation is
an explicit root-only CLI action on the existing Linux host. Existing original
and supplement units are never written or controlled. Only the separate capacity
collector can be closed at the handoff, with its old bytes preserved.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import pwd
import shutil
import subprocess
import sys
import time

UTC=dt.timezone.utc
CODE=Path('/opt/kod/research-r2')
STATE=Path('/var/lib/kod/research-r2')
OPS=Path('/var/lib/kod-research-r2-ops')
STAGE=Path('/opt/kod/.research-r2.installing')
UNIT_ROOT=Path('/etc/systemd/system')
COLLECTOR='kod-research-r2.service'
BACKUP='kod-research-r2-backup.service'
TIMER='kod-research-r2-backup.timer'
SLICE='kod-research-r2.slice'
UNIT_NAMES=(COLLECTOR,BACKUP,TIMER,SLICE)
WRAPPERS={'research.json','RESEARCH_RELEASE.json','PACKAGE.json'}
OLD_COLLECTOR='kod-capacity-r2.service'
OLD_TIMER='kod-capacity-r2-backup.timer'
OLD_BACKUP='kod-capacity-r2-backup.service'
MIN_FREE=2*1024**3


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as source:
        while block:=source.read(65536):digest.update(block)
    return digest.hexdigest()
def timestamp(value):
    instant=dt.datetime.fromisoformat(value.replace('Z','+00:00')) if isinstance(value,str) else value
    if instant.tzinfo is None:raise ValueError('aware UTC timestamp required')
    return instant.astimezone(UTC)
def iso(value):return timestamp(value).isoformat().replace('+00:00','Z')
def now():return dt.datetime.now(UTC)
def relative(value):
    p=PurePosixPath(value)
    if (not isinstance(value,str) or p.is_absolute() or '..' in p.parts or not p.parts
            or str(p)!=value or '\\' in value):raise ValueError('unsafe package path')
    return p

def unit_texts(config):
    start=timestamp(config['t0']); end=timestamp(config['finalization_end_at'])
    frozen=timestamp(config['frozen_at'])
    runtime=int((end-frozen).total_seconds())+600
    if not 35*86400<=runtime<=36*86400:raise ValueError('runtime is not finite35daystudy')
    base='''Environment=PYTHONDONTWRITEBYTECODE=1
Environment=PYTHONUNBUFFERED=1
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
NoNewPrivileges=true
RestrictSUIDSGID=true
LockPersonality=true
UMask=0027
'''
    worker=f'''[Unit]
Description=Finite prospective KOD R2 research observer
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=600
StartLimitBurst=3
[Service]
Type=simple
User=kod
Group=kod
Slice={SLICE}
WorkingDirectory={CODE}
{base}ReadWritePaths={STATE}
ExecStart=/usr/bin/python3 -B -m research_r2.capture_service run
Restart=on-failure
RestartSec=10
RuntimeMaxSec={runtime}
TimeoutStopSec=150
KillMode=control-group
[Install]
WantedBy=multi-user.target
'''
    backup=f'''[Unit]
Description=Scoped R2 research health and incremental backup
After=network-online.target
[Service]
Type=oneshot
User=root
Slice={SLICE}
WorkingDirectory={CODE}
{base}ReadWritePaths={STATE} {OPS}
ExecStart=/usr/bin/python3 -B -m research_r2.capture_service backup --publish
TimeoutStartSec=600
TimeoutStopSec=30
'''
    calendars=[]; day=start.date(); last=(end+dt.timedelta(hours=1)).date()
    while day<=last:
        calendars.append('OnCalendar='+day.isoformat()+' *:*:30 UTC'); day+=dt.timedelta(days=1)
    timer='''[Unit]
Description=Finite R2 research resource guard and backup schedule
[Timer]
Unit=kod-research-r2-backup.service
AccuracySec=1s
RandomizedDelaySec=0
Persistent=false
'''+ '\n'.join(calendars)+'''\n[Install]
WantedBy=timers.target
'''
    envelope='''[Unit]
Description=Isolated R2 research total resource envelope
[Slice]
MemoryAccounting=true
CPUAccounting=true
MemoryMax=192M
CPUQuota=10%
'''
    return dict(zip(UNIT_NAMES,(worker,backup,timer,envelope)))


def warmup_files(root, prefix='research_r2/warmup'):
    """Minimal exact raw/receipt inputs; exclude acquisition locks and derived rows."""
    import gzip
    root=Path(root).resolve();relative(prefix)
    manifest=root/'MANIFEST.json'
    if manifest.is_symlink() or not manifest.is_file():raise ValueError('warmup manifest absent')
    value=json.loads(manifest.read_bytes())
    if value.get('kind')!='BOOTSTRAP_NOT_PROSPECTIVE':raise ValueError('warmup classification differs')
    result={prefix+'/MANIFEST.json':manifest};parents=set()
    for record in value['responses']:
        name=record['raw_path'];relative(name);path=root/name
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
            raise ValueError('unsafe warmup source')
        raw=gzip.decompress(path.read_bytes())
        if hashlib.sha256(raw).hexdigest()!=record['raw_sha256']:
            raise ValueError('warmup raw hash differs:'+name)
        result[prefix+'/'+name]=path;parents.add(path.parent)
        receipt=path.with_name(path.name.removesuffix('.raw.gz')+'.receipt.json')
        if receipt.is_file() and not receipt.is_symlink():
            result[prefix+'/'+str(receipt.relative_to(root))]=receipt
    for parent in parents:
        acquisition=parent/'MANIFEST.json'
        if acquisition.is_file() and not acquisition.is_symlink():
            result[prefix+'/'+str(acquisition.relative_to(root))]=acquisition
    return result


def build_package(destination, config, files, *, release_metadata=None, test_modules=()):
    """Copy an explicit relative-path=>source map; never discover arbitrary data."""
    dest=Path(destination)
    if dest.exists() or dest.is_symlink():raise FileExistsError('package already exists; preserve/reconcile')
    config=dict(config); entries={}
    units=unit_texts(config)
    if set(files)&(WRAPPERS|set(units)):raise ValueError('caller supplied bound wrappers or units')
    for name,source in files.items():
        relative(name); source=Path(source)
        if source.is_symlink() or not source.is_file():raise ValueError('regular source required:'+name)
    # Validate everything possible before creating the new destination.
    from .capture_ops import validate_config
    validate_config(config)
    dest.mkdir(parents=True)
    for name,source in sorted(files.items()):
        target=dest/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
        os.chmod(target,0o444)
        entries[name]={'sha256':sha(target),'bytes':target.stat().st_size}
    for name,body in units.items():
        (dest/name).write_text(body)
        entries[name]={'sha256':sha(dest/name),'bytes':(dest/name).stat().st_size}
    metadata=dict(release_metadata or {})
    if {'files','test_modules'}&set(metadata):raise ValueError('reserved release metadata')
    release=dict(metadata,schema='KOD_RESEARCH_R2_RELEASE_V1',files=entries,test_modules=list(test_modules))
    (dest/'RESEARCH_RELEASE.json').write_bytes(canonical(release))
    config['release_manifest_sha256']=sha(dest/'RESEARCH_RELEASE.json')
    (dest/'research.json').write_bytes(canonical(config))
    package={'schema':'KOD_RESEARCH_R2_PACKAGE_V1','study_id':config['trial_id'],
        'release_manifest_sha256':sha(dest/'RESEARCH_RELEASE.json'),
        'config_sha256':sha(dest/'research.json'),'runtime_file_count':len(entries),
        'runtime_file_bytes':sum(x['bytes'] for x in entries.values())}
    (dest/'PACKAGE.json').write_bytes(canonical(package))
    validate_package(dest,require_future=False)
    return package


def validate_package(package_dir, *, require_future=True, instant=None):
    from .capture_service import verify_release,Paths
    root=Path(package_dir).resolve()
    for path in root.rglob('*'):
        if path.is_symlink():raise ValueError('symlink in research package')
    cfg=json.loads((root/'research.json').read_bytes())
    release=json.loads((root/'RESEARCH_RELEASE.json').read_bytes())
    package=json.loads((root/'PACKAGE.json').read_bytes())
    if not isinstance(release.get('files'),dict) or not release['files']:raise ValueError('empty release')
    if WRAPPERS&set(release['files']):raise ValueError('circular release binding')
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    if actual!=set(release['files'])|WRAPPERS:raise ValueError('unlisted or missing package bytes')
    for name,record in release['files'].items():
        relative(name)
        if not isinstance(record,dict) or (root/name).stat().st_size!=record['bytes']:
            raise ValueError('member size mismatch:'+name)
    for field,path in (('code_root',CODE),('state_root',STATE),('ops_root',OPS)):
        if cfg.get(field)!=str(path):raise ValueError('wrong isolated '+field)
    for key in ('real_orders_or_capital_allocation','automatic_extension','economic_enrollment_enabled'):
        if cfg.get(key) is not False:raise ValueError('unsupported scope:'+key)
    paths=Paths(root,root.parent/(root.name+'.validate-state'),root.parent/(root.name+'.validate-ops'))
    verified=verify_release(paths,test_roots=(paths.code,paths.state,paths.operations))
    if any((root/name).read_text()!=body for name,body in unit_texts(cfg).items()):
        raise ValueError('unit differs from exact isolated template')
    if require_future and timestamp(cfg['t0'])<=timestamp(instant or now()):
        raise ValueError('prospective T0 is no longer future; preserve package as unlaunched')
    if package.get('study_id')!=cfg['trial_id']:raise ValueError('package identity differs')
    return verified


def _run(args, *, timeout=30, cwd=None, env=None):
    result=subprocess.run(args,check=True,capture_output=True,text=True,timeout=timeout,cwd=cwd,env=env)
    return result.stdout

def _props(unit):
    fields=('Id','LoadState','ActiveState','SubState','FragmentPath','UnitFileState','Transient','DropInPaths','MainPID')
    return dict(x.split('=',1) for x in _run(['systemctl','show',unit,*[q for f in fields for q in ('-p',f)]]).splitlines())


def ancestor_envelopes(cgroup_root=Path('/sys/fs/cgroup')):
    """Read common/new-parent ceilings; never configure a shared ancestor."""
    root=Path(cgroup_root);result={}
    for relative_name in ('kod.slice','kod.slice/kod-research.slice'):
        parent=root/relative_name
        if not parent.exists():
            if relative_name=='kod.slice':raise ValueError('existing common kod.slice is absent')
            result[relative_name]=None
        else:
            result[relative_name]={name:(parent/name).read_text().strip() for name in ('cpu.max','memory.max')}
    return result


def verify_ancestor_envelopes(before,after):
    if set(before)!=set(after):raise ValueError('ancestor envelope scope changed')
    for name,old in before.items():
        new=after[name]
        if old is not None and new!=old:raise ValueError('shared or pre-existing ancestor ceiling changed:'+name)
        if old is None and new is not None:
            if new['cpu.max'].split()[0]!='max' or new['memory.max']!='max':
                raise ValueError('new implicit ancestor unexpectedly constrained:'+name)
    return {'unchanged_existing_ancestors':True,'new_implicit_ancestor_unlimited':True,'before':before,'after':after}

def assert_new_targets_absent():
    for path in (CODE,STATE,OPS,STAGE,UNIT_ROOT/'timers.target.wants'/TIMER,
                 UNIT_ROOT/'multi-user.target.wants'/COLLECTOR):
        if path.exists() or path.is_symlink():raise FileExistsError('existing new target:'+str(path))
    for folder in ('/etc/systemd/system','/run/systemd/system','/usr/lib/systemd/system','/lib/systemd/system'):
        for unit in UNIT_NAMES:
            for suffix in ('','.d'):
                p=Path(folder)/(unit+suffix)
                if p.exists() or p.is_symlink():raise FileExistsError('existing new unit:'+str(p))
    for unit in UNIT_NAMES:assert_new_unit_available(unit,_props(unit))


def assert_new_unit_available(unit,p):
    if unit not in UNIT_NAMES:raise ValueError('unscoped unit')
    if (p.get('Id')!=unit or p.get('ActiveState')!='inactive' or p.get('SubState')!='dead'
            or p.get('FragmentPath') or p.get('UnitFileState') or p.get('DropInPaths')
            or p.get('Transient')!='no' or p.get('MainPID') not in ('','0',None)
            or p.get('LoadState') not in ({'not-found','loaded'} if unit==SLICE else {'not-found'})):
        raise FileExistsError('existing or uncertain new unit:'+unit)
    return 'INERT_IMPLICIT_SLICE' if p['LoadState']=='loaded' else 'ABSENT'


def _exclusive(path,value, *, uid=None,gid=None):
    raw=canonical(value)
    with Path(path).open('xb') as target:
        if uid is not None:os.fchown(target.fileno(),uid,gid)
        target.write(raw);target.flush();os.fsync(target.fileno())


def copy_launch_evidence(source,destination, *, reader_gid):
    """Copy exact receipt bytes once; root owns them and the worker can read."""
    source,destination=Path(source),Path(destination)
    if source.is_symlink() or not source.is_file():raise ValueError('regular launch evidence required')
    raw=source.read_bytes()
    with destination.open('xb') as output:
        os.fchmod(output.fileno(),0o440)
        if os.geteuid()==0:os.fchown(output.fileno(),0,reader_gid)
        output.write(raw);output.flush();os.fsync(output.fileno())
    return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),
            'source_name':source.name,'state_name':destination.name,'exact_copy':True}


def install(package_dir, *, close_capacity=False):
    """One auditable handoff; errors retain staged bytes and exact stopped state."""
    if platform.system()!='Linux' or os.geteuid()!=0:raise RuntimeError('existing Linux root required')
    if not close_capacity:raise ValueError('explicit existing separate-capacity handoff flag required')
    bundle=validate_package(package_dir);cfg=bundle['config'];release=bundle['release'];src=Path(package_dir).resolve()
    if cfg.get('integration_test_only'):raise ValueError('synthetic package cannot be installed')
    assert_new_targets_absent()
    user=pwd.getpwnam('kod')
    from .capture_ops import verify_original
    baseline=json.loads((src/release['baseline_path']).read_bytes())
    before=verify_original(baseline)
    if before.get('unchanged') is not True:raise RuntimeError('protected collectors differ before handoff')
    ancestors_before=ancestor_envelopes()
    if shutil.disk_usage(CODE.parent).free-cfg['hard_storage_bytes']-cfg['overshoot_reserve_bytes']<MIN_FREE:
        raise RuntimeError('current host free reserve fails')
    tests=release.get('test_modules')
    if not isinstance(tests,list) or not tests:raise ValueError('new tested release modules required')
    test=_run(['/usr/bin/python3','-B','-m','unittest',*tests],timeout=300,cwd=src,
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(src)))
    verify=_run(['systemd-analyze','verify',*[str(src/n) for n in UNIT_NAMES]],timeout=30)
    validate_package(src)
    # Do not kill a backup writer. Its exact current state is retained.
    deadline=time.monotonic()+65
    while _props(OLD_BACKUP).get('ActiveState') in ('active','activating','deactivating'):
        if time.monotonic()>deadline:raise RuntimeError('capacity backup still active; no changes made')
        time.sleep(.5)
    assert_new_targets_absent()
    receipt={'schema':'KOD_RESEARCH_R2_INSTALL_V1','started_at':iso(now()),'phase':'INSTALLING_NOT_LIVE',
        'trial_id':cfg['trial_id'],'package':bundle['package'],'before':before,'ancestors_before':ancestors_before,
        'capacity_before':_props(OLD_COLLECTOR),'capacity_timer_before':_props(OLD_TIMER),
        'capacity_acceptance':'NOT_PASSED; explicit start-now operational amendment',
        'first_prospective_record_verified':False,'test_stdout':test[-4000:],'systemd_verify':verify[-2000:]}
    stopped_old=False;timer_stopped=False;new_started=False
    try:
        STAGE.mkdir(mode=0o755)
        for name in sorted(set(release['files'])|WRAPPERS):
            target=STAGE/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/name,target)
        for path in STAGE.rglob('*'):
            os.chown(path,0,0);os.chmod(path,0o555 if path.is_dir() else 0o444)
        os.rename(STAGE,CODE);os.chmod(CODE,0o555)
        validate_package(CODE)  # Verify the transferred exact bytes before handoff.
        STATE.mkdir(mode=0o750);os.chown(STATE,user.pw_uid,user.pw_gid)
        OPS.mkdir(mode=0o750);os.chown(OPS,0,user.pw_gid)
        for name in UNIT_NAMES:
            with (UNIT_ROOT/name).open('xb') as target:target.write((CODE/name).read_bytes())
            os.chmod(UNIT_ROOT/name,0o644)
        # Preserve copied diagnostic bytes before the explicit early closure.
        closure=OPS/'capacity-closure-evidence';closure.mkdir(mode=0o750)
        for name in ('HEALTH.json','CAPACITY_HEARTBEAT.json','CAPACITY_STATE.json','PAUSED.json'):
            source=Path('/var/lib/kod/capacity-r2')/name
            if source.is_file() and not source.is_symlink():shutil.copyfile(source,closure/name)
        _run(['systemctl','stop',OLD_TIMER]);timer_stopped=True
        if _props(OLD_BACKUP).get('ActiveState') in ('active','activating','deactivating'):
            raise RuntimeError('capacity backup became active before handoff; no collector stopped')
        _run(['systemctl','stop',OLD_COLLECTOR],timeout=160);stopped_old=True
        receipt['capacity_closed_at']=iso(now());receipt['capacity_after']=_props(OLD_COLLECTOR)
        if receipt['capacity_after'].get('ActiveState') not in ('inactive','failed'):
            raise RuntimeError('capacity shutdown uncertain; research not started')
        # Preserve the final old state without writing its scientific or historical records.
        for name in ('CAPACITY_HEARTBEAT.json','CAPACITY_STATE.json'):
            source=Path('/var/lib/kod/capacity-r2')/name
            if source.is_file() and not source.is_symlink():shutil.copyfile(source,closure/('final-'+name))
        predecessor_backup={}
        for old_name,new_name in (('BACKUP_ACK.json','PREDECESSOR_BACKUP_ACK.json'),
                ('repository/HEAD.json','PREDECESSOR_BACKUP_HEAD.json')):
            source=Path('/var/lib/kod-capacity-r2-ops')/old_name
            predecessor_backup[new_name]=(copy_launch_evidence(source,STATE/new_name,reader_gid=user.pw_gid)
                if source.is_file() and not source.is_symlink() else {'present':False,'status':'UNAVAILABLE_AT_CLOSURE'})
        receipt['predecessor_status']='CLOSED_EARLY_NOT_PASSED'
        receipt['predecessor_backup_evidence']=predecessor_backup
        receipt['predecessor_final_state_sha256']=sha(closure/'final-CAPACITY_STATE.json')
        _exclusive(closure/'CLOSURE.json',dict(receipt,capacity_original_declared_end='2026-11-07T08:27:00Z',
            reason='Owner-directed fresh research cohort; old capacity was not passed or reclassified'))
        receipt['capacity_closure_evidence']=copy_launch_evidence(closure/'CLOSURE.json',
            STATE/'CAPACITY_CLOSURE.json',reader_gid=user.pw_gid)
        if timestamp(cfg['t0'])<=now():raise RuntimeError('T0 passed during handoff; new package remains unlaunched')
        _run(['systemctl','daemon-reload'])
        new_started=True  # Treat a timed-out enable/start as an uncertain mutation.
        _run(['systemctl','enable','--now',COLLECTOR])
        _run(['systemctl','enable','--now',TIMER])
        after=verify_original(baseline)
        ancestor_check=verify_ancestor_envelopes(ancestors_before,ancestor_envelopes())
        receipt.update(phase='ARMED_NOT_YET_VERIFIED_LIVE',completed_at=iso(now()),after=after,
            ancestor_envelope_check=ancestor_check,
            collector=_props(COLLECTOR),timer=_props(TIMER),t0=cfg['t0'],
            admission_end_at=cfg['admission_end_at'],receipt_drain_end=cfg['receipt_drain_end'])
        _exclusive(OPS/'INSTALLATION.json',receipt)
        copy_launch_evidence(OPS/'INSTALLATION.json',STATE/'LAUNCH_RECEIPT.json',reader_gid=user.pw_gid)
        if not after.get('unchanged'):raise RuntimeError('protected preservation differs after installation')
        return receipt
    except BaseException as exc:
        receipt.update(phase='FAILED_OR_UNCERTAIN_INSTALL',failed_at=iso(now()),
            error=type(exc).__name__+':'+str(exc)[:1000],capacity_stopped=stopped_old,
            capacity_timer_stopped=timer_stopped,automatic_retry=False)
        if OPS.is_dir():
            target=OPS/('FAILED_INSTALL_'+now().strftime('%Y%m%dT%H%M%S%fZ')+'.json')
            _exclusive(target,receipt)
        if new_started:
            for unit in (TIMER,COLLECTOR):
                # A known failed install must not silently restart on reboot.
                try:_run(['systemctl','disable','--now',unit],timeout=160)
                except Exception:pass  # Exact outcome must be reconciled, never implied.
        elif timer_stopped and not stopped_old:
            # Handoff never happened; restore only the same separate capacity timer.
            try:_run(['systemctl','start',OLD_TIMER])
            except Exception:pass
        # No automatic collector rollback/restart: reconcile outcome and frozen T0.
        raise


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',required=True)
    p.add_argument('--install',action='store_true');p.add_argument('--close-capacity',action='store_true')
    args=p.parse_args()
    if args.install:result=install(args.package,close_capacity=args.close_capacity)
    else:
        value=validate_package(args.package);result={'status':'VALIDATED_NOT_INSTALLED','package':value['package']}
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))
def watchdog_workflow(config,config_sha256):
    """New workflow only; owner must publish via existing authorized GitHub route.

    Checkout/config/checker paths are fixed. The token is GitHub's existing
    workflow token and only contents-read is requested; no credentials created.
    """
    import re
    branch=config['trial_id']
    if not re.fullmatch(r'research-[A-Za-z0-9_-]+',branch) or not re.fullmatch(r'[a-f0-9]{64}',config_sha256):
        raise ValueError('unsafe frozen monitor identity')
    end=iso(timestamp(config['finalization_end_at'])+dt.timedelta(hours=2))
    return f'''name: KOD R2 research health
on:
  workflow_dispatch:
  schedule:
    - cron: '11,41 * * * *'
permissions:
  contents: read
concurrency:
  group: kod-research-r2-watchdog
  cancel-in-progress: false
jobs:
  check:
    runs-on: ubuntu-latest
    timeout-minutes: 4
    steps:
      - uses: actions/checkout@v4
      - name: Check prospective research health
        env:
          GITHUB_TOKEN: ${{{{ github.token }}}}
        run: >-
          python3 tools/research_r2_watchdog.py
          --branch {branch}
          --config-sha256 {config_sha256}
          --config controls/research-r2/research.json
          --monitor-end {end}
'''


if __name__=='__main__':main()
