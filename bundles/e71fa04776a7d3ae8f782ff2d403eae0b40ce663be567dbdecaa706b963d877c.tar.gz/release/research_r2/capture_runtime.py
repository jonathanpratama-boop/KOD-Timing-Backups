"""Research-only relevant-symbol activity transport; frozen old adapters untouched."""
import datetime as dt
import hashlib
import json
import math
import urllib.parse
from broad_observer import adapters as base
from broad_observer.adapters import (PublicBatchAdapters, ENDPOINTS, BASE, TIMEOUTS, SELECTED_HEADERS,
    _cohort_symbols, _metadata_rows, _index_batch, normalize_batch)
from broad_observer.store import iso
from broad_observer.runtime import RestLanes, WorkerPaused
from .store import ResearchStore


class ResearchMarketAdapters(PublicBatchAdapters):
    def _request(self,kind,*,symbols=None,timeout=None):
        if kind not in ENDPOINTS:
            raise ValueError('unknown fixed endpoint')
        url = BASE + ENDPOINTS[kind]
        if symbols is not None:
            if kind not in ('bbo','stats'):
                raise ValueError('symbols query permitted only for explicit BBO/activity batch')
            symbols = _cohort_symbols(symbols)
            if not symbols:
                raise ValueError('explicit BBO symbol batch must not be empty')
            url += '?' + urllib.parse.urlencode({'symbols':json.dumps(symbols,ensure_ascii=False,separators=(',',':'))})
        timeout = TIMEOUTS[kind] if timeout is None else min(float(timeout),TIMEOUTS[kind])
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError('positive bounded timeout required')
        start = iso(self.now_fn()); monotonic_start = self.monotonic(); self.sequence += 1
        attempt = {'kind':kind,'url':url,'method':'GET','request_started_at':start,
            'received_at':None,'source_timestamp':None,'http_status':None,'status':'FAILED',
            'attempted':False,'headers':{},'body':b'','raw_truncated':False,
            'response_body_complete':False,'capture_status':'NO_RESPONSE_CAPTURED',
            'max_response_bytes':self.max_bytes,'timeout_seconds':timeout}
        if symbols is not None:
            attempt['request_symbols']=list(symbols)
            attempt['transport_mode']='EXPLICIT_FROZEN_SYMBOL_BATCH'
        attempt['request_id'] = hashlib.sha256((url+start+str(self.sequence)).encode()).hexdigest()
        if self.halted:
            attempt.update(status='BLOCKED_LATCHED',received_at=iso(self.now_fn()),
                block_reason=self.halt_reason,requires_operator_review=True,
                elapsed_seconds_monotonic=0)
            return None,attempt
        if self.audit:
            self.audit('request_started',{key:value for key,value in attempt.items() if key!='body'})
        # Errors from audit callbacks remain fatal; source failures cannot hide a
        # durable-store failure. No retries or alternate endpoints exist here.
        try:
            attempt['attempted'] = True
            transport_started=self.monotonic()
            result = self.transport(url,timeout,self.max_bytes)
            attempt['received_at']=iso(self.now_fn())
            attempt['transport_elapsed_seconds_monotonic']=self.monotonic()-transport_started
            raw = result['body']
            if not isinstance(raw,bytes):
                raise ValueError('transport must return exact response bytes')
            attempt['http_status'] = int(result['status'])
            attempt['response_url'] = result.get('response_url',url)
            headers = {str(k).lower():str(v) for k,v in result.get('headers',{}).items()}
            attempt['headers'] = {key:value for key,value in headers.items() if key in SELECTED_HEADERS or key.startswith('x-mbx-used-weight-')}
            attempt['bytes_observed'] = len(raw)
            attempt['body'] = raw[:self.max_bytes]
            attempt['bytes_retained'] = len(attempt['body'])
            attempt['raw_sha256'] = hashlib.sha256(attempt['body']).hexdigest()
            attempt['raw_truncated'] = len(raw)>self.max_bytes
            attempt['response_incomplete'] = bool(result.get('response_incomplete'))
            attempt['response_body_complete'] = not attempt['raw_truncated'] and not attempt['response_incomplete']
            attempt['capture_status'] = ('RESPONSE_CAP_PREFIX' if attempt['raw_truncated']
                else 'INCOMPLETE_RESPONSE_PREFIX' if attempt['response_incomplete'] else 'COMPLETE_RESPONSE_BYTES')
            if result.get('transport_error'):
                attempt['transport_error'] = str(result['transport_error'])[:200]
            blocked = (attempt['http_status'] in (418,429,403,451)
                       or 'retry-after' in headers or 300 <= attempt['http_status'] < 400
                       or attempt['response_url'] != url)
            if blocked:
                attempt.update(status='BLOCKED',block_reason='provider_block_or_retry_after_or_redirect',requires_operator_review=True)
                self.halted,self.halt_reason = True,attempt['block_reason']
                data = None
            elif attempt['raw_truncated']:
                attempt.update(status='RESPONSE_CAP',error='bounded response prefix retained; incomplete raw response')
                data = None
            elif attempt['response_incomplete']:
                attempt.update(status='INCOMPLETE_RESPONSE');data=None
            elif not 200 <= attempt['http_status'] < 300:
                attempt.update(status='HTTP_ERROR');data = None
            else:
                data = json.loads(raw)
                if isinstance(data,dict) and isinstance(data.get('code'),int) and data['code'] < 0:
                    attempt.update(status='API_ERROR',api_error_code=data['code'])
                    if data['code'] == -1003:
                        attempt.update(status='BLOCKED',block_reason='provider_rate_limit_api_error',requires_operator_review=True)
                        self.halted,self.halt_reason = True,attempt['block_reason']
                    data = None
                else:
                    attempt['status']='OK'
        except Exception as exc:
            attempt.update(status='FAILED',error=f'{type(exc).__name__}: {str(exc)[:240]}')
            data = None
        if attempt['received_at'] is None:
            attempt['received_at'] = iso(self.now_fn())
        attempt['processing_finished_at']=iso(self.now_fn())
        attempt['elapsed_seconds_monotonic'] = self.monotonic()-monotonic_start
        if attempt['elapsed_seconds_monotonic'] < 0:
            attempt.update(status='CLOCK_ERROR');data=None
        elif attempt['elapsed_seconds_monotonic'] > timeout:
            attempt['request_time_cap_exceeded']=True
            if attempt['status'] != 'BLOCKED':
                attempt['status']='REQUEST_TIME_CAP'
            data=None
        if self.audit:
            self.audit('request_finished',{key:value for key,value in attempt.items() if key!='body'})
        return data,attempt

    def stats_symbols(self, metadata, symbols):
        planned=tuple(sorted(_cohort_symbols(symbols)))
        _metadata_rows(metadata)
        if not planned or len(planned)>150 or len(planned)!=len(set(planned)):
            raise ValueError('fixed one-request activity panel must contain 1..150 unique symbols')
        if not {'BTCUSDT','ETHUSDT'}.issubset(planned):
            raise ValueError('same-response activity benchmarks required')
        data,attempt=self._request('stats',symbols=planned,timeout=10)
        frame=None
        if data is not None:
            try:
                indexed,duplicates,malformed=_index_batch(data)
                unexpected=sorted(set(indexed)-set(planned))
                if unexpected or duplicates or malformed:
                    raise ValueError('activity response contains unrequested, duplicate or malformed symbols')
                subset=dict(metadata,symbols=[row for row in metadata['symbols'] if row['symbol'] in planned])
                frame=normalize_batch(data,subset,'stats',planned)
                frame.update(transport_mode='EXPLICIT_FROZEN_PRIMARY_ACTIVITY_BATCH',
                    planned_symbols=list(planned),raw_sha256=attempt.get('raw_sha256'),
                    requested_at=attempt['request_started_at'],received_at=attempt['received_at'],
                    pinned_metadata_raw_sha256=metadata.get('raw_sha256'),
                    missing_requested_metadata=sorted(set(planned)-{row['symbol'] for row in subset['symbols']}))
            except ValueError as exc:
                attempt.update(status='SCHEMA_ERROR',error=str(exc))
        status=attempt['status']
        if frame is not None and (frame['missing'] or frame['invalid'] or frame['missing_requested_metadata']):status='PARTIAL'
        return {'kind':'stats','status':status,'raw_http':[attempt],'summary':frame,
            'requires_operator_review':self.halted}


class ResearchRestLanes(RestLanes):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.stats_adapter=ResearchMarketAdapters(transport=self._market_transport,now_fn=self.clock,max_bytes=512*1024)

    def _gate(self):
        if any((self.root/name).exists() for name in ('PAUSED.json','PROVIDER_STOP.json')):
            raise WorkerPaused('new research observer is paused; no request sent')

    def _archive_context(self,kind,target_at,result,summary):
        if kind=='source':
            summary=dict(summary,semantic_acceptance='NOT_COVERED_PENDING_MANUAL_COMPLETE_EVIDENCE_ACCEPTANCE')
            summary['observations']=[dict(row,semantic_status='UNADJUDICATED_SOURCE_WATCH')
                for row in summary.get('observations',[])]
        receipt=ResearchStore(self.root).append_batch('context:'+kind+':'+iso(target_at),self.clock(),result['status'],
            result.get('raw_http',[]),summary,kind='context_'+kind)
        return {'status':result['status'],'raw_http':[],'summary':dict(summary,
            context_archive_hash=receipt['hash'],context_archive_day=receipt['day'],context_archive_seq=receipt['seq']),
            'requires_operator_review':result.get('requires_operator_review',False)}

    def stats(self,*,symbols,target_at):
        self._gate()
        if set(symbols)!=set(self.primary):raise ValueError('activity scope must equal frozen primary universe')
        with self.lock:metadata=self.metadata_frame
        result=self.stats_adapter.stats_symbols(metadata,self.primary)
        frame=result.get('summary') or {}
        summary={key:value for key,value in frame.items() if key not in ('rows','unmatched_rows','cohort_status')}
        summary.update(kind='hourly_activity_context',target_at=target_at,status=result['status'],
            observed_scope='FIXED_PRIMARY_PLUS_BENCHMARKS',all_exchange_activity_claimed=False)
        return self._archive_context('stats',target_at,result,summary)
