# R2 research engine

`engine.py` implements prospective receipt-causal delayed-information replay. It makes no orders and no paid calls. `capture_service.py` runs it in a bounded worker thread in the single new observer process; the original and supplemental collectors are outside this package.

The fixed configuration supplies `t0`, `primary` (symbol and prelaunch liquidity manifest), the release/source/protocol identities, and optional relative `warmup_manifest`. Admissions end at T0 + 30 days. Outcomes drain through T0 + 35 days + 120 seconds. The actual first eligible hourly bar opens at the next UTC hour boundary at or after T0; incomplete initial-hour knowledge stays unavailable.

The four arms reveal received data at 1, 5, 30 and 240 minute phases from T0. The exact causal hourly IGNITION equations come from the pinned `broad_observer.trigger` module. The hourly input requires all 60 received closed minutes. Historical hourly warmup is explicitly separate, with source receipt before T0, and creates no old discoveries or cooldown. The rolling hourly cache retains 180 hours, enough for non-hour-aligned four-hour phases and the 172-hour detector grid.

An absent reference hour settles UNKNOWN 120 seconds after close. A later complete hour is retained with `LATE_COMPLETE_HOUR` and may support future features; it cannot rewrite earlier decisions. An arm trigger without a previously observable reference is recorded `UNMATCHED_ARM_TRIGGER`. The frozen implementation records these limitations. The archive watermark trails actual receipt by five minutes and rounds down to the minute; processing time is distinct from actual market receipt. A packet discovered behind that watermark is retained as `LATE_ARCHIVE_INPUT`, with no retroactive quote choice or signal revision.

Entry is the first valid BBO newly requested at or after the arm cutoff and received within 120 seconds, strictly before admissions end. All arms use the same reference-event + 24/72/120 hour exit deadlines. A missing entry is `NOT_ENTERED`; a missing endpoint is `CENSORED`. Two percentage points are subtracted once from midpoint gross return. BTC and ETH must occur in the same request/receipt batch as the token for a benchmark leg to exist. No cached leg fills a gap. Economic acceptance is `NOT_COVERED_PENDING_MANUAL_COMPLETE_EVIDENCE_ACCEPTANCE`.

Controls use only then-available complete hourly closes for the preceding 24-hour return and 30 complete UTC daily quote volumes. Matching uses Euclidean distance between average-tie percentile ranks and a symbol tie-break. Missing pre-event inputs remain unavailable; no future winner exclusion exists.

## Persistence and verification

`research.sqlite` holds the append-only hash-chained ledger and transactional rolling caches/cursors. Canonical ledger JSON is compressed with zlib in SQLite; hashing and immutable exports cover its exact decoded bytes. Incremental kind counters make health bounded independently of accumulated ledger length. No full archive hash runs on every tick. Inputs are idempotent by original immutable packet hash; conflicting bytes fail closed. A crash commits all decisions/cursors for a transaction or none.

`ResearchEngine.export_incremental(directory)` creates immutable, hashed gzip JSONL ledger segments at completed transaction boundaries. Every source packet order and processing checkpoint is retained, allowing exactly the same earlier decisions to be restored. Back up the segments, frozen config/code/warmup and original raw archive. Do not repeatedly put the growing SQLite cache into Git history. The current local SQLite state supports normal restart; it is not the only authoritative copy.

Restore to a new directory after restoring those bytes off-server:

```sh
python3 -m research_r2.recovery --config /restored/research.json \
  --source-store /restored/archive \
  --ledger-directory /restored/engine/ledger \
  --new-state-directory /restored/rebuilt-engine
```

Recovery verifies compressed segment SHA256, sequence, complete ledger chain, raw packet and warmup hashes, and the exact rebuilt ledger tip. It makes no network requests and starts no collector. Never restore over a running state directory.

The focused suite is `python3 -m unittest research_r2.test_engine research_r2.test_engine_audit test_broad_trigger test_broad_hours`. Synthetic cases cover real causal trigger equations, complete received minutes, phased entries, common outcome deadlines, unavailable benchmarks, inclusive quote tolerance, cooldown, missing outcomes, late input, crash rollback, restart, immutable export and deterministic restore. Resource measurements are engineering fixtures under `readiness`; they are never enrolled observations.
