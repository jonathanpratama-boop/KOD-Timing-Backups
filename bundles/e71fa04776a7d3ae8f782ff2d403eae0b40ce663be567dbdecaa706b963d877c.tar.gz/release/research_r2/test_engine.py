import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest import mock
from research_r2.engine import ResearchEngine, iso, stamp, matched_controls, valid_quote, outcome, rebuild_from_exports, final_archive_drain, poll_archive
from broad_observer.store import BroadStore
from broad_observer.packets import minute_raw

T=stamp('2026-11-06T00:00:00Z')
SYMBOLS=['AAAUSDT','BBBUSDT','BTCUSDT','ETHUSDT']

def config():
    return {'schema':'KOD_RESEARCH_R2_CONFIG_V1','study_id':'fixture','t0':iso(T),
            'primary':[{'symbol':s,'median_quote_volume_30d':1000000} for s in SYMBOLS]}

def bar(symbol,opened,received,close='110.1',volume='2000'):
    candle={'s':symbol,'i':'1m','x':True,'t':int(opened*1000),'T':int((opened+60)*1000)-1,
            'o':close,'h':close,'l':close,'c':close,'v':'1','q':volume,'n':1,'V':'.5','Q':'1000'}
    return {'kind':'minute','received_at':iso(received),'record':{'symbol':symbol,'open_at':iso(opened),
            'close_at':iso(opened+60-.001),'received_at':iso(received),'source':{'e':'kline','s':symbol,'k':candle}}}

def quote(at,price=110,start=None,benchmarks=True,batch=None):
    rows=[]
    for s in SYMBOLS if benchmarks else ['AAAUSDT','BBBUSDT']:
        p=price if s=='AAAUSDT' else 100
        rows.append({'symbol':s,'bidPrice':str(p-.1),'askPrice':str(p+.1),'bidQty':'1','askQty':'2'})
    return {'kind':'quote','request_started_at':iso(at if start is None else start),'received_at':iso(at+.1),
            'batch_id':batch or str(at),'rows':rows}


def warmup():
    result=[]
    for s in SYMBOLS:
        for i in range(-171,0):
            result.append({'kind':'hour_warmup','symbol':s,'opened':iso(T+i*3600),'received_at':iso(T),
                'close':'100','quote_volume':'120000' if i in (-2,-1) and s=='AAAUSDT' else '20000'})
        for d in range(-30,0):
            result.append({'kind':'daily','symbol':s,'opened':iso(T+d*86400),'received_at':iso(T),'quote_volume':'2000000'})
    return result

class EngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.e=ResearchEngine(self.tmp.name,config())
    def tearDown(self): self.e.close();self.tmp.cleanup()
    def records(self,kind):
        return [json.loads(r[0]) for r in self.e.db.execute('SELECT payload FROM ledger WHERE kind=? ORDER BY seq',(kind,))]
    def signal(self):
        self.e.enqueue('warmup',warmup())
        items=[]
        for i in range(60):
            for s in SYMBOLS:
                items.append(bar(s,T+i*60,T+(i+1)*60+.5,'110.1' if s=='AAAUSDT' else '100'))
        self.e.enqueue('hour',items)
        while self.e.health()['pending_items']:
            self.e.process_until(T+3601)
    def test_end_to_end_all_arms_common_deadlines(self):
        self.signal()
        events=self.records('EVENT');self.assertEqual(len(events),1)
        reference=T+3600.5
        self.assertEqual(stamp(events[0]['reference_at']),reference)
        entries=[T+3660,T+3900,T+5400,T+14400]
        self.e.enqueue('entries',[quote(x) for x in entries])
        self.e.process_until(T+14500)
        decisions=[x for x in self.records('ARM_DECISION') if x['role']=='EVENT']
        self.assertEqual([x['arm_minutes'] for x in decisions],[1,5,30,240])
        self.assertEqual(len([x for x in self.records('PAPER_ENTRY') if x['position_id'].endswith('AAAUSDT')]),4)
        self.e.enqueue('exits',[quote(reference+h*3600,121) for h in (24,72,120)])
        self.e.process_until(reference+120*3600+121)
        results=[x for x in self.records('OUTCOME') if x['position_id'].endswith('AAAUSDT')]
        self.assertEqual(len(results),12)
        for x in results:
            self.assertAlmostEqual(x['returns']['gross_token_return'],.1)
            self.assertAlmostEqual(x['returns']['modeled_net_token_return'],.08)
            self.assertEqual(x['returns']['benchmark_50_50_gross_return'],0)
            self.assertEqual(stamp(x['common_deadline']),reference+x['horizon_hours']*3600)
        self.assertEqual(len({x['returns']['actual_elapsed_seconds'] for x in results if x['horizon_hours']==24}),4)
        self.e.verify_ledger()
    def test_no_signal_unknown_warmup_is_durable(self):
        self.e.enqueue('minute',[bar('AAAUSDT',T,T+60)])
        self.e.process_until(T+3721)
        self.assertEqual(self.e.health()['event_count'],0)
        records=self.records('DETECTOR');self.assertTrue(records)
        self.assertTrue(all(x['result']['status']=='UNKNOWN' for x in records))
        self.assertTrue(self.records('RESEARCH_CHECKPOINT'))
    def test_fifty_nine_minutes_never_complete(self):
        self.e.enqueue('incomplete',[bar('AAAUSDT',T+i*60,T+(i+1)*60) for i in range(59)])
        self.e.process_until(T+3721)
        self.assertEqual(self.e.health()['complete_hour_rows'],0)
    def test_first_quote_not_best_and_cached_request_rejected(self):
        self.signal()
        self.e.enqueue('quotes',[quote(T+3660,150,start=T+3659),quote(T+3661,110),quote(T+3662,50)])
        self.e.process_until(T+3790)
        entry=[x for x in self.records('PAPER_ENTRY') if x['position_id'].endswith('1:AAAUSDT')][0]
        self.assertAlmostEqual(entry['quote']['token']['midpoint'],110)
    def test_missing_benchmark_unavailable(self):
        self.signal();self.e.enqueue('entry',[quote(T+3660,110,benchmarks=False)])
        self.e.process_until(T+3800)
        self.e.enqueue('exit',[quote(T+3600.5+24*3600,121)])
        self.e.process_until(T+3600.5+24*3600+121)
        found=[x for x in self.records('OUTCOME') if x['position_id'].endswith('1:AAAUSDT')][0]
        self.assertIsNone(found['returns']['net_excess'])
    def test_idempotency_restart_and_hash_conflict(self):
        self.signal();before=self.e.verify_ledger()
        self.assertFalse(self.e.enqueue('warmup',warmup()))
        self.e.close();self.e=ResearchEngine(self.tmp.name,config())
        self.assertEqual(before,self.e.verify_ledger())
        with self.assertRaises(ValueError): self.e.enqueue('warmup',[])
    def test_append_only_enforced(self):
        with self.assertRaises(sqlite3.IntegrityError):self.e.db.execute("DELETE FROM ledger")
    def test_late_archive_never_rewrites(self):
        self.e.process_until(T+5000)
        self.e.enqueue('late',[bar('AAAUSDT',T,T+60)])
        self.assertEqual(len(self.records('LATE_ARCHIVE_INPUT')),1)
        self.assertEqual(self.e.health()['event_count'],0)
    def test_missing_entries_not_zero(self):
        self.signal();self.e.process_until(T+15000)
        self.assertTrue(self.records('NOT_ENTERED'));self.assertFalse(self.records('OUTCOME'))
    def test_export_and_restore_bytes(self):
        self.signal();path=Path(self.tmp.name)/'exports'
        result=self.e.export_incremental(path)
        packed=Path(result['file']).read_bytes();self.assertEqual(hashlib.sha256(packed).hexdigest(),result['sha256'])
        rows=[json.loads(x) for x in gzip.decompress(packed).splitlines()]
        self.assertEqual(rows[-1]['hash'],result['ledger_tip'])
        backup=Path(self.tmp.name)/'restore.sqlite';self.e.backup(backup)
        restored=sqlite3.connect(backup)
        self.assertEqual(restored.execute('SELECT count(*) FROM ledger').fetchone()[0],self.e.verify_ledger()['records']);restored.close()
    def test_quote_validation(self):
        for bad in ('NaN','Infinity','0','-1'):
            self.assertIsNone(valid_quote({'bidPrice':bad,'askPrice':'1','bidQty':'1','askQty':'1'}))
        self.assertIsNone(valid_quote({'bidPrice':'2','askPrice':'1','bidQty':'1','askQty':'1'}))
    def test_control_ties_symbol_order_no_future_exclusion(self):
        data={s:{'momentum_24h':.1,'median_quote_volume_30d':1} for s in ('Z','B','A','C')}
        self.assertEqual([x['symbol'] for x in matched_controls('Z',data)],['A','B','C'])
    def test_transaction_rolls_back_on_invalid_minute(self):
        item=bar('AAAUSDT',T+1,T+62);self.e.enqueue('bad',[item]);before=self.e.verify_ledger()
        with self.assertRaises(ValueError):self.e.process_until(T+100)
        self.assertEqual(self.e.verify_ledger(),before)
        self.assertEqual(self.e.health()['pending_items'],1)
    def test_immutable_export_rebuild_exact_decisions(self):
        inputs={'warmup':warmup(), 'bars':[bar(s,T+i*60,T+(i+1)*60+.5,'110.1' if s=='AAAUSDT' else '100')
                  for i in range(60) for s in SYMBOLS],
                'quotes':[quote(T+3660),quote(T+3900),quote(T+5400),quote(T+14400)]}
        for key,items in inputs.items():self.e.enqueue(key,items)
        while self.e.health()['pending_items']:self.e.process_until(T+15000)
        exports=Path(self.tmp.name)/'chunks'
        while self.e.export_incremental(exports,limit=25)['records']:pass
        restored=rebuild_from_exports(Path(self.tmp.name)/'rebuilt',config(),exports,inputs.__getitem__)
        self.assertEqual(restored.verify_ledger(),self.e.verify_ledger())
        self.assertEqual(restored.health(),self.e.health());restored.close()
    def test_cooldown_is_seventy_two_hour_bar_grid(self):
        self.signal()
        self.e.enqueue('second-hour',[bar('AAAUSDT',T+3600+i*60,T+3600+(i+1)*60+.5) for i in range(60)])
        self.e.process_until(T+7500)
        rows=[x for x in self.records('DETECTOR') if x['symbol']=='AAAUSDT' and x['hour_open_at']==iso(T+3600)]
        self.assertTrue(any(x['result']['status']=='COOLDOWN' for x in rows))
        self.assertEqual(self.e.health()['event_count'],1)
    def test_entry_window_inclusive_but_admission_cutoff_strict(self):
        self.signal();self.e.enqueue('inclusive',[quote(T+3779.9,110,start=T+3779)])
        self.e.process_until(T+3781)
        self.assertTrue(any(x['position_id'].endswith('1:AAAUSDT') for x in self.records('PAPER_ENTRY')))
    def test_missing_exits_are_censored(self):
        self.signal();self.e.enqueue('entry',[quote(T+3660)])
        self.e.process_until(T+3700);self.e.process_until(T+3600.5+24*3600+121)
        self.assertTrue(self.records('CENSORED'))
        self.assertFalse(self.records('OUTCOME'))
    def test_final_archive_drain_reaches_fixed_end_after_source_closed(self):
        self.e.set('next_cutoff',self.e.admission_end)
        self.e.set('watermark',self.e.end-600)
        end=self.e.end
        with mock.patch('research_r2.engine.poll_archive') as poll:
            poll.return_value={'backlog_possible':False,'health':{'pending_items':0,'processed_receipt_watermark':iso(end)}}
            with self.assertRaises(ValueError):final_archive_drain(self.e,None,end-1)
            result=final_archive_drain(self.e,None,end+60)
            self.assertTrue(result['complete'])
            self.assertEqual(poll.call_args.args[2],end+300)
    def test_old_precompression_database_is_preserved_and_rejected(self):
        old=Path(self.tmp.name)/'old';old.mkdir()
        db=sqlite3.connect(old/'research.sqlite');db.execute('CREATE TABLE ledger(payload TEXT)');db.commit();db.close()
        before=(old/'research.sqlite').read_bytes()
        with self.assertRaisesRegex(ValueError,'old uncompressed'):ResearchEngine(old,config())
        self.assertEqual(before,(old/'research.sqlite').read_bytes())
    def test_last_admitted_exit_is_processed_by_actual_final_drain(self):
        reference=self.e.admission_end-60
        self.e.set('next_cutoff',self.e.admission_end);self.e.set('watermark',reference-1)
        self.e.db.execute('INSERT INTO events VALUES(?,?,?,?,?)',('late','AAAUSDT',reference-3600,reference,'{}'))
        self.e.db.execute('INSERT INTO positions VALUES(?,?,?,?,?,?,?,NULL)',('late:1:AAAUSDT','late',1,'AAAUSDT','EVENT',reference,'AWAIT_ENTRY'))
        self.e.enqueue('late-entry',[quote(reference+1)]);self.e.process_until(reference+10)
        exit_time=reference+120*3600+119
        q=quote(exit_time,121)
        member={'capacity_lane':'broad','http_status':200,'request_started_at':q['request_started_at'],
                'received_at':q['received_at'],'body':json.dumps(q['rows']).encode()}
        raw,_=minute_raw([member]);store=BroadStore(Path(self.tmp.name)/'archive')
        store.append_batch('final-packet',iso(self.e.end+30),'CAPTURED',raw,{},kind='capacity_diagnostic')
        initial=poll_archive(self.e,store,self.e.end+60)
        self.assertEqual(initial['health']['pending_items'],1)
        self.assertFalse(self.records('OUTCOME'))
        final=final_archive_drain(self.e,store,self.e.end+60)
        self.assertTrue(final['complete'])
        results=self.records('OUTCOME');self.assertEqual(len(results),1)
        self.assertEqual(results[0]['horizon_hours'],120)

if __name__=='__main__':unittest.main()
