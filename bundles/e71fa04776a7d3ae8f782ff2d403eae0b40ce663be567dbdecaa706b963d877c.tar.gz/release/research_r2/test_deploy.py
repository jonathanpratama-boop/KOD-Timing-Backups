import datetime as dt
import hashlib
import os
from pathlib import Path
import tempfile
import unittest
from research_r2 import deploy as d

class DeploymentBoundaries(unittest.TestCase):
    def config(self):
        return dict(t0='2026-11-05T18:00:00Z',frozen_at='2026-11-05T17:58:00Z',
                    finalization_end_at='2026-12-10T18:03:00Z')
    def props(self,unit):
        return dict(Id=unit,LoadState='not-found',ActiveState='inactive',SubState='dead',
                    FragmentPath='',UnitFileState='',Transient='no',DropInPaths='',MainPID='0')
    def test_only_scoped_new_units(self):
        units=d.unit_texts(self.config())
        self.assertEqual(set(units),set(d.UNIT_NAMES))
        self.assertEqual(len(units),4)
        for body in units.values():
            self.assertNotIn('kod-observe',body);self.assertNotIn('supplement',body)
            self.assertNotIn('/opt/kod/current',body);self.assertNotIn('capacity-r2',body)
    def test_shared_aggregate_limits_only_new_slice(self):
        units=d.unit_texts(self.config())
        self.assertIn('MemoryMax=192M\nCPUQuota=10%\n',units[d.SLICE])
        for name in (d.COLLECTOR,d.BACKUP):self.assertIn('Slice=kod-research-r2.slice',units[name])
        self.assertNotIn('CPUQuota',units[d.COLLECTOR])
    def test_one_collector_no_second_engine_process(self):
        body=d.unit_texts(self.config())[d.COLLECTOR]
        self.assertEqual(body.count('ExecStart='),1)
        self.assertIn('research_r2.capture_service run',body)
        self.assertIn('ReadWritePaths=/var/lib/kod/research-r2\n',body)
    def test_research_collector_boot_enabled_without_schedule_reset(self):
        body=d.unit_texts(self.config())[d.COLLECTOR]
        self.assertIn('[Install]\nWantedBy=multi-user.target\n',body)
        self.assertIn('research_r2.capture_service run\n',body)
        self.assertNotIn('--reset',body)
        self.assertNotIn('rm ',body)
    def test_timer_finite_dates(self):
        body=d.unit_texts(self.config())[d.TIMER]
        rows=[x for x in body.splitlines() if x.startswith('OnCalendar=')]
        self.assertEqual(len(rows),36)
        self.assertEqual(rows[0],'OnCalendar=2026-11-05 *:*:30 UTC')
        self.assertEqual(rows[-1],'OnCalendar=2026-12-10 *:*:30 UTC')
        self.assertIn('Persistent=false',body)
    def test_runtime_matches_clock_not_capacity48h(self):
        body=d.unit_texts(self.config())[d.COLLECTOR]
        seconds=int(next(x.split('=')[1] for x in body.splitlines() if x.startswith('RuntimeMaxSec=')))
        self.assertEqual(seconds,35*86400+5*60+600)
    def test_unbounded_runtime_rejected(self):
        cfg=self.config();cfg['finalization_end_at']='2027-12-10T18:00:00Z'
        with self.assertRaises(ValueError):d.unit_texts(cfg)
    def test_unsafe_paths_rejected(self):
        for path in ('/root/key','../outside','a/../b','./a','a\\b',''):
            with self.subTest(path=path),self.assertRaises(ValueError):d.relative(path)
        self.assertEqual(str(d.relative('authoritative/PROTOCOL_R2.md')),'authoritative/PROTOCOL_R2.md')
    def test_absent_unit_accepted(self):
        self.assertEqual(d.assert_new_unit_available(d.COLLECTOR,self.props(d.COLLECTOR)),'ABSENT')
    def test_only_inert_new_slice_exception(self):
        p=self.props(d.SLICE);p['LoadState']='loaded'
        self.assertEqual(d.assert_new_unit_available(d.SLICE,p),'INERT_IMPLICIT_SLICE')
        p=self.props(d.COLLECTOR);p['LoadState']='loaded'
        with self.assertRaises(FileExistsError):d.assert_new_unit_available(d.COLLECTOR,p)
    def test_existing_active_or_configured_slice_rejected(self):
        for field,value in (('ActiveState','active'),('FragmentPath','/etc/unit'),('DropInPaths','/etc/x'),('Transient','yes'),('MainPID','3')):
            p=self.props(d.SLICE);p[field]=value
            with self.subTest(field=field),self.assertRaises(FileExistsError):d.assert_new_unit_available(d.SLICE,p)
    def test_unscoped_unit_rejected(self):
        with self.assertRaises(ValueError):d.assert_new_unit_available('kod-observe.timer',self.props('kod-observe.timer'))
    def test_timestamp_awareness(self):
        with self.assertRaises(ValueError):d.timestamp('2026-11-05T18:00:00')
        self.assertEqual(d.timestamp('2026-11-06T01:00:00+07:00'),d.timestamp('2026-11-05T18:00:00Z'))
    def test_only_leaf_slice_may_be_constrained(self):
        before={'kod.slice':{'cpu.max':'max 100000','memory.max':'max'},'kod.slice/kod-research.slice':None}
        after={'kod.slice':dict(before['kod.slice']),'kod.slice/kod-research.slice':{'cpu.max':'max 100000','memory.max':'max'}}
        self.assertTrue(d.verify_ancestor_envelopes(before,after)['unchanged_existing_ancestors'])
        after['kod.slice']['cpu.max']='10000 100000'
        with self.assertRaises(ValueError):d.verify_ancestor_envelopes(before,after)
        after['kod.slice']=dict(before['kod.slice'])
        after['kod.slice/kod-research.slice']['memory.max']='201326592'
        with self.assertRaises(ValueError):d.verify_ancestor_envelopes(before,after)
    def test_launch_evidence_is_exact_immutable_copy(self):
        with tempfile.TemporaryDirectory() as directory:
            source=Path(directory)/'INSTALLATION.json';destination=Path(directory)/'LAUNCH_RECEIPT.json'
            raw=b'{"phase": "ARMED_NOT_YET_VERIFIED_LIVE"}\n';source.write_bytes(raw)
            receipt=d.copy_launch_evidence(source,destination,reader_gid=os.getgid())
            self.assertEqual(destination.read_bytes(),raw)
            self.assertEqual(receipt['sha256'],hashlib.sha256(raw).hexdigest())
            self.assertEqual(destination.stat().st_mode&0o777,0o440)
            self.assertEqual(source.read_bytes(),raw)
            with self.assertRaises(FileExistsError):d.copy_launch_evidence(source,destination,reader_gid=os.getgid())
    def test_all_launch_and_predecessor_receipts_restore_exactly(self):
        from research_r2.capture_test import config
        from research_r2 import capture_ops as ops
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);state=root/'state';state.mkdir();backup=root/'ops'
            cfg=config();(state/'research.json').write_bytes(d.canonical(cfg))
            for name in ('RESEARCH_RELEASE.json','PACKAGE.json'):(state/name).write_bytes(b'{}\n')
            names=('LAUNCH_RECEIPT.json','CAPACITY_CLOSURE.json',
                   'PREDECESSOR_BACKUP_ACK.json','PREDECESSOR_BACKUP_HEAD.json')
            for name in names:
                self.assertIn(name,ops.RESEARCH_CONTROL_NAMES)
                source=root/name;source.write_bytes(b'{"exact": "'+name.encode()+b'"}\n')
                d.copy_launch_evidence(source,state/name,reader_gid=os.getgid())
            ops.snapshot_research_controls(state,backup,cfg)
            restored=root/'restored';receipt=ops.restore_research_controls(backup,restored,cfg)
            self.assertTrue(receipt['byte_identical'])
            for name in names:self.assertEqual((restored/name).read_bytes(),(root/name).read_bytes())
if __name__=='__main__':unittest.main()
