"""External read-only health evaluator for one frozen R2 research branch.

Run on GitHub Actions (or the owner's existing off-host execution capability),
never on the observed server to claim an independent check. A failed workflow is
an alert condition, not proof that an owner received a notification.
"""
import argparse
import base64
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import urllib.request

UTC=dt.timezone.utc
REPO='jonathanpratama-boop/KOD-Timing-Backups'

def ts(value):
    result=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
    if result.tzinfo is None:raise ValueError('timezone missing')
    return result.astimezone(UTC)

def inspect(health,config,config_sha256,now):
    """Do not mistake current process activity for complete historical coverage."""
    problems=[];metrics={};now=now.astimezone(UTC)
    def need(value,message):
        if not value:problems.append(message)
    def mapping(value):return value if isinstance(value,dict) else {}
    def fresh(value,label,limit):
        try:age=(now-ts(value)).total_seconds()
        except (TypeError,ValueError,AttributeError):problems.append(label+'_TIMESTAMP_UNKNOWN');return
        need(-60<=age<=limit,label+'_STALE_OR_FUTURE')
        metrics[label+'_age_seconds']=age
    health=mapping(health);collector=mapping(health.get('collector'))
    end=ts(config['receipt_drain_end']);start=ts(config['t0'])
    need(health.get('schema')=='KOD_RESEARCH_HEALTH_V1','WRONG_HEALTH_SCHEMA')
    need(health.get('trial_id')==config['trial_id'],'WRONG_STUDY')
    need(health.get('config_sha256')==config_sha256,'WRONG_FROZEN_CONFIG')
    need(health.get('capacity_pass_claimed') is False,'CAPACITY_HISTORY_MISREPRESENTED')
    need(health.get('pause_latched') is False,'PAUSED_OR_UNKNOWN')
    need(health.get('status') in ('OK','PRELIMINARY'),'HEALTH_FAILED_OR_UNKNOWN')
    need(health.get('issues')==[],'HEALTH_ISSUES')
    if now<start:return {'status':'ALERT' if problems else 'SCHEDULED','issues':problems,'metrics':metrics}
    if now<=end:
        fresh(health.get('emitted_at'),'report',1800)
        fresh(collector.get('as_of'),'collector',1800)
        need(collector.get('phase') in ('RUNNING','DRAINING'),'COLLECTOR_STOPPED')
        actual=mapping(health.get('service_actual_status'))
        need(actual.get('ActiveState')=='active','SERVICE_NOT_ACTIVE')
        need(config.get('scientific_enrollment_enabled') is True,'RESEARCH_NOT_ENABLED')
        need(collector.get('capacity_trial_only') is False,'CAPACITY_ONLY')
        committed=collector.get('last_minute_commit_at')
        if now>=start+dt.timedelta(minutes=3):fresh(committed,'last_commit',1800)
    resources=mapping(health.get('resource_check'))
    need(resources.get('status') in ('OK','PRELIMINARY'),'RESOURCE_FAILURE')
    preservation=mapping(health.get('preservation'))
    need(preservation.get('unchanged') is True and preservation.get('source_files_checked')==527
        and preservation.get('static_invariants_checked')==34,'PROTECTED_PRESERVATION_UNVERIFIED')
    # Capture quality remains visible but never rewrites missing slots.
    coverage=mapping(collector.get('coverage'))
    for lane,field in (('closed_bars','on_time'),('broad_bbo','valid_received'),('detailed_five','valid_received')):
        rows=mapping(coverage.get(lane));expected=valid=0;below=[];invalid=[]
        wanted=set(config['detailed_symbols'] if lane=='detailed_five' else config['primary_symbols'])
        if set(rows)!=wanted:problems.append(lane+'_MEMBERSHIP_UNKNOWN')
        for symbol in sorted(wanted):
            row=mapping(rows.get(symbol));n=row.get('expected');v=row.get(field)
            if type(n)is not int or type(v)is not int or not 0<=v<=n:invalid.append(symbol);continue
            expected+=n;valid+=v
            if n and v/n<.99:below.append(symbol)
        metrics[lane]={'valid':valid,'expected':expected,'coverage':valid/expected if expected else None,
                       'below_99_percent_assets':below,'invalid_assets':invalid}
        if invalid:problems.append(lane+'_INVALID_COUNTS')
        if below:problems.append(lane+'_BELOW_99_PERCENT')
    engine=mapping(health.get('research_engine'))
    if now>=start+dt.timedelta(minutes=10) and now<=end:
        need(bool(engine),'RESEARCH_ENGINE_HEALTH_UNAVAILABLE')
        if engine:
            need(engine.get('status') not in ('FAILED','STOPPED','ERROR'),'RESEARCH_ENGINE_FAILED')
            # Meaningful runner progress must be checked separately from its source clock.
            for name in ('last_processed_at','as_of','emitted_at','processed_receipt_watermark'):
                if name in engine:fresh(engine[name],'research_engine',1800);break
            else:problems.append('RESEARCH_ENGINE_PROGRESS_TIMESTAMP_UNKNOWN')
    return {'status':'ALERT' if problems else 'OK','issues':sorted(set(problems)),'metrics':metrics,
            'scope':'external health/quality condition; notification delivery not independently proven'}

def fetch(branch,path,token):
    if not re.fullmatch(r'research-[A-Za-z0-9_-]+',branch):raise ValueError('unexpected branch')
    if path not in ('HEALTH.json','research.json'):raise ValueError('unexpected scoped path')
    url='https://api.github.com/repos/'+REPO+'/contents/'+path+'?ref='+branch
    request=urllib.request.Request(url,headers={'Authorization':'Bearer '+token,
        'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'})
    with urllib.request.urlopen(request,timeout=20) as response:
        raw=response.read(4*1024*1024+1)
    if len(raw)>4*1024*1024:raise ValueError('health response cap exceeded')
    document=json.loads(raw)
    if document.get('encoding')!='base64':raise ValueError('unexpected GitHub content encoding')
    return base64.b64decode(document['content'],validate=False)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--branch',required=True)
    parser.add_argument('--config-sha256',required=True);parser.add_argument('--monitor-end',required=True)
    parser.add_argument('--config',type=Path,required=True)
    args=parser.parse_args();instant=dt.datetime.now(UTC)
    if instant>ts(args.monitor_end):print(json.dumps({'status':'MONITOR_WINDOW_ENDED'}));return 0
    raw=args.config.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=args.config_sha256:raise ValueError('frozen monitor config differs')
    config=json.loads(raw)
    if config['trial_id']!=args.branch:raise ValueError('branch/config identity differs')
    health=json.loads(fetch(args.branch,'HEALTH.json',os.environ['GITHUB_TOKEN']))
    result=inspect(health,config,args.config_sha256,instant)
    print(json.dumps(result,sort_keys=True,ensure_ascii=False))
    return 1 if result['status']=='ALERT' else 0
if __name__=='__main__':raise SystemExit(main())
