"""Explicit reviewed runtime/evidence inputs for root's final T0 freeze."""
from pathlib import Path
from .deploy import sha,warmup_files

RESEARCH_MODULES=('__init__','capture','capture_ops','capture_service','capture_runtime','store','engine','recovery','deploy',
    'deploy_inputs','deploy_watchdog','capture_test','capture_service_test','capture_runtime_test','test_engine','test_engine_audit',
    'test_deploy','test_deploy_watchdog','test_store')
SHARED_MODULES=('adapters','store','backup','streams','packets','capacity','runtime','legacy_sources','hours','trigger')
TEST_MODULES=('research_r2.capture_test','research_r2.capture_service_test','research_r2.capture_runtime_test','research_r2.test_engine','research_r2.test_engine_audit',
    'research_r2.test_deploy','research_r2.test_deploy_watchdog','research_r2.test_store','test_broad_trigger','test_broad_hours')
EVIDENCE=(
    'authoritative/PROTOCOL_R2.md','authoritative/Pasted text(5).txt',
    'authoritative/RESEARCH_START_ADDENDUM_R2.md',
    'research_r2/ENGINE_README.md','research_r2/DEPLOYMENT.md','research_r2/capture_RECOVERY.md',
    'authoritative/legacy-ignition-c7c84127/scan_v0.py',
    'broad_observer/universe-bootstrap-final.json','broad_observer/detail-five-bootstrap-final.json',
    'broad_observer/classifications-final-protocol.json','broad_observer/classifications-final-sources.json',
    'broad_observer/bootstrap-bytes-final.manifest.json',
    'evidence/host-preflight.json','evidence/census-smoke-only/metadata-recovery.raw',
    'evidence/census-smoke-only/metadata-recovery.receipt.json','sources.json','sources-research.md',
    'test_broad_capacity.py','test_broad_trigger.py','test_broad_hours.py','test_broad_adapters.py',
    'repair/cloud-check-20261105/candidate/capacity.py')


def package_inputs(workspace,*,readiness=None,extras=None):
    root=Path(workspace).resolve()
    names=tuple('research_r2/'+n+'.py' for n in RESEARCH_MODULES)+tuple('broad_observer/'+n+'.py' for n in SHARED_MODULES)+EVIDENCE
    files={name:root/name for name in names}
    files.update(warmup_files(root/'research_r2/warmup'))
    if readiness is not None:files['READINESS.json']=Path(readiness).resolve()
    if extras:
        for name,path in extras.items():
            if name in files:raise ValueError('duplicate explicit file '+name)
            files[name]=Path(path).resolve()
    for name,path in files.items():
        if path.is_symlink() or not path.is_file():raise ValueError('required file missing or symlink:'+name)
    paths={
        'universe_path':'broad_observer/universe-bootstrap-final.json',
        'detail_path':'broad_observer/detail-five-bootstrap-final.json',
        'baseline_path':'evidence/host-preflight.json',
        'metadata_path':'evidence/census-smoke-only/metadata-recovery.raw',
        'source_manifest_path':'sources.json',
        'startup_amendment_path':'authoritative/RESEARCH_START_ADDENDUM_R2.md',
        'warmup_manifest_path':'research_r2/warmup/MANIFEST.json'}
    metadata=dict(paths,
        protocol_sha256=sha(root/'authoritative/PROTOCOL_R2.md'),
        attachment_sha256=sha(root/'authoritative/Pasted text(5).txt'),
        universe_sha256=sha(root/paths['universe_path']),
        detail_sha256=sha(root/paths['detail_path']),
        source_manifest_sha256=sha(root/paths['source_manifest_path']),
        startup_amendment_sha256=sha(root/paths['startup_amendment_path']),
        warmup_manifest_sha256=sha(root/paths['warmup_manifest_path']))
    return files,metadata,TEST_MODULES
