import copy
import datetime as dt
import unittest
from research_r2 import deploy_watchdog as w
from research_r2.deploy import watchdog_workflow

class ExternalMonitor(unittest.TestCase):
    def setUp(self):
        self.now=w.ts('2026-11-05T18:30:00Z')
        self.config=dict(trial_id='research-r2-test',t0='2026-11-05T18:00:00Z',
            receipt_drain_end='2026-12-10T18:02:00Z',finalization_end_at='2026-12-10T18:03:00Z',
            primary_symbols=['BTCUSDT'],detailed_symbols=['BTCUSDT'],scientific_enrollment_enabled=True)
        self.health=dict(schema='KOD_RESEARCH_HEALTH_V1',trial_id='research-r2-test',config_sha256='a'*64,
            capacity_pass_claimed=False,pause_latched=False,status='OK',issues=[],emitted_at='2026-11-05T18:29:30Z',
            service_actual_status={'ActiveState':'active'},resource_check={'status':'OK'},
            preservation={'unchanged':True,'source_files_checked':527,'static_invariants_checked':34},
            research_engine={'processed_receipt_watermark':'2026-11-05T18:25:00Z'},
            collector=dict(as_of='2026-11-05T18:29:30Z',phase='RUNNING',capacity_trial_only=False,
                scientific_enrollment=False,last_minute_commit_at='2026-11-05T18:29:01Z',
                coverage={x:{'BTCUSDT':dict(expected=20,on_time=20,valid_received=20)}
                    for x in ('closed_bars','broad_bbo','detailed_five')}))
    def assess(self):return w.inspect(self.health,self.config,'a'*64,self.now)
    def test_healthy_capture_and_research_is_ok(self):self.assertEqual(self.assess()['status'],'OK')
    def test_stopped_capture_is_alert(self):
        self.health['collector']['phase']='HALTED'
        self.assertIn('COLLECTOR_STOPPED',self.assess()['issues'])
    def test_stale_collector_cannot_hide_behind_new_report(self):
        self.health['collector']['as_of']='2026-11-05T17:59:59Z'
        self.assertIn('collector_STALE_OR_FUTURE',self.assess()['issues'])
    def test_engine_progress_required(self):
        del self.health['research_engine']
        self.assertIn('RESEARCH_ENGINE_HEALTH_UNAVAILABLE',self.assess()['issues'])
    def test_historical_gap_still_visible(self):
        self.health['collector']['coverage']['detailed_five']['BTCUSDT']['valid_received']=19
        self.assertIn('detailed_five_BELOW_99_PERCENT',self.assess()['issues'])
    def test_missing_quality_counts_unknown(self):
        del self.health['collector']['coverage']['closed_bars']['BTCUSDT']['expected']
        self.assertIn('closed_bars_INVALID_COUNTS',self.assess()['issues'])
    def test_wrong_config_alert(self):
        self.health['config_sha256']='b'*64
        self.assertIn('WRONG_FROZEN_CONFIG',self.assess()['issues'])
    def test_new_workflow_read_only_and_own_scope(self):
        body=watchdog_workflow(self.config,'a'*64)
        self.assertIn('contents: read',body);self.assertNotIn('contents: write',body)
        self.assertIn('kod-research-r2-watchdog',body);self.assertNotIn('capacity-r2',body)
        self.assertIn('2026-12-10T20:03:00Z',body)
    def test_untrusted_branch_rejected(self):
        self.config['trial_id']='research-x; echo x'
        with self.assertRaises(ValueError):watchdog_workflow(self.config,'a'*64)
if __name__=='__main__':unittest.main()
