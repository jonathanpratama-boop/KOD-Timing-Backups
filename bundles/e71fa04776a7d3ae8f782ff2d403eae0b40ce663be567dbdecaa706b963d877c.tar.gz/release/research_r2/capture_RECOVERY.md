# R2 research capture and recovery

This is the new `RESEARCH35D` capture implementation, derived from the retained
v2 capacity scheduler. It does not edit the capacity release or the original and
supplemental collectors. A failed/closed capacity attempt is not relabelled as a
passed capacity test or a prospective outcome cohort.

The three production roots are `/opt/kod/research-r2`,
`/var/lib/kod/research-r2`, and `/var/lib/kod-research-r2-ops`.
The dedicated aggregate leaf slice is `kod-research-r2.slice`; its 192 MiB and
10% CPU envelope applies to capture, its in-process research thread, and scoped
operations together. Shared ancestor slices must not be changed.

`python3 -B -m research_r2.capture_service run` starts capture and the research
thread. `... ops --publish` performs the bounded resource/preservation check,
local incremental snapshot when due and exact-branch publication. Startup must
use the frozen future T0. Restarts keep that T0 and retain all missed slots.
Neither command installs units, changes credentials or starts real orders.

The configuration fixes T0, admission_end_at=T0+30 days, end_at=T0+35 days,
receipt_drain_end=T0+35 days+120 seconds, and finalization_end_at=that+60 seconds.
Requests stop at receipt_drain_end. The following minute only settles already
received final bars and outstanding bounded callbacks. Once capture closes, the
engine uses `final_archive_drain` over the committed finite archive. This is
bounded processing, not extra market acquisition. The process has a further
360-second final processing bound; the operations command becomes read-only/no-op
one hour after finalization_end_at. Collection never extends to rescue results.

Full-period allocated bytes, temporary staging, the Git object database, engine
SQLite and ledger exports, file counts and inodes belong in the storage forecast.
The validator requires a measured full-period projection within the frozen hard
cap, hard cap plus overshoot reserve within 25% of initial free disk, and at least
2 GiB free. A five-second filesystem check and at-most-60-second aggregate guard
fail closed. Startup/cgroup-reset CPU is preliminary until a second measurement;
missing CPU data never turns real disk/inode readings into zero.

The raw archive remains BroadStore's immutable compressed objects and segmented
journal. Capture minute batch kinds retain the legacy `capacity_minute_end` /
`capacity_diagnostic` names for reader compatibility, with RESEARCH_CAPTURE
schemas and research identity. V2_BITMAP summaries encode only derived coverage
updates as per-index hexadecimal masks in frozen primary/detail manifest order;
the enclosing config hash binds that order. Seen and on-time flags remain
separate. Raw PACK/message order, clocks, failures and attempts remain unchanged.
`decode_delta` also reads older unlaunched list-form deltas during reconstruction.
Their `scientific_enrollment=false` means the
capture adapter does not make paper decisions: actual research processing is
reported separately in `RESEARCH_ENGINE_HEALTH.json` and aggregate HEALTH.json.

The engine owns one SQLite connection in one thread. It publishes compact
immutable gzip ledger chunks containing processing boundaries and decisions.
The authoritative ledger, raw packets, frozen configuration and pinned warmup
support deterministic reconstruction. Hourly full SQLite generations are not
backed up. SQLite remains durable local working state, included in resource
accounting. Engine failures/stale progress are visible and latch a pause.

## Backup representation

Use the already authorized private KOD-Timing-Backups repository and existing
deploy key, with branch equal to the frozen `research-*` trial identity. No key,
remote repository, access grant or paid storage is created by these tools.

The new backup retains immutable bounded hourly PAX/gzip chunks in Git. A chunk
contains new raw backup objects, archive/control manifests, newly exported engine
ledger chunks and (once) the exact frozen code/source/manifest/warmup package.
Each member's exact bytes and SHA-256 are in the chunk descriptor. PAX supports
the real engine export names longer than 100 bytes; extraction never uses a
blind `extractall` and rejects unexpected paths, links, duplicates or sizes.

After a local Git commit, the chunk's Git blob is verified against its SHA-256.
Only then are extra local tar and snapshot payload copies retired. Original raw
archive bytes and authoritative engine exports remain. The method works even
when systemd mount boundaries prevent hardlinks. Git holds the second durable
payload copy; temporary hourly staging and Git internals are counted separately.
A bounded SQLite index deduplicates members already in committed chunks. It is
rebuildable from committed bundle manifests and never replaces the raw evidence.
Local snapshot objects may therefore be absent by design: restore from the Git
chunks, not from an assumption that the transient snapshot cache is complete.

A known DNS/connection-timeout/reset failure can retry at the next scheduled ops
slot only while a verified off-host acknowledgement is no older than two hours.
The failure and previous acknowledgement remain visible. Authentication, host
key, access-policy and unclassified Git failures fail closed. No host switching,
force-push, fetch/rebase, GC or permission change is used to bypass a failure.

## Off-host byte restoration

Clone the exact private research branch through the existing authorized route to
new staging on the Mac. Preserve its commit hash. Do not overwrite a live root.

1. Read the frozen research configuration from the clone's verified control data
   or its original release package. `capture_ops.restore_bundle_repository(clone,
   new_ops/'repository', config)` reconstructs the complete incremental backup
   repository from local Git blobs and verifies every chunk/member byte hash.
2. `IncrementalBackup(new_ops/'repository').restore(new_archive)` reconstructs
   BroadStore evidence and checks the archive manifest chain. Use a fresh path.
3. `capture_ops.restore_research_controls(new_ops, new_controls, config)` restores
   exact authoritative config/release/package/control bytes. The frozen runtime
   and warmup bytes are under `new_ops/repository/release/`; engine ledger exports
   are under `new_ops/repository/engine/`.
4. Rebuild the research engine from raw evidence, frozen configuration/warmup and
   exported authoritative boundaries using the engine's tested reconstruction
   helper. Compare its ledger hashes. Do not invent earlier receipt times.
5. Review the restored source/cache boundaries and last confirmed slot before any
   authorized resume. Resume preserves the original end; missed intervals stay
   missing. Restoring bytes does not automatically install or activate a service.

Full archive verification and off-host restored-byte checks are independent
integrity boundaries. Normal minute appends do not rehash the entire month.
External monitoring is a separate collector-specific route; the old watchdog or
an on-server health file alone is not proof of an external alert.
