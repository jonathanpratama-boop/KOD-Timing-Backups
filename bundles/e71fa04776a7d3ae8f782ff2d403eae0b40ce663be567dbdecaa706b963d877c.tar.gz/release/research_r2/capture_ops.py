"""Local research-trial health, scoped backup binding and external-watch plan.

No deployment, network request, remote Git mutation, automation creation or alert
send is performed here. The explicit packing probe uses an isolated local Git
fixture only. External monitoring must run outside the observed server.
"""
import datetime as dt
import gzip
import io
import tarfile
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import sqlite3
import subprocess
import tempfile
import threading
import time

from broad_observer.backup import IncrementalBackup, canonical, immutable_write, fsync_directory, stream_hash

UTC = dt.timezone.utc
ORIGINAL_COMMIT = 'dbb27ea5c6a16c5b37c6f94b938a1509c2a9148e'
ATTACHMENT_SHA256 = '145a17f1c9714c32b97ae50e1973e58921acd829443fd3e23c27e11d4328e780'
PROTOCOL_R2_SHA256 = '0950356e3f7c894cab0d98eef3c9e030c24cca7c4efdd03df76fb19464a1e4f2'
MEMORY_LIMIT_BYTES = 192 * 1024 ** 2
MIN_FREE_BYTES = 2 * 1024 ** 3
REPOSITORY = 'jonathanpratama-boop/KOD-Timing-Backups'
REMOTE = 'git@github.com:' + REPOSITORY + '.git'
GIT_SCOPED_OPTIONS = ('-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
    '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', 'pack.threads=1',
    '-c', 'pack.window=0', '-c', 'pack.windowMemory=16m')


def timestamp(value):
    result = value if isinstance(value, dt.datetime) else dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('aware timestamp required')
    return result.astimezone(UTC)


def iso(value):
    return timestamp(value).isoformat().replace('+00:00', 'Z')


def config_hash(config):
    # Bind the same UTF-8 canonical bytes used by the frozen research.json and
    # controller, including non-ASCII exchange symbols.
    from broad_observer.store import canonical as config_canonical
    return hashlib.sha256(config_canonical(config)).hexdigest()


def validate_config(config):
    trial = config['trial_id']
    if not isinstance(trial, str) or re.fullmatch(r'research-[A-Za-z0-9_-]+', trial) is None:
        raise ValueError('new scoped research identity required')
    start = timestamp(config['t0'])
    admission = timestamp(config['admission_end_at'])
    end = timestamp(config['end_at'])
    drain = timestamp(config['receipt_drain_end'])
    finalization = timestamp(config['finalization_end_at'])
    if (start.second or start.microsecond or admission-start != dt.timedelta(days=30)
            or end-start != dt.timedelta(days=35) or drain-end != dt.timedelta(seconds=120)
            or finalization-drain != dt.timedelta(seconds=60)):
        raise ValueError('exact 30-day admissions, 35-day study and 120-second request tolerance required')
    if config.get('phase') != 'RESEARCH35D' or config.get('scientific_enrollment_enabled') is not True:
        raise ValueError('explicit RESEARCH35D enrollment configuration required')
    initial = config['initial_free_bytes']
    if not isinstance(initial, int) or isinstance(initial, bool) or initial <= MIN_FREE_BYTES:
        raise ValueError('measured initial free bytes required')
    for key in ('projected_35day_all_in_bytes','hard_storage_bytes','hard_file_count','hard_inode_count',
                'initial_free_inodes','minimum_free_inodes','guard_interval_seconds',
                'overshoot_reserve_bytes','overshoot_reserve_inodes'):
        if not isinstance(config.get(key),int) or isinstance(config.get(key),bool) or config[key]<=0:
            raise ValueError('finite research guard requires positive integer '+key)
    if (config['projected_35day_all_in_bytes']>config['hard_storage_bytes']
            or config['hard_storage_bytes']+config['overshoot_reserve_bytes']>initial//4
            or initial-config['hard_storage_bytes']-config['overshoot_reserve_bytes']<MIN_FREE_BYTES
            or config['hard_file_count']>config['hard_inode_count']
            or config['initial_free_inodes']<config['hard_inode_count']+config['overshoot_reserve_inodes']+config['minimum_free_inodes']
            or config['guard_interval_seconds']>60
            or config.get('full35day_gate_status')!='PASS_MEASURED'):
        raise ValueError('research forecast/caps/overshoot exceed frozen full-duration budget')
    return {'trial_id': trial, 'start': start, 'admission_end': admission, 'end': end, 'drain_end': drain,
            'finalization_end': finalization, 'checkpoint_24h': start + dt.timedelta(hours=24),
            'initial_free_bytes': initial, 'new_storage_budget_bytes': initial//4,
            'config_sha256': config_hash(config), 'backup_branch': trial}


def verify_original(baseline, *, source_root='/opt/kod/current', expected_source_files=527,
                    expected_invariants=34):
    """Hash read-only controls and all pinned original files; never open evidence for writing."""
    source_root = Path(source_root)
    invariants = baseline['invariants']
    problems = []
    if len(invariants) != expected_invariants:
        problems.append('unexpected_static_invariant_count')
    for name, expected in invariants.items():
        path = Path(name)
        if path.is_symlink() or not path.is_file():
            problems.append('missing_or_nonregular_static:' + name)
        elif stream_hash(path)[0] != expected:
            problems.append('changed_static:' + name)
    checked = 0
    try:
        manifest = json.loads((source_root / 'SOURCE_MANIFEST.json').read_bytes())
        if manifest.get('commit') != ORIGINAL_COMMIT or len(manifest['files']) != expected_source_files:
            problems.append('original_release_identity_or_count_differs')
        for relative, expected in manifest['files'].items():
            path = source_root / relative
            if (Path(relative).is_absolute() or '..' in Path(relative).parts or path.is_symlink()
                    or not path.is_file() or not path.resolve().is_relative_to(source_root.resolve())):
                problems.append('unsafe_or_missing_source:' + relative)
            elif stream_hash(path)[0] != expected['sha256']:
                problems.append('changed_source:' + relative)
            checked += 1
    except (OSError, ValueError, KeyError, TypeError) as exc:
        problems.append('original_manifest_unreadable:' + type(exc).__name__)
    return {'status': 'OK' if not problems else 'FAILED', 'unchanged': not problems,
            'source_files_checked': checked, 'static_invariants_checked': len(invariants),
            'source_commit': ORIGINAL_COMMIT, 'problems': problems,
            'scope': 'static controls and original pinned source; dynamic original observations not modified'}


def unique_storage_bytes(roots):
    """Stream disjoint namespace trees; deduplicate compact inode identities.

    Avoid retaining a Path per file. Roots are normalized/pruned before walking,
    so repeated/nested roots do not double count namespace entries. Physical
    hardlinks still count one allocated inode, and their names remain visible.
    """
    selected=[]
    for value in roots:
        path=Path(value)
        if path.is_symlink():raise ValueError('new storage root must not be symlink')
        root=path.resolve()
        if not root.exists():continue
        if not root.is_dir():raise ValueError('new storage root must be a regular directory')
        if any(root==old or root.is_relative_to(old) for old in selected):continue
        selected=[old for old in selected if not old.is_relative_to(root)]
        selected.append(root)
    seen=set();logical=allocated=files=directories=file_paths=vanished_entries=0
    def identity(info):
        if not 0<=info.st_ino<2**64 or info.st_dev<0:raise ValueError('inode identity outside supported bound')
        return (int(info.st_dev)<<64)|int(info.st_ino)
    def account_directory(path):
        nonlocal allocated,directories,vanished_entries
        try:info=os.stat(path,follow_symlinks=False)
        except FileNotFoundError:
            vanished_entries+=1;return
        if not stat.S_ISDIR(info.st_mode):raise ValueError('non-directory or symlink in new storage')
        key=identity(info)
        if key not in seen:
            seen.add(key);allocated+=info.st_blocks*512;directories+=1
    for root in selected:
        account_directory(root)
        for directory,child_dirs,names in os.walk(root,followlinks=False):
            for name in child_dirs:account_directory(os.path.join(directory,name))
            for name in names:
                try:info=os.stat(os.path.join(directory,name),follow_symlinks=False)
                except FileNotFoundError:
                    vanished_entries+=1;continue
                if not stat.S_ISREG(info.st_mode):raise ValueError('nonregular file in research storage')
                file_paths+=1;key=identity(info)
                if key in seen:continue
                seen.add(key);logical+=info.st_size;allocated+=info.st_blocks*512;files+=1
    return {'unique_logical_bytes':logical,'unique_allocated_bytes':allocated,'unique_files':files,
        'file_paths':file_paths,'namespace_entries':file_paths+directories,'unique_directories':directories,
        'directory_blocks_included':True,'hardlink_deduplication':True,
        'git_and_restore_roots_must_be_included_if_local':True,
        'inventory_memory_policy':'compact inode integers only; no retained file Path set',
        'vanished_during_scan':vanished_entries,'inter_scan_growth_covered_by_frozen_overshoot_reserve':True}


def collect_clock_evidence(*, runner=None):
    """Raw new-launch UTC/monotonic and sync status; no legacy offset conversion."""
    runner = runner or (lambda args: subprocess.run(args, capture_output=True, text=True, timeout=10))
    started, monotonic_started = dt.datetime.now(UTC), time.monotonic_ns()
    commands = {}
    for name, args in (('chrony_tracking', ['chronyc', 'tracking']),
                       ('ntp_synchronized', ['timedatectl', 'show', '-p', 'NTPSynchronized', '--value'])):
        try:
            result = runner(args)
            commands[name] = {'argv': args, 'returncode': result.returncode,
                              'stdout': result.stdout, 'stderr': result.stderr}
        except (OSError, subprocess.SubprocessError) as exc:
            commands[name] = {'argv': args, 'returncode': None, 'error': type(exc).__name__ + ':' + str(exc)[:300]}
    chrony, ntp = commands['chrony_tracking'], commands['ntp_synchronized']
    normal = (chrony.get('returncode') == 0 and any(
        row.lower().startswith('leap status') and row.split(':', 1)[-1].strip() == 'Normal'
        for row in chrony.get('stdout', '').splitlines()))
    synchronized = ntp.get('returncode') == 0 and ntp.get('stdout', '').strip().lower() == 'yes'
    return {'schema': 'KOD_RESEARCH_RAW_CLOCK_V1', 'utc_started_at': iso(started),
            'utc_received_at': iso(dt.datetime.now(UTC)), 'monotonic_started_ns': monotonic_started,
            'monotonic_received_ns': time.monotonic_ns(), 'commands': commands,
            'sync_status': 'OK' if normal and synchronized else 'UNKNOWN_OR_UNSYNCHRONIZED',
            'legacy_offset_math_used': False, 'one_way_latency_proven': False,
            'independent_absolute_timestamp_proof': False}


def local_git_packing_probe(archive_root, backup_repository, temporary_parent,
                            *, compare_forbidden_repack=True):
    """Measure all local allocation stages on a retained-source fixture.

    Hardlink only the new backup allowlist into an isolated temporary worktree.
    Record loose Git storage, stdout packing and a conservative retained
    loose-plus-pack stage. No remote is configured and no push occurs. This
    validates physical accounting; extrapolating actual 35-day load still needs
    measured complete transport/normalized containers and index growth.
    """
    archive_root, backup_repository = Path(archive_root), Path(backup_repository)
    temporary_parent = Path(temporary_parent)
    if temporary_parent.resolve().is_relative_to(archive_root.resolve()) or temporary_parent.resolve().is_relative_to(backup_repository.resolve()):
        raise ValueError('packing probe staging must be separate from live archives')
    head = IncrementalBackup(backup_repository)._head()
    if head is None:
        raise ValueError('packing probe needs a committed local backup fixture')
    env = {key: value for key, value in os.environ.items() if not key.startswith('GIT_')}
    env.update(GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1')
    with tempfile.TemporaryDirectory(prefix='research-packing-', dir=temporary_parent) as temporary:
        worktree = Path(temporary) / 'worktree'; worktree.mkdir()
        for part in ('objects', 'manifests', 'HEAD.json'):
            source = backup_repository / part
            paths = [source] if source.is_file() else [path for path in source.rglob('*') if path.is_file()]
            for path in paths:
                if path.is_symlink(): raise ValueError('symlink in packing fixture')
                target = worktree / path.relative_to(backup_repository)
                target.parent.mkdir(parents=True, exist_ok=True)
                os.link(path, target)
        roots = [archive_root, backup_repository, worktree]
        stages = {'linked_worktree': unique_storage_bytes(roots)}
        base = ['git', *GIT_SCOPED_OPTIONS]
        def git(*args):
            result = subprocess.run([*base, '-C', str(worktree), *args], capture_output=True,
                                    text=True, timeout=60, env=env)
            if result.returncode: raise RuntimeError('isolated local Git probe failed: ' + result.stderr[-500:])
            return result.stdout.strip()
        git('init', '-b', 'research-packing-probe')
        for name, value in (('gc.auto','0'), ('maintenance.auto','false'),
                            ('pack.threads','1'), ('pack.windowMemory','16m'), ('pack.window','0')):
            git('config', '--local', name, value)
        git('add', 'objects', 'manifests', 'HEAD.json')
        git('-c', 'user.name=Capacity probe', '-c', 'user.email=research-probe@localhost',
            'commit', '-m', 'Isolated local research packing fixture')
        stages['loose_git_objects'] = unique_storage_bytes(roots)
        hasher, streamed = hashlib.sha256(), 0
        with tempfile.TemporaryFile() as error:
            process = subprocess.Popen([*base, '-C', str(worktree), 'pack-objects', '--all', '--stdout'],
                                       stdout=subprocess.PIPE, stderr=error, env=env)
            expired = []
            def expire():
                if process.poll() is None:
                    expired.append(True)
                    process.kill()
            watchdog = threading.Timer(60, expire)
            watchdog.daemon = True
            watchdog.start()
            try:
                while block := process.stdout.read(65536):
                    streamed += len(block); hasher.update(block)
                if process.wait(timeout=60): raise RuntimeError('isolated stdout packing probe failed or exceeded 60 seconds')
            finally:
                watchdog.cancel()
                process.stdout.close()
                if process.poll() is None: process.kill(); process.wait()
        stages['after_stdout_packing'] = unique_storage_bytes(roots)
        chosen_maximum = max(value['unique_allocated_bytes'] for value in stages.values())
        # Comparison is confined to this disposable local probe. The chosen
        # operational helper never invokes gc/repack or writes a complete pack.
        if compare_forbidden_repack:
            git('repack', '-a')
            stages['forbidden_loose_plus_retained_full_pack'] = unique_storage_bytes(roots)
        maximum = max(value['unique_allocated_bytes'] for value in stages.values())
        return {'schema': 'KOD_RESEARCH_LOCAL_GIT_FOOTPRINT_V1', 'backup_manifest': head['manifest'],
                'stages': stages, 'maximum_measured_allocated_bytes': maximum,
                'chosen_streamed_mode_peak_allocated_bytes': chosen_maximum,
                'chosen_mode_writes_full_pack_file': False,
                'chosen_mode_server_gc_or_repack_permitted': False,
                'forbidden_full_repack_comparison_measured': compare_forbidden_repack,
                'streamed_pack_bytes': streamed, 'streamed_pack_sha256': hasher.hexdigest(),
                'remote_configured': False, 'pushed': False, 'temporary_probe_removed_after_measurement': True,
                'projection_status': 'UNDECIDED_UNTIL_ACTUAL_WS_CONTAINER_AND_35_DAY_GROWTH_ARE_MEASURED',
                'limits': ['Conservative loose-plus-pack stage is measured, not a strict kernel transient-space upper bound.',
                           'Existing remote repository quotas/transfer limits are not verified.',
                           'A full server-side restore requires another copy; use the authorized off-host Mac route for full restore.']}



class BackupTransportTransient(RuntimeError):
    """Known retryable network transport failure; no access-policy bypass."""


def classify_backup_git_failure(action, stderr):
    text=stderr.decode('utf-8','replace').lower() if isinstance(stderr,bytes) else str(stderr).lower()
    if action not in ('ls-remote','push'):return 'UNKNOWN_OR_LOCAL_FAILURE'
    denied=('permission denied','publickey','repository not found','access denied','authentication failed',
            'host key verification failed','remote host identification has changed','forbidden','403','429','451')
    if any(marker in text for marker in denied):return 'ACCESS_OR_POLICY_DENIED'
    transient=('could not resolve hostname','temporary failure in name resolution','connection timed out',
               'connection timeout','connection reset by peer','network is unreachable','no route to host')
    return 'TRANSIENT_NETWORK_TRANSPORT' if any(marker in text for marker in transient) else 'UNKNOWN_OR_LOCAL_FAILURE'

def scoped_git_backup(backup_root, config, *, health=None, publish=False, ssh_command=None):
    """Commit only new scoped manifests/objects; optional exact-branch push.

    No fetch, force, checkout, gc, maintenance or repack is used. Git send-pack
    streams pack-objects stdout to SSH; it does not create a full local pack.
    Existing authorized SSH workflow may be supplied by the installer. This
    function creates no key, grant, remote resource or security setting.
    """
    limits = validate_config(config)
    backup_root = Path(backup_root)
    binding = json.loads((backup_root/'RESEARCH_IDENTITY.json').read_bytes())
    if (binding.get('trial_id') != limits['trial_id'] or binding.get('config_sha256') != limits['config_sha256']
            or binding.get('branch') != limits['backup_branch'] or binding.get('repository') != REPOSITORY):
        raise ValueError('exact scoped backup binding differs')
    repository = backup_root/'repository'
    if repository.is_symlink() or (repository/'.git').is_symlink():
        raise ValueError('scoped Git paths must not be symlinks')
    if ((repository/'.git').exists() and not (repository/'.git').is_dir()
            or (repository/'.git/commondir').exists()):
        raise ValueError('scoped Git repository must have its own contained Git directory')
    forbidden = tuple(Path(path).resolve() for path in ('/var/lib/kod-ops', '/var/lib/kod-supplement-ops',
                                                       '/var/lib/kod-economic-backup-v1'))
    if any(repository.resolve().is_relative_to(path) for path in forbidden):
        raise ValueError('protected original backup root')
    env = {key: value for key, value in os.environ.items() if not key.startswith('GIT_')}
    env.update(GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1', GIT_TERMINAL_PROMPT='0')
    if ssh_command is not None: env['GIT_SSH_COMMAND'] = ssh_command
    base = ['git', *GIT_SCOPED_OPTIONS, '-C', str(repository)]
    def git(*args, accepted=(0,), input=None):
        result = subprocess.run([*base,*args], input=input, capture_output=True, timeout=90, env=env)
        if result.returncode not in accepted:
            # Do not echo SSH environment, key paths or unsanitized remote output.
            category=classify_backup_git_failure(args[0],result.stderr)
            if category=='TRANSIENT_NETWORK_TRANSPORT':
                raise BackupTransportTransient('scoped Git '+args[0]+' failed; category='+category)
            raise RuntimeError('scoped Git '+args[0]+' failed; returncode='+str(result.returncode)+'; category='+category)
        return result
    backup = IncrementalBackup(repository)
    with backup.lock():
        head = backup._head()
        if head is None: raise ValueError('committed local snapshot required before Git backup')
        if not (repository/'.git').exists():
            git('init','-b',limits['backup_branch'])
        branch = git('symbolic-ref','--short','HEAD').stdout.decode().strip()
        if branch != limits['backup_branch']:
            raise ValueError('existing Git branch is not the exact scoped research branch')
        origin = git('remote','get-url','origin',accepted=(0,2))
        if origin.returncode == 0 and origin.stdout.decode().strip() != REMOTE:
            raise ValueError('existing scoped Git remote differs')
        if origin.returncode == 2: git('remote','add','origin',REMOTE)
        for name, value in (('gc.auto','0'), ('maintenance.auto','false'), ('pack.threads','1'),
                            ('pack.windowMemory','16m'), ('pack.window','0')):
            git('config','--local',name,value)
        has_commit = git('rev-parse','--verify','HEAD',accepted=(0,128)).returncode == 0
        if has_commit:
            previous = git('show','HEAD:HEAD.json')
            prior_manifest = json.loads(previous.stdout)['manifest']
        else:
            if git('ls-files','-z').stdout:
                raise ValueError('unborn scoped Git repository contains an existing index; reconcile first')
            prior_manifest = '0'*64
        object_index = refresh_bundle_index(repository, git, git('rev-parse','HEAD').stdout.decode().strip() if has_commit else None)
        manifest, pending, seen = head['manifest'], set(), set()
        while manifest != prior_manifest:
            if manifest == '0'*64 or manifest in seen:
                raise ValueError('Git snapshot head is not an ancestor of current backup')
            seen.add(manifest)
            value = backup._manifest(manifest)
            pending.add('manifests/'+manifest+'.json')
            for record in value['files'].values():
                for obj in record['objects']:
                    pending.add('objects/'+obj['sha256'][:2]+'/'+obj['sha256'])
            manifest = value['previous']
        control_head=_control_head(repository)
        if control_head:
            old_control=git('show','HEAD:CONTROL_HEAD.json',accepted=(0,128))
            old_manifest=json.loads(old_control.stdout)['manifest'] if old_control.returncode==0 else '0'*64
            control_manifest=control_head['manifest'];control_seen=set()
            while control_manifest!=old_manifest:
                if control_manifest=='0'*64 or control_manifest in control_seen:
                    raise ValueError('Git control head is not an ancestor of current controls')
                control_seen.add(control_manifest);value=_control_manifest(repository,control_manifest)
                pending.add('controls/manifests/'+control_manifest+'.json')
                pending.update(record['object'] for record in value['files'].values() if record['present'])
                control_manifest=value['previous']
            pending.add('CONTROL_HEAD.json')
        engine_head_path=repository/'ENGINE_HEAD.json'
        if engine_head_path.exists():
            current_engine=json.loads(engine_head_path.read_bytes())
            previous_engine=git('show','HEAD:ENGINE_HEAD.json',accepted=(0,128))
            old_files=json.loads(previous_engine.stdout)['files'] if previous_engine.returncode==0 else {}
            for name,record in current_engine['files'].items():
                if name in old_files and old_files[name]!=record:raise ValueError('immutable engine export changed')
                if name not in old_files:pending.add(name)
            pending.add('ENGINE_HEAD.json')
        release_head_path=repository/'RELEASE_HEAD.json'
        if release_head_path.exists():
            current_release=json.loads(release_head_path.read_bytes())
            previous_release=git('show','HEAD:RELEASE_HEAD.json',accepted=(0,128))
            old_files=json.loads(previous_release.stdout)['files'] if previous_release.returncode==0 else {}
            for name,record in current_release['files'].items():
                if name in old_files and old_files[name]!=record:raise ValueError('frozen release backup changed')
                if name not in old_files:pending.add(name)
            pending.add('RELEASE_HEAD.json')
        if health is not None:
            if health.get('trial_id') != limits['trial_id'] or health.get('config_sha256') != limits['config_sha256']:
                raise ValueError('published health identity differs')
            _shared_atomic(repository/'HEALTH.json', health)
        immutable_write(repository/'RESEARCH_IDENTITY.json',canonical(binding)+b'\n')
        pending.update(('HEAD.json','RESEARCH_IDENTITY.json'))
        for name in ('HEALTH.json','RESTORE.md','STOPPED-HEARTBEAT-DEMONSTRATION.json'):
            if (repository/name).is_file(): pending.add(name)
        for name in pending:
            if (repository/name).is_symlink() or not (repository/name).is_file():
                raise ValueError('scoped Git member must be regular')
        # One immutable hourly payload replaces thousands of growing hash-prefix
        # Git tree entries. The working payload is disposable after Git commits
        # it: its exact bytes then live in Git; source/archive hardlinks remain.
        # Remove only byte-verified temporary copies of members already safely
        # committed in prior Git bundles. Keep manifest chains locally readable.
        for name in tuple(pending):
            prior = object_index.execute('SELECT sha,bytes FROM members WHERE name=?',(name,)).fetchone()
            if prior is not None and name.startswith(('objects/','controls/objects/','engine/','release/')):
                path=repository/name
                if stream_hash(path)!=(prior[0],prior[1]):raise ValueError('repeated retired object differs')
                path.unlink();pending.remove(name)
        bundle = None
        immutable_members = {name for name in pending if name.startswith(('objects/','manifests/','controls/','engine/','release/'))}
        if immutable_members:
            bundle = build_backup_bundle(repository, immutable_members | {'HEAD.json','RESEARCH_IDENTITY.json'}
                | ({'CONTROL_HEAD.json'} if control_head else set())
                | ({'ENGINE_HEAD.json'} if engine_head_path.exists() else set())
                | ({'RELEASE_HEAD.json'} if release_head_path.exists() else set()), config, head)
        pending = {name for name in pending if not name.startswith(('objects/','manifests/','controls/','engine/','release/'))}
        if bundle:
            pending.update((bundle['bundle_path'], bundle['manifest_path']))
        git('add','--pathspec-from-file=-','--pathspec-file-nul',
            input=b''.join(name.encode()+b'\0' for name in sorted(pending)))
        staged = {name.decode() for name in git('diff','--cached','--name-only','-z').stdout.split(b'\0') if name}
        if staged - pending:
            raise ValueError('unrelated pre-staged Git paths; reconcile without committing')
        changed = git('diff','--cached','--quiet',accepted=(0,1)).returncode == 1
        if changed:
            git('-c','user.name=KOD research backup','-c','user.email=kod-research@localhost',
                'commit','-m','Capacity archive delta '+str(head['seq']))
        commit = git('rev-parse','HEAD').stdout.decode().strip()
        if bundle:
            # Check the Git blob before removing its additional filesystem copy.
            stored = git('show', commit+':'+bundle['bundle_path']).stdout
            if hashlib.sha256(stored).hexdigest() != bundle['sha256']:
                raise ValueError('committed immutable backup bundle differs')
            (repository/bundle['bundle_path']).unlink()
            for record in bundle['files']:
                name=record['path']
                if name.startswith(('objects/','controls/objects/','engine/','release/')):
                    object_index.execute('INSERT OR IGNORE INTO members VALUES(?,?,?)',(name,record['sha256'],record['bytes']))
            object_index.commit()
            # Retirement follows durable Git commit and exact blob verification.
            # A crash before this loop only retains extra safe staging copies.
            for record in bundle['files']:
                name=record['path']
                if name.startswith(('objects/','controls/objects/','engine/','release/')):
                    path=repository/name
                    if path.exists():path.unlink()
            fsync_directory(repository/'bundles')
        object_index.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('git_commit',commit))
        object_index.commit();object_index.close()
        acknowledged = False
        if publish:
            remote = git('ls-remote','--heads','origin','refs/heads/'+limits['backup_branch']).stdout.decode().split()
            if remote:
                remote_sha = remote[0]
                if git('merge-base','--is-ancestor',remote_sha,commit,accepted=(0,1,128)).returncode != 0:
                    raise ValueError('remote branch is not a known local ancestor; reconcile before push')
            git('push','--no-verify','origin','HEAD:refs/heads/'+limits['backup_branch'])
            remote = git('ls-remote','--heads','origin','refs/heads/'+limits['backup_branch']).stdout.decode().split()
            if not remote or remote[0] != commit: raise RuntimeError('scoped off-host acknowledgement differs')
            acknowledged = True
        return {'schema':'KOD_RESEARCH_STREAMED_GIT_BACKUP_V1','trial_id':limits['trial_id'],
            'branch':limits['backup_branch'],'repository':REPOSITORY,'manifest':head['manifest'],
            'commit':commit,'new_manifests':len(seen),'staged_paths':len(pending),'committed':changed,
            'pushed':publish,'offhost_acknowledged':acknowledged,'full_local_pack_file_written':False,
            'server_gc_or_repack_used':False,'source_hardlinks_are_independent_copy':False,
            'backup_format':'KOD_RESEARCH_BUNDLES_V1','bundle':bundle}


def stream_incremental_git_probe(repository, previous_commit):
    """Read-only stdout pack of the new commit range, without a pack tempfile."""
    repository = Path(repository)
    if not re.fullmatch('[0-9a-f]{40,64}',previous_commit):
        raise ValueError('explicit prior Git commit required')
    if repository.is_symlink() or (repository/'.git').is_symlink():
        raise ValueError('regular scoped Git repository required')
    env = {key:value for key,value in os.environ.items() if not key.startswith('GIT_')}
    env.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0')
    argv = ['git',*GIT_SCOPED_OPTIONS,'-C',str(repository)]
    process = subprocess.Popen([*argv,'pack-objects','--stdout','--revs'],stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,env=env)
    expired = []
    def expire():
        if process.poll() is None:
            expired.append(True);process.kill()
    watchdog = threading.Timer(60,expire);watchdog.daemon=True;watchdog.start()
    hasher,total = hashlib.sha256(),0
    try:
        process.stdin.write(('HEAD\n^'+previous_commit+'\n').encode());process.stdin.close()
        while block := process.stdout.read(65536): total+=len(block);hasher.update(block)
        if process.wait(timeout=60): raise RuntimeError('incremental stdout Git probe failed or exceeded60seconds')
    finally:
        watchdog.cancel();process.stdout.close()
        if process.poll() is None: process.kill();process.wait()
    return {'schema':'KOD_INCREMENTAL_STREAMED_GIT_PROBE_V1','pack_bytes':total,
        'pack_sha256':hasher.hexdigest(),'previous_commit':previous_commit,
        'full_local_pack_file_written':False,'network_or_push_performed':False,
        'server_gc_or_repack_used':False,'stream_buffer_bytes':65536}


def sample_cgroup(cgroup, *, previous=None, now=None):
    """Read only this new service cgroup; CPU uses one-core wall-time fraction."""
    path = Path(cgroup)
    epoch = time.time() if now is None else float(now)
    def values(name):
        return dict(row.split() for row in (path / name).read_text().splitlines() if row.strip())
    cpu = values('cpu.stat')
    memory_events = values('memory.events')
    usage = int(cpu['usage_usec'])
    fraction = None
    if previous is not None:
        elapsed = epoch - previous['epoch']
        if elapsed <= 0 or usage < previous['cpu_usage_usec']:
            raise ValueError('cgroup sample clock or CPU counter regressed')
        fraction = (usage - previous['cpu_usage_usec']) / (elapsed * 1_000_000)
    return {'epoch': epoch, 'cpu_usage_usec': usage, 'cpu_fraction': fraction,
            'cpu_fraction_definition': 'one logical core; no division by host core count',
            'memory_current_bytes': int((path / 'memory.current').read_text()),
            'memory_peak_bytes': int((path / 'memory.peak').read_text()),
            'oom_kills': int(memory_events.get('oom_kill', 0)),
            'oom_events': int(memory_events.get('oom', 0))}


def assess_resources(config, resources):
    limits = validate_config(config)
    issues, unknown = [], []
    def known_number(value):
        return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>=0
    required = ('disk_free_bytes', 'new_storage_bytes', 'memory_current_bytes', 'memory_peak_bytes', 'oom_kills')
    for key in required:
        value = resources.get(key)
        if not known_number(value):
            unknown.append(key)
    if known_number(resources.get('disk_free_bytes')) and resources['disk_free_bytes']<MIN_FREE_BYTES:
        issues.append('FREE_DISK_BELOW_2_GIB')
    if known_number(resources.get('new_storage_bytes')) and resources['new_storage_bytes']>limits['new_storage_budget_bytes']:
        issues.append('NEW_STORAGE_ABOVE_FROZEN_25_PERCENT_BUDGET')
    if any(known_number(resources.get(key)) and resources[key]>MEMORY_LIMIT_BYTES for key in ('memory_current_bytes','memory_peak_bytes')):
        issues.append('NEW_WORKER_MEMORY_ABOVE_192_MIB')
    if any(known_number(resources.get(key)) and resources[key]>0 for key in ('oom_kills','oom_events')):
        issues.append('NEW_WORKER_OOM_EVENT')
    cpu = resources.get('cpu_fraction')
    if cpu is None:
        unknown.append('cpu_fraction_needs_second_sample')
    elif not isinstance(cpu, (int, float)) or isinstance(cpu, bool) or not math.isfinite(cpu) or cpu < 0:
        unknown.append('cpu_fraction_invalid')
    elif cpu > .10:
        issues.append('NEW_WORKER_CPU_ABOVE_TEN_PERCENT_OF_ONE_CORE')
    if resources.get('backlog_growing') is True: issues.append('GROWING_PROCESSING_BACKLOG')
    if config.get('phase')=='RESEARCH35D':
        if known_number(resources.get('new_storage_bytes')) and resources['new_storage_bytes']>config['hard_storage_bytes']:
            issues.append('FINITE_RESEARCH_STORAGE_HARD_CAP')
        if known_number(resources.get('disk_free_bytes')) and resources['disk_free_bytes']<MIN_FREE_BYTES+config['overshoot_reserve_bytes']:
            issues.append('FINITE_RESEARCH_FREE_DISK_RESERVE')
        for key,cap in (('new_file_count',config['hard_file_count']),('new_inode_count',config['hard_inode_count'])):
            value=resources.get(key)
            if not isinstance(value,int) or isinstance(value,bool) or value<0:unknown.append(key)
            elif value>cap:issues.append('FINITE_RESEARCH_'+key.upper()+'_HARD_CAP')
        free=resources.get('free_inodes')
        if not isinstance(free,int) or isinstance(free,bool) or free<0:unknown.append('free_inodes')
        elif free<config['minimum_free_inodes']+config['overshoot_reserve_inodes']:
            issues.append('FINITE_RESEARCH_FREE_INODE_RESERVE')
    return {'status': 'FAILED' if issues or any(not key.endswith('needs_second_sample') for key in unknown)
            else 'PRELIMINARY' if unknown else 'OK', 'issues': issues, 'unknown': unknown,
            'memory_limit_bytes': MEMORY_LIMIT_BYTES, 'cpu_fraction_limit': .10,
            'minimum_free_bytes': MIN_FREE_BYTES, 'new_storage_budget_bytes': limits['new_storage_budget_bytes']}


def health_record(config, heartbeat, resources, preservation, *, backup_ack=None, now=None):
    limits = validate_config(config)
    instant = timestamp(now or dt.datetime.now(UTC))
    epoch = instant.timestamp()
    resource_check = assess_resources(config, resources)
    issues = list(resource_check['issues'])
    issues.extend('RESOURCE_UNKNOWN:' + key for key in resource_check['unknown'] if key != 'cpu_fraction_needs_second_sample')
    if preservation.get('unchanged') is not True or preservation.get('source_files_checked') != 527 or preservation.get('static_invariants_checked') != 34:
        issues.append('ORIGINAL_PRESERVATION_UNVERIFIED_OR_CHANGED')
    if heartbeat.get('trial_id') != limits['trial_id']: issues.append('COLLECTOR_TRIAL_ID_MISMATCH')
    collector_epoch = heartbeat.get('epoch', heartbeat.get('emitted_epoch'))
    if not isinstance(collector_epoch, (int, float)) or isinstance(collector_epoch, bool) or not math.isfinite(collector_epoch):
        issues.append('COLLECTOR_HEARTBEAT_MISSING')
        collector_epoch = None
    elif collector_epoch > epoch + 5:
        issues.append('COLLECTOR_CLOCK_IN_FUTURE')
    phase = str(heartbeat.get('phase', 'UNKNOWN')).upper()
    if phase == 'COMPLETE' and instant < limits['end']:
        issues.append('COLLECTOR_FINISHED_BEFORE_FROZEN_END')
    running_window = limits['start'] <= instant <= limits['drain_end']
    if running_window and collector_epoch is not None and epoch - collector_epoch > 120:
        issues.append('COLLECTOR_HEARTBEAT_STOPPED_OVER_120_SECONDS')
    if phase in ('PAUSED', 'FAILED', 'HALTED', 'PROVIDER_STOPPED'): issues.append('COLLECTOR_' + phase)
    acknowledged = (backup_ack or {}).get('epoch')
    if instant >= limits['start'] + dt.timedelta(hours=2):
        if (not isinstance(acknowledged, (int, float)) or isinstance(acknowledged, bool)
                or not math.isfinite(acknowledged) or acknowledged > epoch + 5 or epoch - acknowledged > 7200):
            issues.append('OFFHOST_BACKUP_ACKNOWLEDGEMENT_MISSING_OR_OVER_TWO_HOURS')
            acknowledged = None
    return {'schema': 'KOD_RESEARCH_HEALTH_V1', 'trial_id': limits['trial_id'],
            'config_sha256': limits['config_sha256'], 'epoch': epoch, 'emitted_at': iso(instant),
            'collector_epoch': collector_epoch, 'phase': phase,
            'start_at': iso(limits['start']), 'end_at': iso(limits['end']),
            'receipt_drain_end': iso(limits['drain_end']),
            'status': 'FAILED' if issues else resource_check['status'], 'issues': sorted(set(issues)),
            'preservation': preservation, 'resources': resources, 'resource_check': resource_check,
            'last_acknowledged_epoch': acknowledged, 'collector': heartbeat,
            'research_phase': 'PROSPECTIVE_RESEARCH', 'capacity_pass_claimed': False,
            'automatically_promotes_30_day_study': False}


def _shared_atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    owner = path.parent.stat()
    descriptor, temporary = tempfile.mkstemp(dir=path.parent, prefix='.research-health-')
    try:
        with os.fdopen(descriptor, 'wb') as output:
            os.fchmod(output.fileno(), 0o644)
            if os.geteuid() == 0:
                os.fchown(output.fileno(), owner.st_uid, owner.st_gid)
            output.write(canonical(value) + b'\n')
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
        fsync_directory(path.parent)
    finally:
        if os.path.exists(temporary): os.unlink(temporary)


def write_health(state, health):
    """Status-only shared files; never clear a pause or mutate the event journal."""
    state = Path(state)
    pause = state / 'PAUSED.json'
    if health['status'] == 'FAILED' and not pause.exists():
        value = {'schema': 'KOD_RESEARCH_OPS_PAUSE_V1', 'trial_id': health['trial_id'],
                 'at': health['emitted_at'], 'reason': health['issues'],
                 'manual_review_required': True, 'frozen_end_unchanged': True}
        immutable_write(pause, canonical(value) + b'\n')
        pause.chmod(0o644)
        fsync_directory(state)
    value = dict(health, pause_latched=pause.exists())
    if pause.exists() and value['status'] != 'FAILED': value['status'] = 'PAUSED'
    _shared_atomic(state / 'HEALTH.json', value)
    return value


def research_backup(store, backup_root, config):
    """Bind a new local backup root to one research identity; no old HEAD reuse."""
    limits = validate_config(config)
    backup_root = Path(backup_root)
    source = Path(store.root).resolve()
    forbidden = tuple(Path(path).resolve() for path in ('/var/lib/kod-ops', '/var/lib/kod-supplement-ops',
                 '/var/lib/kod-economic-backup-v1'))
    if any(backup_root.resolve().is_relative_to(path) for path in forbidden):
        raise ValueError('original or other-study backup root is protected')
    if backup_root.resolve() == source or backup_root.resolve().is_relative_to(source):
        raise ValueError('backup root must be separate from the one new observer archive')
    protected_source = ('/opt/kod/current', '/opt/kod/supplement-v1', '/var/lib/kod/timing-forward',
                        '/var/lib/kod/schedule', '/var/lib/kod/supplement-v1', '/var/lib/kod/economic-v1')
    if any(source.is_relative_to(Path(path).resolve()) for path in protected_source):
        raise ValueError('original or other-study archive is protected')
    backup_root.mkdir(parents=True, exist_ok=True)
    identity = {'schema': 'KOD_RESEARCH_BACKUP_BINDING_V1', 'trial_id': limits['trial_id'],
                'config_sha256': limits['config_sha256'], 'branch': limits['backup_branch'],
                'repository': REPOSITORY, 'source_root': str(source)}
    binding = backup_root / 'RESEARCH_IDENTITY.json'
    if not binding.exists() and (backup_root / 'repository' / 'HEAD.json').exists():
        raise ValueError('unbound existing backup HEAD; reconcile before reuse')
    immutable_write(binding, canonical(identity) + b'\n')
    receipt = IncrementalBackup(backup_root / 'repository').snapshot(store)
    engine_exports = snapshot_engine_exports(source, backup_root/'repository', config)
    return dict(receipt, intended_branch=limits['backup_branch'], intended_repository=REPOSITORY,
                network_or_git_mutation_performed=False, binding_sha256=stream_hash(binding)[0], engine_exports=engine_exports)


RESEARCH_CONTROL_NAMES = ('research.json','RESEARCH_RELEASE.json','PACKAGE.json','PAUSED.json',
    'PROVIDER_STOP.json','SOURCE_HOST_STOPS.json','SOURCE_CACHE.json',
    'LAUNCH_RECEIPT.json','CAPACITY_CLOSURE.json','PREDECESSOR_BACKUP_ACK.json','PREDECESSOR_BACKUP_HEAD.json')


def _control_head(repository):
    path=Path(repository)/'CONTROL_HEAD.json'
    if not path.exists():
        if any((Path(repository)/'controls/manifests').glob('*.json')):
            raise ValueError('control manifests without HEAD require reconciliation')
        return None
    if path.is_symlink() or not path.is_file():raise ValueError('control HEAD must be regular')
    raw=path.read_bytes();value=json.loads(raw)
    unsigned={key:child for key,child in value.items() if key!='hash'}
    if (canonical(value)+b'\n'!=raw or hashlib.sha256(canonical(unsigned)).hexdigest()!=value.get('hash')
            or value.get('schema')!='KOD_RESEARCH_CONTROL_HEAD_V1'):
        raise ValueError('control HEAD hash differs')
    return value


def _control_manifest(repository,identity):
    if not re.fullmatch('[a-f0-9]{64}',identity):raise ValueError('invalid control manifest hash')
    path=Path(repository)/'controls/manifests'/(identity+'.json')
    if path.is_symlink() or not path.is_file():raise ValueError('regular control manifest absent')
    raw=path.read_bytes();value=json.loads(raw)
    if (hashlib.sha256(raw).hexdigest()!=identity or canonical(value)+b'\n'!=raw
            or value.get('schema')!='KOD_RESEARCH_CONTROL_SNAPSHOT_V1'):
        raise ValueError('control manifest bytes differ')
    return value


def snapshot_research_controls(state_root,ops_root,config):
    """Retain exact authoritative controls; caches are explicitly recovery hints."""
    limits=validate_config(config);state_root=Path(state_root);ops_root=Path(ops_root)
    for protected in ('/var/lib/kod-ops','/var/lib/kod-supplement-ops','/var/lib/kod-economic-backup-v1'):
        if ops_root.resolve().is_relative_to(Path(protected).resolve()):raise ValueError('protected backup root')
    if state_root.resolve()==ops_root.resolve() or ops_root.resolve().is_relative_to(state_root.resolve()):
        raise ValueError('control backup must be separate from source state')
    repository=ops_root/'repository';backup=IncrementalBackup(repository)
    identity={'schema':'KOD_RESEARCH_BACKUP_BINDING_V1','trial_id':limits['trial_id'],
        'config_sha256':limits['config_sha256'],'branch':limits['backup_branch'],
        'repository':REPOSITORY,'source_root':str(state_root.resolve())}
    immutable_write(ops_root/'RESEARCH_IDENTITY.json',canonical(identity)+b'\n')
    with backup.lock():
        head=_control_head(repository);files={};new_bytes=0
        for name in RESEARCH_CONTROL_NAMES:
            path=state_root/name
            if path.is_symlink():raise ValueError('control source symlink refused')
            if not path.exists():
                if name in RESEARCH_CONTROL_NAMES[:3]:raise ValueError('authoritative control missing: '+name)
                files[name]={'present':False};continue
            if not path.is_file() or path.stat().st_size>4*1024**2:
                raise ValueError('control source must be bounded regular JSON')
            raw=path.read_bytes();value=json.loads(raw)
            if name=='research.json' and value!=config:raise ValueError('exact config object differs')
            digest=hashlib.sha256(raw).hexdigest();relative='controls/objects/'+digest
            if immutable_write(repository/relative,raw):new_bytes+=len(raw)
            files[name]={'present':True,'sha256':digest,'bytes':len(raw),'object':relative,
                'recovery_role':'DERIVED_HINT_RECONCILE_AGAINST_ARCHIVE' if name=='SOURCE_CACHE.json' else 'AUTHORITATIVE_EXACT_BYTES'}
        previous=_control_manifest(repository,head['manifest']) if head else None
        if previous and previous['files']==files:
            return {'status':'NO_CHANGE','manifest':head['manifest'],'new_object_bytes':new_bytes}
        manifest={'schema':'KOD_RESEARCH_CONTROL_SNAPSHOT_V1','trial_id':limits['trial_id'],
            'config_sha256':limits['config_sha256'],'seq':head['seq']+1 if head else 0,
            'previous':head['manifest'] if head else '0'*64,'files':files,
            'at':iso(dt.datetime.now(UTC)),'automatic_resume':False,
            'source_cache_may_precede_archive_commit':True}
        raw=canonical(manifest)+b'\n';digest=hashlib.sha256(raw).hexdigest()
        immutable_write(repository/'controls/manifests'/(digest+'.json'),raw)
        value={'schema':'KOD_RESEARCH_CONTROL_HEAD_V1','manifest':digest,'seq':manifest['seq'],
            'trial_id':limits['trial_id'],'config_sha256':limits['config_sha256']}
        value['hash']=hashlib.sha256(canonical(value)).hexdigest()
        _shared_atomic(repository/'CONTROL_HEAD.json',value)
        return {'status':'COMMITTED_LOCAL','manifest':digest,'seq':manifest['seq'],
            'new_object_bytes':new_bytes,'offhost_acknowledged':False}


def restore_research_controls(ops_root,destination,config):
    """Verify every control version and restore latest exact bytes to new staging."""
    limits=validate_config(config);repository=Path(ops_root)/'repository';destination=Path(destination)
    if destination.exists() or destination.is_symlink():raise ValueError('new control restore staging required')
    head=_control_head(repository)
    if head is None:raise ValueError('control snapshot absent')
    if head.get('trial_id')!=limits['trial_id'] or head.get('config_sha256')!=limits['config_sha256']:
        raise ValueError('control HEAD identity differs')
    chain=[];seen=set();identity=head['manifest']
    while identity!='0'*64:
        if identity in seen:raise ValueError('cyclic control history')
        seen.add(identity);value=_control_manifest(repository,identity);chain.append(value);identity=value['previous']
    for seq,value in enumerate(reversed(chain)):
        if (value['seq']!=seq or value['trial_id']!=limits['trial_id']
                or value['config_sha256']!=limits['config_sha256'] or set(value['files'])!=set(RESEARCH_CONTROL_NAMES)):
            raise ValueError('control chain identity or sequence differs')
        for name,record in value['files'].items():
            if not record['present']:continue
            if record['object']!='controls/objects/'+record['sha256']:raise ValueError('unsafe control object path')
            path=repository/record['object']
            if path.is_symlink() or not path.is_file() or stream_hash(path)!=(record['sha256'],record['bytes']):
                raise ValueError('control object bytes differ')
    if chain[0]['seq']!=head['seq']:raise ValueError('control HEAD sequence differs')
    destination.mkdir(parents=True,mode=0o700)
    latest=chain[0];restored=[]
    for name,record in latest['files'].items():
        if record['present']:
            immutable_write(destination/name,(repository/record['object']).read_bytes());restored.append(name)
    fsync_directory(destination);fsync_directory(destination.parent)
    return {'restored':True,'byte_identical':True,'files':restored,'control_versions_verified':len(chain),
        'manifest':head['manifest'],'source_cache_requires_archive_reconciliation':True,'automatic_resume':False}


def evaluate_external(health, config, *, now, allow_demonstration=False):
    """Pure validator for an external connected-GitHub read; never sends alerts."""
    limits = validate_config(config)
    instant, issues = timestamp(now), []
    epoch = instant.timestamp()
    if health.get('schema') != 'KOD_RESEARCH_HEALTH_V1': issues.append('HEALTH_SCHEMA_UNKNOWN')
    if health.get('trial_id') != limits['trial_id'] or health.get('config_sha256') != limits['config_sha256']:
        issues.append('EXACT_RESEARCH_IDENTITY_MISMATCH')
    if health.get('demonstration') and not allow_demonstration: issues.append('DEMONSTRATION_RECORD_IN_PRODUCTION_HEALTH')
    emitted = health.get('epoch')
    if not isinstance(emitted, (int, float)) or isinstance(emitted, bool) or not math.isfinite(emitted):
        issues.append('REMOTE_HEARTBEAT_MISSING')
    elif emitted > epoch + 5:
        issues.append('REMOTE_CLOCK_IN_FUTURE')
    elif limits['start'] <= instant <= limits['drain_end'] + dt.timedelta(hours=1):
        if str(health.get('phase', '')).upper() != 'COMPLETE' and epoch - emitted > 1800:
            issues.append('REMOTE_HEARTBEAT_STOPPED_OVER_30_MINUTES')
    if health.get('status') in ('FAILED', 'PAUSED', 'HALTED') or health.get('pause_latched'):
        issues.append('RESEARCH_COLLECTOR_REQUIRES_REVIEW')
    if health.get('status') not in ('OK', 'PRELIMINARY', 'FAILED', 'PAUSED', 'HALTED'):
        issues.append('REMOTE_HEALTH_STATUS_UNKNOWN')
    if str(health.get('phase', '')).upper() == 'COMPLETE' and instant < limits['end']:
        issues.append('FINITE_TRIAL_FINISHED_BEFORE_FROZEN_END')
    collector = health.get('collector_epoch')
    if limits['start'] <= instant <= limits['drain_end']:
        # The remote file is published every15min. Compare process liveness to
        # its own health-generation clock, not to the later external read time.
        reference = emitted if isinstance(emitted, (int, float)) and not isinstance(emitted, bool) and math.isfinite(emitted) else epoch
        if (not isinstance(collector, (int, float)) or isinstance(collector, bool)
                or not math.isfinite(collector) or collector > reference + 5 or reference - collector > 120):
            issues.append('COLLECTOR_HEARTBEAT_STOPPED_OR_UNKNOWN')
    if instant > limits['drain_end'] + dt.timedelta(minutes=10) and str(health.get('phase', '')).upper() != 'COMPLETE':
        issues.append('FINITE_TRIAL_FINAL_RECEIPT_MISSING')
    return {'notify_user': bool(issues), 'issues': sorted(set(issues)), 'checked_at': iso(instant),
            'trial_id': limits['trial_id'], 'delivery_performed': False,
            'demonstration': health.get('demonstration') is True,
            'detection_target': 'hourly checks plus30min freshness threshold:nominal90min maximum before platform/tool delays;no delivery SLA'}


def stopped_heartbeat_fixture(config, *, now):
    limits = validate_config(config)
    instant = timestamp(now)
    return {'schema': 'KOD_RESEARCH_HEALTH_V1', 'trial_id': limits['trial_id'],
            'config_sha256': limits['config_sha256'], 'epoch': instant.timestamp(),
            'collector_epoch': instant.timestamp() - 121, 'phase': 'RUNNING',
            'status': 'FAILED', 'pause_latched': True, 'demonstration': True,
            'issues': ['DEMONSTRATION_ONLY_COLLECTOR_STOPPED']}


def external_monitor_plan(config):
    limits = validate_config(config)
    start = limits['start'].strftime('%Y%m%dT%H%M%S')
    prompt = (f'Read HEALTH.json from the connected GitHub repository {REPOSITORY}, exact branch '
              f'{limits["backup_branch"]}. Validate trial_id={limits["trial_id"]} and config_sha256='
              f'{limits["config_sha256"]}. The fixed start is {iso(limits["start"])}, end is '
              f'{iso(limits["end"])}, and receipt-drain end is {iso(limits["drain_end"])}. '
              'Notify me if the file is unavailable, unreadable, identity-mismatched, marked FAILED/PAUSED, '
              'or the remote health epoch is more than 30 minutes old while collection should run. '
              'Also notify me if collector_epoch trails the health record epoch by more than 120 seconds during the active collection '
              'window or the finite final receipt is absent 10 minutes after receipt-drain end. '
              'Report exact observed UTC clocks and the linked branch file. Preserve unknown states; '
              'do not change services, original backup branches, access settings or schedules. '
              'If phase is COMPLETE after the drain, report its final status without treating intentionally '
              'stopped collection as an outage. At the 24-hour checkpoint, report the retained research '
              'checkpoint and WebSocket renewal evidence; report missing evidence as undecided. '
              'This is research monitoring, not trading approval or authorization to extend the trial.')
    return {'schema': 'KOD_RESEARCH_EXTERNAL_MONITOR_PLAN_V1', 'created_or_sent': False,
            'source_attachment_sha256': ATTACHMENT_SHA256,
            'protocol_r2_sha256': PROTOCOL_R2_SHA256,
            'github_read_args': {'repository_full_name': REPOSITORY, 'ref': limits['backup_branch'], 'path': 'HEALTH.json'},
            'server_publication_interval_seconds': 900, 'external_check_interval_seconds': 3600,
            'remote_stale_seconds': 1800, 'nominal_detection_target_seconds': 5400,
            'limits': ['No platform/tool delivery SLA.', 'Connected private repository access must still work on each run.',
                       'A new-branch GitHub Actions cron is not a substitute: scheduled workflows run from the default branch.',
                       'No main/default-branch change is authorized.', 'Git storage and transfer quotas remain unverified.'],
            'automation_create_args': {'title': 'Capacity heartbeat', 'prompt': prompt,
                'schedule': f'BEGIN:VEVENT\nDTSTART;TZID=Etc/UTC:{start}\nRRULE:FREQ=HOURLY;COUNT=50\nEND:VEVENT',
                'timing_mode': 'condition_watch', 'default_timezone': 'Etc/UTC'},
            'activation_evidence_required': ['Actual scoped branch HEALTH.json read from connected GitHub after first collection.',
                'Root/parent creates and confirms the finite external automation;record returned automation identity.',
                'Publish a demonstration-only stopped-heartbeat fixture on this new branch;manual external read must produce notify_user=true.',
                'Demonstrate user-visible alert delivery using the existing authorized route;pure local validator tests are insufficient.',
                'Never stop original collectors;any physical stop test targets only the new trial and retains gaps.']}


MAX_BUNDLE_BYTES = 64 * 1024**2
MAX_BUNDLE_EXPANDED_BYTES = 256 * 1024**2
MAX_BUNDLE_MEMBERS = 20000


def build_backup_bundle(repository, members, config, head):
    """Create one deterministic bounded immutable chunk; preserve original bytes."""
    repository = Path(repository)
    if len(members) > MAX_BUNDLE_MEMBERS: raise ValueError('backup bundle member cap exceeded')
    descriptors = []
    total = 0
    for name in sorted(members):
        path = repository/name
        if (Path(name).is_absolute() or '..' in Path(name).parts or path.is_symlink()
                or not path.is_file() or not path.resolve().is_relative_to(repository.resolve())):
            raise ValueError('unsafe backup bundle source')
        sha, size = stream_hash(path)
        total += size
        if total > MAX_BUNDLE_EXPANDED_BYTES: raise ValueError('backup bundle expanded byte cap exceeded')
        descriptors.append({'path':name, 'sha256':sha, 'bytes':size})
    repository.joinpath('bundles').mkdir(exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.bundle-', dir=repository)
    try:
        with os.fdopen(fd,'wb') as raw:
            with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=1) as compressed:
                with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as archive:
                    for record in descriptors:
                        info=tarfile.TarInfo(record['path']);info.size=record['bytes'];info.mode=0o444
                        with (repository/record['path']).open('rb') as body:archive.addfile(info,body)
            raw.flush();os.fsync(raw.fileno())
        sha, size = stream_hash(Path(temporary))
        if size > MAX_BUNDLE_BYTES: raise ValueError('compressed backup bundle byte cap exceeded')
        relative='bundles/'+sha+'.tar.gz';target=repository/relative
        if target.exists():
            if stream_hash(target)!=(sha,size):raise ValueError('existing bundle differs')
        else:os.link(temporary,target);target.chmod(0o444);fsync_directory(target.parent)
        descriptor={'schema':'KOD_RESEARCH_BACKUP_BUNDLE_V1','trial_id':config['trial_id'],
            'config_sha256':config_hash(config),'sha256':sha,'bytes':size,'bundle_path':relative,
            'archive_manifest':head['manifest'],'archive_sequence':head['seq'],
            'files':descriptors,'expanded_bytes':total}
        manifest_path='bundles/'+sha+'.json'
        immutable_write(repository/manifest_path,canonical(descriptor)+b'\n')
        return dict(descriptor,manifest_path=manifest_path)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)


def restore_bundle_repository(repository, destination, config):
    """Restore exact incremental-backup repository from local Git blobs.

    No network/checkout is needed; use a verified off-host clone for production.
    The recovered IncrementalBackup repository then validates/restores the archive.
    """
    limits=validate_config(config);repository=Path(repository);destination=Path(destination)
    if destination.exists() or destination.is_symlink():raise ValueError('new bundle restore staging required')
    env={key:value for key,value in os.environ.items() if not key.startswith('GIT_')}
    env.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0')
    def git(*args):
        result=subprocess.run(['git',*GIT_SCOPED_OPTIONS,'-C',str(repository),*args],capture_output=True,timeout=90,env=env)
        if result.returncode:raise ValueError('local bundle restore Git read failed')
        return result.stdout
    binding=json.loads(git('show','HEAD:RESEARCH_IDENTITY.json'))
    if binding['trial_id']!=limits['trial_id'] or binding['config_sha256']!=limits['config_sha256']:
        raise ValueError('bundle restore identity differs')
    names=git('ls-tree','-r','--name-only','HEAD','bundles').decode().splitlines()
    manifests=[]
    for name in names:
        if not re.fullmatch(r'bundles/[0-9a-f]{64}\.json',name):continue
        value=json.loads(git('show','HEAD:'+name))
        if (value.get('schema')!='KOD_RESEARCH_BACKUP_BUNDLE_V1' or value['trial_id']!=limits['trial_id']
                or value['config_sha256']!=limits['config_sha256']):raise ValueError('backup bundle manifest identity differs')
        manifests.append(value)
    if not manifests:raise ValueError('no immutable backup bundles')
    destination.mkdir(parents=True,mode=0o700)
    verified_bytes=0
    for value in sorted(manifests,key=lambda v:(v['archive_sequence'],v['sha256'])):
        raw=git('show','HEAD:'+value['bundle_path'])
        if len(raw)>MAX_BUNDLE_BYTES or len(raw)!=value['bytes'] or hashlib.sha256(raw).hexdigest()!=value['sha256']:
            raise ValueError('backup bundle bytes differ')
        expected={record['path']:record for record in value['files']};seen=set();expanded=0
        if len(expected)>MAX_BUNDLE_MEMBERS:raise ValueError('restore bundle count cap')
        with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
            for member in archive:
                record=expected.get(member.name)
                if (record is None or member.name in seen or not member.isfile()
                        or Path(member.name).is_absolute() or '..' in Path(member.name).parts
                        or member.size!=record['bytes']):raise ValueError('unsafe or mismatched bundle member')
                expanded+=member.size
                if expanded>MAX_BUNDLE_EXPANDED_BYTES:raise ValueError('restore expanded size cap')
                body=archive.extractfile(member).read()
                if hashlib.sha256(body).hexdigest()!=record['sha256']:raise ValueError('bundle member hash differs')
                # Mutable heads are replaced with exact current Git-head bytes below.
                if member.name not in ('HEAD.json','CONTROL_HEAD.json','ENGINE_HEAD.json','RELEASE_HEAD.json'):
                    immutable_write(destination/member.name,body)
                seen.add(member.name);verified_bytes+=len(body)
        if seen!=set(expected):raise ValueError('bundle member missing')
    for name in ('HEAD.json','CONTROL_HEAD.json','ENGINE_HEAD.json','RELEASE_HEAD.json','RESEARCH_IDENTITY.json','HEALTH.json'):
        if name in git('ls-tree','--name-only','HEAD',name).decode().splitlines():
            immutable_write(destination/name,git('show','HEAD:'+name))
    IncrementalBackup(destination)._head()
    if (destination/'CONTROL_HEAD.json').exists():_control_head(destination)
    return {'restored':True,'byte_identical':True,'bundles_verified':len(manifests),
        'member_bytes_verified':verified_bytes,'repository':str(destination),'network_used':False}



def snapshot_engine_exports(state_root, repository, config):
    """Only immutable authoritative ledger chunks; never growing SQLite copies."""
    root=Path(state_root)/'engine'/'ledger';repository=Path(repository)
    head_path=repository/'ENGINE_HEAD.json'
    current=json.loads(head_path.read_bytes()) if head_path.exists() else {
        'schema':'KOD_RESEARCH_ENGINE_EXPORT_HEAD_V1','trial_id':config['trial_id'],
        'config_sha256':config_hash(config),'files':{}}
    if current['trial_id']!=config['trial_id'] or current['config_sha256']!=config_hash(config):
        raise ValueError('engine export backup identity differs')
    added=0
    for path in sorted(root.glob('ledger-*.jsonl.gz')) if root.exists() else []:
        if path.is_symlink() or not path.is_file():raise ValueError('engine ledger export must be regular')
        name='engine/'+path.name
        if not re.fullmatch(r'engine/ledger-[0-9]{10}-[0-9]{10}-[0-9a-f]{64}\.jsonl\.gz',name):
            raise ValueError('engine export name differs')
        if name in current['files']:
            if path.stat().st_size!=current['files'][name]['bytes']:raise ValueError('engine export size changed')
            continue
        sha,size=stream_hash(path)
        if sha not in path.name:raise ValueError('engine export content identity differs')
        target=repository/name;target.parent.mkdir(exist_ok=True)
        if not target.exists():
            try:os.link(path,target)
            except OSError:immutable_write(target,path.read_bytes())
            fsync_directory(target.parent)
        elif stream_hash(target)!=(sha,size):raise ValueError('existing engine backup export differs')
        current['files'][name]={'sha256':sha,'bytes':size};added+=1
    if added or not head_path.exists():_shared_atomic(head_path,current)
    return {'new_chunks':added,'total_chunks':len(current['files']),
        'sqlite_cache_generations_retained':False,'authoritative_processing_boundaries_retained':True}



def snapshot_frozen_release(code_root, repository, config):
    """One byte-restorable package snapshot, not merely runtime hashes."""
    code=Path(code_root);repository=Path(repository);head_path=repository/'RELEASE_HEAD.json'
    manifest=json.loads((code/'RESEARCH_RELEASE.json').read_bytes())
    identity={'schema':'KOD_RESEARCH_RELEASE_BACKUP_V1','trial_id':config['trial_id'],
        'config_sha256':config_hash(config),'release_sha256':stream_hash(code/'RESEARCH_RELEASE.json')[0]}
    if head_path.exists():
        old=json.loads(head_path.read_bytes())
        if any(old.get(key)!=value for key,value in identity.items()):raise ValueError('frozen release snapshot identity differs')
        return {'status':'NO_CHANGE','files':len(old['files'])}
    names=sorted(set(manifest['files'])|{'research.json','RESEARCH_RELEASE.json','PACKAGE.json'})
    if len(names)>10000:raise ValueError('bounded frozen package member cap')
    files={}
    for name in names:
        source=code/name
        if Path(name).is_absolute() or '..' in Path(name).parts or source.is_symlink() or not source.is_file():
            raise ValueError('frozen release unsafe source')
        sha,size=stream_hash(source)
        if name in manifest['files']:
            expected=manifest['files'][name]
            if sha!=(expected['sha256'] if isinstance(expected,dict) else expected):raise ValueError('frozen release source differs')
        target=repository/'release'/name;target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():
            try:os.link(source,target)
            except OSError:immutable_write(target,source.read_bytes())
        elif stream_hash(target)!=(sha,size):raise ValueError('release backup source differs')
        files['release/'+name]={'sha256':sha,'bytes':size}
    _shared_atomic(head_path,dict(identity,files=files))
    return {'status':'SNAPSHOT_LOCAL','files':len(files),'source_hardlinks_are_independent_copy':False}



def refresh_bundle_index(repository, git, commit):
    """Bounded rebuildable index of immutable members already committed in Git."""
    connection=sqlite3.connect(Path(repository)/'BUNDLED_OBJECTS.sqlite',timeout=10)
    connection.execute('PRAGMA cache_size=-1024')
    connection.executescript('CREATE TABLE IF NOT EXISTS members(name TEXT PRIMARY KEY,sha TEXT NOT NULL,bytes INTEGER NOT NULL);CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);')
    prior=connection.execute("SELECT value FROM meta WHERE key='git_commit'").fetchone()
    old=prior[0] if prior else None
    if commit is None:return connection
    if old==commit:return connection
    if old:
        if git('merge-base','--is-ancestor',old,commit,accepted=(0,1,128)).returncode!=0:
            raise ValueError('bundle index Git history is not an ancestor')
        names=git('diff','--name-only',old,commit,'--','bundles').stdout.decode().splitlines()
    else:names=git('ls-tree','-r','--name-only',commit,'bundles').stdout.decode().splitlines()
    for name in names:
        if not re.fullmatch(r'bundles/[0-9a-f]{64}\.json',name):continue
        descriptor=json.loads(git('show',commit+':'+name).stdout)
        if descriptor.get('schema')!='KOD_RESEARCH_BACKUP_BUNDLE_V1':raise ValueError('bundle index source schema differs')
        for record in descriptor['files']:
            member=record['path']
            if member.startswith(('objects/','controls/objects/','engine/','release/')):
                previous=connection.execute('SELECT sha,bytes FROM members WHERE name=?',(member,)).fetchone()
                if previous and tuple(previous)!=(record['sha256'],record['bytes']):raise ValueError('committed bundle immutable member differs')
                connection.execute('INSERT OR IGNORE INTO members VALUES(?,?,?)',(member,record['sha256'],record['bytes']))
    connection.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('git_commit',commit));connection.commit()
    return connection
