"""Independent receipt-clock and non-hour-phase regression checks."""
import json
import tempfile
import unittest

from research_r2.engine import ResearchEngine, iso, stamp
from broad_observer.trigger import evaluate_causal


class IndependentReplayAudit(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory(prefix='kod-r2-engine-audit-')
        self.t0=stamp('2026-11-05T00:20:00Z')
        self.base=self.t0-1200
        self.engine=ResearchEngine(self.folder.name,{'t0':iso(self.t0),'primary':[{'symbol':'AAAUSDT'}]})

    def tearDown(self):
        self.engine.close();self.folder.cleanup()

    def _seed_hours(self,end=8):
        # Readily known, explicitly synthetic closed-hour rows. The20-minute
        # schedule phase makes the oldest240-minute-arm target175h20m old.
        with self.engine.transaction(self.engine):
            for hour in range(-180,end):
                opened=self.base+hour*3600
                value={'close':1.0,'quote_volume':30000.0}
                self.engine.db.execute('INSERT INTO hours VALUES(?,?,?,?,?,?)',
                    ('AAAUSDT',opened,max(opened+3600,self.t0-10),1.0,30000.0,json.dumps(value)))

    def test_non_hour_aligned_four_hour_arm_keeps_required_oldest_close(self):
        self._seed_hours()
        self.engine.process_until(self.base+8*3600+19*60)
        target=self.base+4*3600
        required_close=target-171*3600
        self.assertEqual(1,self.engine.db.execute('SELECT count(*) FROM hours WHERE symbol=? AND opened=?',
            ('AAAUSDT',required_close)).fetchone()[0])
        self.engine.process_until(self.base+8*3600+20*60)
        row=self.engine.db.execute('SELECT payload FROM ledger WHERE id=?',
            ('detector:240:AAAUSDT:'+str(int(target)),)).fetchone()
        payload=json.loads(row[0])
        self.assertEqual('FALSE',payload['result']['status'])
        self.assertEqual(168,payload['result']['features']['finite_baseline_hours'])
        self.assertEqual(iso(self.base+8*3600+20*60),payload['decision_cutoff'])

    def test_late_completed_hour_is_explicit_and_does_not_rewrite_settlement(self):
        opened=self.base+3600
        self.engine.process_until(opened+3600+120)
        ident='detector:0:AAAUSDT:'+str(int(opened))
        before=self.engine.db.execute('SELECT payload,hash FROM ledger WHERE id=?',(ident,)).fetchone()
        with self.engine.transaction(self.engine):
            self.engine._hour({'symbol':'AAAUSDT','opened':iso(opened),
                'received_at':iso(opened+3600+180),'close':'1','quote_volume':'30000'})
        after=self.engine.db.execute('SELECT payload,hash FROM ledger WHERE id=?',(ident,)).fetchone()
        self.assertEqual(tuple(before),tuple(after))
        rows=self.engine.db.execute("SELECT payload FROM ledger WHERE kind='LATE_COMPLETE_HOUR'").fetchall()
        self.assertEqual(1,len(rows))
        self.assertFalse(json.loads(rows[0][0])['prior_decisions_rewritten'])
        self.engine.verify_ledger()

    def test_warmup_known_after_an_earlier_cutoff_cannot_enter_that_view(self):
        opened=self.base-3600
        received=self.t0-10
        self.engine.enqueue('fixture-warmup',[{'kind':'hour_warmup','symbol':'AAAUSDT',
            'opened':iso(opened),'received_at':iso(received),'close':'1','quote_volume':'30000'}])
        self.engine.process_until(received-1)
        self.assertEqual(0,self.engine.db.execute('SELECT count(*) FROM hours').fetchone()[0])
        self.engine.process_until(received)
        row=self.engine.db.execute('SELECT available FROM hours').fetchone()
        self.assertEqual(received,row[0])

    def test_capacity_fixture_result_shape_matches_production_detector_payload(self):
        self._seed_hours()
        opened=self.base+4*3600
        with self.engine.transaction(self.engine):
            self.engine._evaluate(1,'AAAUSDT',opened,opened+3600+1)
        row=self.engine.db.execute('SELECT payload FROM ledger WHERE id=?',
            ('detector:1:AAAUSDT:'+str(int(opened)),)).fetchone()
        actual=json.loads(row[0])['result']
        source=evaluate_causal([1.0]*172,[30000.0]*172)
        expected={key:source[key] for key in ('status','raw_trigger','reason','features')}
        self.assertEqual(expected,actual)


if __name__=='__main__':unittest.main()
