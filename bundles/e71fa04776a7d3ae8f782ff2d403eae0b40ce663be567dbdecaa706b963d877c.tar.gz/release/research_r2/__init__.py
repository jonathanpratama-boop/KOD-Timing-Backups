"""Prospective R2 research; no orders, account APIs or paid inference."""
